
import React, { useState, useEffect, useMemo } from 'react';
import { 
  Search, 
  Plus, 
  MoreHorizontal, 
  CheckCircle2, 
  AlertOctagon, 
  Clock, 
  TrendingUp, 
  Users, 
  CalendarRange, 
  Filter, 
  RefreshCcw, 
  Ban, 
  Wallet, 
  Settings, 
  ArrowRight, 
  UserPlus, 
  Calendar, 
  XCircle, 
  History,
  Check,
  List,
  ChevronRight,
  Mail,
  Phone,
  ArrowRightLeft
} from 'lucide-react';
import { Subscription, Customer } from '../types';
import { supabase } from '../supabaseClient';
import SubscriptionForm from './SubscriptionForm';
import UserMenu from './UserMenu';

interface SubscriptionListProps {
  customers: Customer[];
  companyId?: string;
  toggleSidebar?: () => void;
  refreshTrigger?: number;
  onRefreshData?: () => void;
  portalUserIds: Set<string>;
}

const formatCurrency = (val: number) => val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const getSafeDateObj = (val: string) => {
    if (!val) return null;
    const cleanVal = val.split('T')[0];
    const parts = cleanVal.split('-');
    if (parts.length < 3) return null;
    
    const [y, m, d] = parts.map(Number);
    return new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
};

const parseSafeDate = (dateStr: string) => {
    if (!dateStr) return null;
    const cleanDate = dateStr.split('T')[0];
    const parts = cleanDate.split('-');
    if (parts.length < 3) return null;
    const [y, m, d] = parts.map(Number);
    return new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
};

const formatDate = (val: string) => {
    if (!val) return '-';
    const d = getSafeDateObj(val);
    if (!d) return '-';
    
    const day = d.getUTCDate().toString().padStart(2, '0');
    const months = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
    const month = months[d.getUTCMonth()];
    return `${day} de ${month}. de ${d.getUTCFullYear()}`;
};

const getDateBadge = (dateStr?: string) => {
    if (!dateStr) return { day: '--', month: '---' };
    const date = getSafeDateObj(dateStr);
    if (!date || isNaN(date.getTime())) return { day: '--', month: '---' };
    
    const day = date.getUTCDate().toString().padStart(2, '0');
    const months = ['JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN', 'JUL', 'AGO', 'SET', 'OUT', 'NOV', 'DEZ'];
    const month = months[date.getUTCMonth()];
    
    return { day, month };
};

const getStatusColor = (sub: Subscription & { _isGhost?: boolean }) => {
    if (sub._isGhost) return { bg: 'bg-amber-50', text: 'text-amber-700', label: 'Configurar', icon: Settings, border: 'border-amber-200' };
    if (sub.status === 'cancelled') return { bg: 'bg-gray-100', text: 'text-gray-500', label: 'Cancelado', icon: XCircle, border: 'border-gray-200' };

    if (!sub.end_date) return { bg: 'bg-gray-100', text: 'text-gray-600', label: 'Sem Data', icon: Settings, border: 'border-gray-200' };

    const today = new Date();
    today.setHours(0,0,0,0);
    
    const end = getSafeDateObj(sub.end_date);
    if (end) end.setHours(23, 59, 59);

    const isPaid = !!sub.payment_date;

    if (isPaid) return { bg: 'bg-emerald-100', text: 'text-emerald-700', label: 'Pago', icon: CheckCircle2, border: 'border-emerald-200' };
    if (end && today > end) return { bg: 'bg-rose-100', text: 'text-rose-700', label: 'Vencido', icon: AlertOctagon, border: 'border-rose-200' };
    return { bg: 'bg-indigo-50', text: 'text-indigo-700', label: 'Aguardando', icon: Clock, border: 'border-indigo-100' };
};

const SubscriptionList: React.FC<SubscriptionListProps> = ({ customers, companyId, toggleSidebar, refreshTrigger, onRefreshData, portalUserIds }) => {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'active' | 'overdue' | 'paid' | 'pending_setup' | 'cancelled'>('all');
  const [selectedMonth, setSelectedMonth] = useState('all'); 
  const [showHistory, setShowHistory] = useState(false); 
  
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingSubscription, setEditingSubscription] = useState<Subscription | null>(null);
  const [isRenewing, setIsRenewing] = useState(false);

  const months = [
      { value: '0', label: 'Janeiro' }, { value: '1', label: 'Fevereiro' },
      { value: '2', label: 'Março' }, { value: '3', label: 'Abril' },
      { value: '4', label: 'Maio' }, { value: '5', label: 'Junho' },
      { value: '6', label: 'Julho' }, { value: '7', label: 'Agosto' },
      { value: '8', label: 'Setembro' }, { value: '9', label: 'Outubro' },
      { value: '10', label: 'Novembro' }, { value: '11', label: 'Dezembro' },
  ];

  const fetchSubscriptions = async () => {
    if (!companyId) return;
    setLoading(true);
    
    const [subRes] = await Promise.all([
        supabase.from('subscriptions').select('*').eq('company_id', companyId).order('end_date', { ascending: true })
    ]);

    if (!subRes.error && subRes.data) {
      const enriched = subRes.data.map((sub: any) => {
        const customer = customers.find(c => c.id === sub.customer_id);
        return {
          ...sub,
          customer_name: customer?.name || 'Cliente Desconhecido',
          customer_fantasy: customer?.fantasyName, 
          customer_avatar: customer?.avatarText,
          customer_phone: customer?.phone,
          customer_email: customer?.email,
          customer_cpf: customer?.cpf,
          customer_cnpj: customer?.cnpj
        };
      });
      setSubscriptions(enriched);
    }

    setLoading(false);
  };

  useEffect(() => { 
      fetchSubscriptions(); 
  }, [customers, companyId, refreshTrigger]);

  const mergedSubscriptions = useMemo(() => {
      const realSubscriptionCustomerIds = new Set(subscriptions.map(s => s.customer_id));
      const pendingSetupCustomers = customers.filter(c => c.isSubscriber && !realSubscriptionCustomerIds.has(c.id));

      const ghostSubs = pendingSetupCustomers.map(c => {
          const regDate = c.createdAt || new Date().toISOString(); 
          return {
            id: `ghost-${c.id}`, 
            customer_id: c.id,
            customer_name: c.name,
            customer_fantasy: c.fantasyName,
            customer_avatar: c.avatarText,
            customer_phone: c.phone,
            customer_email: c.email,
            customer_cpf: c.cpf,
            customer_cnpj: c.cnpj,
            provider: 'Não Configurado',
            value: 0,
            frequency: 'Mensal',
            start_date: regDate,
            end_date: '', 
            status: 'active',
            _isGhost: true 
          } as unknown as Subscription & { _isGhost: boolean };
      });

      let allSubs = [...ghostSubs, ...subscriptions];

      if (!showHistory) {
          const subscriberFlagsMap = new Map(customers.map(c => [c.id, c.isSubscriber]));
          
          allSubs = allSubs.filter(sub => {
              if (sub.id.startsWith('ghost-')) return true;
              return subscriberFlagsMap.get(sub.customer_id) === true;
          });

          const groupedMap = new Map<string, any[]>();
          allSubs.sort((a, b) => {
              const dateA = new Date(a.end_date || '1970-01-01').getTime();
              const dateB = new Date(b.end_date || '1970-01-01').getTime();
              return dateA - dateB; 
          });
          
          allSubs.forEach((sub: any) => {
              const uniqueKey = `${sub.customer_id}-${(sub.provider || 'default').trim().toLowerCase()}`;
              if (!groupedMap.has(uniqueKey)) groupedMap.set(uniqueKey, []);
              groupedMap.get(uniqueKey)?.push(sub);
          });
          
          const result: any[] = [];
          groupedMap.forEach((group) => {
              const latest = group[group.length - 1];
              const lastPaid = [...group].reverse().find(s => !!s.payment_date);
              result.push({
                  ...latest,
                  _lastPaidDate: lastPaid ? lastPaid.payment_date : null
              });
          });
          return result;
      }
      
      return allSubs;
  }, [customers, subscriptions, showHistory]);

  const metrics = useMemo(() => {
      const validSubs = mergedSubscriptions.filter((s: any) => !s._isGhost && s.status !== 'cancelled');
      const totalMRR = validSubs.reduce((acc: number, sub: any) => acc + (sub.value || 0), 0); 
      const activeCount = validSubs.length; 
      const paidCount = validSubs.filter((s: any) => !!s.payment_date).length;
      
      const today = new Date(); today.setHours(0,0,0,0);
      const overdueCount = validSubs.filter((s: any) => {
          if (s.payment_date || !s.end_date) return false;
          const end = getSafeDateObj(s.end_date);
          if (end) end.setHours(23, 59, 59);
          return end && end < today;
      }).length;

      const pendingSetupCount = mergedSubscriptions.filter((s: any) => s._isGhost).length;
      return { totalMRR, activeCount, paidCount, overdueCount, pendingSetupCount };
  }, [mergedSubscriptions]);

  const filteredSubscriptions = useMemo(() => {
    const query = searchQuery.toLowerCase().trim();
    const queryDigits = searchQuery.replace(/\D/g, '');

    return mergedSubscriptions.filter((sub: any) => {
      const matchesSearch = !query || (
        (sub.customer_name?.toLowerCase().includes(query)) || 
        (sub.customer_fantasy?.toLowerCase().includes(query)) ||
        (sub.provider?.toLowerCase().includes(query)) ||
        (queryDigits && sub.customer_cpf?.replace(/\D/g, '').includes(queryDigits)) ||
        (queryDigits && sub.customer_cnpj?.replace(/\D/g, '').includes(queryDigits))
      );
      
      if (!matchesSearch) return false;

      if (selectedMonth !== 'all') {
          if (!sub.end_date) return false;
          const date = getSafeDateObj(sub.end_date);
          if (date && date.getUTCMonth().toString() !== selectedMonth) return false;
      }

      if (activeTab === 'cancelled') return sub.status === 'cancelled';
      if (activeTab !== 'all' && sub.status === 'cancelled') return false;

      const status = getStatusColor(sub);
      if (activeTab === 'active') return status.label === 'Aguardando' || status.label === 'Pago' || status.label === 'Vencido';
      if (activeTab === 'overdue') return status.label === 'Vencido';
      if (activeTab === 'paid') return status.label === 'Pago';
      if (activeTab === 'pending_setup') return sub._isGhost;

      return true;
    }).sort((a: any, b: any) => {
        const statusA = getStatusColor(a).label;
        const statusB = getStatusColor(b).label;
        const priority = { 'Vencido': 1, 'Aguardando': 2, 'Configurar': 3, 'Pago': 4, 'Cancelado': 5, 'Sem Data': 6 };
        const scoreA = priority[statusA as keyof typeof priority] || 99;
        const scoreB = priority[statusB as keyof typeof priority] || 99;
        if (scoreA !== scoreB) return scoreA - scoreB;
        const dateA = new Date(a.end_date || '2099-01-01').getTime();
        const dateB = new Date(b.end_date || '2099-01-01').getTime();
        return dateA - dateB;
    });
  }, [mergedSubscriptions, searchQuery, activeTab, selectedMonth]);

  const handleSave = async (subData: Partial<Subscription>) => {
      try {
          const { id, ...data } = subData;
          const payload = { ...data, company_id: companyId };
          
          const targetId = id || (editingSubscription?.id && !editingSubscription.id.startsWith('ghost-') ? editingSubscription.id : null);

          if (targetId && !isRenewing) {
             const { error } = await supabase.from('subscriptions').update(payload).eq('id', targetId);
             if (error) throw error;
          } else {
             const { error } = await supabase.from('subscriptions').insert([payload]);
             if (error) throw error;
          }
          await fetchSubscriptions();
          onRefreshData?.();
      } catch (error: any) {
          console.error("Erro ao salvar", error);
          alert(`Erro ao salvar assinatura: ${error.message || 'Verifique sua conexão'}`);
      }
  };

  const handleDelete = async (id: string) => {
      if (id.startsWith('ghost-')) {
          const customerId = id.replace('ghost-', '');
          if (window.confirm("Remover status de assinante deste cliente?")) {
              await supabase.from('customers').update({ is_subscriber: false }).eq('id', customerId);
              window.location.reload(); 
          }
          return;
      }
      if (window.confirm("Deseja excluir permanentemente este registro?")) {
          await supabase.from('subscriptions').delete().eq('id', id);
          fetchSubscriptions();
          onRefreshData?.();
      }
  };

  const handleRenovarClick = (sub: Subscription) => {
      const oldEndStr = sub.end_date?.split('T')[0];
      if (!oldEndStr) return;
      
      const newStart = parseSafeDate(oldEndStr)!;
      const newEnd = new Date(newStart);
      
      if (sub.frequency === 'Anual') newEnd.setUTCFullYear(newEnd.getUTCFullYear() + 1);
      else newEnd.setUTCMonth(newEnd.getUTCMonth() + 1);
      
      setEditingSubscription({ 
          ...sub, 
          id: '', 
          start_date: oldEndStr, 
          end_date: newEnd.toISOString().split('T')[0], 
          payment_date: null, 
          commission_payment_date: null, 
          status: 'active' 
      }); 
      setIsRenewing(true); 
      setIsFormOpen(true);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#EEF2F6] dark:bg-[#1a1b2e] overflow-hidden relative transition-colors">
      
      {/* ESTILIZAÇÃO DA SCROLLBAR HORIZONTAL OTIMIZADA */}
      <style>{`
        .horizontal-scroll-enhanced::-webkit-scrollbar {
          height: 12px; /* Thicker for easier mouse interaction */
        }
        .horizontal-scroll-enhanced::-webkit-scrollbar-track {
          background: #f1f5f9;
          border-radius: 10px;
        }
        .dark .horizontal-scroll-enhanced::-webkit-scrollbar-track {
          background: #2a2b42;
        }
        .horizontal-scroll-enhanced::-webkit-scrollbar-thumb {
          background: #cbd5e1;
          border-radius: 10px;
          border: 3px solid transparent;
          background-clip: content-box;
          transition: background 0.3s;
        }
        .horizontal-scroll-enhanced::-webkit-scrollbar-thumb:hover {
          background: #94a3b8;
          border: 2px solid transparent;
          background-clip: content-box;
        }
        .dark .horizontal-scroll-enhanced::-webkit-scrollbar-thumb {
          background: #475569;
          border: 3px solid transparent;
          background-clip: content-box;
        }
        .dark .horizontal-scroll-enhanced::-webkit-scrollbar-thumb:hover {
          background: #64748b;
          border: 2px solid transparent;
          background-clip: content-box;
        }
      `}</style>

      <header className="bg-[#EEF2F6] dark:bg-[#23243a] border-b border-gray-200 dark:border-white/5 h-[80px] px-4 sm:px-8 flex justify-between items-center shrink-0 transition-colors">
          <div className="flex items-center gap-4">
              <button 
                  onClick={() => toggleSidebar?.()} 
                  className="lg:hidden p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-lg transition-colors"
              >
                  <List size={24} />
              </button>
              <div>
                  <h1 className="text-[23px] font-mono font-black text-gray-900 dark:text-white tracking-tighter uppercase leading-none italic">Assinaturas</h1>
                  <p className="text-[10px] text-gray-400 dark:text-gray-500 uppercase tracking-[0.25em] font-bold mt-1.5">Gestão de Contratos e Receita Recorrente</p>
              </div>
          </div>
          <div className="flex items-center gap-4">
              <UserMenu />
          </div>
      </header>

      <main className="flex-1 flex flex-col overflow-hidden">
          
          {/* TOPO CONGELADO: MÉTRICAS E FILTROS */}
          <div className="shrink-0 p-4 sm:p-8 pb-4 space-y-6 sm:space-y-8 bg-[#EEF2F6] dark:bg-[#1a1b2e] z-10">
              <div className="flex flex-col xl:flex-row gap-6">
                  <div className="flex-1 grid grid-cols-2 md:grid-cols-3 gap-3 sm:gap-6">
                      <div className="bg-white dark:bg-[#23243a] p-4 sm:p-5 rounded-2xl border border-gray-100 dark:border-white/5 shadow-sm flex items-start justify-between group transition-all">
                          <div className="relative z-10">
                              <p className="text-gray-500 dark:text-gray-400 text-[10px] sm:text-xs font-bold uppercase tracking-wider mb-1">Total Ativos</p>
                              <h3 className="text-xl sm:text-3xl font-extrabold text-gray-800 dark:text-white">{metrics.activeCount}</h3>
                              <p className="hidden sm:flex text-xs text-emerald-600 dark:text-emerald-400 font-bold mt-2 items-center gap-1"><TrendingUp size={12} /> {metrics.paidCount} Em dia</p>
                          </div>
                          <div className="p-2 sm:p-3 bg-emerald-50 dark:bg-emerald-500/10 rounded-xl text-emerald-600 dark:text-emerald-400 group-hover:scale-110 transition-transform"><Users size={20} sm:size={24} /></div>
                      </div>

                      <div className="bg-white dark:bg-[#23243a] p-4 sm:p-5 rounded-2xl border border-gray-100 dark:border-white/5 shadow-sm flex items-start justify-between group transition-all">
                          <div className="relative z-10">
                              <p className="text-gray-500 dark:text-gray-400 text-[10px] sm:text-xs font-bold uppercase tracking-wider mb-1">Pendências</p>
                              <h3 className="text-xl sm:text-3xl font-extrabold text-rose-600 dark:text-rose-400">{metrics.overdueCount + metrics.pendingSetupCount}</h3>
                              <p className="hidden sm:flex text-xs text-rose-400 font-bold mt-2 items-center gap-1"><AlertOctagon size={12} /> {metrics.overdueCount} Vencidos</p>
                          </div>
                          <div className="p-2 sm:p-3 bg-rose-50 dark:bg-rose-500/10 rounded-xl text-rose-600 dark:text-rose-400 group-hover:scale-110 transition-transform"><Ban size={20} sm:size={24} /></div>
                      </div>

                      <div className="col-span-2 md:col-span-1 bg-gradient-to-br from-indigo-600 to-violet-600 p-4 sm:p-5 rounded-2xl shadow-lg shadow-indigo-200 dark:shadow-none text-white flex items-center justify-between">
                          <div className="relative z-10">
                              <p className="text-indigo-100 text-[10px] sm:text-xs font-bold uppercase tracking-wider mb-1">Valor Contratos</p>
                              <h3 className="text-xl sm:text-3xl font-extrabold">{formatCurrency(metrics.totalMRR)}</h3>
                              <p className="hidden sm:block text-xs text-indigo-100 mt-2 opacity-80">Faturamento total ativo</p>
                          </div>
                          <div className="p-3 bg-white/20 backdrop-blur-sm rounded-xl text-white"><Wallet size={24} /></div>
                      </div>
                  </div>

                  <div className="hidden xl:flex items-center gap-6 bg-white dark:bg-[#23243a] px-8 py-2 rounded-2xl border border-gray-100 dark:border-white/5 shadow-sm transition-all">
                      <div className="text-right">
                          <span className="block text-[9px] uppercase font-bold text-gray-400 dark:text-gray-500 tracking-widest">Receita Prevista</span>
                          <span className="block text-lg font-black text-gray-800 dark:text-white leading-none mt-1">{formatCurrency(metrics.totalMRR)}</span>
                      </div>
                      <div className="h-10 w-px bg-gray-100 dark:bg-white/5"></div>
                      <div className="text-right">
                          <span className="block text-[9px] uppercase font-bold text-gray-400 dark:text-gray-500 tracking-widest">Status Geral</span>
                          <div className="flex gap-2 mt-1">
                              {metrics.overdueCount > 0 ? <span className="text-xs font-black text-rose-600 dark:text-rose-400">{metrics.overdueCount} VENCIDOS</span> : <span className="text-xs font-black text-emerald-600 dark:text-emerald-400">EM DIA</span>}
                          </div>
                      </div>
                  </div>
              </div>

              <div className="flex flex-col lg:flex-row justify-between items-center gap-4">
                  <div className="flex flex-col sm:flex-row items-center gap-3 w-full lg:w-auto">
                      <div className="relative w-full sm:w-80 group">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <Search className="h-4 w-4 text-gray-400 group-focus-within:text-indigo-500 transition-colors" />
                          </div>
                          <input 
                            type="text" 
                            className="block w-full pl-10 pr-3 py-3 border border-gray-200 dark:border-white/5 rounded-xl bg-white dark:bg-[#23243a] dark:text-white placeholder-gray-400 focus:outline-none focus:border-indigo-500 transition-all shadow-sm text-sm" 
                            placeholder="Buscar nome, CPF ou CNPJ..." 
                            value={searchQuery} 
                            onChange={(e) => setSearchQuery(e.target.value)} 
                          />
                      </div>
                      <div className="flex items-center gap-2 w-full sm:w-auto">
                        <button 
                            onClick={() => setShowHistory(!showHistory)} 
                            className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-xs font-bold border transition-all ${showHistory ? 'bg-indigo-50 border-indigo-200 text-indigo-600 dark:bg-indigo-500/10 dark:border-indigo-500/20' : 'bg-white dark:bg-[#23243a] border-gray-200 dark:border-white/5 text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-white/10'}`}
                        >
                            <History size={16} /> 
                            <span className="whitespace-nowrap">{showHistory ? 'Ocultar Histórico' : 'Ver Histórico'}</span>
                        </button>
                        <div className="relative flex-1 sm:flex-none min-w-[140px] sm:min-w-[160px]">
                            <select 
                                value={selectedMonth} 
                                onChange={(e) => setSelectedMonth(e.target.value)} 
                                className="appearance-none block w-full pl-4 pr-10 py-3 border border-gray-200 dark:border-white/5 rounded-xl bg-white dark:bg-[#23243a] text-gray-700 dark:text-gray-300 font-bold text-sm focus:outline-none focus:border-indigo-500 shadow-sm cursor-pointer"
                            >
                                <option value="all">Todos os Meses</option>
                                {months.map(m => (<option key={m.value} value={m.value}>{m.label}</option>))}
                            </select>
                            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-gray-500">
                                <Calendar size={16} />
                            </div>
                        </div>
                      </div>
                  </div>
                  
                  <div className="flex items-center gap-3 w-full lg:w-auto">
                      <div className="flex bg-white dark:bg-[#23243a] p-1 rounded-xl shadow-sm border border-gray-100 dark:border-white/5 overflow-x-auto no-scrollbar flex-1 lg:flex-none">
                          {[{ id: 'all', label: 'Todos' }, { id: 'active', label: 'Em Aberto' }, { id: 'overdue', label: 'Vencidos' }, { id: 'paid', label: 'Pagos' }].map(tab => (
                              <button 
                                key={tab.id} 
                                onClick={() => setActiveTab(tab.id as any)} 
                                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex-1 lg:flex-none ${activeTab === tab.id ? 'bg-gray-100 dark:bg-white/10 text-gray-900 dark:text-white shadow-sm' : 'text-gray-400 hover:text-gray-700 dark:hover:text-white'}`}
                              >
                                {tab.label}
                              </button>
                          ))}
                      </div>

                      <button 
                          onClick={() => { setEditingSubscription(null); setIsRenewing(false); setIsFormOpen(true); }} 
                          className="bg-indigo-600 hover:bg-indigo-700 text-white font-black py-3 px-6 rounded-xl shadow-lg shadow-indigo-500/20 flex items-center gap-2 transition-all transform active:scale-95 text-xs uppercase tracking-widest shrink-0"
                      >
                          <Plus size={20} strokeWidth={3} /> Nova Assinatura
                      </button>
                  </div>
              </div>
          </div>

          {/* TABELA OTIMIZADA COM ROLAGEM HORIZONTAL E COLUNAS FIXAS */}
          <div className="flex-1 overflow-hidden px-4 sm:px-8 pb-10">
              <div className="h-full bg-white dark:bg-[#23243a] rounded-2xl shadow-sm border border-gray-100 dark:border-white/5 flex flex-col transition-colors relative">
                  
                  {/* SINALIZADORES DE ROLAGEM (SHADOW OVERLAYS) */}
                  <div className="absolute left-16 top-0 bottom-0 w-8 pointer-events-none bg-gradient-to-r from-white dark:from-[#23243a] to-transparent z-20 opacity-0 group-scroll-active:opacity-100 transition-opacity"></div>
                  <div className="absolute right-32 top-0 bottom-0 w-8 pointer-events-none bg-gradient-to-l from-white dark:from-[#23243a] to-transparent z-20 opacity-0 group-scroll-active:opacity-100 transition-opacity"></div>

                  <div className="flex-1 overflow-x-auto overflow-y-auto custom-scrollbar horizontal-scroll-enhanced relative">
                      <table className="min-w-[1200px] w-full border-separate border-spacing-0">
                          <thead>
                              <tr className="bg-gray-50/50 dark:bg-white/5">
                                  {/* STICKY LEFT COLUMN */}
                                  <th className="sticky left-0 z-30 bg-gray-50 dark:bg-[#2a2b42] px-6 py-4 text-center text-[10px] font-bold text-gray-400 uppercase tracking-widest w-24 border-b border-gray-100 dark:border-white/5">Vencimento</th>
                                  
                                  <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-400 uppercase tracking-widest border-b border-gray-100 dark:border-white/5">Dados do Assinante</th>
                                  <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-400 uppercase tracking-widest border-b border-gray-100 dark:border-white/5">Plano & Progresso</th>
                                  <th className="px-6 py-4 text-center text-[10px] font-bold text-gray-400 uppercase tracking-widest border-b border-gray-100 dark:border-white/5">Status</th>
                                  <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-400 uppercase tracking-widest border-b border-gray-100 dark:border-white/5">Valor da Fatura</th>
                                  <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-400 uppercase tracking-widest border-b border-gray-100 dark:border-white/5">Origem / Indicação</th>
                                  
                                  {/* STICKY RIGHT COLUMN */}
                                  <th className="sticky right-0 z-30 bg-gray-50 dark:bg-[#2a2b42] px-6 py-4 text-right text-[10px] font-bold text-gray-400 uppercase tracking-widest border-b border-gray-100 dark:border-white/5">Ações</th>
                              </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-50 dark:divide-white/5">
                              {loading ? (
                                  <tr><td colSpan={7} className="p-10 text-center text-gray-400">Carregando dados...</td></tr>
                              ) : filteredSubscriptions.length === 0 ? (
                                  <tr><td colSpan={7} className="p-16 text-center"><div className="flex flex-col items-center justify-center text-gray-300"><Filter size={48} className="mb-4 opacity-20" /><p className="text-sm font-medium text-gray-500">Nenhuma assinatura encontrada.</p></div></td></tr>
                              ) : (
                                  filteredSubscriptions.map((sub: any) => {
                                      const statusColor = getStatusColor(sub);
                                      const dateBadge = getDateBadge(sub.end_date);
                                      const isCancelled = sub.status === 'cancelled';
                                      const hasPortal = portalUserIds.has(sub.customer_id);
                                      
                                      let progress = 0;
                                      if (sub.start_date && sub.end_date) {
                                          const start = parseSafeDate(sub.start_date)?.getTime() || 0;
                                          const end = parseSafeDate(sub.end_date)?.getTime() || 0;
                                          const now = new Date().getTime();
                                          if (end > start) progress = Math.min(Math.max(((now - start) / (end - start)) * 100, 0), 100);
                                      }

                                      return (
                                          <tr key={sub.id} className={`group transition-colors cursor-default ${sub._isGhost ? 'bg-amber-50/10 hover:bg-amber-50/20' : isCancelled ? 'opacity-70 grayscale' : 'hover:bg-gray-50/80 dark:hover:bg-white/5'}`}>
                                              {/* STICKY LEFT TD */}
                                              <td className="sticky left-0 z-20 bg-white dark:bg-[#23243a] group-hover:bg-gray-50 dark:group-hover:bg-white/10 px-6 py-4 whitespace-nowrap transition-colors">
                                                  <div className="flex items-center gap-3 justify-center">
                                                      {hasPortal && <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)] animate-pulse shrink-0" title="Possui conta no portal" />}
                                                      <div className={`flex flex-col items-center justify-center rounded-xl w-14 h-14 border shadow-sm transition-colors ${sub._isGhost ? 'bg-amber-50 text-amber-600 border-amber-100' : isCancelled ? 'bg-gray-100 text-gray-400 border-gray-200' : statusColor.label === 'Vencido' ? 'bg-rose-50 text-rose-700 border-rose-100' : statusColor.label === 'Pago' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-indigo-50 text-indigo-700 border-indigo-100'}`}>
                                                          <span className="text-xl font-extrabold leading-none tracking-tight">{dateBadge.day}</span>
                                                          <span className="text-[10px] font-bold leading-none mt-1 uppercase tracking-wide opacity-80">{dateBadge.month}</span>
                                                      </div>
                                                  </div>
                                              </td>

                                              {/* MERGED CLIENT INFO */}
                                              <td className="px-6 py-4">
                                                  <div className="flex items-center gap-4 min-w-[280px]">
                                                      <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-white/5 flex items-center justify-center text-slate-400 font-black text-xs uppercase border dark:border-white/10 shrink-0">
                                                          {sub.customer_avatar || sub.customer_name.substring(0, 2).toUpperCase()}
                                                      </div>
                                                      <div className="min-w-0 flex-1">
                                                          <div className={`text-sm font-black uppercase truncate leading-tight ${isCancelled ? 'text-gray-500 line-through' : 'text-gray-800 dark:text-white'}`}>
                                                              {sub.customer_fantasy || sub.customer_name}
                                                          </div>
                                                          {sub.customer_fantasy && <p className="uppercase text-[9px] text-gray-400 font-bold truncate mt-0.5">{sub.customer_name}</p>}
                                                          <div className="flex items-center gap-3 mt-1.5 opacity-60 group-hover:opacity-100 transition-opacity">
                                                              {sub.customer_phone && <span className="flex items-center gap-1 text-[10px] font-bold text-gray-500 dark:text-gray-400"><Phone size={10}/> {sub.customer_phone}</span>}
                                                              {sub.customer_email && <span className="flex items-center gap-1 text-[10px] font-bold text-gray-500 dark:text-gray-400"><Mail size={10}/> {sub.customer_email.split('@')[0]}</span>}
                                                          </div>
                                                      </div>
                                                  </div>
                                              </td>

                                              {/* MERGED PLAN & CYCLE */}
                                              <td className="px-6 py-4">
                                                  <div className="min-w-[180px]">
                                                      {sub._isGhost ? (
                                                          <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest italic">Aguardando definição</span>
                                                      ) : (
                                                          <div className="space-y-2">
                                                              <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-500/20 uppercase tracking-wide">
                                                                  {sub.provider}
                                                              </span>
                                                              <div className="flex flex-col gap-1">
                                                                  <div className="flex justify-between text-[8px] text-gray-400 font-black uppercase">
                                                                      <span>Início: {formatDate(sub.start_date)}</span>
                                                                      <span>{progress.toFixed(0)}%</span>
                                                                  </div>
                                                                  <div className="w-full bg-gray-100 dark:bg-white/5 rounded-full h-1 overflow-hidden">
                                                                      <div className={`h-full transition-all duration-1000 ${isCancelled ? 'bg-gray-300' : statusColor.label === 'Vencido' ? 'bg-rose-500' : statusColor.label === 'Pago' ? 'bg-emerald-500' : 'bg-indigo-500'}`} style={{ width: `${isCancelled ? 100 : progress}%` }}></div>
                                                                  </div>
                                                              </div>
                                                          </div>
                                                      )}
                                                  </div>
                                              </td>

                                              <td className="px-6 py-4 whitespace-nowrap text-center">
                                                  <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold border uppercase tracking-widest ${statusColor.bg} ${statusColor.text} ${statusColor.border}`}>
                                                      <statusColor.icon size={12} strokeWidth={2.5} /> {statusColor.label}
                                                  </span>
                                              </td>

                                              <td className="px-6 py-4 whitespace-nowrap">
                                                  {sub._isGhost ? <span className="text-gray-300 font-bold">-</span> : 
                                                  <div className="flex flex-col">
                                                      <div className="text-sm font-black text-gray-900 dark:text-white tabular-nums tracking-tighter">{formatCurrency(sub.value)}</div>
                                                      {sub.payment_date ? (
                                                          <div className="text-[9px] text-emerald-600 dark:text-emerald-400 font-bold mt-0.5 flex items-center gap-1 uppercase tracking-tighter">
                                                              <Check size={10} strokeWidth={3} /> Pago em {formatDate(sub.payment_date).split(' de ')[0]}
                                                          </div>
                                                      ) : sub._lastPaidDate ? (
                                                          <div className="text-[9px] text-slate-400 dark:text-gray-500 font-medium mt-0.5 flex items-center gap-1 bg-slate-100 dark:bg-white/5 px-1.5 py-0.5 rounded w-fit" title="Fatura anterior foi paga">
                                                              <Check size={10} /> Ant: {formatDate(sub._lastPaidDate).split(' de ')[0]}
                                                          </div>
                                                      ) : null}
                                                  </div>}
                                              </td>

                                              <td className="px-6 py-4 whitespace-nowrap">
                                                  {sub.referral ? (
                                                      <div className="flex flex-col">
                                                          <span className="text-xs font-black text-gray-700 dark:text-gray-300 flex items-center gap-1 uppercase tracking-tighter truncate max-w-[120px]">
                                                              <UserPlus size={12} className="text-indigo-400"/> {sub.referral}
                                                          </span>
                                                          <div className="flex items-center gap-2 mt-1">
                                                              <span className="text-[10px] font-bold text-gray-500">{formatCurrency(sub.commission_value || 0)}</span>
                                                              <span className={`text-[8px] px-1 py-0.5 rounded border font-black uppercase tracking-widest ${sub.commission_payment_date ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-amber-50 text-amber-600 border-amber-100'}`}>
                                                                  {sub.commission_payment_date ? 'Comissão OK' : 'Pend. Comissão'}
                                                              </span>
                                                          </div>
                                                      </div>
                                                  ) : <span className="text-gray-300 font-bold">-</span>}
                                              </td>

                                              {/* STICKY RIGHT TD */}
                                              <td className="sticky right-0 z-20 bg-white dark:bg-[#23243a] group-hover:bg-gray-50 dark:group-hover:bg-white/10 px-6 py-4 whitespace-nowrap text-right transition-colors shadow-[-10px_0_15px_rgba(0,0,0,0.02)]">
                                                  <div className="flex justify-end gap-2">
                                                      {sub._isGhost ? (
                                                          <button onClick={() => { setEditingSubscription({ ...sub, id: '', start_date: sub.start_date, value: 0, payment_date: '', end_date: '' }); setIsRenewing(false); setIsFormOpen(true); }} className="px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all flex items-center gap-2 text-[10px] font-black uppercase tracking-widest shadow-lg shadow-indigo-500/20 active:scale-95">
                                                              Configurar <ChevronRight size={14} strokeWidth={3} />
                                                          </button>
                                                      ) : (
                                                          <div className="flex gap-2">
                                                              {!isCancelled && (
                                                                  <button onClick={() => handleRenovarClick(sub)} className="p-2.5 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-500/10 rounded-xl transition-all" title="Renovar Ciclo">
                                                                      <RefreshCcw size={20} strokeWidth={2.5} />
                                                                  </button>
                                                              )}
                                                              <button onClick={() => { setEditingSubscription(sub); setIsRenewing(false); setIsFormOpen(true); }} className="p-2.5 text-gray-400 dark:text-gray-500 hover:text-gray-800 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-white/10 rounded-xl transition-all">
                                                                  <MoreHorizontal size={20} />
                                                              </button>
                                                          </div>
                                                      )}
                                                  </div>
                                              </td>
                                          </tr>
                                      );
                                  })
                              )}
                          </tbody>
                      </table>
                  </div>
              </div>
              
              <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4 px-2">
                  <div className="flex items-center gap-3 text-[10px] text-gray-400 dark:text-gray-600 font-black uppercase tracking-[0.3em]">
                      <ArrowRightLeft size={14} /> Deslize para ver mais colunas
                  </div>
                  <div className="text-[10px] text-gray-400 dark:text-gray-600 font-black uppercase tracking-[0.3em]">
                      Exibindo {filteredSubscriptions.length} registros no período
                  </div>
              </div>
          </div>
      </main>

      <SubscriptionForm 
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        customers={customers}
        onSave={handleSave}
        initialData={editingSubscription}
        isRenewing={isRenewing}
        companyId={companyId}
        onDelete={editingSubscription && editingSubscription.id && !editingSubscription.id.startsWith('ghost-') && !isRenewing ? () => handleDelete(editingSubscription.id) : undefined}
      />
    </div>
  );
};

export default SubscriptionList;
