
import React, { useState, useMemo } from 'react';
import { 
  Users, Search, Star, DollarSign, TrendingUp, ChevronRight, 
  History, Calendar, CheckCircle2, Clock, MessageCircle, Mail,
  List, Filter, MoreHorizontal, ArrowUpRight, Award, Wallet,
  Check, X
} from 'lucide-react';
import { Customer, Subscription } from '../types';
import UserMenu from './UserMenu';
import PartnerDetailPanel from './PartnerDetailPanel';

interface PartnersScreenProps {
  customers: Customer[];
  subscriptions: Subscription[];
  toggleSidebar: () => void;
  companyId: string;
  onRefreshData: () => void;
  portalUserIds: Set<string>;
}

const formatCurrency = (val: number) => val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const PartnersScreen: React.FC<PartnersScreenProps> = ({ customers, subscriptions, toggleSidebar, companyId, onRefreshData, portalUserIds }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPartner, setSelectedPartner] = useState<Customer | null>(null);

  // Filtra apenas clientes marcados como parceiros
  const partners = useMemo(() => {
    return customers.filter(c => c.isPartner);
  }, [customers]);

  // Calcula estatísticas globais e por parceiro
  const partnerMetrics = useMemo(() => {
    const list = partners.map(p => {
        // Encontra indicações vinculadas a este parceiro pelo ID ou Nome (compatibilidade)
        const referrals = subscriptions.filter(s => 
            s.referral === p.id || (s.referral && s.referral.trim().toUpperCase() === p.name.trim().toUpperCase())
        );

        const totalCommissions = referrals.reduce((acc, curr) => acc + (curr.commission_value || 0), 0);
        const paidCommissions = referrals.filter(s => !!s.commission_payment_date).reduce((acc, curr) => acc + (curr.commission_value || 0), 0);
        const pendingCommissions = totalCommissions - paidCommissions;

        return {
            ...p,
            referralCount: referrals.length,
            totalCommissions,
            paidCommissions,
            pendingCommissions,
            activeReferrals: referrals.filter(s => s.status === 'active').length
        };
    });

    return list.filter(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (p.cpf || '').includes(searchQuery) ||
        (p.cnpj || '').includes(searchQuery)
    ).sort((a, b) => b.totalCommissions - a.totalCommissions);
  }, [partners, subscriptions, searchQuery]);

  const globalStats = useMemo(() => {
      const totalCommissions = subscriptions.reduce((acc, curr) => acc + (curr.commission_value || 0), 0);
      const pendingCount = subscriptions.filter(s => s.referral && !s.commission_payment_date).length;
      return {
          totalPartners: partners.length,
          totalReferrals: subscriptions.filter(s => !!s.referral).length,
          totalPaid: subscriptions.filter(s => s.referral && !!s.commission_payment_date).reduce((acc, curr) => acc + (curr.commission_value || 0), 0),
          totalPending: subscriptions.filter(s => s.referral && !s.commission_payment_date).reduce((acc, curr) => acc + (curr.commission_value || 0), 0),
          pendingCount
      };
  }, [partners, subscriptions]);

  if (selectedPartner) {
      return (
          <PartnerDetailPanel 
            partner={selectedPartner} 
            subscriptions={subscriptions.filter(s => 
              s.referral === selectedPartner.id || 
              (s.referral && s.referral.trim().toUpperCase() === selectedPartner.name.trim().toUpperCase())
            )}
            customers={customers}
            onBack={() => setSelectedPartner(null)}
            onRefresh={onRefreshData}
            portalUserIds={portalUserIds}
          />
      );
  }

  return (
    <div className="flex-1 flex flex-col h-full bg-[#F3F6F9] dark:bg-[#1a1b2e] overflow-hidden transition-colors">
      <header className="bg-white dark:bg-[#23243a] h-[90px] px-4 lg:px-10 flex justify-between items-center shrink-0 border-b border-gray-100 dark:border-white/5 sticky top-0 z-50 transition-colors">
          <div className="flex items-center gap-4">
              <button onClick={toggleSidebar} className="lg:hidden p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-xl transition-colors">
                  <List size={26} />
              </button>
              <div>
                  <h1 className="text-[23px] font-mono font-black text-gray-900 dark:text-white tracking-tighter uppercase leading-none italic">
                    <span className="hidden sm:inline">Ecosystem </span>Parceiros
                  </h1>
                  <p className="text-[10px] text-gray-400 font-black uppercase tracking-[0.3em] mt-1 hidden sm:block">Growth & Revenue Share</p>
              </div>
          </div>
          <UserMenu />
      </header>

      <div className="flex-1 overflow-y-auto px-8 pb-40 custom-scrollbar">
          <div className="max-w-7xl mx-auto space-y-10">
              
              {/* KPIS DE PARCERIA */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
                  <div className="bg-white dark:bg-[#23243a] p-5 sm:p-6 rounded-[1.5rem] sm:rounded-[2rem] shadow-sm border border-slate-100 dark:border-white/5 flex items-center gap-4 sm:gap-5 transition-all hover:shadow-md">
                      <div className="w-12 h-12 sm:w-14 sm:h-14 bg-amber-50 dark:bg-amber-500/10 rounded-2xl flex items-center justify-center text-amber-500 shadow-inner shrink-0"><Award size={24} className="sm:w-7 sm:h-7" /></div>
                      <div className="min-w-0">
                          <p className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5 sm:mb-1 truncate">Parceiros Ativos</p>
                          <h3 className="text-xl sm:text-2xl font-black text-slate-800 dark:text-white truncate">{globalStats.totalPartners}</h3>
                      </div>
                  </div>
                  <div className="bg-white dark:bg-[#23243a] p-5 sm:p-6 rounded-[1.5rem] sm:rounded-[2rem] shadow-sm border border-slate-100 dark:border-white/5 flex items-center gap-4 sm:gap-5 transition-all hover:shadow-md">
                      <div className="w-12 h-12 sm:w-14 sm:h-14 bg-indigo-50 dark:bg-indigo-500/10 rounded-2xl flex items-center justify-center text-indigo-500 shadow-inner shrink-0"><TrendingUp size={24} className="sm:w-7 sm:h-7" /></div>
                      <div className="min-w-0">
                          <p className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5 sm:mb-1 truncate">Total de Indicações</p>
                          <h3 className="text-xl sm:text-2xl font-black text-slate-800 dark:text-white truncate">{globalStats.totalReferrals}</h3>
                      </div>
                  </div>
                  <div className="bg-[#1e293b] p-5 sm:p-6 rounded-[1.5rem] sm:rounded-[2rem] shadow-xl text-white flex items-center gap-4 sm:gap-5 relative overflow-hidden">
                      <div className="relative z-10 w-12 h-12 sm:w-14 sm:h-14 bg-white/10 rounded-2xl flex items-center justify-center text-emerald-400 shrink-0"><DollarSign size={24} className="sm:w-7 sm:h-7" /></div>
                      <div className="relative z-10 min-w-0">
                          <p className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5 sm:mb-1 truncate">Comissões Pagas</p>
                          <h3 className="text-xl sm:text-2xl font-black text-white tabular-nums truncate">{formatCurrency(globalStats.totalPaid)}</h3>
                      </div>
                      <CheckCircle2 className="absolute -bottom-4 -right-4 w-24 h-24 opacity-5" />
                  </div>
                  <div className="bg-white dark:bg-[#23243a] p-5 sm:p-6 rounded-[1.5rem] sm:rounded-[2rem] shadow-sm border border-slate-100 dark:border-white/5 flex items-center justify-between group transition-all">
                      <div className="flex items-center gap-4 sm:gap-5 min-w-0">
                        <div className="w-12 h-12 sm:w-14 sm:h-14 bg-rose-50 dark:bg-rose-500/10 rounded-2xl flex items-center justify-center text-rose-500 shadow-inner shrink-0"><Clock size={24} className="sm:w-7 sm:h-7" /></div>
                        <div className="min-w-0">
                            <p className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5 sm:mb-1 truncate">Pendente ({globalStats.pendingCount})</p>
                            <h3 className="text-xl sm:text-2xl font-black text-rose-600 dark:text-rose-400 tabular-nums truncate">{formatCurrency(globalStats.totalPending)}</h3>
                        </div>
                      </div>
                      <ChevronRight className="text-slate-200 group-hover:translate-x-1 transition-transform shrink-0" />
                  </div>
              </div>

              {/* FILTROS E BUSCA */}
              <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1 relative group">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-amber-500 transition-colors" size={20} />
                      <input 
                        type="text" 
                        placeholder="BUSCAR PARCEIRO PELO NOME OU DOCUMENTO..." 
                        className="w-full bg-white dark:bg-[#23243a] border-none rounded-2xl pl-12 pr-4 py-4 text-[11px] font-black uppercase shadow-sm outline-none focus:ring-4 focus:ring-amber-500/10 transition-all placeholder:text-slate-300"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                  </div>
                  <button className="bg-white dark:bg-[#23243a] p-4 rounded-2xl border border-slate-100 dark:border-white/5 text-slate-400 shadow-sm"><Filter size={20}/></button>
              </div>

              {/* LISTA DE PARCEIROS */}
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-8">
                  {partnerMetrics.length === 0 ? (
                      <div className="col-span-full py-20 text-center bg-white dark:bg-[#23243a] rounded-[2rem] sm:rounded-[3rem] border border-dashed dark:border-white/10">
                          <Users size={64} className="mx-auto text-slate-100 dark:text-slate-800 mb-6" />
                          <p className="text-sm font-black text-slate-400 uppercase tracking-widest">Nenhum parceiro cadastrado com este critério</p>
                      </div>
                  ) : (
                      partnerMetrics.map(partner => (
                          <div 
                            key={partner.id} 
                            onClick={() => setSelectedPartner(partner)}
                            className="bg-white dark:bg-[#23243a] rounded-[2rem] sm:rounded-[2.8rem] p-6 sm:p-10 shadow-sm border border-slate-100 dark:border-white/5 flex flex-col group cursor-pointer transition-all hover:shadow-2xl hover:-translate-y-2"
                          >
                              <div className="flex justify-between items-start mb-6 sm:mb-10">
                                  <div className="flex items-center gap-4 sm:gap-5 min-w-0">
                                      <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-[1.2rem] sm:rounded-[1.8rem] bg-amber-50 dark:bg-amber-500/10 text-amber-600 flex items-center justify-center font-black text-lg sm:text-xl shadow-inner border border-amber-100 dark:border-amber-500/20 group-hover:scale-110 transition-transform shrink-0">
                                          {partner.avatarText || partner.name.substring(0, 2).toUpperCase()}
                                      </div>
                                      <div className="min-w-0">
                                          <h4 className="text-sm sm:text-base font-black text-slate-800 dark:text-white uppercase tracking-tighter truncate leading-none mb-1.5 sm:mb-2 flex items-center gap-2">
                                            <span className="truncate">{partner.name}</span>
                                            {portalUserIds.has(partner.id) && (
                                              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.6)] shrink-0" title="Cadastro Habilitado no Portal" />
                                            )}
                                          </h4>
                                          <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
                                              <span className="text-[7px] sm:text-[8px] font-black bg-indigo-600 text-white px-2 py-0.5 rounded tracking-widest uppercase whitespace-nowrap">{partner.activeReferrals} ATIVOS</span>
                                              <span className="text-[8px] sm:text-[9px] font-bold text-slate-400 uppercase tracking-widest truncate">{partner.cpf || partner.cnpj || 'CONDOMÍNIO'}</span>
                                          </div>
                                      </div>
                                  </div>
                                  <ArrowUpRight className="text-slate-200 group-hover:text-amber-500 transition-colors shrink-0 ml-2" />
                              </div>

                              <div className="grid grid-cols-2 gap-3 sm:gap-4 mb-6 sm:mb-10">
                                  <div className="bg-slate-50 dark:bg-white/5 p-4 sm:p-5 rounded-2xl sm:rounded-3xl border border-transparent group-hover:border-amber-100 transition-colors">
                                      <p className="text-[7px] sm:text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1 sm:mb-1.5">Acumulado</p>
                                      <p className="text-xs sm:text-sm font-black text-slate-800 dark:text-white tabular-nums truncate">{formatCurrency(partner.totalCommissions)}</p>
                                  </div>
                                  <div className="bg-rose-50/30 dark:bg-rose-500/5 p-4 sm:p-5 rounded-2xl sm:rounded-3xl border border-transparent group-hover:border-rose-100 transition-colors">
                                      <p className="text-[7px] sm:text-[8px] font-black text-rose-400 uppercase tracking-widest mb-1 sm:mb-1.5">Pendente</p>
                                      <p className="text-xs sm:text-sm font-black text-rose-600 dark:text-rose-400 tabular-nums truncate">{formatCurrency(partner.pendingCommissions)}</p>
                                  </div>
                              </div>

                              <div className="mt-auto flex items-center justify-between pt-5 sm:pt-6 border-t dark:border-white/5 opacity-60 group-hover:opacity-100 transition-opacity">
                                  <div className="flex gap-4 min-w-0">
                                      <div className="flex items-center gap-1.5 text-[9px] sm:text-[10px] font-bold text-slate-500 dark:text-slate-400 truncate"><MessageCircle size={14} className="shrink-0"/> <span className="truncate">{partner.phone?.split(' ')[1] || '---'}</span></div>
                                  </div>
                                  <span className="text-[9px] sm:text-[10px] font-black text-indigo-500 uppercase tracking-widest flex items-center gap-1 shrink-0 ml-2">Extrato <ChevronRight size={14} strokeWidth={3} /></span>
                              </div>
                          </div>
                      ))
                  )}
              </div>
          </div>
      </div>
    </div>
  );
};

export default PartnersScreen;
