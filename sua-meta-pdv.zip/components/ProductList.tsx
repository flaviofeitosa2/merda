
import React, { useState, useMemo, useEffect } from 'react';
import { 
  Search, 
  ScanLine, 
  List as ListIcon, 
  LayoutGrid, 
  Star,
  ChevronRight,
  Plus,
  X,
  ShoppingBag,
  PackagePlus,
  ArrowRight,
  Loader2,
  Minus,
  ShoppingCart,
  Edit2
} from 'lucide-react';
import { Product, CartItem, Category } from '../types';
import UserMenu from './UserMenu';

interface ProductListProps {
  products: Product[];
  categories: Category[];
  addToCart: (product: Product, meta?: any) => void;
  cartItems: CartItem[];
  toggleSidebar: () => void;
  onOpenCart?: () => void;
  editingOrderId?: string | null;
  onToggleFavorite?: (product: Product) => void;
  onGoToProducts?: () => void;
  isLoading?: boolean;
  onCancelEdit?: () => void;
}

const ProductList: React.FC<ProductListProps> = ({
  products,
  addToCart,
  cartItems,
  toggleSidebar,
  onOpenCart,
  onGoToProducts,
  isLoading = false,
  editingOrderId,
  onCancelEdit
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'tudo' | 'destaques' | 'produto' | 'serviço'>('tudo');
  const [lastAddedId, setLastAddedId] = useState<string | null>(null);
  const [animateCart, setAnimateCart] = useState(false);
  
  const [viewMode, setViewMode] = useState<'grid' | 'list'>(() => {
      const saved = localStorage.getItem('posViewMode');
      return (saved === 'grid' || saved === 'list') ? saved : 'grid';
  });

  const handleSetViewMode = (mode: 'grid' | 'list') => {
      setViewMode(mode);
      localStorage.setItem('posViewMode', mode);
  };

  const cartQtyMap = useMemo(() => {
    const map: Record<string, number> = {};
    cartItems.forEach(item => {
      map[item.id] = (map[item.id] || 0) + item.quantity;
    });
    return map;
  }, [cartItems]);

  const getQtyInCart = (productId: string) => {
    return cartQtyMap[productId] || 0;
  };

  const currentTotal = cartItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const currentCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  useEffect(() => {
    if (currentCount > 0) {
      setAnimateCart(true);
      const timer = setTimeout(() => setAnimateCart(false), 400);
      return () => clearTimeout(timer);
    }
  }, [currentCount]);

  const handleAddToCart = (product: Product, quantity: number = 1) => {
    const currentQtyInCart = getQtyInCart(product.id);
    if (product.manage_stock && (currentQtyInCart + quantity) > (product.stock || 0)) {
        alert(`Estoque insuficiente para ${product.name}. Disponível: ${product.stock}`);
        return;
    }
    setLastAddedId(product.id);
    addToCart(product, { quantity });
    setTimeout(() => setLastAddedId(null), 800);
  };

  const filteredProducts = useMemo(() => {
      const filtered = products.filter(p => {
          const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                                (p.code && p.code.includes(searchQuery));
          
          if (!matchesSearch) return false;

          if (activeFilter === 'destaques') return p.is_favorite;
          
          const isServiceCategory = p.category?.toLowerCase().includes('serviço');
          
          if (activeFilter === 'produto') return !isServiceCategory;
          if (activeFilter === 'serviço') return isServiceCategory;
          
          return true;
      });

      return filtered.sort((a, b) => {
          if (a.is_favorite && !b.is_favorite) return -1;
          if (!a.is_favorite && b.is_favorite) return 1;
          return a.name.localeCompare(b.name);
      });
  }, [products, searchQuery, activeFilter]);

  const getAbbreviation = (name: string) => {
      return name.substring(0, 6).toUpperCase();
  };

  // Componente de Skeleton para Grid
  const GridSkeleton = () => (
    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-6 xl:grid-cols-6 gap-2 md:gap-3">
        {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="bg-white dark:bg-[#23243a] rounded-xl md:rounded-2xl overflow-hidden shadow-sm border border-gray-100 dark:border-white/5 flex flex-col animate-pulse">
                <div className="bg-gray-100 dark:bg-white/5 h-4 w-full"></div>
                <div className="aspect-square bg-gray-50 dark:bg-white/5 m-3 rounded-lg"></div>
                <div className="p-2 space-y-2">
                    <div className="h-2 bg-gray-100 dark:bg-white/10 rounded w-3/4 mx-auto"></div>
                    <div className="h-2 bg-gray-100 dark:bg-white/10 rounded w-1/2 mx-auto"></div>
                </div>
            </div>
        ))}
    </div>
  );

  // Componente de Skeleton para Lista
  const ListSkeleton = () => (
    <div className="max-w-6xl mx-auto space-y-3">
        {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="flex items-center gap-4 p-4 rounded-2xl bg-white dark:bg-[#23243a] border border-gray-100 dark:border-white/5 animate-pulse">
                <div className="w-14 h-14 bg-gray-100 dark:bg-white/5 rounded-xl"></div>
                <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-100 dark:bg-white/5 rounded w-1/3"></div>
                    <div className="h-2 bg-gray-100 dark:bg-white/5 rounded w-1/4"></div>
                </div>
                <div className="w-16 h-6 bg-gray-100 dark:bg-white/5 rounded"></div>
            </div>
        ))}
    </div>
  );

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#EEF2F6] dark:bg-[#1a1b2e] relative font-sans transition-colors">
      
      <style>{`
        @keyframes cart-bump {
          0% { transform: scale(1); }
          25% { transform: scale(1.1); background-color: #34d399; }
          50% { transform: scale(1.15); background-color: #10b981; }
          75% { transform: scale(1.05); }
          100% { transform: scale(1); }
        }
        .animate-cart-bump {
          animation: cart-bump 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        @keyframes border-pulse {
          0% { border-color: transparent; box-shadow: 0 0 0 0 rgba(45, 212, 191, 0.7); }
          50% { border-color: #2dd4bf; box-shadow: 0 0 0 4px rgba(45, 212, 191, 0); }
          100% { border-color: transparent; box-shadow: 0 0 0 0 rgba(45, 212, 191, 0); }
        }
        .product-card-active {
            animation: border-pulse 0.8s ease-out;
            border-color: #2dd4bf !important;
            transform: scale(0.98);
        }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>

      {/* BANNER DE EDIÇÃO */}
      {editingOrderId && (
        <div className="bg-amber-500 text-white px-6 py-2 flex items-center justify-between animate-in slide-in-from-top duration-300">
          <div className="flex items-center gap-2">
            <Edit2 size={16} className="animate-pulse" />
            <span className="text-xs font-black uppercase tracking-widest">Editando Pedido em Aberto</span>
          </div>
          <button 
            onClick={onCancelEdit}
            className="text-[10px] font-black uppercase tracking-tighter bg-white/20 hover:bg-white/30 px-3 py-1 rounded-lg transition-colors"
          >
            Cancelar Edição
          </button>
        </div>
      )}

      <header className="bg-white dark:bg-[#23243a] h-[90px] px-4 lg:px-10 flex justify-between items-center shrink-0 border-b border-gray-100 dark:border-white/5 sticky top-0 z-50 transition-colors">
          <div className="flex items-center gap-4">
              <button onClick={toggleSidebar} className="lg:hidden p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-xl transition-colors">
                  <ListIcon size={26} />
              </button>
              <div className="flex flex-col">
                  <div className="flex items-center gap-4">
                      <h1 className="text-[23px] font-mono font-black text-gray-900 dark:text-white tracking-tighter uppercase leading-none italic">VENDER</h1>
                      <span className="bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-[9px] lg:text-[10px] font-bold px-2 lg:px-3 py-1 rounded-full border border-emerald-100 dark:border-emerald-500/20 uppercase tracking-widest">
                          PDV Aberto
                      </span>
                  </div>
                  <p className="text-[10px] text-gray-400 font-black uppercase tracking-[0.3em] mt-1 hidden sm:block">Selecione produtos para adicionar à venda</p>
              </div>
          </div>
          <UserMenu />
      </header>

      {/* --- BARRA DE BUSCA E FILTROS --- */}
      <div className="bg-white dark:bg-[#23243a] px-4 py-3 lg:px-6 lg:py-4 flex items-center justify-between gap-4 lg:gap-6 shrink-0 transition-colors">
          <div className="relative flex-1 group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500 group-focus-within:text-[#2dd4bf] transition-colors" size={18} />
              <input 
                  type="text"
                  placeholder="Pesquisar..."
                  className="w-full bg-gray-50 dark:bg-[#1a1b2e] border border-transparent dark:text-white focus:border-[#2dd4bf]/20 focus:ring-4 focus:ring-[#2dd4bf]/5 rounded-2xl pl-11 pr-10 py-3 text-sm font-medium outline-none transition-all"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
              />
              {searchQuery && (
                  <button 
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-white transition-colors"
                  >
                      <X size={16} />
                  </button>
              )}
          </div>
          
          <div className="flex items-center gap-2 lg:gap-4 shrink-0">
              <button className="p-2 text-gray-400 dark:text-gray-500 dark:hover:text-[#2dd4bf] transition-colors hover:bg-gray-50 dark:hover:bg-white/5 rounded-xl"><ScanLine size={24} /></button>
              
              <div className="flex gap-1 bg-gray-100 dark:bg-white/5 p-1 rounded-xl">
                  <button 
                      onClick={() => handleSetViewMode('list')} 
                      className={`p-1.5 rounded-lg transition-all ${viewMode === 'list' ? 'bg-white dark:bg-[#23243a] text-[#2dd4bf] shadow-sm' : 'text-gray-400 dark:text-gray-600 hover:text-gray-500'}`}
                  >
                      <ListIcon size={18} />
                  </button>
                  <button 
                      onClick={() => handleSetViewMode('grid')} 
                      className={`p-1.5 rounded-lg transition-all ${viewMode === 'grid' ? 'bg-white dark:bg-[#23243a] text-[#2dd4bf] shadow-sm' : 'text-gray-400 dark:text-gray-600 hover:text-gray-500'}`}
                  >
                      <LayoutGrid size={18} />
                  </button>
              </div>
          </div>
      </div>

      {/* Tabs / Filtros */}
      <div className="bg-white dark:bg-[#23243a] w-full flex items-center justify-between px-2 md:px-6 overflow-x-auto no-scrollbar border-b border-gray-100 dark:border-white/5 shrink-0 transition-colors gap-2">
          {[
              { id: 'tudo', label: 'TUDO' },
              { id: 'destaques', label: 'DESTAQUES' },
              { id: 'produto', label: 'PRODUTO' },
              { id: 'serviço', label: 'SERVIÇO' }
          ].map(tab => (
              <button
                  key={tab.id}
                  onClick={() => setActiveFilter(tab.id as any)}
                  className={`flex-1 py-4 px-2 md:px-6 text-[10px] font-bold tracking-[0.2em] uppercase transition-all border-b-2 whitespace-nowrap text-center
                      ${activeFilter === tab.id ? 'text-[#2dd4bf] border-[#2dd4bf]' : 'text-gray-400 dark:text-gray-500 border-transparent hover:text-gray-600 dark:hover:text-white'}`}
              >
                  {tab.label}
              </button>
          ))}
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-10 pb-28 custom-scrollbar">
          {isLoading ? (
              <div className="space-y-10 animate-in fade-in duration-500">
                  <div className="flex flex-col items-center justify-center py-6 text-center">
                      <Loader2 size={32} className="text-[#2dd4bf] animate-spin mb-3" />
                      <h3 className="text-xs font-black text-gray-400 dark:text-gray-600 uppercase tracking-[0.3em]">Organizando seu balcão...</h3>
                      <p className="text-[10px] text-gray-300 dark:text-gray-700 font-bold uppercase mt-1">Sincronizando catálogo em tempo real</p>
                  </div>
                  {viewMode === 'grid' ? <GridSkeleton /> : <ListSkeleton />}
              </div>
          ) : products.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center p-6 animate-in fade-in zoom-in duration-500">
                  <div className="w-24 h-24 bg-white dark:bg-[#23243a] rounded-[2rem] shadow-xl shadow-teal-500/10 border border-teal-100 dark:border-white/5 flex items-center justify-center text-[#2dd4bf] mb-8">
                      <PackagePlus size={48} strokeWidth={1.5} />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800 dark:text-white uppercase tracking-tight mb-3">Seu catálogo está vazio</h3>
                  <p className="text-gray-500 dark:text-gray-400 max-w-sm mx-auto mb-8 leading-relaxed font-medium text-center">
                      Para começar a realizar vendas, você precisa cadastrar seus produtos ou serviços no sistema primeiro.
                  </p>
                  <button 
                    onClick={onGoToProducts}
                    className="bg-[#2dd4bf] hover:bg-[#14b8a6] text-white font-black py-4 px-8 rounded-2xl shadow-xl shadow-teal-500/30 flex items-center justify-center gap-3 transition-all transform hover:scale-105 active:scale-95 uppercase text-xs tracking-widest"
                  >
                      <Plus size={20} strokeWidth={3} />
                      Cadastrar Primeiro Produto
                      <ArrowRight size={18} />
                  </button>
              </div>
          ) : filteredProducts.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-center text-gray-400 dark:text-gray-600 uppercase font-bold text-xs tracking-widest">
                  Nenhum produto encontrado na busca
              </div>
          ) : viewMode === 'grid' ? (
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-6 xl:grid-cols-6 gap-2 md:gap-3">
                  {filteredProducts.map((product) => {
                      const qty = getQtyInCart(product.id);
                      const isOutOfStock = product.manage_stock && (product.stock || 0) <= 0;
                      const isRecentlyAdded = lastAddedId === product.id;
                      
                      return (
                          <div 
                            key={product.id} 
                            onClick={() => !isOutOfStock && handleAddToCart(product)}
                            className={`bg-white dark:bg-[#23243a] rounded-xl md:rounded-2xl overflow-hidden shadow-sm border border-gray-100 dark:border-white/5 flex flex-col relative transition-all duration-300 group
                                ${isOutOfStock ? 'opacity-40 grayscale cursor-not-allowed' : 'active:scale-95 cursor-pointer hover:shadow-xl hover:border-[#2dd4bf] dark:hover:border-[#2dd4bf]/40 hover:ring-4 hover:ring-[#2dd4bf]/5'}
                                ${isRecentlyAdded ? 'product-card-active' : ''}`}
                          >
                              {isRecentlyAdded && (
                                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-50">
                                      <span className="text-[#2dd4bf] font-semibold text-2xl md:text-3xl animate-float-up drop-shadow-md">+1</span>
                                  </div>
                              )}

                              <div className="bg-[#4a5568] dark:bg-[#1a1b2e]/60 px-1.5 py-0.5 md:px-2 md:py-1 flex justify-between items-center transition-colors">
                                  <span className="text-[7px] md:text-[9px] font-bold text-gray-300 dark:text-gray-400 tracking-widest truncate uppercase">
                                      {getAbbreviation(product.name)}
                                  </span>
                                  <div className="flex gap-0.5 md:gap-1">
                                    {product.is_favorite && <Star size={8} className="text-[#2dd4bf] fill-current md:w-[10px]" />}
                                    {isOutOfStock && <div className="w-1.5 h-1.5 md:w-2 md:h-2 bg-rose-500 rounded-full border border-white dark:border-[#23243a]"></div>}
                                  </div>
                              </div>

                              {qty > 0 && (
                                  <div className={`absolute top-5 right-1 md:top-6 md:right-2 bg-[#2dd4bf] text-[#1a1b2e] text-[9px] md:text-[11px] font-bold px-1.5 py-0.5 rounded-lg shadow-xl z-10 transition-transform border border-white/20 dark:border-[#1a1b2e]/20 ${isRecentlyAdded ? 'scale-110' : ''}`}>
                                      {qty}
                                  </div>
                              )}

                              <div className="aspect-square bg-white dark:bg-white/5 flex items-center justify-center p-1.5 md:p-3 transition-colors">
                                  <img 
                                    src={product.image || 'https://cdn-icons-png.flaticon.com/512/1256/1256650.png'} 
                                    alt="" 
                                    className="w-full h-full object-contain" 
                                  />
                              </div>

                              <div className="bg-gray-50 dark:bg-[#1a1b2e]/40 p-1.5 md:p-2.5 mt-auto transition-colors text-center">
                                  <h3 className="text-[7px] md:text-[9px] font-bold text-gray-800 dark:text-gray-300 uppercase truncate mb-0.5 md:mb-1">
                                      {product.name}
                                  </h3>
                                  <p className="text-[9px] md:text-xs font-bold text-[#1a1b2e] dark:text-[#2dd4bf]">
                                      {product.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                                  </p>
                              </div>
                          </div>
                      );
                  })}
              </div>
          ) : (
              <div className="max-w-6xl mx-auto space-y-2">
                  {filteredProducts.map((product) => {
                      const qty = getQtyInCart(product.id);
                      const isOutOfStock = product.manage_stock && (product.stock || 0) <= 0;
                      const isRecentlyAdded = lastAddedId === product.id;
                      
                      return (
                          <div 
                            key={product.id} 
                            onClick={() => !isOutOfStock && handleAddToCart(product)}
                            className={`flex items-center gap-4 md:gap-6 p-3 md:p-4 rounded-2xl md:rounded-3xl transition-all duration-300 relative border border-transparent group
                                ${isOutOfStock ? 'opacity-40 grayscale' : 'active:scale-[0.99] cursor-pointer hover:bg-white dark:hover:bg-[#23243a] hover:shadow-xl hover:border-[#2dd4bf]/40 hover:ring-2 hover:ring-[#2dd4bf]/5'} 
                                ${isRecentlyAdded ? 'bg-[#2dd4bf]/5 dark:bg-[#2dd4bf]/10 border-[#2dd4bf]/20' : ''}`}
                          >
                              <div className="relative shrink-0">
                                  <div className={`w-12 h-12 md:w-14 md:h-14 rounded-xl md:rounded-2xl border border-gray-100 dark:border-white/5 overflow-hidden flex flex-col transition-colors ${isRecentlyAdded ? 'border-[#2dd4bf]' : 'bg-gray-50 dark:bg-[#1a1b2e]'}`}>
                                      <div className="flex-1 flex items-center justify-center p-2 bg-white dark:bg-white/5 transition-colors">
                                          <img src={product.image || 'https://cdn-icons-png.flaticon.com/512/1256/1256650.png'} alt="" className="w-full h-full object-contain" />
                                      </div>
                                  </div>
                                  
                                  {qty > 0 && (
                                      <div className="absolute -top-2 -right-2 bg-[#2dd4bf] text-[#1a1b2e] text-[9px] md:text-[10px] font-bold w-5 h-5 md:w-6 md:h-6 flex items-center justify-center rounded-lg border-2 border-white dark:border-[#1a1b2e] shadow-lg z-10">
                                          {qty}
                                      </div>
                                  )}
                              </div>

                              <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-2 mb-0.5 md:mb-1">
                                      {product.is_favorite && <Star size={12} className="text-[#2dd4bf] fill-current md:w-[14px]" />}
                                      <h3 className={`text-sm md:text-base font-semibold truncate uppercase tracking-tight transition-colors ${isRecentlyAdded ? 'text-[#2dd4bf]' : 'text-gray-800 dark:text-white'}`}>
                                          {product.name}
                                      </h3>
                                  </div>
                                  <p className="text-[8px] md:text-[10px] text-gray-400 dark:text-gray-500 font-bold uppercase tracking-widest">SKU: {product.code || 'N/A'}</p>
                              </div>

                              {/* Estoque Column */}
                              <div className="hidden sm:flex flex-col items-center justify-center w-20 md:w-24 shrink-0">
                                  <span className={`text-sm md:text-base font-bold transition-colors ${isOutOfStock ? 'text-rose-500' : isRecentlyAdded ? 'text-[#2dd4bf]' : 'text-gray-600 dark:text-gray-400'}`}>
                                      {product.manage_stock ? (product.stock || 0) : '∞'}
                                  </span>
                                  <p className="text-[8px] md:text-[9px] font-black text-gray-400 dark:text-gray-600 uppercase tracking-widest leading-none mt-1">Estoque</p>
                              </div>

                              <div className="text-right shrink-0">
                                  <span className={`text-base md:text-lg font-bold tracking-tight transition-colors ${isRecentlyAdded ? 'text-[#2dd4bf]' : 'text-gray-800 dark:text-white'}`}>
                                      {product.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                                  </span>
                                  {isOutOfStock && (
                                      <p className="text-[8px] md:text-[10px] font-bold text-rose-500 uppercase tracking-widest mt-0.5 md:mt-1">Esgotado</p>
                                  )}
                              </div>
                          </div>
                      );
                  })}
              </div>
          )}
      </div>

      {/* --- BOTÃO FLUTUANTE MOBILE --- */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 w-[90%] max-w-lg z-40 lg:hidden">
          {currentCount > 0 ? (
            <div className="p-1.5 md:p-2 bg-white/10 dark:bg-black/20 backdrop-blur-2xl border border-white/20 dark:border-white/10 rounded-[2rem] md:rounded-[2.5rem] shadow-2xl">
                <button 
                    onClick={onOpenCart}
                    className={`w-full py-4 md:py-5 px-6 md:px-8 rounded-[1.8rem] md:rounded-[2rem] font-bold text-base md:text-lg flex items-center justify-between transition-all active:scale-[0.98] 
                        ${animateCart ? 'animate-cart-bump' : ''}
                        ${currentCount > 0 
                            ? 'bg-[#2dd4bf] text-[#1a1b2e] shadow-xl shadow-[#2dd4bf]/20' 
                            : 'bg-gray-800 dark:bg-[#2d2e42] text-white/90 border border-transparent dark:border-white/10 shadow-lg'
                        }`}
                >
                    <div className="flex items-center gap-2 md:gap-3">
                        <ShoppingBag size={20} md:size={24} strokeWidth={2.5} />
                        <span className="uppercase tracking-widest text-xs md:text-sm">{currentCount} {currentCount === 1 ? 'ITEM' : 'ITENS'}</span>
                    </div>
                    <div className="flex items-center gap-2 md:gap-3">
                        <span className="font-black tracking-tighter">{currentTotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                        <ChevronRight size={20} md:size={24} strokeWidth={3} />
                    </div>
                </button>
            </div>
          ) : (
            !isLoading && (
                <div className="bg-[#ceffab] border-2 border-[#ceffab] rounded-2xl py-4 shadow-xl flex items-center justify-center animate-in fade-in slide-in-from-bottom-2 transition-colors">
                    <span className="text-slate-900 font-black uppercase tracking-[0.2em] text-sm">Nenhum item</span>
                </div>
            )
          )}
      </div>
    </div>
  );
};

export default ProductList;
