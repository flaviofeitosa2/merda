
import React, { useState, useEffect, useMemo } from 'react';
import { 
  X, 
  Save, 
  Loader2, 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  FileText, 
  History, 
  Check, 
  Star, 
  Shield, 
  CreditCard,
  ChevronRight,
  ShoppingBag,
  Clock,
  AlertCircle,
  StickyNote,
  Briefcase,
  Upload,
  ShieldCheck,
  Key,
  Lock,
  Eye,
  EyeOff,
  FileCode,
  AlertTriangle,
  Settings,
  Landmark,
  RefreshCw,
  Copy
} from 'lucide-react';
import { Customer, Sale, Subscription } from '../types';
import { supabase, supabaseUrl, supabaseKey } from '../supabaseClient';
import { createClient } from '@supabase/supabase-js';
import * as SaleDetailPanel from './SaleDetailPanel';

// Configuração para cliente temporário (evita deslogar o admin)
const memoryStorage = {
  getItem: (key: string) => null,
  setItem: (key: string, value: string) => {},
  removeItem: (key: string) => {},
};

let tempAuthClient: any = null;
const getTempClient = () => {
    if (!tempAuthClient) {
        tempAuthClient = createClient(supabaseUrl, supabaseKey, {
            auth: {
                storage: memoryStorage,
                persistSession: false,
                autoRefreshToken: false,
                detectSessionInUrl: false
            }
        });
    }
    return tempAuthClient;
};

interface CustomerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (customer: Customer) => Promise<any>;
  initialData?: Customer | null;
  companyId: string;
  customers?: Customer[];
  subscriptions?: Subscription[];
  portalUserIds: Set<string>;
}

const safeParse = (str: string | null, fallback: any) => {
  if (!str) return fallback;
  try {
    return JSON.parse(str);
  } catch (e) {
    console.error("Error parsing JSON:", e);
    return fallback;
  }
};

const CustomerModal: React.FC<CustomerModalProps> = ({ 
  isOpen, 
  onClose, 
  onSave, 
  initialData, 
  companyId,
  customers = [],
  subscriptions = [],
  portalUserIds
}) => {
  const [activeTab, setActiveTab] = useState<'info' | 'address' | 'history' | 'commissions'>('info');
  const [loading, setLoading] = useState(false);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [history, setHistory] = useState<Sale[]>([]);
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null);
  const [uploading, setUploading] = useState(false);
  const [showFirstPassword, setShowFirstPassword] = useState(false);
  const [portalLoading, setPortalLoading] = useState(false);
  const [portalStatus, setPortalStatus] = useState<{ type: 'success' | 'error' | 'info', message: string } | null>(null);
  
  const [formData, setFormData] = useState<Partial<Customer>>({
    name: '',
    fantasyName: '',
    socialReason: '',
    cpf: '',
    cnpj: '',
    email: '',
    phone: '',
    address: '',
    complement: '',
    notes: '',
    allowTab: false,
    isSubscriber: false,
    isPartner: false,
    balance: 0,
    digital_certificate_url: '',
    first_password: '',
    createdAt: new Date().toISOString().split('T')[0] + 'T12:00:00Z'
  });

  const partnerSubscriptions = useMemo(() => {
    if (!formData.isPartner || !initialData?.id) return [];
    return subscriptions.filter(s => 
      s.referral === initialData.id || 
      (s.referral && initialData.name && s.referral.trim().toUpperCase() === initialData.name.trim().toUpperCase())
    );
  }, [subscriptions, formData.isPartner, initialData?.id, initialData?.name]);

  const getCustomerName = (id: string) => {
    const customer = customers.find(c => c.id === id);
    return customer ? customer.name : id;
  };

  useEffect(() => {
    setPortalStatus(null);
    if (initialData) {
      setFormData({ 
        ...initialData, 
        createdAt: initialData.createdAt ? new Date(initialData.createdAt).toISOString().split('T')[0] + 'T12:00:00Z' : new Date().toISOString().split('T')[0] + 'T12:00:00Z'
      });
      fetchHistory(initialData.id);
    } else {
      setFormData({
        name: '',
        fantasyName: '',
        socialReason: '',
        cpf: '',
        cnpj: '',
        email: '',
        phone: '',
        address: '',
        complement: '',
        notes: '',
        allowTab: false,
        isSubscriber: false,
        isPartner: false,
        balance: 0,
        digital_certificate_url: '',
        first_password: '',
        createdAt: new Date().toISOString().split('T')[0] + 'T12:00:00Z'
      });
      setHistory([]);
    }
    setActiveTab('info');
  }, [initialData, isOpen]);

  const fetchHistory = async (customerId: string) => {
    setLoadingHistory(true);
    try {
      const { data, error } = await supabase
        .from('sales')
        .select('*')
        .eq('customer_id', customerId)
        .order('date', { ascending: false });

      if (error) throw error;
      if (data) {
        setHistory(data.map((s: any) => ({
          ...s,
          total: Number(s.total || 0),
          clientName: s.client_name || '',
          sellerName: s.seller_name || '',
          items: typeof s.items === 'string' ? safeParse(s.items, []) : (s.items || []),
          payments: typeof s.payments === 'string' ? safeParse(s.payments, []) : (s.payments || [])
        })));
      }
    } catch (err) {
      console.error("Erro ao carregar histórico:", err);
    } finally {
      setLoadingHistory(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !initialData) return;

    if (!file.name.toLowerCase().endsWith('.pfx')) {
      alert('Por favor, selecione um arquivo .pfx');
      return;
    }

    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${initialData.id}/${Date.now()}.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from('certificates')
        .upload(fileName, file, { upsert: true });

      if (uploadError) throw uploadError;

      const newFormData = { ...formData, digital_certificate_url: fileName };
      setFormData(newFormData);
      await onSave(newFormData as Customer);
      alert('Certificado enviado com sucesso!');
    } catch (error: any) {
      console.error('Erro no upload:', error);
      alert('Erro ao enviar certificado: ' + error.message);
    } finally {
      setUploading(false);
    }
  };

  const handleLiberarAcesso = async () => {
    if (!formData.email) {
      setPortalStatus({ type: 'error', message: 'O cliente precisa de um e-mail para liberar o acesso.' });
      return;
    }
    
    if (!formData.first_password || formData.first_password.length < 6) {
      setPortalStatus({ type: 'error', message: 'Defina uma senha de pelo menos 6 caracteres.' });
      return;
    }

    setPortalLoading(true);
    setPortalStatus(null);
    
    try {
      const cleanEmail = formData.email.trim().toLowerCase();
      const tempClient = getTempClient();

      // 1. Tentar criar o usuário no Auth
      const { data: authData, error: authError } = await tempClient.auth.signUp({
        email: cleanEmail,
        password: formData.first_password,
        options: {
          data: {
            full_name: formData.name
          }
        }
      });

      if (authError) {
        if (authError.message.includes('already registered')) {
          // Se já existe, vamos apenas garantir que o perfil está vinculado
          const { data: existingUser } = await supabase.rpc('get_user_id_by_email', { email_param: cleanEmail });
          
          // Como não temos a RPC, vamos tentar buscar no profiles
          const { data: profile } = await supabase
            .from('profiles')
            .select('id')
            .eq('email', cleanEmail)
            .maybeSingle();

          if (profile) {
            // Atualizar perfil existente
            const { error: updateError } = await supabase
              .from('profiles')
              .update({
                customer_id: initialData?.id,
                role: 'customer',
                company_id: companyId
              })
              .eq('id', profile.id);

            if (updateError) throw updateError;
            
            setPortalStatus({ type: 'success', message: 'Acesso vinculado ao usuário existente!' });
          } else {
            throw new Error('Este e-mail já está em uso, mas não conseguimos vincular o perfil. Contate o suporte.');
          }
        } else {
          throw authError;
        }
      } else if (authData.user) {
        // 2. Criar o perfil vinculado
        const { error: profileError } = await supabase
          .from('profiles')
          .upsert({
            id: authData.user.id,
            full_name: formData.name,
            role: 'customer',
            company_id: companyId,
            email: cleanEmail,
            customer_id: initialData?.id
          });

        if (profileError) throw profileError;

        // 3. Salvar a senha no cadastro do cliente para referência
        if (initialData?.id) {
          await supabase
            .from('customers')
            .update({ first_password: formData.first_password })
            .eq('id', initialData.id);
        }

        setPortalStatus({ type: 'success', message: 'Conta criada com sucesso! O cliente já pode acessar o portal.' });
      }
    } catch (error: any) {
      console.error('Erro ao liberar acesso:', error);
      setPortalStatus({ type: 'error', message: error.message || 'Erro ao processar solicitação.' });
    } finally {
      setPortalLoading(false);
    }
  };

  const handleRedefinirSenha = async () => {
    if (!formData.email) return;
    setPortalLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(formData.email.trim().toLowerCase(), {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) throw error;
      setPortalStatus({ type: 'success', message: 'E-mail de redefinição enviado para o cliente.' });
    } catch (error: any) {
      setPortalStatus({ type: 'error', message: error.message });
    } finally {
      setPortalLoading(false);
    }
  };

  const handleSave = async () => {
    if (!formData.name?.trim()) return;
    setLoading(true);
    try {
      console.log("Tentando salvar cliente:", formData);
      const success = await onSave(formData as Customer);
      if (success) {
        onClose();
      }
    } catch (error: any) {
      console.error("Erro ao salvar:", error);
      setPortalStatus({ type: 'error', message: error.message || 'Erro ao salvar cliente.' });
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 sm:p-6 backdrop-blur-xl bg-slate-900/60 animate-in fade-in duration-300">
      <div className="bg-white dark:bg-[#1a1b2e] w-full max-w-5xl max-h-[90vh] rounded-[3rem] shadow-[0_32px_64px_-12px_rgba(0,0,0,0.3)] flex flex-col overflow-hidden border border-white/20 dark:border-white/5 animate-in zoom-in-95 duration-300">
        
        {/* Header */}
        <div className="px-10 py-8 border-b border-slate-100 dark:border-white/5 flex items-center justify-between bg-slate-50/50 dark:bg-white/2">
          <div className="flex items-center gap-6">
            <div className={`w-16 h-16 rounded-[1.5rem] flex items-center justify-center text-white shadow-2xl transform rotate-3 ${formData.isPartner ? 'bg-gradient-to-br from-amber-400 to-orange-600' : formData.isSubscriber ? 'bg-gradient-to-br from-indigo-500 to-purple-700' : 'bg-gradient-to-br from-slate-500 to-slate-700'}`}>
              <User size={32} strokeWidth={2.5} />
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tighter leading-none mb-1 flex items-center gap-2">
                {initialData ? 'Perfil do Cliente' : 'Novo Cadastro'}
                {initialData && portalUserIds.has(initialData.id) && (
                  <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(16,185,129,0.6)] shrink-0" title="Cadastro Habilitado no Portal" />
                )}
              </h2>
              <div className="flex items-center gap-3">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
                  {initialData ? `REGISTRO: ${initialData.id.substring(0, 8)}` : 'SISTEMA DE GESTÃO'}
                </span>
                {formData.balance !== 0 && (
                  <span className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase ${formData.balance && formData.balance > 0 ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'}`}>
                    Saldo: {formData.balance?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </span>
                )}
              </div>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-12 h-12 rounded-2xl flex items-center justify-center text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-rose-500 transition-all active:scale-90"
          >
            <X size={28} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex px-10 border-b border-slate-100 dark:border-white/5 bg-white dark:bg-[#1a1b2e]">
          <button 
            onClick={() => setActiveTab('info')}
            className={`px-8 py-5 text-xs font-black uppercase tracking-widest transition-all border-b-4 relative ${activeTab === 'info' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
          >
            Identificação
            {activeTab === 'info' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-t-full shadow-[0_-4px_12px_rgba(79,70,229,0.4)]" />}
          </button>
          <button 
            onClick={() => setActiveTab('address')}
            className={`px-8 py-5 text-xs font-black uppercase tracking-widest transition-all border-b-4 relative ${activeTab === 'address' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
          >
            Endereço & Notas
            {activeTab === 'address' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-t-full shadow-[0_-4px_12px_rgba(79,70,229,0.4)]" />}
          </button>
          {initialData && (
            <button 
              onClick={() => setActiveTab('history')}
              className={`px-8 py-5 text-xs font-black uppercase tracking-widest transition-all border-b-4 relative ${activeTab === 'history' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
            >
              Histórico
              {activeTab === 'history' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-t-full shadow-[0_-4px_12px_rgba(79,70,229,0.4)]" />}
            </button>
          )}
          {formData.isPartner && (
            <button 
              onClick={() => setActiveTab('commissions')}
              className={`px-8 py-5 text-xs font-black uppercase tracking-widest transition-all border-b-4 relative ${activeTab === 'commissions' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
            >
              Comissões
              {activeTab === 'commissions' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-t-full shadow-[0_-4px_12px_rgba(79,70,229,0.4)]" />}
            </button>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-10 custom-scrollbar bg-white dark:bg-[#1a1b2e]">
          {portalStatus && portalStatus.type === 'error' && (
            <div className="mb-8 p-6 bg-rose-50 dark:bg-rose-500/10 border-2 border-rose-100 dark:border-rose-500/20 rounded-[2rem] flex items-center gap-4 text-rose-700 dark:text-rose-400 animate-in fade-in slide-in-from-top-4 duration-300 shadow-xl shadow-rose-500/5">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-500/20 flex items-center justify-center shrink-0">
                <AlertCircle size={24} />
              </div>
              <div className="flex-1">
                <p className="text-[10px] font-black uppercase tracking-widest mb-1 opacity-60">Erro na Operação</p>
                <p className="text-sm font-bold leading-tight">{portalStatus.message}</p>
              </div>
              <button onClick={() => setPortalStatus(null)} className="p-2 hover:bg-rose-200/50 dark:hover:bg-rose-500/20 rounded-xl transition-colors">
                <X size={20} />
              </button>
            </div>
          )}
          {activeTab === 'info' && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-8">
                <div className="relative">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 block ml-1">Nome do Cliente *</label>
                  <div className="group relative">
                    <User className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={20} />
                    <input 
                      type="text"
                      value={formData.name || ''}
                      onChange={e => setFormData({...formData, name: e.target.value})}
                      className="w-full pl-14 pr-5 py-5 bg-slate-50 dark:bg-white/5 border-2 border-transparent focus:border-indigo-500/20 rounded-[1.5rem] text-sm font-bold text-slate-700 dark:text-white outline-none transition-all shadow-sm"
                      placeholder="Ex: João Silva"
                    />
                  </div>
                </div>

                <div className="relative">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 block ml-1">Razão Social</label>
                  <div className="group relative">
                    <Briefcase className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={20} />
                    <input 
                      type="text"
                      value={formData.socialReason || ''}
                      onChange={e => setFormData({...formData, socialReason: e.target.value})}
                      className="w-full pl-14 pr-5 py-5 bg-slate-50 dark:bg-white/5 border-2 border-transparent focus:border-indigo-500/20 rounded-[1.5rem] text-sm font-bold text-slate-700 dark:text-white outline-none transition-all shadow-sm"
                      placeholder="Razão Social da Empresa"
                    />
                  </div>
                </div>

                <div className="relative">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 block ml-1">Nome Fantasia</label>
                  <div className="group relative">
                    <Star className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={20} />
                    <input 
                      type="text"
                      value={formData.fantasyName || ''}
                      onChange={e => setFormData({...formData, fantasyName: e.target.value})}
                      className="w-full pl-14 pr-5 py-5 bg-slate-50 dark:bg-white/5 border-2 border-transparent focus:border-indigo-500/20 rounded-[1.5rem] text-sm font-bold text-slate-700 dark:text-white outline-none transition-all shadow-sm"
                      placeholder="Nome comercial"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div className="relative">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 block ml-1">CPF</label>
                    <input 
                      type="text"
                      value={formData.cpf || ''}
                      onChange={e => setFormData({...formData, cpf: e.target.value})}
                      className="w-full px-5 py-5 bg-slate-50 dark:bg-white/5 border-2 border-transparent focus:border-indigo-500/20 rounded-[1.5rem] text-sm font-bold text-slate-700 dark:text-white outline-none transition-all shadow-sm"
                      placeholder="000.000.000-00"
                    />
                  </div>
                  <div className="relative">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 block ml-1">CNPJ</label>
                    <input 
                      type="text"
                      value={formData.cnpj || ''}
                      onChange={e => setFormData({...formData, cnpj: e.target.value})}
                      className="w-full px-5 py-5 bg-slate-50 dark:bg-white/5 border-2 border-transparent focus:border-indigo-500/20 rounded-[1.5rem] text-sm font-bold text-slate-700 dark:text-white outline-none transition-all shadow-sm"
                      placeholder="00.000.000/0001-00"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-8">
                <div className="relative">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 block ml-1">E-mail de Contato</label>
                  <div className="group relative">
                    <Mail className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={20} />
                    <input 
                      type="email"
                      value={formData.email || ''}
                      onChange={e => setFormData({...formData, email: e.target.value})}
                      className="w-full pl-14 pr-5 py-5 bg-slate-50 dark:bg-white/5 border-2 border-transparent focus:border-indigo-500/20 rounded-[1.5rem] text-sm font-bold text-slate-700 dark:text-white outline-none transition-all shadow-sm"
                      placeholder="cliente@exemplo.com"
                    />
                  </div>
                </div>

                <div className="relative">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 block ml-1">WhatsApp / Telefone</label>
                  <div className="group relative">
                    <Phone className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={20} />
                    <input 
                      type="text"
                      value={formData.phone || ''}
                      onChange={e => setFormData({...formData, phone: e.target.value})}
                      className="w-full pl-14 pr-5 py-5 bg-slate-50 dark:bg-white/5 border-2 border-transparent focus:border-indigo-500/20 rounded-[1.5rem] text-sm font-bold text-slate-700 dark:text-white outline-none transition-all shadow-sm"
                      placeholder="(00) 00000-0000"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6 pt-2">
                  <button 
                    onClick={() => setFormData({...formData, isSubscriber: !formData.isSubscriber})}
                    className={`p-5 rounded-[1.5rem] border-2 transition-all flex flex-col items-center gap-3 group ${formData.isSubscriber ? 'bg-indigo-50 border-indigo-500 text-indigo-600 dark:bg-indigo-500/10 dark:border-indigo-500' : 'bg-slate-50 border-transparent text-slate-400 dark:bg-white/5'}`}
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${formData.isSubscriber ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-400 dark:bg-white/10'}`}>
                      <Shield size={20} />
                    </div>
                    <span className="text-[10px] font-black uppercase tracking-widest">Assinante</span>
                  </button>
                  <button 
                    onClick={() => setFormData({...formData, isPartner: !formData.isPartner})}
                    className={`p-5 rounded-[1.5rem] border-2 transition-all flex flex-col items-center gap-3 group ${formData.isPartner ? 'bg-amber-50 border-amber-500 text-amber-600 dark:bg-amber-500/10 dark:border-amber-500' : 'bg-slate-50 border-transparent text-slate-400 dark:bg-white/5'}`}
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${formData.isPartner ? 'bg-amber-500 text-white' : 'bg-slate-200 text-slate-400 dark:bg-white/10'}`}>
                      <Star size={20} />
                    </div>
                    <span className="text-[10px] font-black uppercase tracking-widest">Parceiro</span>
                  </button>
                </div>
              </div>

            {/* NOVOS CARDS SOLICITADOS */}
            <div className="md:col-span-2 space-y-10 mt-6">
              
              {/* HISTÓRICO DE TRANSAÇÕES CARD */}
              <div className="bg-white dark:bg-white/2 border border-slate-100 dark:border-white/5 rounded-[2.5rem] overflow-hidden shadow-sm">
                <div className="px-8 py-6 border-b border-slate-50 dark:border-white/5 flex items-center justify-between bg-slate-50/30">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-500/10 flex items-center justify-center text-indigo-600">
                      <History size={20} />
                    </div>
                    <div>
                      <h4 className="text-[11px] font-black text-slate-800 dark:text-white uppercase tracking-widest">Histórico de Transações</h4>
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">Vendas vinculadas a este CPF/CNPJ</p>
                    </div>
                  </div>
                  <div className="bg-indigo-100 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 px-3 py-1 rounded-lg text-[10px] font-black uppercase">
                    {history.length} REGS
                  </div>
                </div>
                <div className="p-8">
                  {history.length === 0 ? (
                    <p className="text-center py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Nenhuma transação encontrada</p>
                  ) : (
                    <div className="space-y-4">
                      {history.slice(0, 3).map(sale => (
                        <div key={sale.id} className="flex items-center justify-between p-4 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-100 dark:border-white/5">
                          <div className="flex items-center gap-4">
                            <div className="flex flex-col">
                              <div className="flex items-center gap-2">
                                <span className="text-[10px] font-black text-slate-400 uppercase">#{sale.code.substring(0, 8)}</span>
                                <span className={`text-[8px] font-black px-1.5 py-0.5 rounded uppercase ${sale.status === 'completed' ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'}`}>
                                  {sale.status === 'completed' ? 'PAGO' : 'CANCELADO'}
                                </span>
                              </div>
                              <span className="text-[11px] font-black text-slate-700 dark:text-white uppercase mt-1">
                                {sale.items.length} ITEM: {sale.items[0]?.name || 'Venda'}
                              </span>
                              <div className="flex items-center gap-1.5 mt-1 text-slate-400">
                                <Clock size={10} />
                                <span className="text-[9px] font-bold uppercase">{new Date(sale.date).toLocaleString('pt-BR')}</span>
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-black text-slate-900 dark:text-white tracking-tighter">
                              {sale.total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                            </p>
                            <button onClick={() => setSelectedSale(sale)} className="text-[9px] font-black text-indigo-500 uppercase tracking-widest mt-1 hover:underline">Ver Detalhes &gt;</button>
                          </div>
                        </div>
                      ))}
                      {history.length > 3 && (
                        <button onClick={() => setActiveTab('history')} className="w-full py-3 text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-indigo-600 transition-colors">Ver histórico completo</button>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* COFRE DE DOCUMENTOS CARD */}
              <div className="bg-white dark:bg-white/2 border border-slate-100 dark:border-white/5 rounded-[2.5rem] overflow-hidden shadow-sm">
                <div className="px-8 py-6 border-b border-slate-50 dark:border-white/5 flex items-center gap-3 bg-slate-50/30">
                  <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-500/10 flex items-center justify-center text-teal-600">
                    <ShieldCheck size={20} />
                  </div>
                  <div>
                    <h4 className="text-[11px] font-black text-teal-600 uppercase tracking-widest">Cofre de Documentos</h4>
                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">Backup de Certificado Digital</p>
                  </div>
                </div>
                <div className="p-8 space-y-6">
                  <div className="relative">
                    <input 
                      type="file" 
                      accept=".pfx" 
                      onChange={handleFileUpload} 
                      className="hidden" 
                      id="cert-upload"
                      disabled={uploading || !initialData}
                    />
                    <label 
                      htmlFor="cert-upload"
                      className={`w-full flex items-center justify-center gap-4 py-6 rounded-[1.5rem] font-black text-xs uppercase tracking-widest transition-all cursor-pointer shadow-lg ${uploading ? 'bg-slate-100 text-slate-400' : 'bg-[#2dd4bf] hover:bg-[#14b8a6] text-white shadow-teal-500/20 active:scale-95'}`}
                    >
                      {uploading ? <Loader2 className="animate-spin" size={20} /> : <Upload size={20} />}
                      {formData.digital_certificate_url ? 'Substituir Certificado (.pfx)' : 'Subir Certificado (.pfx)'}
                    </label>
                    {formData.digital_certificate_url && (
                      <div className="mt-4 flex items-center gap-3 p-4 bg-emerald-50 dark:bg-emerald-500/10 rounded-2xl border border-emerald-100 dark:border-emerald-500/20">
                        <FileCode className="text-emerald-600" size={20} />
                        <div className="flex-1">
                          <p className="text-[10px] font-black text-emerald-700 dark:text-emerald-400 uppercase tracking-widest">Certificado Armazenado</p>
                          <p className="text-[9px] font-bold text-emerald-600/60 truncate max-w-[300px]">{formData.digital_certificate_url}</p>
                        </div>
                        <Check className="text-emerald-600" size={20} />
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-slate-50 dark:bg-white/5 rounded-2xl text-slate-400">
                    <AlertCircle size={18} />
                    <p className="text-[9px] font-bold italic">Ações no cofre são salvas imediatamente no banco de dados.</p>
                  </div>
                </div>
              </div>

              {/* PORTAL DO ASSINANTE CARD */}
              <div className="bg-white dark:bg-white/2 border border-slate-100 dark:border-white/5 rounded-[2.5rem] overflow-hidden shadow-sm">
                <div className="px-8 py-6 border-b border-slate-50 dark:border-white/5 flex items-center gap-3 bg-slate-50/30">
                  <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-500/10 flex items-center justify-center text-indigo-600">
                    <Key size={20} />
                  </div>
                  <div>
                    <h4 className="text-[11px] font-black text-indigo-600 uppercase tracking-widest">Portal do Assinante</h4>
                  </div>
                </div>
                <div className="p-8 space-y-8 relative">
                  <div className="absolute top-4 right-8 opacity-5 pointer-events-none">
                    <Key size={120} className="text-indigo-600" />
                  </div>
                  
                  <div className="relative">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2 block ml-1">E-mail de Login (Sincronizado)</label>
                    <div className="flex items-center border-2 border-slate-100 dark:border-white/10 rounded-2xl p-4 bg-slate-50 dark:bg-white/5 h-16">
                      <Mail className="text-slate-300 mr-4" size={20} />
                      <input 
                        type="text"
                        readOnly
                        value={formData.email || ''}
                        className="w-full bg-transparent outline-none text-sm font-bold text-slate-600 dark:text-slate-400 cursor-default"
                        placeholder="E-mail não definido"
                      />
                    </div>
                  </div>

                  <div className="relative">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2 block ml-1">Senha de Primeiro Acesso</label>
                    <div className="flex items-center border-2 border-slate-100 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] focus-within:border-indigo-400 transition-all h-16">
                      <Lock className="text-slate-300 mr-4" size={20} />
                      <input 
                        type={showFirstPassword ? "text" : "password"}
                        value={formData.first_password || ''}
                        onChange={e => setFormData({...formData, first_password: e.target.value})}
                        className="w-full bg-transparent outline-none text-sm font-bold text-slate-700 dark:text-white"
                        placeholder="Definir senha inicial"
                      />
                      <div className="flex items-center gap-2">
                        <button onClick={() => setShowFirstPassword(!showFirstPassword)} className="text-slate-300 hover:text-indigo-600 transition-colors p-1">
                          {showFirstPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                        </button>
                        {formData.first_password && (
                          <button 
                            onClick={() => {
                              navigator.clipboard.writeText(formData.first_password || '');
                              setPortalStatus({ type: 'info', message: 'Senha copiada!' });
                              setTimeout(() => setPortalStatus(null), 2000);
                            }}
                            className="text-slate-300 hover:text-indigo-600 transition-colors p-1"
                            title="Copiar Senha"
                          >
                            <Copy size={20} />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  {portalStatus && (
                    <div className={`p-4 rounded-2xl border flex gap-3 animate-in fade-in slide-in-from-top-2 ${
                      portalStatus.type === 'error' ? 'bg-rose-50 dark:bg-rose-500/10 text-rose-700 dark:text-rose-400 border-rose-100 dark:border-rose-500/20' : 
                      portalStatus.type === 'success' ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-100 dark:border-emerald-500/20' :
                      'bg-blue-50 dark:bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-100 dark:border-blue-500/20'
                    }`}>
                      {portalStatus.type === 'error' ? <AlertCircle size={20} className="shrink-0" /> : <Check size={20} className="shrink-0" />}
                      <span className="text-[10px] font-bold uppercase tracking-tight leading-relaxed">{portalStatus.message}</span>
                    </div>
                  )}

                  <div className="flex flex-col sm:flex-row gap-4">
                    <button 
                      onClick={handleLiberarAcesso}
                      disabled={portalLoading || !initialData}
                      className={`flex-1 py-6 rounded-[1.8rem] font-black text-xs uppercase tracking-widest shadow-xl transition-all flex items-center justify-center gap-4 active:scale-95 ${
                        initialData && !portalUserIds.has(initialData.id)
                          ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-500/20'
                          : 'bg-slate-100 dark:bg-white/5 text-slate-400 cursor-not-allowed shadow-none'
                      }`}
                    >
                      {portalLoading ? <Loader2 className="animate-spin" size={22} /> : <User size={22} strokeWidth={3} />} 
                      {initialData && portalUserIds.has(initialData.id) ? 'Acesso já Liberado' : 'Liberar Acesso'}
                    </button>

                    {initialData && portalUserIds.has(initialData.id) && (
                      <button 
                        onClick={handleRedefinirSenha}
                        disabled={portalLoading}
                        className="flex-1 py-6 bg-amber-500 hover:bg-amber-600 text-white rounded-[1.8rem] font-black text-xs uppercase tracking-widest shadow-xl shadow-amber-500/20 transition-all flex items-center justify-center gap-4 active:scale-95"
                      >
                        {portalLoading ? <Loader2 className="animate-spin" size={22} /> : <RefreshCw size={22} strokeWidth={3} />} 
                        Redefinir Senha
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* CONTROLE CARD */}
              <div className="bg-white dark:bg-white/2 border border-slate-100 dark:border-white/5 rounded-[2.5rem] overflow-hidden shadow-sm">
                <div className="px-8 py-6 border-b border-slate-50 dark:border-white/5 flex items-center gap-3 bg-slate-50/30">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-white/10 flex items-center justify-center text-slate-600">
                    <Settings size={20} />
                  </div>
                  <div>
                    <h4 className="text-[11px] font-black text-slate-600 dark:text-white uppercase tracking-widest">Controle</h4>
                  </div>
                </div>
                <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="relative">
                    <label className="absolute -top-2.5 left-5 bg-white dark:bg-[#1a1b2e] px-2 text-[9px] font-black text-slate-400 uppercase tracking-widest z-10">Data de Cadastro</label>
                    <div className="flex items-center border-2 border-slate-100 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] h-16">
                      <input 
                        type="date"
                        value={formData.createdAt ? new Date(formData.createdAt).toISOString().split('T')[0] : ''}
                        onChange={e => {
                          if (e.target.value) {
                            // Usar meio-dia UTC para evitar problemas de fuso horário ao extrair a data
                            const date = new Date(e.target.value + 'T12:00:00Z');
                            setFormData({...formData, createdAt: date.toISOString()});
                          } else {
                            setFormData({...formData, createdAt: new Date().toISOString().split('T')[0] + 'T12:00:00Z'});
                          }
                        }}
                        className="w-full bg-transparent outline-none text-sm font-bold text-slate-700 dark:text-white"
                      />
                    </div>
                  </div>

                  <div className="relative">
                    <label className="absolute -top-2.5 left-5 bg-white dark:bg-[#1a1b2e] px-2 text-[9px] font-black text-slate-400 uppercase tracking-widest z-10">Fiado</label>
                    <div className="flex items-center border-2 border-slate-100 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] h-16 relative">
                      <select 
                        value={formData.allowTab ? 'on' : 'off'}
                        onChange={e => setFormData({...formData, allowTab: e.target.value === 'on'})}
                        className="w-full bg-transparent outline-none text-sm font-bold text-slate-700 dark:text-white appearance-none uppercase"
                      >
                        <option value="off">OFF</option>
                        <option value="on">ON</option>
                      </select>
                      <div className="absolute right-4 pointer-events-none text-slate-300">
                        {formData.allowTab ? <Check size={20} className="text-emerald-500" /> : <X size={20} className="text-rose-500" />}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
          </>
        )}

          {activeTab === 'address' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-8">
                <div className="relative">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 block ml-1">Endereço Completo</label>
                  <div className="group relative">
                    <MapPin className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={20} />
                    <input 
                      type="text"
                      value={formData.address || ''}
                      onChange={e => setFormData({...formData, address: e.target.value})}
                      className="w-full pl-14 pr-5 py-5 bg-slate-50 dark:bg-white/5 border-2 border-transparent focus:border-indigo-500/20 rounded-[1.5rem] text-sm font-bold text-slate-700 dark:text-white outline-none transition-all shadow-sm"
                      placeholder="Rua, Número, Bairro"
                    />
                  </div>
                </div>
                <div className="relative">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 block ml-1">Complemento</label>
                  <input 
                    type="text"
                    value={formData.complement || ''}
                    onChange={e => setFormData({...formData, complement: e.target.value})}
                    className="w-full px-5 py-5 bg-slate-50 dark:bg-white/5 border-2 border-transparent focus:border-indigo-500/20 rounded-[1.5rem] text-sm font-bold text-slate-700 dark:text-white outline-none transition-all shadow-sm"
                    placeholder="Apto, Bloco, Referência"
                  />
                </div>
              </div>
              <div className="space-y-8">
                <div className="relative">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 block ml-1">Observações Internas</label>
                  <div className="group relative">
                    <StickyNote className="absolute left-5 top-6 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={20} />
                    <textarea 
                      value={formData.notes || ''}
                      onChange={e => setFormData({...formData, notes: e.target.value})}
                      rows={6}
                      className="w-full pl-14 pr-5 py-5 bg-slate-50 dark:bg-white/5 border-2 border-transparent focus:border-indigo-500/20 rounded-[1.5rem] text-sm font-bold text-slate-700 dark:text-white outline-none transition-all resize-none shadow-sm"
                      placeholder="Informações relevantes sobre este cliente..."
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-6">
              {loadingHistory ? (
                <div className="py-32 flex flex-col items-center justify-center">
                  <div className="relative">
                    <div className="w-16 h-16 border-4 border-indigo-100 dark:border-indigo-500/10 rounded-full" />
                    <div className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin absolute top-0 left-0" />
                  </div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mt-6 animate-pulse">Sincronizando Histórico...</p>
                </div>
              ) : history.length === 0 ? (
                <div className="py-32 flex flex-col items-center justify-center text-center">
                  <div className="w-24 h-24 bg-slate-50 dark:bg-white/5 rounded-[2rem] flex items-center justify-center text-slate-200 dark:text-slate-800 mb-6 transform -rotate-6">
                    <ShoppingBag size={48} />
                  </div>
                  <h4 className="text-lg font-black text-slate-900 dark:text-white uppercase tracking-tight mb-2">Sem Transações</h4>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Este cliente ainda não realizou compras.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4">
                  <div className="flex items-center justify-between px-2 mb-2">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{history.length} Transações encontradas</span>
                    <div className="h-px flex-1 bg-slate-100 dark:bg-white/5 mx-4" />
                  </div>
                  {history.map(sale => (
                    <div 
                      key={sale.id}
                      onClick={() => setSelectedSale(sale)}
                      className="group p-6 bg-white dark:bg-white/2 border border-slate-100 dark:border-white/5 rounded-[2rem] hover:border-indigo-300 dark:hover:border-indigo-500/30 hover:shadow-xl hover:shadow-indigo-500/5 transition-all cursor-pointer flex items-center justify-between"
                    >
                      <div className="flex items-center gap-6">
                        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-sm transition-all group-hover:scale-110 ${sale.status === 'completed' ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10' : 'bg-rose-50 text-rose-600 dark:bg-rose-500/10'}`}>
                          <ReceiptText size={28} />
                        </div>
                        <div>
                          <div className="flex items-center gap-3 mb-1">
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">VENDA #{sale.code}</span>
                            <span className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase ${sale.status === 'completed' ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'}`}>
                              {sale.status === 'completed' ? 'Finalizada' : 'Cancelada'}
                            </span>
                          </div>
                          <p className="text-sm font-black text-slate-700 dark:text-white uppercase">
                            {sale.items.length} {sale.items.length === 1 ? 'Produto' : 'Produtos'}
                          </p>
                          <div className="flex items-center gap-2 mt-1">
                            <Clock size={12} className="text-slate-300" />
                            <span className="text-[10px] font-bold text-slate-400 uppercase">
                              {new Date(sale.date).toLocaleString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-black text-slate-900 dark:text-white tracking-tighter">
                          {sale.total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </p>
                        <div className="flex items-center justify-end gap-2 text-[10px] font-black text-indigo-500 uppercase tracking-widest mt-2 opacity-0 group-hover:opacity-100 transition-all transform translate-x-2 group-hover:translate-x-0">
                          Ver Detalhes <ChevronRight size={14} strokeWidth={3} />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'commissions' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white dark:bg-white/5 p-6 rounded-[2rem] border border-slate-100 dark:border-white/5 shadow-sm">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Total de Comissões</p>
                  <h3 className="text-2xl font-black text-slate-800 dark:text-white tabular-nums tracking-tighter">
                    {partnerSubscriptions.reduce((acc, curr) => acc + (curr.commission_value || 0), 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </h3>
                </div>
                <div className="bg-emerald-50 dark:bg-emerald-500/10 p-6 rounded-[2rem] border border-emerald-100 dark:border-emerald-500/20 shadow-sm">
                  <p className="text-[10px] font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-widest mb-2">Recebido</p>
                  <h3 className="text-2xl font-black text-emerald-700 dark:text-emerald-400 tabular-nums tracking-tighter">
                    {partnerSubscriptions.filter(s => !!s.commission_payment_date).reduce((acc, curr) => acc + (curr.commission_value || 0), 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </h3>
                </div>
                <div className="bg-amber-50 dark:bg-amber-500/10 p-6 rounded-[2rem] border border-amber-100 dark:border-amber-500/20 shadow-sm">
                  <p className="text-[10px] font-black text-amber-600 dark:text-amber-400 uppercase tracking-widest mb-2">Pendente</p>
                  <h3 className="text-2xl font-black text-amber-700 dark:text-amber-400 tabular-nums tracking-tighter">
                    {partnerSubscriptions.filter(s => !s.commission_payment_date).reduce((acc, curr) => acc + (curr.commission_value || 0), 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </h3>
                </div>
              </div>

               <div className="bg-white dark:bg-white/2 border border-slate-100 dark:border-white/5 rounded-[2.5rem] overflow-hidden shadow-sm">
                  <div className="px-8 py-6 border-b border-slate-50 dark:border-white/5 flex items-center gap-3 bg-slate-50/30">
                    <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-500/10 flex items-center justify-center text-indigo-600">
                      <Landmark size={20} />
                    </div>
                    <div>
                      <h4 className="text-[11px] font-black text-slate-800 dark:text-white uppercase tracking-widest">Extrato de Comissões</h4>
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">Listagem de indicações</p>
                    </div>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-separate border-spacing-0">
                        <thead>
                            <tr className="bg-slate-50/50 dark:bg-white/5 text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-[0.2em] border-b dark:border-white/5">
                                <th className="px-8 py-6">Data</th>
                                <th className="px-8 py-6">Cliente Indicado</th>
                                <th className="px-8 py-6">Produto</th>
                                <th className="px-8 py-6">Valor Produto</th>
                                <th className="px-8 py-6">Comissão</th>
                                <th className="px-8 py-6 text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50 dark:divide-white/5">
                            {partnerSubscriptions.length === 0 ? (
                                <tr><td colSpan={6} className="py-24 text-center text-slate-300 font-black uppercase text-sm tracking-widest">Nenhuma comissão encontrada.</td></tr>
                            ) : (
                                partnerSubscriptions.map(sub => (
                                    <tr key={sub.id} className="hover:bg-gray-50/50 dark:hover:bg-white/5 transition-colors group">
                                        <td className="px-8 py-6">
                                            <div className="flex flex-col">
                                                <span className="text-xs font-bold text-slate-800 dark:text-white leading-none mb-1">{new Date(sub.start_date).toLocaleDateString('pt-BR')}</span>
                                                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Início</span>
                                            </div>
                                        </td>
                                        <td className="px-8 py-6">
                                            <div className="flex items-center gap-3">
                                                <div className="w-8 h-8 bg-gray-100 dark:bg-white/5 rounded-lg flex items-center justify-center text-slate-400"><User size={14}/></div>
                                                <span className="text-xs font-black text-slate-700 dark:text-white uppercase tracking-tight truncate max-w-[150px]">{getCustomerName(sub.customer_id)}</span>
                                            </div>
                                        </td>
                                        <td className="px-8 py-6">
                                            <span className="text-xs font-bold text-slate-600 dark:text-slate-300 uppercase">{sub.provider || 'Assinatura'}</span>
                                        </td>
                                        <td className="px-8 py-6"><span className="text-xs font-bold text-slate-400 tabular-nums">{sub.value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span></td>
                                        <td className="px-8 py-6"><span className="text-sm font-black text-indigo-600 dark:text-indigo-400 tabular-nums tracking-tighter">{(sub.commission_value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span></td>
                                        <td className="px-8 py-6 text-center">
                                            {sub.commission_payment_date ? (
                                                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-500/20 text-[8px] font-black uppercase tracking-widest">
                                                    <Check size={12} strokeWidth={4} /> Pago
                                                </div>
                                            ) : (
                                                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-400 border border-amber-100 dark:border-amber-500/20 text-[8px] font-black uppercase tracking-widest">
                                                    <Clock size={12} strokeWidth={4} /> Pendente
                                                </div>
                                            )}
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                  </div>
               </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-10 py-8 border-t border-slate-100 dark:border-white/5 bg-slate-50/50 dark:bg-white/2 flex justify-end items-center gap-6">
          <button 
            onClick={onClose}
            className="text-xs font-black text-slate-400 uppercase tracking-widest hover:text-slate-600 dark:hover:text-white transition-all"
          >
            Descartar
          </button>
          <button 
            onClick={handleSave}
            disabled={loading || !formData.name?.trim()}
            className="px-12 py-5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-black text-xs uppercase tracking-widest rounded-[1.5rem] shadow-[0_20px_40px_-12px_rgba(79,70,229,0.4)] flex items-center gap-3 transition-all active:scale-95 hover:-translate-y-1"
          >
            {loading ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />}
            {initialData ? 'Atualizar Perfil' : 'Confirmar Cadastro'}
          </button>
        </div>
      </div>

      {selectedSale && (
        <SaleDetailPanel.default 
          isOpen={!!selectedSale} 
          onClose={() => setSelectedSale(null)} 
          sale={selectedSale} 
        />
      )}
    </div>
  );
};

const ReceiptText = ({ size }: { size: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1-2-1Z"/>
    <path d="M16 8h-8"/><path d="M16 12H8"/><path d="M13 16H8"/>
  </svg>
);

export default CustomerModal;
