
import React, { useState, useEffect } from 'react';
import { X, Loader2, Eye, EyeOff, AlertCircle } from 'lucide-react';
import { createClient } from '@supabase/supabase-js';
import { supabaseUrl, supabaseKey, supabase as mainSupabase } from '../supabaseClient';
import { UserRole } from '../types';

interface UserPanelProps {
  isOpen: boolean;
  onClose: () => void;
  companyId: string;
  onUserAdded: () => void;
}

const memoryStorage = {
  getItem: (key: string) => null,
  setItem: (key: string, value: string) => {},
  removeItem: (key: string) => {},
};

let tempAuthClient: any = null;
const getTempClient = () => {
    if (!tempAuthClient) {
        tempAuthClient = createClient(supabaseUrl, supabaseKey, {
            auth: {
                storage: memoryStorage,
                persistSession: false,
                autoRefreshToken: false,
                detectSessionInUrl: false
            }
        });
    }
    return tempAuthClient;
};

const UserPanel: React.FC<UserPanelProps> = ({ isOpen, onClose, companyId, onUserAdded }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('operator');
  
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<{message: string, type: 'error' | 'warning'} | null>(null);

  useEffect(() => {
    if (!isOpen) {
      setName('');
      setEmail('');
      setPassword('');
      setRole('operator');
      setError(null);
      setLoading(false);
    }
  }, [isOpen]);

  const handleSubmit = async () => {
      const cleanEmail = email.trim().toLowerCase();
      if (!name || !cleanEmail || !password) return;
      
      if (password.length < 6) {
          setError({ message: "A senha deve ter no mínimo 6 caracteres.", type: 'error' });
          return;
      }

      setLoading(true);
      setError(null);

      try {
          const tempClient = getTempClient();

          const { data: authData, error: authError } = await tempClient.auth.signUp({
              email: cleanEmail,
              password,
              options: {
                  data: {
                      full_name: name
                  }
              }
          });

          if (authError) {
              if (authError.message.includes('already registered')) {
                  const { data: existingProfile } = await mainSupabase
                      .from('profiles')
                      .select('id, company_id')
                      .eq('email', cleanEmail)
                      .maybeSingle();

                  if (existingProfile) {
                      if (existingProfile.company_id === companyId) {
                          throw new Error("Este usuário já faz parte da sua equipe.");
                      } else {
                          throw new Error("Este e-mail já está vinculado a outra empresa no sistema.");
                      }
                  } else {
                      throw new Error("Este e-mail já possui uma conta no sistema. Entre em contato com o suporte para vincular um usuário existente.");
                  }
              }
              throw authError;
          }

          if (authData.user) {
              const { error: profileError } = await mainSupabase
                  .from('profiles')
                  .upsert({
                      id: authData.user.id,
                      full_name: name,
                      role: role,
                      company_id: companyId,
                      email: cleanEmail
                  });

              if (profileError) {
                   console.error("Profile creation error:", profileError);
                   throw new Error(`Usuário autenticado, mas erro ao criar perfil: ${profileError.message}`);
              }

              onUserAdded();
              onClose();
          } else {
              throw new Error("Não foi possível processar o cadastro. Tente novamente.");
          }

      } catch (err: any) {
          console.error(err);
          setError({ 
              message: err.message || "Erro desconhecido ao criar usuário.", 
              type: 'error' 
          });
      } finally {
          setLoading(false);
      }
  };

  const isValid = name.trim().length > 0 && email.trim().length > 0 && password.trim().length >= 6;

  return (
    <>
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 z-[120] transition-opacity backdrop-blur-sm"
          onClick={onClose}
        />
      )}

      <div 
        className={`fixed inset-y-0 right-0 max-w-md w-full bg-white dark:bg-[#23243a] shadow-2xl z-[130] transform transition-transform duration-300 ease-in-out flex flex-col border-l border-transparent dark:border-white/5 ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between p-6 border-b border-gray-100 dark:border-white/5 transition-colors">
          <h2 className="text-xl font-black text-gray-800 dark:text-white uppercase tracking-tighter">Adicionar Usuário</h2>
          <button 
            onClick={onClose}
            className="text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-white transition-colors p-2 rounded-full hover:bg-gray-100 dark:hover:bg-white/5"
          >
            <X size={24} />
          </button>
        </div>

        <div className="p-8 space-y-8 flex-1 overflow-y-auto custom-scrollbar transition-colors">
           
           {error && (
               <div className={`p-4 rounded-2xl border flex gap-3 animate-in fade-in slide-in-from-top-2 ${
                   error.type === 'error' ? 'bg-rose-50 dark:bg-rose-500/10 text-rose-700 dark:text-rose-400 border-rose-100 dark:border-rose-500/20' : 'bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-100 dark:border-amber-500/20'
               }`}>
                   <AlertCircle size={20} className="shrink-0" />
                   <span className="text-xs font-bold uppercase tracking-tight leading-relaxed">{error.message}</span>
               </div>
           )}

           <div className="relative group">
              <label className="absolute -top-2 left-3 bg-white dark:bg-[#23243a] px-1 text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest group-focus-within:text-[#2dd4bf] transition-all">
                Nome Completo
              </label>
              <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full border border-gray-200 dark:border-white/10 bg-transparent rounded-xl p-4 text-sm font-bold text-gray-700 dark:text-white outline-none focus:border-[#2dd4bf] transition-all"
                autoFocus
                placeholder="Ex: Maria Silva"
              />
           </div>

           <div className="relative group">
              <label className="absolute -top-2 left-3 bg-white dark:bg-[#23243a] px-1 text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest group-focus-within:text-[#2dd4bf] transition-all">
                Email de Acesso
              </label>
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full border border-gray-200 dark:border-white/10 bg-transparent rounded-xl p-4 text-sm font-bold text-gray-700 dark:text-white outline-none focus:border-[#2dd4bf] transition-all"
                placeholder="Ex: maria@empresa.com"
              />
           </div>

           <div className="relative group">
              <label className="absolute -top-2 left-3 bg-white dark:bg-[#23243a] px-1 text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest group-focus-within:text-[#2dd4bf] transition-all">
                Definir Senha
              </label>
              <div className="relative">
                <input 
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full border border-gray-200 dark:border-white/10 bg-transparent rounded-xl p-4 pr-12 text-sm font-bold text-gray-700 dark:text-white outline-none focus:border-[#2dd4bf] transition-all"
                    placeholder="Mínimo 6 caracteres"
                />
                <button 
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-600 hover:text-gray-600 dark:hover:text-white p-1"
                >
                    {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
           </div>

           <div className="relative group">
              <label className="absolute -top-2 left-3 bg-white dark:bg-[#23243a] px-1 text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest transition-all">
                Perfil de Acesso
              </label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as UserRole)}
                className="w-full border border-gray-200 dark:border-white/10 bg-white dark:bg-[#1a1b2e] rounded-xl p-4 text-sm font-bold text-gray-700 dark:text-white outline-none focus:border-[#2dd4bf] transition-all cursor-pointer appearance-none"
              >
                  <option value="operator">OPERADOR (APENAS PDV E VENDAS)</option>
                  <option value="admin">ADMINISTRADOR (ACESSO TOTAL)</option>
              </select>
           </div>

           <div className="bg-blue-50 dark:bg-blue-500/10 p-4 rounded-2xl border border-blue-100 dark:border-blue-500/20 transition-colors">
               <p className="text-[10px] text-blue-700 dark:text-blue-400 font-bold uppercase leading-relaxed">
                   O novo usuário poderá acessar o sistema imediatamente após o cadastro usando o e-mail e senha definidos acima.
               </p>
           </div>

        </div>

        <div className="p-8 border-t border-gray-100 dark:border-white/5 bg-gray-50/50 dark:bg-white/5 sticky bottom-0 transition-colors">
           <div className="flex gap-3">
               <button 
                 onClick={onClose}
                 className="flex-1 px-6 py-4 border border-gray-200 dark:border-white/10 rounded-2xl text-gray-500 dark:text-gray-400 font-black text-xs uppercase tracking-widest hover:bg-white dark:hover:bg-white/10 transition-all active:scale-95"
                 disabled={loading}
               >
                 Cancelar
               </button>
               <button 
                 onClick={handleSubmit}
                 disabled={!isValid || loading}
                 className={`flex-[2] px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3 shadow-xl active:scale-95 ${
                   isValid && !loading
                    ? 'bg-[#2dd4bf] hover:bg-[#14b8a6] text-white dark:text-[#1a1b2e] shadow-teal-500/20' 
                    : 'bg-gray-200 dark:bg-white/5 text-gray-400 dark:text-gray-600 cursor-not-allowed'
                 }`}
               >
                 {loading ? <Loader2 size={18} className="animate-spin" /> : 'Salvar Usuário'}
               </button>
           </div>
        </div>
      </div>
    </>
  );
};

export default UserPanel;
