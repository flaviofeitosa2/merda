import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  X, 
  User, 
  Save, 
  Trash2, 
  DollarSign, 
  Layers, 
  Edit2, 
  CheckCircle, 
  Loader2, 
  UserPlus, 
  Search, 
  ChevronDown, 
  Check, 
  Star,
  Package,
  Plus,
  ShoppingCart,
  Calendar,
  Coins
} from 'lucide-react';
import { Customer, Subscription, SubscriptionPlan, Product } from '../types';
import { supabase } from '../supabaseClient';

interface SubscriptionFormProps {
  isOpen: boolean;
  onClose: () => void;
  customers: Customer[];
  onSave: (data: Partial<Subscription>) => Promise<void>;
  initialData?: Subscription | null;
  isRenewing?: boolean;
  onDelete?: () => void;
  companyId?: string; 
}

const getLocalISOString = (dateObj: Date = new Date()) => {
    const year = dateObj.getFullYear();
    const month = String(dateObj.getMonth() + 1).padStart(2, '0');
    const day = String(dateObj.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

const parseSafeDate = (dateStr: string) => {
    if (!dateStr) return null;
    const cleanDate = dateStr.split('T')[0];
    const [y, m, d] = cleanDate.split('-').map(Number);
    return new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
};

const SubscriptionForm: React.FC<SubscriptionFormProps> = ({
  isOpen,
  onClose,
  customers,
  onSave,
  initialData,
  isRenewing,
  onDelete,
  companyId
}) => {
  const [customerId, setCustomerId] = useState('');
  const [selectedProviders, setSelectedProviders] = useState<{name: string, value: number}[]>([]);
  const [frequency, setFrequency] = useState('Mensal');
  const [startDate, setStartDate] = useState(getLocalISOString());
  const [endDate, setEndDate] = useState('');
  const [dataDePagamento, setDataDePagamento] = useState('');
  const [status, setStatus] = useState('active');
  const [encaminhamento, setEncaminhamento] = useState('');
  const [valorDaComissao, setValorDaComissao] = useState('');
  const [dataPagtoComissao, setDataPagtoComissao] = useState('');
  const [totalValueInput, setTotalValueInput] = useState('');

  // Estados para o Searchable Dropdown de Clientes
  const [isCustomerSelectOpen, setIsCustomerSelectOpen] = useState(false);
  const [customerSearchQuery, setCustomerSearchQuery] = useState('');
  const customerDropdownRef = useRef<HTMLDivElement>(null);

  // Estados para o Searchable Dropdown de Parceiros
  const [isPartnerSelectOpen, setIsPartnerSelectOpen] = useState(false);
  const [partnerSearchQuery, setPartnerSearchQuery] = useState('');
  const partnerDropdownRef = useRef<HTMLDivElement>(null);

  // Estados para Seleção Múltipla de Planos
  const [isPlanSelectOpen, setIsPlanSelectOpen] = useState(false);
  const [planSearchQuery, setPlanSearchQuery] = useState('');
  const planDropdownRef = useRef<HTMLDivElement>(null);

  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [subscriptionProducts, setSubscriptionProducts] = useState<Product[]>([]);
  const [loadingPlans, setLoadingPlans] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (initialData) {
        setCustomerId(initialData.customer_id || '');
        setSelectedProviders([{ name: initialData.provider, value: initialData.value }]);
        setFrequency(initialData.frequency || 'Mensal');
        
        const safeStart = initialData.start_date ? initialData.start_date.split('T')[0] : getLocalISOString();
        const safeEnd = initialData.end_date ? initialData.end_date.split('T')[0] : '';
        const safePayment = initialData.payment_date ? initialData.payment_date.split('T')[0] : '';
        const safeCommPayment = initialData.commission_payment_date ? initialData.commission_payment_date.split('T')[0] : '';

        setStartDate(safeStart);
        setEndDate(safeEnd); 
        setDataDePagamento(safePayment);
        setStatus(initialData.status || 'active');
        setEncaminhamento(initialData.referral || '');
        setValorDaComissao(initialData.commission_value?.toString() || '');
        setDataPagtoComissao(safeCommPayment);
      } else {
        setCustomerId(''); 
        setSelectedProviders([]); 
        setFrequency('Mensal'); 
        setStatus('active');
        setStartDate(getLocalISOString());
        setEndDate(''); 
        setDataDePagamento(''); 
        setEncaminhamento(''); 
        setValorDaComissao(''); 
        setDataPagtoComissao('');
      }
      setCustomerSearchQuery('');
      setIsCustomerSelectOpen(false);
      setIsPartnerSelectOpen(false);
      setIsPlanSelectOpen(false);
      setPartnerSearchQuery('');
      setPlanSearchQuery('');
    }
  }, [isOpen, initialData]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (customerDropdownRef.current && !customerDropdownRef.current.contains(event.target as Node)) {
        setIsCustomerSelectOpen(false);
      }
      if (partnerDropdownRef.current && !partnerDropdownRef.current.contains(event.target as Node)) {
        setIsPartnerSelectOpen(false);
      }
      if (planDropdownRef.current && !planDropdownRef.current.contains(event.target as Node)) {
        setIsPlanSelectOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (startDate && isOpen) {
        const dateObj = parseSafeDate(startDate);
        if (dateObj) {
            if (frequency === 'Anual') {
                dateObj.setUTCFullYear(dateObj.getUTCFullYear() + 1);
            } else {
                dateObj.setUTCMonth(dateObj.getUTCMonth() + 1);
            }
            
            const calculatedEnd = dateObj.toISOString().split('T')[0];
            // Sempre recalcular se for novo ou renovação. Se for edição, recalcular apenas se o usuário mudar a data inicial
            if (!initialData || isRenewing) {
                setEndDate(calculatedEnd);
            }
        }
    }
  }, [startDate, frequency, isOpen]);

  const fetchPlansAndProducts = async () => {
    if (!companyId) return;
    setLoadingPlans(true);
    try {
      const [plansRes, prodRes] = await Promise.all([
          supabase.from('subscription_plans').select('*').eq('id_da_empresa', companyId).order('name'),
          supabase.from('products').select('*').eq('company_id', companyId).order('name')
      ]);
      if (plansRes.data) setPlans(plansRes.data);
      if (prodRes.data) {
          const triggers = prodRes.data.filter((p: any) => p.is_subscription_trigger === true);
          setSubscriptionProducts(triggers);
      }
    } catch (err) { console.error(err); } 
    finally { setLoadingPlans(false); }
  };

  useEffect(() => { if (isOpen) fetchPlansAndProducts(); }, [isOpen, companyId]);

  const filteredCustomers = useMemo(() => {
    if (!customerSearchQuery.trim()) return customers;
    const query = customerSearchQuery.toLowerCase();
    return customers.filter(c => 
      c.name.toLowerCase().includes(query) || 
      (c.cpf && c.cpf.includes(query)) ||
      (c.cnpj && c.cnpj.includes(query))
    );
  }, [customers, customerSearchQuery]);

  const filteredPartners = useMemo(() => {
    const onlyPartners = customers.filter(c => c.isPartner);
    if (!partnerSearchQuery.trim()) return onlyPartners;
    const query = partnerSearchQuery.toLowerCase();
    return onlyPartners.filter(c => 
      c.name.toLowerCase().includes(query) || 
      (c.cpf && c.cpf.includes(query)) ||
      (c.cnpj && c.cnpj.includes(query))
    );
  }, [customers, partnerSearchQuery]);

  const filteredPlans = useMemo(() => {
      const allOptions = [
          ...subscriptionProducts.map(p => ({ id: p.id, name: p.name, value: p.price, type: 'PRODUTO' })),
          ...plans.map(p => ({ id: p.id, name: p.name, value: 0, type: 'PLANO' }))
      ];
      if (!planSearchQuery.trim()) return allOptions;
      const q = planSearchQuery.toLowerCase();
      return allOptions.filter(o => o.name.toLowerCase().includes(q));
  }, [subscriptionProducts, plans, planSearchQuery]);

  const selectedCustomer = useMemo(() => {
    return customers.find(c => c.id === customerId);
  }, [customers, customerId]);

  const togglePlanSelection = (plan: {name: string, value: number}) => {
      setSelectedProviders(prev => {
          const exists = prev.find(p => p.name === plan.name);
          if (exists) return prev.filter(p => p.name !== plan.name);
          return [...prev, plan];
      });
  };

  const totalSubscriptionValue = useMemo(() => {
      return selectedProviders.reduce((acc, p) => acc + p.value, 0);
  }, [selectedProviders]);

  useEffect(() => {
    setTotalValueInput(totalSubscriptionValue.toFixed(2).replace('.', ','));
  }, [totalSubscriptionValue]);

  const handleTotalValueChange = (val: number) => {
      if (selectedProviders.length === 0) return;
      
      if (selectedProviders.length === 1) {
          setSelectedProviders([{ ...selectedProviders[0], value: val }]);
      } else {
          const currentTotal = selectedProviders.reduce((acc, p) => acc + p.value, 0);
          if (currentTotal === 0) {
              const newProviders = [...selectedProviders];
              newProviders[0] = { ...newProviders[0], value: val };
              setSelectedProviders(newProviders);
          } else {
              const ratio = val / currentTotal;
              setSelectedProviders(selectedProviders.map(p => ({
                  ...p,
                  value: p.value * ratio
              })));
          }
      }
  };

  const referralPartner = useMemo(() => {
      if (!encaminhamento) return null;
      return customers.find(c => c.id === encaminhamento || c.name === encaminhamento);
  }, [customers, encaminhamento]);

  const handleSubmitSubscription = async () => {
    if (!customerId || selectedProviders.length === 0) return alert("Selecione o cliente e ao menos um plano.");
    
    try {
        const parseAmount = (val: string | number | null | undefined) => {
            if (!val) return 0;
            let raw = val.toString().replace(/[^\d.,]/g, '');
            const lastComma = raw.lastIndexOf(',');
            const lastDot = raw.lastIndexOf('.');
            if (lastComma > lastDot) {
                raw = raw.replace(/\./g, '').replace(',', '.');
            } else if (lastDot > lastComma) {
                if (lastComma === -1 && raw.length - lastDot === 4) {
                    raw = raw.replace(/\./g, '');
                } else {
                    raw = raw.replace(/,/g, '');
                }
            }
            return parseFloat(raw) || 0;
        };

        for (let i = 0; i < selectedProviders.length; i++) {
            const providerData = selectedProviders[i];
            await onSave({
                id: (i === 0 && initialData?.id && !initialData.id.startsWith('ghost-') && !isRenewing) ? initialData.id : undefined,
                customer_id: customerId, 
                provider: providerData.name, 
                frequency, 
                start_date: startDate, 
                end_date: endDate || startDate, 
                value: providerData.value, 
                status: status as any, 
                payment_date: dataDePagamento || null,
                referral: encaminhamento, 
                commission_value: parseAmount(valorDaComissao),
                commission_payment_date: dataPagtoComissao || null
            });
        }
        onClose();
    } catch (error) {
        console.error("Erro ao salvar assinaturas em lote", error);
    }
  };

  return (
    <>
      <div className={`fixed inset-0 bg-gray-900/60 backdrop-blur-sm z-[80] transition-opacity ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={onClose} />
      <div className={`fixed inset-y-0 right-0 w-full max-w-xl bg-white shadow-2xl z-[90] transform transition-transform duration-300 flex flex-col ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
          <div className="p-8 border-b border-gray-100 flex justify-between items-start">
              <div><h2 className="text-2xl font-bold text-gray-900">{initialData?.id && !isRenewing && !initialData.id.startsWith('ghost-') ? 'Editar Assinatura' : 'Nova Assinatura Múltipla'}</h2><p className="text-sm text-gray-500">Selecione um ou mais planos para este contrato.</p></div>
              <button onClick={onClose} className="p-2 bg-gray-50 text-gray-400 rounded-full hover:bg-gray-100 transition-colors"><X size={24} /></button>
          </div>
          <div className="flex-1 overflow-y-auto p-8 space-y-8 bg-gray-50/20 custom-scrollbar">
              <section className="space-y-4">
                  <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest flex items-center gap-2"><User size={14} /> Dados do Contrato</h3>
                  <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-6">
                      <div className="relative" ref={customerDropdownRef}>
                          <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Assinante / Cliente *</label>
                          <div 
                              onClick={() => setIsCustomerSelectOpen(!isCustomerSelectOpen)}
                              className={`w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 flex items-center justify-between cursor-pointer transition-all ${isCustomerSelectOpen ? 'ring-2 ring-indigo-500/20 border-indigo-500 bg-white' : ''}`}
                          >
                              {selectedCustomer ? (
                                  <div className="flex items-center gap-3 overflow-hidden">
                                      <div className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center text-[10px] font-black uppercase shrink-0">
                                          {selectedCustomer.avatarText || selectedCustomer.name.substring(0, 2)}
                                      </div>
                                      <span className="font-bold text-sm text-gray-800 truncate uppercase">{selectedCustomer.name}</span>
                                  </div>
                              ) : (
                                  <span className="text-sm text-gray-400 font-medium">Selecione o cliente...</span>
                              )}
                              <ChevronDown size={18} className={`text-gray-400 transition-transform ${isCustomerSelectOpen ? 'rotate-180' : ''}`} />
                          </div>

                          {isCustomerSelectOpen && (
                              <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-100 shadow-2xl rounded-2xl z-[100] overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                                  <div className="p-3 border-b border-gray-50 bg-gray-50/50">
                                      <div className="relative group">
                                          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-indigo-500" size={16} />
                                          <input autoFocus type="text" placeholder="Buscar por nome ou documento..." className="w-full bg-white border border-gray-200 rounded-xl pl-10 pr-4 py-2 text-sm font-medium outline-none focus:border-indigo-500 transition-all" value={customerSearchQuery} onChange={(e) => setCustomerSearchQuery(e.target.value)} onClick={(e) => e.stopPropagation()}/>
                                      </div>
                                  </div>
                                  <div className="max-h-[250px] overflow-y-auto custom-scrollbar">
                                      {filteredCustomers.length === 0 ? (<div className="p-8 text-center text-gray-400 text-xs italic uppercase font-bold tracking-widest">Nenhum cliente encontrado</div>) : (
                                          filteredCustomers.map(c => (
                                              <div key={c.id} onClick={(e) => { e.stopPropagation(); setCustomerId(c.id); setIsCustomerSelectOpen(false); setCustomerSearchQuery(''); }} className={`px-4 py-3 hover:bg-indigo-50 transition-colors cursor-pointer flex items-center justify-between group ${customerId === c.id ? 'bg-indigo-50' : ''}`}><div className="flex items-center gap-3 overflow-hidden"><div className={`w-8 h-8 rounded-lg flex items-center justify-center text-[10px] font-black uppercase transition-colors ${customerId === c.id ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-400 group-hover:bg-indigo-200 group-hover:text-indigo-600'}`}>{c.avatarText || c.name.substring(0, 2)}</div><div className="min-w-0"><p className={`text-xs font-bold uppercase truncate ${customerId === c.id ? 'text-indigo-600' : 'text-gray-700'}`}>{c.name}</p><p className="text-[9px] text-gray-400 font-medium">{c.cpf || c.cnpj || 'Sem documento'}</p></div></div>{customerId === c.id && <Check size={16} className="text-indigo-600" strokeWidth={3} />}</div>
                                          ))
                                      )}
                                  </div>
                              </div>
                          )}
                      </div>

                      <div className="relative" ref={planDropdownRef}>
                          <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Plano(s) e Serviço(s) *</label>
                          <div 
                              onClick={() => setIsPlanSelectOpen(!isPlanSelectOpen)}
                              className={`w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 flex items-center justify-between cursor-pointer transition-all ${isPlanSelectOpen ? 'ring-2 ring-indigo-500/20 border-indigo-500 bg-white' : ''}`}
                          >
                              <div className="flex flex-wrap gap-1.5 overflow-hidden">
                                  {selectedProviders.length > 0 ? (
                                      selectedProviders.map(p => (
                                          <span key={p.name} className="bg-indigo-600 text-white text-[9px] font-black uppercase px-2 py-1 rounded-lg flex items-center gap-1">
                                              {p.name}
                                              <X size={10} onClick={(e) => { e.stopPropagation(); togglePlanSelection(p); }} className="hover:text-rose-200" />
                                          </span>
                                      ))
                                  ) : (
                                      <span className="text-sm text-gray-400 font-medium">Selecione um ou mais planos...</span>
                                  )}
                              </div>
                              <Plus size={18} className={`text-gray-400 transition-transform ${isPlanSelectOpen ? 'rotate-45' : ''}`} />
                          </div>

                          {isPlanSelectOpen && (
                              <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-100 shadow-2xl rounded-2xl z-[100] overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                                  <div className="p-3 border-b border-gray-50 bg-gray-50/50">
                                      <div className="relative group">
                                          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-indigo-500" size={16} />
                                          <input autoFocus type="text" placeholder="Buscar planos..." className="w-full bg-white border border-gray-200 rounded-xl pl-10 pr-4 py-2 text-sm font-medium outline-none focus:border-indigo-500 transition-all" value={planSearchQuery} onChange={(e) => setPlanSearchQuery(e.target.value)} onClick={(e) => e.stopPropagation()}/>
                                      </div>
                                  </div>
                                  <div className="max-h-[300px] overflow-y-auto custom-scrollbar">
                                      {filteredPlans.map(plan => {
                                          const isSelected = selectedProviders.some(p => p.name === plan.name);
                                          return (
                                              <div 
                                                  key={plan.id} 
                                                  onClick={(e) => { e.stopPropagation(); togglePlanSelection({ name: plan.name, value: plan.value }); }}
                                                  className={`px-4 py-3 hover:bg-indigo-50 transition-colors cursor-pointer flex items-center justify-between group ${isSelected ? 'bg-indigo-50/50' : ''}`}
                                              >
                                                  <div className="flex items-center gap-3">
                                                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${isSelected ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-400'}`}>
                                                          {plan.type === 'PRODUTO' ? <Package size={16} /> : <ShoppingCart size={16} />}
                                                      </div>
                                                      <div>
                                                          <p className={`text-xs font-bold uppercase ${isSelected ? 'text-indigo-600' : 'text-gray-700'}`}>{plan.name}</p>
                                                          <p className="text-[9px] text-gray-400 font-bold uppercase">{plan.value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })} • {plan.type}</p>
                                                      </div>
                                                  </div>
                                                  {isSelected ? <CheckCircle size={18} className="text-indigo-600" /> : <div className="w-5 h-5 rounded-full border-2 border-gray-100 group-hover:border-indigo-200"></div>}
                                              </div>
                                          );
                                      })}
                                  </div>
                              </div>
                          )}
                          
                          <button 
                            type="button"
                            onClick={() => setIsPlanSelectOpen(true)}
                            className="mt-3 flex items-center gap-2 text-[10px] font-black text-indigo-600 hover:text-indigo-700 uppercase tracking-widest transition-all group"
                          >
                            <div className="w-5 h-5 rounded-full bg-indigo-50 flex items-center justify-center group-hover:bg-indigo-100 transition-colors">
                                <Plus size={12} strokeWidth={3} />
                            </div>
                            Incluir Novo Plano
                          </button>
                      </div>
                  </div>
              </section>

              <section className="space-y-4">
                  <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest flex items-center gap-2"><Layers size={14} /> Ciclo e Valores</h3>
                  <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-6">
                      <div className="grid grid-cols-2 gap-4">
                          <div><label className="block text-[10px] font-black text-gray-400 uppercase mb-2">Frequência</label><div className="flex bg-gray-100 p-1 rounded-xl">{['Mensal', 'Anual'].map(f => (<button key={f} onClick={() => setFrequency(f)} className={`flex-1 py-2 rounded-lg text-[10px] font-black transition-all ${frequency === f ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}>{f}</button>))}</div></div>
                          <div><label className="block text-[10px] font-black text-gray-400 uppercase mb-2">Status do Contrato</label><div className="flex bg-gray-100 p-1 rounded-xl">{['active', 'cancelled'].map(s => (<button key={s} onClick={() => setStatus(s)} className={`flex-1 py-2 rounded-lg text-[10px] font-black transition-all ${status === s ? (s === 'active' ? 'bg-emerald-500 text-white shadow-sm' : 'bg-rose-500 text-white shadow-sm') : 'text-gray-400 hover:text-gray-600'}`}>{s === 'active' ? 'ATIVO' : 'CANCELADO'}</button>))}</div></div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                          <div>
                              <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">Valor Total Consolidado</label>
                              <div className="bg-indigo-50 border border-indigo-100 rounded-xl px-4 py-3 flex items-center justify-between gap-2">
                                  <span className="text-indigo-400 font-bold text-sm">R$</span>
                                  <input 
                                    type="text"
                                    className="bg-transparent border-none text-right text-lg font-black text-indigo-700 tabular-nums outline-none w-full"
                                    value={totalValueInput}
                                    onChange={e => setTotalValueInput(e.target.value)}
                                    onBlur={() => {
                                        let raw = totalValueInput.toString().replace(/[^\d.,]/g, '');
                                        const lastComma = raw.lastIndexOf(',');
                                        const lastDot = raw.lastIndexOf('.');
                                        if (lastComma > lastDot) {
                                            raw = raw.replace(/\./g, '').replace(',', '.');
                                        } else if (lastDot > lastComma) {
                                            if (lastComma === -1 && raw.length - lastDot === 4) {
                                                raw = raw.replace(/\./g, '');
                                            } else {
                                                raw = raw.replace(/,/g, '');
                                            }
                                        }
                                        const val = parseFloat(raw) || 0;
                                        handleTotalValueChange(val);
                                    }}
                                  />
                              </div>
                          </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                          <div><label className="block text-[10px] font-black text-gray-400 uppercase mb-2">Data Inicial</label><input type="date" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 font-bold text-xs outline-none focus:border-indigo-500" value={startDate} onChange={e => setStartDate(e.target.value)} /></div>
                          <div><label className="block text-[10px] font-black text-indigo-400 uppercase mb-2">Vencimento da Parcela</label><input type="date" className="w-full bg-indigo-50 border border-indigo-100 rounded-xl px-4 py-3 font-bold text-xs text-indigo-700 outline-none" value={endDate} onChange={e => setEndDate(e.target.value)} /></div>
                      </div>
                      <div className={`p-4 rounded-2xl border flex justify-between items-center transition-colors ${dataDePagamento ? 'bg-emerald-50 border-emerald-100' : 'bg-gray-50 border-gray-200'}`}>
                          <div className="flex items-center gap-3"><div className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${dataDePagamento ? 'bg-emerald-100 text-emerald-600' : 'bg-white text-gray-300'}`}><DollarSign size={20} /></div><span className="text-xs font-black text-gray-700">Lançar como Pago</span></div>
                          <input type="date" className="bg-white border rounded-lg px-2 py-1 text-[10px] font-bold outline-none border-gray-200 focus:border-emerald-500" value={dataDePagamento} onChange={e => setDataDePagamento(e.target.value)} />
                      </div>
                  </div>
              </section>

              <section className="space-y-4">
                  <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest flex items-center gap-2"><UserPlus size={14} /> Indicação</h3>
                  <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-6">
                      <div className="relative" ref={partnerDropdownRef}>
                          <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Indicado por (Parceiro)</label>
                          <div onClick={() => setIsPartnerSelectOpen(!isPartnerSelectOpen)} className={`w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 flex items-center justify-between cursor-pointer transition-all ${isPartnerSelectOpen ? 'ring-2 ring-amber-500/20 border-amber-500 bg-white' : ''}`}>
                              {encaminhamento ? (
                                  <div className="flex items-center gap-3 overflow-hidden"><div className="w-6 h-6 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center text-[10px] font-black uppercase shrink-0"><Star size={10} fill="currentColor" /></div><span className="font-bold text-sm text-gray-800 truncate uppercase">{referralPartner?.name || encaminhamento}</span></div>
                              ) : (<span className="text-sm text-gray-400 font-medium">Selecione o parceiro...</span>)}
                              <ChevronDown size={18} className={`text-gray-400 transition-transform ${isPartnerSelectOpen ? 'rotate-180' : ''}`} />
                          </div>
                          {isPartnerSelectOpen && (
                              <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-100 shadow-2xl rounded-2xl z-[100] overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                                  <div className="p-3 border-b border-gray-50 bg-gray-50/50"><div className="relative group"><Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-amber-500" size={16} /><input autoFocus type="text" placeholder="Buscar parceiro..." className="w-full bg-white border border-gray-200 rounded-xl pl-10 pr-4 py-2 text-sm font-medium outline-none focus:border-amber-500 transition-all" value={partnerSearchQuery} onChange={(e) => setPartnerSearchQuery(e.target.value)} onClick={(e) => e.stopPropagation()}/></div></div>
                                  <div className="max-h-[200px] overflow-y-auto custom-scrollbar">
                                      {filteredPartners.length === 0 ? (<div className="p-8 text-center text-gray-400 text-xs italic uppercase font-bold tracking-widest">Nenhum parceiro encontrado</div>) : (
                                          /* Fix: Replaced 'c' with 'p' in the iteration variable usage below */
                                          filteredPartners.map(p => {
                                              const isSelected = encaminhamento === p.id || encaminhamento === p.name;
                                              return (
                                                  <div key={p.id} onClick={(e) => { e.stopPropagation(); setEncaminhamento(p.id); setIsPartnerSelectOpen(false); setPartnerSearchQuery(''); }} className={`px-4 py-3 hover:bg-amber-50 transition-colors cursor-pointer flex items-center justify-between group ${isSelected ? 'bg-amber-50' : ''}`}><div className="flex items-center gap-3 overflow-hidden"><div className={`w-8 h-8 rounded-lg flex items-center justify-center text-[10px] font-black uppercase transition-colors ${isSelected ? 'bg-amber-500 text-white' : 'bg-gray-100 text-gray-400 group-hover:bg-indigo-200 group-hover:text-indigo-600'}`}>{p.avatarText || p.name.substring(0, 2)}</div><div className="min-w-0"><p className={`text-xs font-bold uppercase truncate ${isSelected ? 'text-amber-600' : 'text-gray-700'}`}>{p.name}</p><p className="text-[9px] text-gray-400 font-medium">{p.cpf || p.cnpj || 'Sem documento'}</p></div></div>{isSelected && <Check size={16} className="text-amber-600" strokeWidth={3} />}</div>
                                              );
                                          })
                                      )}
                                      {encaminhamento && (<div onClick={(e) => { e.stopPropagation(); setEncaminhamento(''); setIsPartnerSelectOpen(false); }} className="px-4 py-3 border-t border-gray-50 text-rose-500 text-xs font-black uppercase tracking-widest hover:bg-rose-50 cursor-pointer text-center">Remover Indicação</div>)}
                                  </div>
                              </div>
                          )}
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                          <div className="relative group">
                              <label className="absolute -top-2.5 left-4 bg-white px-1 text-[10px] font-black text-gray-400 uppercase tracking-widest z-10 transition-all">Valor Pago ao Indicador</label>
                              <div className="flex items-center gap-2 border border-gray-200 rounded-xl px-4 py-3 bg-white focus-within:border-amber-400 transition-all">
                                  <Coins size={16} className="text-gray-300" />
                                  <input 
                                      type="text" 
                                      className="w-full bg-transparent outline-none text-sm font-bold text-gray-700" 
                                      placeholder="0,00"
                                      value={valorDaComissao}
                                      onChange={e => setValorDaComissao(e.target.value)}
                                  />
                              </div>
                          </div>
                          <div className="relative group">
                              <label className="absolute -top-2.5 left-4 bg-white px-1 text-[10px] font-black text-gray-400 uppercase tracking-widest z-10 transition-all">Data Pagto Comissão</label>
                              <div className="flex items-center gap-2 border border-gray-200 rounded-xl px-4 py-3 bg-white focus-within:border-amber-400 transition-all">
                                  <Calendar size={16} className="text-gray-300" />
                                  <input 
                                      type="date" 
                                      className="w-full bg-transparent outline-none text-sm font-bold text-gray-700" 
                                      value={dataPagtoComissao}
                                      onChange={e => setDataPagtoComissao(e.target.value)}
                                  />
                              </div>
                          </div>
                      </div>
                  </div>
              </section>
          </div>
          <div className="p-8 border-t border-gray-100 flex justify-between items-center bg-white">
              {onDelete && <button onClick={onDelete} className="text-rose-500 hover:bg-rose-50 p-3 rounded-xl transition-colors"><Trash2 size={20} /></button>}
              <div className="flex gap-4 ml-auto">
                  <button onClick={onClose} className="px-8 py-3 border border-gray-200 rounded-xl text-gray-500 font-bold text-sm hover:bg-gray-50 transition-colors">Cancelar</button>
                  <button 
                    onClick={handleSubmitSubscription} 
                    className={`px-10 py-3 rounded-xl font-bold text-sm flex items-center gap-2 transform active:scale-95 transition-all shadow-lg ${selectedProviders.length > 0 ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-100' : 'bg-gray-200 text-gray-400 cursor-not-allowed'}`}
                  >
                      <Save size={18} /> {selectedProviders.length > 1 ? `Salvar ${selectedProviders.length} Assinaturas` : 'Salvar Assinatura'}
                  </button>
              </div>
          </div>
      </div>
    </>
  );
};

export default SubscriptionForm;