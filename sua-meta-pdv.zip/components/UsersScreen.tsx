
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  HelpCircle, 
  Plus, 
  List,
  User as UserIcon,
  Shield,
  ChevronRight,
  TrendingUp,
  DollarSign,
  ShoppingCart,
  Loader2,
  CalendarDays,
  ChevronDown
} from 'lucide-react';
import UserPanel from './UserPanel';
import UserDetailPanel from './UserDetailPanel';
import UserMenu from './UserMenu';
import { UserProfile, Sale } from '../types';
import { supabase } from '../supabaseClient';

interface UsersScreenProps {
  toggleSidebar?: () => void;
  userProfile: UserProfile;
  sales: Sale[]; // Recebendo lista mestre
}

const UsersScreen: React.FC<UsersScreenProps> = ({ toggleSidebar, userProfile, sales = [] }) => {
  const [isUserPanelOpen, setIsUserPanelOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<'current' | 'previous'>('current');

  const hasAdminAccess = ['admin', 'owner', 'master', 'mestre'].includes(userProfile.role);
  const isOperator = userProfile.role === 'operator' || userProfile.role === 'operador';

  const fetchUsers = useCallback(async () => {
        if (!userProfile?.company_id) return;
        setLoading(true);
        try {
            let usersList: UserProfile[] = [];
            if (!hasAdminAccess) {
                usersList = [userProfile];
            } else {
                const { data: uData, error: uError } = await supabase
                    .from('profiles')
                    .select('*')
                    .eq('company_id', userProfile.company_id)
                    .in('role', ['master', 'mestre', 'admin', 'owner', 'operator', 'operador'])
                    .order('full_name');
                if (!uError && uData) usersList = uData as UserProfile[];
            }
            setUsers(usersList);
        } catch (err) {
            console.error("Error fetching users:", err);
        } finally {
            setLoading(false);
        }
  }, [userProfile, hasAdminAccess]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  // --- Motor de Cálculo de Datas Consistente ---
  const dateBoundaries = useMemo(() => {
      const now = new Date();
      let start: Date;
      let end: Date;

      if (period === 'current') {
          start = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
          end = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
      } else {
          start = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0, 0);
          end = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
      }
      return { startT: start.getTime(), endT: end.getTime() };
  }, [period]);

  // Filtra as vendas do período e normaliza fuso horário
  const filteredSalesForMetrics = useMemo(() => {
    return sales.filter(s => {
        if (s.status !== 'completed' && s.status) return false;
        
        const sTime = new Date(s.date).getTime();
        if (sTime < dateBoundaries.startT || sTime > dateBoundaries.endT) return false;

        // Filtro de Dono da Venda para Operadores
        if (isOperator) {
            const sellerName = (s.sellerName || (s as any).seller_name || '').trim().toLowerCase();
            const currentName = (userProfile.full_name || '').trim().toLowerCase();
            if (sellerName !== currentName) return false;
        }

        return true;
    });
  }, [sales, isOperator, userProfile.full_name, dateBoundaries]);

  const userStats = useMemo(() => {
      const statsMap = new Map<string, { revenue: number; count: number }>();
      let totalRevenue = 0;

      // Inicializa mapa com usuários da lista, usando normalização rigorosa
      users.forEach(u => {
          const nameKey = (u.full_name || u.email || 'sem nome').trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
          statsMap.set(nameKey, { revenue: 0, count: 0 });
      });

      filteredSalesForMetrics.forEach(sale => {
          const rawName = sale.sellerName || (sale as any).seller_name;
          const val = Number(sale.total) || 0;
          
          if (rawName) {
              // Normalização também na venda para garantir o de-para
              const key = rawName.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
              if (statsMap.has(key)) {
                  const current = statsMap.get(key)!;
                  statsMap.set(key, { 
                      revenue: current.revenue + val, 
                      count: current.count + 1 
                  });
              }
              totalRevenue += val;
          }
      });

      return users.map(user => {
          const key = (user.full_name || user.email || '').trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
          const stat = statsMap.get(key) || { revenue: 0, count: 0 };
          const percent = totalRevenue > 0 ? (stat.revenue / totalRevenue) * 100 : 0;
          
          return {
              ...user,
              revenue: stat.revenue,
              count: stat.count,
              percent: percent
          };
      }).sort((a, b) => b.revenue - a.revenue);

  }, [users, filteredSalesForMetrics]);

  const grandTotalRevenue = useMemo(() => {
      return filteredSalesForMetrics.reduce((acc, s) => acc + (Number(s.total) || 0), 0);
  }, [filteredSalesForMetrics]);

  const grandTotalSalesCount = useMemo(() => {
      return filteredSalesForMetrics.length;
  }, [filteredSalesForMetrics]);

  const chartGradient = useMemo(() => {
      if (userStats.length === 0) return 'conic-gradient(#e5e7eb 0% 100%)';
      let currentDeg = 0;
      const colors = ['#2dd4bf', '#818cf8', '#fbbf24', '#f472b6', '#34d399', '#60a5fa', '#a78bfa'];
      const segments = userStats.map((u, i) => {
          const deg = (u.percent / 100) * 360;
          const color = colors[i % colors.length];
          const start = currentDeg;
          const end = currentDeg + deg;
          currentDeg = end;
          return `${color} ${start}deg ${end}deg`;
      });
      if (currentDeg < 360) segments.push(`transparent ${currentDeg}deg 360deg`);
      return `conic-gradient(${segments.join(', ')})`;
  }, [userStats]);

  if (selectedUser) {
    return (
      <UserDetailPanel 
        user={selectedUser} 
        currentUser={userProfile} 
        onBack={() => { setSelectedUser(null); fetchUsers(); }}
        companyId={userProfile.company_id}
      />
    );
  }

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#EEF2F6] dark:bg-[#1a1b2e] font-sans transition-colors">
      <header className="bg-white dark:bg-[#23243a] h-[90px] px-4 lg:px-10 flex justify-between items-center shrink-0 border-b border-gray-100 dark:border-white/5 sticky top-0 z-50 transition-colors">
          <div className="flex items-center gap-4">
              <button 
                  onClick={toggleSidebar} 
                  className="lg:hidden p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-xl transition-colors"
              >
                  <List size={26} />
              </button>
              <div>
                  <h1 className="text-[23px] font-mono font-black text-gray-900 dark:text-white tracking-tighter uppercase leading-none italic">Usuários</h1>
                  <p className="text-[10px] text-gray-400 font-black uppercase tracking-[0.3em] mt-1 hidden sm:block">Equipe e Performance de Vendas</p>
              </div>
          </div>
          <div className="flex items-center gap-4">
              <button className="hidden sm:flex items-center gap-1.5 text-xs font-bold text-gray-500 dark:text-gray-400 bg-white dark:bg-white/5 hover:bg-gray-50 dark:hover:bg-white/10 border border-gray-200 dark:border-white/10 px-4 py-2 rounded-full transition-all">
                  <HelpCircle size={14} /> Ajuda
              </button>
              <UserMenu />
          </div>
      </header>

      <div className="flex-1 overflow-y-auto p-4 sm:p-8 custom-scrollbar">
          <div className="max-w-7xl mx-auto space-y-8 pb-20">
              
              <div className="flex flex-col lg:flex-row gap-8">
                  {/* Stats Chart Card */}
                  <div className="lg:w-1/3 bg-white dark:bg-[#23243a] p-8 rounded-[2rem] shadow-sm border border-gray-100 dark:border-white/5 flex flex-col items-center justify-center text-center transition-colors relative">
                      <h3 className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-8">
                          {isOperator ? 'Meu Desempenho' : 'Participação no Faturamento'}
                      </h3>
                      
                      <div className="relative w-48 h-48 mb-8">
                          <div 
                              className="w-full h-full rounded-full shadow-inner" 
                              style={{ background: chartGradient }}
                          ></div>
                          <div className="absolute inset-4 bg-white dark:bg-[#23243a] rounded-full flex flex-col items-center justify-center shadow-sm transition-colors">
                              <span className="text-2xl font-black text-gray-800 dark:text-white leading-none">
                                  {isOperator ? grandTotalSalesCount : userStats.length}
                              </span>
                              <span className="text-[8px] font-bold text-gray-400 dark:text-gray-500 uppercase mt-1">
                                  {isOperator ? 'Vendas' : 'Usuários'}
                              </span>
                          </div>
                      </div>

                      {/* OCULTA O VALOR TOTAL PARA OPERADORES */}
                      {!isOperator && (
                        <div className="space-y-1 animate-in fade-in duration-500">
                            <p className="text-2xl font-black text-gray-800 dark:text-white">{grandTotalRevenue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
                            <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest">Total Vendido no Período</p>
                        </div>
                      )}
                  </div>

                  {/* Users List Card */}
                  <div className="lg:w-2/3 bg-white dark:bg-[#23243a] rounded-[2rem] shadow-sm border border-gray-100 dark:border-white/5 overflow-hidden flex flex-col transition-colors">
                      <div className="p-8 border-b border-gray-50 dark:border-white/5 flex flex-col sm:row justify-between items-start sm:items-center bg-gray-50/30 dark:bg-white/5 transition-colors gap-4">
                          <div>
                            <h3 className="text-lg font-bold text-gray-800 dark:text-white uppercase tracking-tight flex items-center gap-2">
                                <Shield size={20} className="text-indigo-600 dark:text-indigo-400" /> Membros da Equipe
                            </h3>
                          </div>

                          <div className="flex items-center gap-3 w-full sm:w-auto">
                              <div className="flex bg-gray-100 dark:bg-[#1a1b2e] p-1 rounded-xl border border-gray-200 dark:border-white/10 transition-colors">
                                  <button 
                                      onClick={() => setPeriod('current')}
                                      className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all ${period === 'current' ? 'bg-white dark:bg-indigo-600 text-indigo-600 dark:text-white shadow-sm' : 'text-gray-400'}`}
                                  >
                                      Mês Atual
                                  </button>
                                  <button 
                                      onClick={() => setPeriod('previous')}
                                      className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all ${period === 'previous' ? 'bg-white dark:bg-indigo-600 text-indigo-600 dark:text-white shadow-sm' : 'text-gray-400'}`}
                                  >
                                      Anterior
                                  </button>
                              </div>

                              {hasAdminAccess && (
                                  <button 
                                    onClick={() => setIsUserPanelOpen(true)}
                                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-black py-2.5 px-6 rounded-xl shadow-lg shadow-indigo-100 dark:shadow-none flex items-center gap-2 text-[10px] uppercase tracking-widest transition-all transform active:scale-95 ml-auto sm:ml-0"
                                  >
                                      <Plus size={18} strokeWidth={3} /> <span className="hidden sm:inline">Adicionar</span>
                                  </button>
                              )}
                          </div>
                      </div>

                      <div className="flex-1 overflow-y-auto max-h-[500px] custom-scrollbar">
                          {loading ? (
                              <div className="p-20 text-center text-gray-400 dark:text-gray-600 uppercase text-[10px] font-bold tracking-widest">
                                  <Loader2 className="animate-spin inline-block mr-2" size={16} /> Sincronizando equipe...
                              </div>
                          ) : userStats.length === 0 ? (
                              <div className="p-20 text-center text-gray-400 dark:text-gray-600 uppercase text-[10px] font-bold tracking-widest">
                                  Nenhum usuário encontrado.
                              </div>
                          ) : (
                              <div className="divide-y divide-gray-50 dark:divide-white/5">
                                  {userStats.map((user) => (
                                      <div 
                                          key={user.id} 
                                          onClick={() => setSelectedUser(user)}
                                          className="p-6 flex items-center gap-6 hover:bg-gray-50/50 dark:hover:bg-white/5 transition-colors cursor-pointer group"
                                      >
                                          <div className="w-14 h-14 rounded-2xl bg-gray-100 dark:bg-white/5 flex items-center justify-center text-gray-400 dark:text-gray-500 group-hover:bg-indigo-50 dark:group-hover:bg-indigo-500/10 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                                              <UserIcon size={28} />
                                          </div>
                                          <div className="flex-1 min-w-0">
                                              <div className="flex items-center gap-3 mb-1">
                                                  <h4 className="font-bold text-gray-800 dark:text-white uppercase text-sm truncate tracking-tight">{user.full_name}</h4>
                                                  <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest ${user.role === 'owner' ? 'bg-amber-100 dark:bg-amber-500/10 text-amber-700 dark:text-amber-400' : user.role === 'admin' ? 'bg-blue-100 dark:bg-blue-500/10 text-blue-700 dark:text-blue-400' : 'bg-gray-100 dark:bg-white/5 text-gray-500'}`}>
                                                      {user.role}
                                                  </span>
                                              </div>
                                              <div className="flex items-center gap-4">
                                                  <p className="text-[10px] text-gray-400 dark:text-gray-500 font-medium flex items-center gap-1"><ShoppingCart size={12}/> {user.count} vendas</p>
                                                  {/* Oculta o faturamento na lista se for operador */}
                                                  {!isOperator && (
                                                    <p className="text-[10px] text-gray-400 dark:text-gray-500 font-medium flex items-center gap-1"><DollarSign size={12}/> {user.revenue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
                                                  )}
                                              </div>
                                          </div>
                                          <div className="text-right hidden sm:block">
                                              <p className="text-sm font-black text-gray-800 dark:text-white">{user.percent.toFixed(1)}%</p>
                                              <p className="text-[9px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest">Share</p>
                                          </div>
                                          <ChevronRight size={20} className="text-gray-300 dark:text-gray-600 group-hover:text-indigo-500 transition-colors" />
                                      </div>
                                  ))}
                              </div>
                          )}
                      </div>
                  </div>
              </div>
          </div>
      </div>

      <UserPanel 
        isOpen={isUserPanelOpen} 
        onClose={() => setIsUserPanelOpen(false)} 
        companyId={userProfile.company_id} 
        onUserAdded={fetchUsers} 
      />
    </div>
  );
};

export default UsersScreen;
