
import React, { useRef, useState } from 'react';
import { 
  X, 
  Calendar, 
  User, 
  ShoppingBag, 
  CreditCard, 
  FileText, 
  Ban, 
  CheckCircle,
  Copy,
  Send,
  Printer,
  Loader2,
  Check,
  Mail,
  Smartphone,
  ExternalLink
} from 'lucide-react';
import { Sale, PaymentMethod } from '../types';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

interface SaleDetailPanelProps {
  isOpen: boolean;
  onClose: () => void;
  sale: Sale | null;
  portalUserIds: Set<string>;
}

const SaleDetailPanel: React.FC<SaleDetailPanelProps> = ({ isOpen, onClose, sale, portalUserIds }) => {
  const receiptRef = useRef<HTMLDivElement>(null);
  const [loadingAction, setLoadingAction] = useState<'copy' | 'pdf' | 'copied' | null>(null);

  if (!sale) return null;

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('pt-BR', {
      timeZone: 'America/Sao_Paulo',
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const paymentMethodLabels: Record<PaymentMethod, string> = {
    money: 'Dinheiro',
    debit: 'Cartão de Débito',
    credit: 'Cartão de Crédito',
    pix: 'Pix',
    others: 'Outros',
    credit_tab: 'Venda Fiado',
    link: 'Link de Pagamento'
  };

  const currency = (val: number) => val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const dateStr = new Date(sale.date).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });

  const subtotalValue = sale.subtotal ?? sale.total;
  const discountValue = sale.discount ?? 0;

  const handlePrint = () => {
    const itemsHtml = sale.items.map(item => `
      <div style="margin-bottom: 8px;">
        <div style="font-weight: 800; font-size: 13px; text-transform: uppercase;">${item.name}</div>
        <div style="display: flex; justify-content: space-between; font-size: 12px; margin-top: 2px;">
          <span>${currency(item.price)}</span>
          <span>x${item.quantity}</span>
          <span>${currency(item.price * item.quantity)}</span>
        </div>
      </div>
    `).join('');

    const paymentDetailsHtml = (sale.payments && sale.payments.length > 0) 
        ? sale.payments.map(p => `
            <div style="display: flex; justify-content: space-between; margin-top: 2px;">
                <span>${paymentMethodLabels[p.method].toUpperCase()}</span>
                <span>${currency(p.amount)}</span>
            </div>`).join('')
        : `<div style="display: flex; justify-content: space-between; margin-top: 2px;">
                <span>${paymentMethodLabels[sale.paymentMethod].toUpperCase()}</span>
                <span>${currency(sale.total)}</span>
           </div>`;

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            @page { margin: 0; size: 80mm auto; }
            * { box-sizing: border-box; -webkit-print-color-adjust: exact; }
            body { 
              font-family: ui-monospace, 'Cascadia Code', monospace; 
              margin: 0; padding: 4mm; width: 80mm; font-size: 11px; line-height: 1.2; color: #000; background: #fff;
            }
            .center { text-align: center; }
            .bold { font-weight: 800; }
            .divider { border-top: 1px dashed #000; margin: 8px 0; width: 100%; }
            h1 { font-size: 16px; margin: 0 0 2px 0; text-transform: uppercase; font-weight: 900; }
            .flex { display: flex; justify-content: space-between; }
            .header-info p { margin: 1px 0; }
          </style>
        </head>
        <body>
          <div class="center header-info">
            <h1>ESPAÇO DIGITAL</h1>
            <p>Espaço Digital e Informática</p>
            <p>Rua 4A Chacara 108 Lote 07 Loja 03</p>
            <p>Vicente Pires - Brasília/DF</p>
            <p>CNPJ: 11.353.879/0001-71</p>
          </div>
          <div class="divider"></div>
          <p><span class="bold">VENDA:</span> #${sale.code}</p>
          <p><span class="bold">DATA:</span> ${new Date(sale.date).toLocaleString('pt-BR')}</p>
          <p><span class="bold">CLIENTE:</span> ${sale.clientName.toUpperCase()}</p>
          <div class="divider"></div>
          <div class="flex bold" style="margin-bottom: 4px;">
            <span style="width: 50%;">ITEM</span>
            <span style="width: 25%; text-align: center;">QTD</span>
            <span style="width: 25%; text-align: right;">TOTAL</span>
          </div>
          <div class="divider"></div>
          ${itemsHtml}
          <div class="divider"></div>
          <div class="flex"><span>SUBTOTAL</span><span>${currency(subtotalValue)}</span></div>
          <div class="flex"><span>DESCONTOS</span><span>${currency(discountValue)}</span></div>
          <div class="flex bold" style="font-size: 14px; margin-top: 4px;">
            <span>TOTAL A PAGAR</span><span>${currency(sale.total)}</span>
          </div>
          <div class="divider"></div>
          <div class="bold" style="margin-bottom: 4px;">FORMA DE PAGAMENTO</div>
          ${paymentDetailsHtml}
          <div class="divider"></div>
          <div class="center" style="margin-top: 15px;">
            <p class="bold">*** RECIBO DE PAGAMENTO ***</p>
            <p>Não é documento fiscal</p>
            <br/>
            <p class="bold">Obrigado pela preferência!</p>
            <p>suameta.com.br</p>
          </div>
        </body>
      </html>
    `;

    const printWindow = window.open('', '_blank', 'width=450,height=600');
    if (printWindow) {
        printWindow.document.write(htmlContent);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => { printWindow.print(); onClose(); }, 500);
    }
  };

  const handleCopyImage = async () => {
    if (!receiptRef.current) return;
    setLoadingAction('copy');
    try {
        const canvas = await html2canvas(receiptRef.current, { 
            scale: 2, 
            backgroundColor: '#ffffff',
            logging: false,
            useCORS: true
        });
        
        canvas.toBlob(async (blob) => {
            if (blob) {
                try {
                    const item = new ClipboardItem({ "image/png": blob });
                    await navigator.clipboard.write([item]);
                    setLoadingAction('copied');
                    setTimeout(() => setLoadingAction(null), 2000);
                } catch (err) {
                    setLoadingAction(null);
                }
            }
        }, 'image/png');
    } catch (err) { 
        setLoadingAction(null); 
    }
  };

  const handleDownloadPDF = async () => {
    if (!receiptRef.current) return;
    setLoadingAction('pdf');
    try {
        const canvas = await html2canvas(receiptRef.current, { 
            scale: 2, 
            backgroundColor: '#ffffff',
            logging: false
        });
        const imgData = canvas.toDataURL('image/png');
        const pdfWidth = 80; 
        const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
        const doc = new jsPDF({ orientation: 'p', unit: 'mm', format: [pdfWidth, pdfHeight + 2] });
        doc.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
        doc.save(`recibo_${sale.code}.pdf`);
    } catch (err) { 
        alert('Erro ao gerar PDF'); 
    } finally { 
        setLoadingAction(null); 
    }
  };

  const handleEmail = () => {
    const subject = `Recibo de Pagamento - Venda #${sale.code}`;
    const body = `Olá ${sale.clientName},\n\nRecebemos o seu pagamento no valor de ${currency(sale.total)} em ${dateStr}.\n\nObrigado pela preferência!\nEspaço Digital`;
    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 bg-black/40 z-[80] transition-opacity backdrop-blur-sm" onClick={onClose} />
      )}

      {/* Elemento Oculto para Captura - Mantém Branco para a Impressão ser correta */}
      <div style={{ position: 'fixed', top: -20000, left: -20000, visibility: 'visible', pointerEvents: 'none' }}>
        <div ref={receiptRef} className="bg-white p-6 text-black" style={{ fontFamily: "ui-monospace, monospace", width: '80mm', lineHeight: '1.2' }}>
             <div className="text-center" style={{ marginBottom: '10px' }}>
                <h3 style={{ fontSize: '18px', margin: '0', fontWeight: '900', textTransform: 'uppercase' }}>Espaço Digital</h3>
                <p style={{ margin: '2px 0', fontSize: '12px' }}>Espaço Digital e Informática</p>
                <p style={{ margin: '2px 0', fontSize: '12px' }}>Rua 4A Chacara 108 Lote 07 Loja 03</p>
                <p style={{ margin: '2px 0', fontSize: '12px' }}>Vicente Pires - Brasília/DF</p>
                <p style={{ margin: '2px 0', fontSize: '12px' }}>CNPJ: 11.353.879/0001-71</p>
             </div>
             <div style={{ borderBottom: '1px dashed black', margin: '8px 0' }}></div>
             <div style={{ fontSize: '13px' }}>
                <p style={{ margin: '2px 0' }}><b>VENDA:</b> #${sale.code}</p>
                <p style={{ margin: '2px 0' }}><b>DATA:</b> {new Date(sale.date).toLocaleString('pt-BR')}</p>
                <p style={{ margin: '2px 0' }}><b>CLIENTE:</b> {sale.clientName.toUpperCase()}</p>
             </div>
             <div style={{ borderBottom: '1px dashed black', margin: '8px 0' }}></div>
             <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: '900', marginBottom: '4px', fontSize: '12px' }}>
                <span style={{ width: '50%' }}>ITEM</span>
                <span style={{ width: '25%', textAlign: 'center' }}>QTD</span>
                <span style={{ width: '25%', textAlign: 'right' }}>TOTAL</span>
             </div>
             <div style={{ borderBottom: '1px dashed black', margin: '8px 0' }}></div>
             {sale.items.map((item, i) => (
                <div key={i} style={{ marginBottom: '8px' }}>
                    <div style={{ fontWeight: '800', fontSize: '13px', textTransform: 'uppercase' }}>{item.name}</div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}>
                        <span>${item.price.toFixed(2)}</span>
                        <span>x{item.quantity}</span>
                        <span>${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                </div>
             ))}
             <div style={{ borderBottom: '1px dashed black', margin: '8px 0' }}></div>
             <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}><span>SUBTOTAL</span><span>${subtotalValue.toFixed(2)}</span></div>
             <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}><span>DESCONTOS</span><span>${discountValue.toFixed(2)}</span></div>
             <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: '900', fontSize: '16px', marginTop: '6px' }}>
                 <span>TOTAL A PAGAR</span><span>${sale.total.toFixed(2)}</span>
             </div>
             <div style={{ borderBottom: '1px dashed black', margin: '8px 0' }}></div>
             <div style={{ fontWeight: '900', fontSize: '12px', marginBottom: '4px' }}>FORMA DE PAGAMENTO</div>
             {(sale.payments && sale.payments.length > 0) ? (
                sale.payments.map((p, idx) => (
                    <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}>
                        <span style={{ textTransform: 'uppercase' }}>{paymentMethodLabels[p.method]}</span>
                        <span>${p.amount.toFixed(2)}</span>
                    </div>
                ))
             ) : (
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}>
                    <span style={{ textTransform: 'uppercase' }}>{paymentMethodLabels[sale.paymentMethod]}</span>
                    <span>${sale.total.toFixed(2)}</span>
                </div>
             )}
             <div style={{ borderBottom: '1px dashed black', margin: '8px 0' }}></div>
             <div className="text-center" style={{ marginTop: '20px' }}>
                 <p style={{ fontWeight: '900', fontSize: '12px', margin: '0' }}>*** RECIBO DE PAGAMENTO ***</p>
                 <p style={{ margin: '2px 0', fontSize: '11px' }}>Não é documento fiscal</p>
                 <br/>
                 <p style={{ fontWeight: '900', fontSize: '11px', margin: '0' }}>Obrigado pela preferência!</p>
                 <p style={{ margin: '2px 0', fontSize: '11px' }}>suameta.com.br</p>
             </div>
        </div>
      </div>

      {/* UI do Modal de Detalhes - Dark mode no container */}
      <div className={`fixed inset-y-0 right-0 max-w-md w-full bg-[#f8fafc] dark:bg-[#1a1b2e] shadow-2xl z-[90] transform transition-transform duration-300 flex flex-col border-l dark:border-white/5 ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex items-center justify-between p-6 border-b border-gray-100 dark:border-white/5 bg-white dark:bg-[#23243a] shrink-0 transition-colors">
          <div>
              <h2 className="text-xl font-bold text-[#1e293b] dark:text-white flex items-center gap-2">Venda #{sale.code}</h2>
              <span className="bg-emerald-100 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 text-[10px] font-bold uppercase px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-500/20 inline-flex items-center gap-1 mt-1 transition-colors">
                  <CheckCircle size={10} /> CONCLUÍDA
              </span>
          </div>
          <button onClick={onClose} className="text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-white p-2 bg-gray-50 dark:bg-white/5 rounded-full transition-colors"><X size={20} /></button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
          <div className="bg-white dark:bg-[#23243a] rounded-2xl border border-gray-100 dark:border-white/5 p-5 shadow-sm space-y-4 transition-colors">
              <div className="flex items-center gap-3 text-sm"><Calendar size={16} className="text-teal-500" /><span className="font-medium text-gray-600 dark:text-gray-400">{formatDate(sale.date)}</span></div>
              <div className="flex items-center gap-3 text-sm"><User size={16} className="text-teal-500" />
                  <div><span className="block text-[10px] text-gray-400 dark:text-gray-500 font-bold uppercase">Cliente</span><span className="font-bold text-gray-700 dark:text-gray-300 uppercase flex items-center gap-2">{sale.clientName} {portalUserIds.has(sale.customerId) && <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.6)]" title="Cadastro Habilitado no Portal" />}</span></div>
              </div>
              <div className="flex items-center gap-3 text-sm"><Smartphone size={16} className="text-teal-500" />
                  <div><span className="block text-[10px] text-gray-400 dark:text-gray-500 font-bold uppercase">Vendedor</span><span className="font-bold text-gray-700 dark:text-gray-300">{sale.sellerName}</span></div>
              </div>
          </div>

          <div>
              <h3 className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-3 flex items-center gap-2 transition-colors"><FileText size={14} /> ITENS DO PEDIDO</h3>
              <div className="bg-white dark:bg-[#23243a] rounded-2xl border border-gray-100 dark:border-white/5 shadow-sm overflow-hidden transition-colors">
                  <table className="w-full text-left text-sm">
                      <thead className="bg-gray-50 dark:bg-white/5 text-gray-400 dark:text-gray-500 font-bold text-[10px] uppercase border-b border-gray-100 dark:border-white/5">
                          <tr><th className="px-4 py-3">ITEM</th><th className="px-4 py-3 text-center">QTD</th><th className="px-4 py-3 text-right">TOTAL</th></tr>
                      </thead>
                      <tbody className="divide-y divide-gray-50 dark:divide-white/5">
                          {sale.items.map((item, idx) => (
                              <tr key={idx} className="text-gray-700 dark:text-gray-300">
                                  <td className="px-4 py-3 font-bold uppercase text-[11px]">{item.name}<div className="text-[9px] text-gray-400 dark:text-gray-500 font-medium lowercase">Unit: {currency(item.price)}</div></td>
                                  <td className="px-4 py-3 text-center font-medium">{item.quantity}</td>
                                  <td className="px-4 py-3 text-right font-bold">{currency(item.price * item.quantity)}</td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
              </div>
          </div>

          {/* Bloco de Pagamento */}
          <div className="bg-[#1e293b] dark:bg-[#2d2e42] text-white rounded-[2rem] p-6 shadow-xl space-y-6 transition-colors">
              <div className="flex justify-between items-center">
                  <span className="text-[10px] font-black text-slate-400 dark:text-gray-400 uppercase tracking-widest">Pagamento</span>
                  <div className="w-10 h-10 bg-slate-700/50 dark:bg-white/5 rounded-xl flex items-center justify-center text-teal-400 dark:text-[#2dd4bf]"><CreditCard size={20} /></div>
              </div>
              <div className="h-px bg-slate-700/50 dark:bg-white/10"></div>
              <div>
                  <h4 className="text-[10px] font-black text-slate-400 dark:text-gray-400 uppercase tracking-widest mb-4">Detalhamento</h4>
                  <div className="space-y-3">
                      {(sale.payments && sale.payments.length > 0) ? (
                          sale.payments.map((p, idx) => (
                              <div key={idx} className="flex justify-between items-center">
                                  <span className="text-sm font-bold text-slate-300 dark:text-gray-300 uppercase">{paymentMethodLabels[p.method]}</span>
                                  <span className="text-sm font-black text-white">{currency(p.amount)}</span>
                              </div>
                          ))
                      ) : (
                          <div className="flex justify-between items-center">
                              <span className="text-sm font-bold text-slate-300 dark:text-gray-300 uppercase">{paymentMethodLabels[sale.paymentMethod]}</span>
                              <span className="text-sm font-black text-white">{currency(sale.total)}</span>
                          </div>
                      )}
                  </div>
              </div>
              <div className="h-px bg-slate-700/50 dark:bg-white/10"></div>
              <div className="space-y-2">
                  <div className="flex justify-between items-center text-sm"><span className="text-slate-400 dark:text-gray-400 font-bold uppercase">Subtotal</span><span className="font-black">{currency(subtotalValue)}</span></div>
                  <div className="flex justify-between items-center text-sm"><span className="text-rose-400 font-bold uppercase">Descontos</span><span className="font-black text-rose-400">{currency(discountValue)}</span></div>
                  <div className="flex justify-between items-end mt-4 pt-2">
                      <span className="text-lg font-black uppercase tracking-tight">Total Pago</span>
                      <span className="text-3xl font-black text-teal-400 dark:text-[#2dd4bf] tracking-tighter transition-colors">{currency(sale.total)}</span>
                  </div>
              </div>
          </div>
        </div>

        <div className="bg-[#334155] dark:bg-[#23243a] p-4 pt-6 border-t border-slate-600 dark:border-white/5 sticky bottom-0 z-10 shrink-0 transition-colors">
           <div className="grid grid-cols-4 gap-2">
               <button 
                onClick={handleCopyImage}
                disabled={!!loadingAction}
                className="flex flex-col items-center justify-center gap-2 text-slate-300 dark:text-gray-400 hover:text-white dark:hover:text-[#2dd4bf] transition-colors group"
               >
                   <div className="h-8 flex items-center justify-center">
                    {loadingAction === 'copy' ? <Loader2 size={24} className="animate-spin text-white" /> : loadingAction === 'copied' ? <Check size={24} className="text-emerald-400" /> : <Copy size={24} />}
                   </div>
                   <span className="text-[10px] font-medium text-center leading-tight">Copiar imagem</span>
               </button>

               <button 
                onClick={handleDownloadPDF}
                disabled={!!loadingAction}
                className="flex flex-col items-center justify-center gap-2 text-slate-300 dark:text-gray-400 hover:text-white dark:hover:text-[#2dd4bf] transition-colors group"
               >
                   <div className="h-8 flex items-center justify-center">
                    {loadingAction === 'pdf' ? <Loader2 size={24} className="animate-spin text-white" /> : <FileText size={24} />}
                   </div>
                   <span className="text-[10px] font-medium text-center leading-tight">Baixar PDF</span>
               </button>

               <button 
                onClick={handleEmail}
                className="flex flex-col items-center justify-center gap-2 text-slate-300 dark:text-gray-400 hover:text-white dark:hover:text-[#2dd4bf] transition-colors group"
               >
                   <div className="h-8 flex items-center justify-center">
                    <Send size={24} />
                   </div>
                   <span className="text-[10px] font-medium text-center leading-tight px-1">Enviar por E-mail</span>
               </button>

               <button 
                onClick={handlePrint}
                className="flex flex-col items-center justify-center gap-2 text-slate-300 dark:text-gray-400 hover:text-white dark:hover:text-[#2dd4bf] transition-colors group"
               >
                   <div className="h-8 flex items-center justify-center">
                    <Printer size={24} />
                   </div>
                   <span className="text-[10px] font-medium text-center leading-tight">Imprimir</span>
               </button>
           </div>
        </div>
      </div>
    </>
  );
};

export default SaleDetailPanel;
