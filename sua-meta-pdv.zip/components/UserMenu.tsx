import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Lock, Eye, EyeOff, X, Loader2, ShieldCheck, Key, CheckCircle } from 'lucide-react';
import { supabase, supabaseUrl } from '../supabaseClient';
import Toast from './Toast';

const UserMenu: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMsg, setToastMsg] = useState('');
  
  const menuRef = useRef<HTMLDivElement>(null);
  const [userInfo, setUserInfo] = useState({
    name: 'Carregando...',
    email: '',
    initials: '...'
  });

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) return;

        // Use session user initially to avoid delay or extra network call
        let currentUser = session.user;

        // Optionally verify with server
        const { data: { user }, error } = await supabase.auth.getUser();
        if (error) {
          // If getUser fails but we have a session, we can still try to display the user from session
          if (!error.message.includes("Auth session missing")) {
            console.warn("UserMenu - Error verifying user with server:", error.message || error);
          }
        } else if (user) {
          currentUser = user;
        }

        if (currentUser) {
          const { data: profile } = await supabase
            .from('profiles')
            .select('full_name')
            .eq('id', currentUser.id)
            .maybeSingle();

          const fullName = profile?.full_name || currentUser.user_metadata?.full_name || 'Usuário';
          const firstName = fullName.split(' ')[0];
          const email = currentUser.email || '';
          const initials = fullName.substring(0, 2).toUpperCase();

          setUserInfo({
            name: firstName,
            email: email,
            initials: initials
          });
        }
      } catch (err: any) {
        console.error("UserMenu - Failed to fetch user:", err?.message || err);
      }
    };
    
    fetchUser();

    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleSignOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) {
        console.error('Error signing out:', error);
      }
    } catch (e) {
      console.warn("Error during signOut:", e);
    }
  };

  const handleUpdatePassword = async () => {
    if (newPassword.length < 6) {
        alert("A senha deve ter pelo menos 6 caracteres.");
        return;
    }
    if (newPassword !== confirmPassword) {
        alert("As senhas não coincidem.");
        return;
    }

    setIsUpdating(true);
    try {
        const { error } = await supabase.auth.updateUser({
            password: newPassword
        });

        if (error) throw error;

        setToastMsg("Senha atualizada com sucesso!");
        setShowToast(true);
        setIsPasswordModalOpen(false);
        setNewPassword('');
        setConfirmPassword('');
        setIsOpen(false);
    } catch (err: any) {
        alert("Erro ao atualizar senha: " + err.message);
    } finally {
        setIsUpdating(false);
    }
  };

  return (
    <div className={`relative ${isOpen ? 'z-[10001]' : ''}`} ref={menuRef}>
      <button 
        className="flex items-center gap-2 text-left hover:bg-gray-100 dark:hover:bg-white/5 p-1 -mr-1 rounded-lg transition-colors outline-none"
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="w-8 h-8 rounded-full bg-slate-600 dark:bg-indigo-500/20 dark:text-indigo-400 flex items-center justify-center text-white text-xs font-bold uppercase transition-colors">
          {userInfo.initials}
        </div>
        <div className="hidden sm:block text-sm leading-tight">
          <p className="font-semibold text-gray-900 dark:text-white transition-colors">{userInfo.name}</p>
          <p className="text-gray-500 dark:text-gray-400 text-xs truncate max-w-[140px] transition-colors" title={userInfo.email}>
            {userInfo.email}
          </p>
        </div>
        <ChevronDown size={14} className={`text-gray-400 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute right-0 top-full mt-2 w-64 bg-white dark:bg-[#23243a] rounded-xl shadow-2xl py-2 z-[9999] animate-in fade-in zoom-in-95 duration-100 origin-top-right border border-gray-100 dark:border-white/5">
           
           <div className="px-5 py-3 border-b border-gray-100 dark:border-white/10 mb-1">
              <p className="text-gray-900 dark:text-white font-bold text-sm truncate uppercase tracking-tight">{userInfo.name}</p>
              <p className="text-gray-500 dark:text-gray-400 text-[10px] font-bold truncate tracking-wider uppercase">{userInfo.email}</p>
           </div>
           
           <div className="px-3 py-1">
              <button className="text-gray-700 dark:text-gray-300 font-bold text-[11px] uppercase tracking-widest hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-gray-50 dark:hover:bg-white/5 px-3 py-2.5 rounded-lg w-full text-left transition-all">
                  Gerenciar assinatura
              </button>
           </div>
           
           <div className="px-3 py-1">
              <button 
                onClick={() => setIsPasswordModalOpen(true)}
                className="text-gray-700 dark:text-gray-300 font-bold text-[11px] uppercase tracking-widest hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-gray-50 dark:hover:bg-white/5 px-3 py-2.5 rounded-lg w-full text-left transition-all flex items-center gap-2"
              >
                  <Key size={14} /> Redefinir senha
              </button>
           </div>

           <div className="border-t border-gray-100 dark:border-white/10 my-2 mx-5"></div>

           <div className="px-3 py-1 pb-3">
              <button 
                onClick={handleSignOut}
                className="text-red-500 dark:text-rose-400 font-black text-[11px] uppercase tracking-widest hover:bg-rose-50 dark:hover:bg-rose-500/10 px-3 py-2.5 rounded-lg w-full text-left transition-all"
              >
                  Sair do sistema
              </button>
           </div>
        </div>
      )}

      {/* MODAL REDEFINIR SENHA */}
      {isPasswordModalOpen && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[10000] flex items-center justify-center p-4">
              <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] w-full max-w-md shadow-2xl overflow-hidden animate-in zoom-in-95 border border-slate-50 dark:border-white/5 transition-colors">
                  <div className="p-8 pb-4 flex justify-between items-start">
                      <div>
                          <h3 className="text-2xl font-black text-[#1e293b] dark:text-white uppercase tracking-tighter italic">TROCAR SENHA</h3>
                          <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mt-1">Atualize seu acesso por segurança</p>
                      </div>
                      <button 
                        onClick={() => setIsPasswordModalOpen(false)}
                        className="text-slate-300 hover:text-slate-500 dark:hover:text-white p-1 transition-colors"
                      >
                          <X size={24} />
                      </button>
                  </div>

                  <div className="p-8 space-y-6">
                      <div className="relative group">
                          <label className="absolute -top-2 left-4 bg-white dark:bg-[#23243a] px-1 text-[10px] font-black text-indigo-500 uppercase tracking-widest z-10">Nova Senha</label>
                          <div className="flex items-center border border-gray-200 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] focus-within:border-indigo-500 transition-all">
                              <Lock className="text-gray-300 mr-3" size={18} />
                              <input 
                                type={showPassword ? "text" : "password"}
                                className="w-full bg-transparent outline-none text-sm font-bold text-gray-800 dark:text-white"
                                placeholder="Mínimo 6 dígitos"
                                value={newPassword}
                                onChange={(e) => setNewPassword(e.target.value)}
                                autoFocus
                              />
                              <button onClick={() => setShowPassword(!showPassword)} className="text-gray-300 hover:text-gray-600 ml-2">
                                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                              </button>
                          </div>
                      </div>

                      <div className="relative group">
                          <label className="absolute -top-2 left-4 bg-white dark:bg-[#23243a] px-1 text-[10px] font-black text-indigo-500 uppercase tracking-widest z-10">Confirmar Senha</label>
                          <div className="flex items-center border border-gray-200 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] focus-within:border-indigo-500 transition-all">
                              <CheckCircle className="text-gray-300 mr-3" size={18} />
                              <input 
                                type={showPassword ? "text" : "password"}
                                className="w-full bg-transparent outline-none text-sm font-bold text-gray-800 dark:text-white"
                                placeholder="Repita a nova senha"
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                              />
                          </div>
                      </div>

                      <button 
                        onClick={handleUpdatePassword}
                        disabled={isUpdating || !newPassword || newPassword !== confirmPassword}
                        className="w-full py-5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-black text-[11px] uppercase tracking-widest shadow-xl shadow-indigo-200 dark:shadow-none transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:grayscale"
                      >
                          {isUpdating ? <Loader2 className="animate-spin" size={18} /> : <CheckCircle size={18} strokeWidth={3} />}
                          SALVAR NOVA SENHA
                      </button>
                  </div>
                  
                  <div className="px-8 py-6 bg-slate-50 dark:bg-white/5 border-t dark:border-white/5 flex justify-center">
                       <p className="text-[9px] text-gray-400 dark:text-gray-500 font-bold uppercase tracking-widest text-center leading-relaxed">
                          Ao salvar, você continuará logado com sua nova credencial.
                       </p>
                  </div>
              </div>
          </div>
      )}

      <Toast message={toastMsg} isVisible={showToast} onClose={() => setShowToast(false)} />
    </div>
  );
};

export default UserMenu;