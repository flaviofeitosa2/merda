
import React, { useState, useEffect } from 'react';
import { supabase } from '../supabaseClient';
import { Mail, Lock, Loader2, ArrowLeft, Building2, AlertCircle, CheckCircle, User, Briefcase, Eye, EyeOff } from 'lucide-react';

interface AuthPageProps {
  initialView?: 'login' | 'register' | 'forgot-password' | 'update-password';
  initialLoginMode?: 'company' | 'customer';
  onBack: () => void;
  externalError?: string | null;
}

const AuthPage: React.FC<AuthPageProps> = ({ initialView = 'login', initialLoginMode = 'company', onBack, externalError }) => {
  const [view, setView] = useState<'login' | 'register' | 'forgot-password' | 'update-password'>(initialView);
  const [loginMode, setLoginMode] = useState<'company' | 'customer'>(initialLoginMode);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(externalError || null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [storeName, setStoreName] = useState('');
  const [fullName, setFullName] = useState('');
  const [cnpj, setCnpj] = useState('');

  // Sincroniza o modo se o componente for remontado com novos props
  useEffect(() => {
    setLoginMode(initialLoginMode);
    setView(initialView);
  }, [initialLoginMode, initialView]);

  const maskCnpj = (value: string) => {
    return value
      .replace(/\D/g, "")
      .replace(/^(\d{2})(\d)/, "$1.$2")
      .replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")
      .replace(/\.(\d{3})(\d)/, ".$1/$2")
      .replace(/(\d{4})(\d)/, "$1-$2")
      .slice(0, 18);
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      // Usar a origem atual (seja localhost, preview ou domínio customizado)
      // Isso garante que o link de volta funcione no ambiente que o usuário está usando
      const redirectUrl = window.location.origin;

      const { error: resetError } = await supabase.auth.resetPasswordForEmail(email.trim(), {
        redirectTo: `${redirectUrl}/auth/callback`,
      });
      if (resetError) throw resetError;
      setSuccessMsg("Link de redefinição enviado para seu e-mail!");
    } catch (err: any) {
      setError(err.message || 'Erro ao enviar e-mail de redefinição.');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      const { error: updateError } = await supabase.auth.updateUser({ password });
      if (updateError) throw updateError;
      setSuccessMsg("Senha atualizada com sucesso! Redirecionando...");
      setTimeout(() => {
        window.location.href = 'https://www.suameta.com.br';
      }, 2000);
    } catch (err: any) {
      setError(err.message || 'Erro ao atualizar senha.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (view === 'login') {
        const { error: authError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (authError) throw authError;
      } else {
        const { data: authData, error: authError } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { data: { full_name: fullName } }
        });
        
        if (authError) throw authError;

        if (authData.user) {
            const { data: companyData, error: companyError } = await supabase
                .from('companies')
                .insert([{ name: storeName, cnpj: cnpj, owner_id: authData.user.id }])
                .select().single();

            if (companyError) throw companyError;

            await supabase.from('profiles').upsert({
                id: authData.user.id,
                full_name: fullName,
                role: 'owner',
                company_id: companyData.id,
                email: email.trim()
            });

            // Sign out immediately after registration
            // and force the user to log in for their first access as requested.
            await supabase.auth.signOut();
        }
        setSuccessMsg("Empresa cadastrada com sucesso! Faça login para acessar.");
        setView('login');
      }
    } catch (err: any) {
      setError(err.message || 'Erro na autenticação.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-screen bg-white flex flex-col lg:flex-row font-sans overflow-hidden">
      {/* Lado Esquerdo - Estético / Header Mobile */}
      <div className={`lg:w-1/2 p-5 sm:p-12 lg:p-20 text-white flex flex-col lg:justify-between relative overflow-hidden transition-colors duration-500 ${loginMode === 'customer' ? 'bg-[#4f46e5]' : 'bg-[#2dd4bf]'} shrink-0`}>
        <div className="relative z-10">
            <button onClick={onBack} className="flex items-center gap-2 text-white/80 hover:text-white mb-2 sm:mb-12 transition-colors font-medium text-xs sm:text-sm">
                <ArrowLeft size={16} className="sm:w-[18px]" /> Voltar
            </button>
            <h1 className="text-2xl sm:text-5xl lg:text-7xl font-extrabold mb-1 sm:mb-8 leading-tight tracking-tighter animate-in fade-in slide-in-from-left-6 duration-500">
                {view === 'forgot-password' 
                    ? 'Recuperar Senha'
                    : view === 'update-password'
                        ? 'Nova Senha'
                        : view === 'login' 
                            ? (loginMode === 'customer' ? 'Portal do Assinante' : 'Portal da Empresa') 
                            : view === 'welcome'
                                ? 'Bem-vindo!'
                                : 'Cadastre sua empresa'}
            </h1>
            <p className="text-white/80 text-sm sm:text-xl max-w-md font-medium leading-relaxed animate-in fade-in slide-in-from-left-8 duration-700 hidden sm:block">
                {view === 'welcome'
                    ? 'Sua conta foi criada com sucesso. Estamos felizes em ter você conosco!'
                    : loginMode === 'customer' 
                        ? 'Acesse suas faturas, visualize seu histórico de pagamentos e gere boletos PIX de forma rápida.' 
                        : 'O PDV mais moderno para sua empresa. Controle estoque, clientes e vendas em um só lugar.'}
            </p>
        </div>
        
        {view !== 'welcome' && (
            <div className="relative z-10 mt-3 sm:mt-12">
                <p className="text-[9px] sm:text-[10px] font-black uppercase tracking-[0.2em] opacity-50 mb-1.5 sm:mb-4 hidden sm:block">Selecione seu tipo de acesso</p>
                <div className="flex bg-black/10 backdrop-blur-md p-1 rounded-xl sm:rounded-2xl w-fit border border-white/10 shadow-lg">
                    <button 
                        onClick={() => { setLoginMode('company'); setView('login'); setError(null); }}
                        className={`flex items-center gap-2 sm:gap-3 px-3 sm:px-8 py-1.5 sm:py-3 rounded-lg sm:rounded-xl text-[10px] sm:text-sm font-bold transition-all ${loginMode === 'company' ? 'bg-white text-[#2dd4bf] shadow-xl' : 'text-white/60 hover:text-white'}`}
                    >
                        <Briefcase size={14} className="sm:w-[18px]" /> Empresa
                    </button>
                    <button 
                        onClick={() => { setLoginMode('customer'); setView('login'); setError(null); }}
                        className={`flex items-center gap-2 sm:gap-3 px-3 sm:px-8 py-1.5 sm:py-3 rounded-lg sm:rounded-xl text-[10px] sm:text-sm font-bold transition-all ${loginMode === 'customer' ? 'bg-white text-[#4f46e5] shadow-xl' : 'text-white/60 hover:text-white'}`}
                    >
                        <User size={14} className="sm:w-[18px]" /> Assinante
                    </button>
                </div>
            </div>
        )}
        <div className="absolute -bottom-20 -right-20 w-96 h-96 bg-white/5 rounded-full blur-[100px] pointer-events-none"></div>
      </div>

      {/* Lado Direito - Card de Login */}
      <div className="flex-1 flex items-center justify-center p-4 sm:p-8 lg:p-12 bg-[#f8fafc] overflow-y-auto lg:overflow-y-hidden">
        <div className="max-w-md w-full bg-white rounded-[1.5rem] sm:rounded-[3rem] shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] p-5 sm:p-12 border border-slate-50 relative animate-in zoom-in-95 duration-500">
            <>
                <div className="mb-4 sm:mb-10">
                        <h2 className="text-lg sm:text-3xl font-black text-slate-900 tracking-tight leading-none">
                            {view === 'forgot-password' ? 'Recuperar Senha' : view === 'update-password' ? 'Nova Senha' : view === 'login' ? 'Entrar na conta' : 'Crie sua conta'}
                        </h2>
                        <p className="text-[10px] sm:text-sm text-slate-400 mt-1.5 sm:mt-3 font-medium leading-relaxed">
                            {view === 'forgot-password'
                              ? 'Enviaremos um link para você redefinir sua senha.'
                              : view === 'update-password'
                                ? 'Digite sua nova senha abaixo.'
                                : loginMode === 'customer' 
                                  ? 'Informe os dados fornecidos pelo seu provedor.' 
                                  : 'Acesso restrito para administradores.'}
                        </p>
                    </div>

                    {error && (
                      <div className="mb-3 sm:mb-8 p-2.5 sm:p-4 bg-rose-50 text-rose-600 text-[9px] sm:text-xs font-bold rounded-lg sm:rounded-2xl border border-rose-100 flex gap-2 sm:gap-3 animate-in shake duration-300">
                        <AlertCircle size={14} className="shrink-0 sm:w-[18px]" />
                        <span>{error}</span>
                      </div>
                    )}
                    {successMsg && (
                      <div className="mb-3 sm:mb-8 p-2.5 sm:p-4 bg-emerald-50 text-emerald-700 text-[9px] sm:text-xs font-bold rounded-lg sm:rounded-2xl border border-emerald-100 flex gap-2 sm:gap-3">
                        <CheckCircle size={14} className="shrink-0 sm:w-[18px]" />
                        <span>{successMsg}</span>
                      </div>
                    )}

                    {view === 'forgot-password' ? (
                      <form onSubmit={handleForgotPassword} className="space-y-3 sm:space-y-6">
                        <div className="space-y-1">
                          <label className="text-[8px] font-black text-slate-400 uppercase ml-2 tracking-widest">E-mail</label>
                          <div className="relative group">
                            <Mail className="absolute left-4 sm:left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-slate-500 transition-colors" size={16} />
                            <input 
                                type="email" 
                                required 
                                placeholder="seu@email.com" 
                                className={`w-full pl-11 sm:pl-14 pr-4 sm:pr-5 py-2.5 sm:py-4 rounded-xl sm:rounded-2xl border border-slate-200 outline-none transition-all font-bold text-sm bg-white text-slate-900 focus:ring-4 ${loginMode === 'customer' ? 'focus:ring-indigo-50 focus:border-indigo-500' : 'focus:ring-teal-50 focus:border-[#2dd4bf]'}`} 
                                value={email} 
                                onChange={e => setEmail(e.target.value)} 
                            />
                          </div>
                        </div>
                        <button 
                            type="submit" 
                            disabled={loading} 
                            className={`w-full py-3.5 sm:py-5 rounded-xl sm:rounded-2xl text-white font-black text-[10px] sm:text-sm uppercase tracking-widest shadow-2xl flex items-center justify-center gap-2 sm:gap-3 transition-all active:scale-95 disabled:opacity-50 disabled:grayscale mt-2 sm:mt-8 ${loginMode === 'customer' ? 'bg-[#4f46e5] hover:bg-indigo-700 shadow-indigo-200' : 'bg-[#2dd4bf] hover:bg-[#14b8a6] shadow-teal-100'}`}
                        >
                            {loading ? <Loader2 className="animate-spin" size={18} /> : 'ENVIAR LINK'}
                        </button>
                        <div className="text-center mt-4">
                          <button type="button" onClick={() => setView('login')} className="text-slate-400 font-black text-[8px] uppercase tracking-[0.2em] hover:text-slate-600">
                              Voltar para o login
                          </button>
                        </div>
                      </form>
                    ) : view === 'update-password' ? (
                      <form onSubmit={handleUpdatePassword} className="space-y-3 sm:space-y-6">
                        <div className="space-y-1">
                          <label className="text-[8px] font-black text-slate-400 uppercase ml-2 tracking-widest">Nova Senha</label>
                          <div className="relative group">
                            <Lock className="absolute left-4 sm:left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-slate-500 transition-colors" size={16} />
                            <input 
                                type={showPassword ? "text" : "password"}
                                required 
                                placeholder="••••••••" 
                                className={`w-full pl-11 sm:pl-14 pr-11 sm:pr-14 py-2.5 sm:py-4 rounded-xl sm:rounded-2xl border border-slate-200 outline-none transition-all font-bold text-sm bg-white text-slate-900 focus:ring-4 ${loginMode === 'customer' ? 'focus:ring-indigo-50 focus:border-indigo-500' : 'focus:ring-teal-50 focus:border-[#2dd4bf]'}`} 
                                value={password} 
                                onChange={e => setPassword(e.target.value)} 
                            />
                            <button 
                              type="button"
                              onClick={() => setShowPassword(!showPassword)}
                              className="absolute right-4 sm:right-5 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-500"
                            >
                              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                            </button>
                          </div>
                        </div>
                        <button 
                            type="submit" 
                            disabled={loading} 
                            className={`w-full py-3.5 sm:py-5 rounded-xl sm:rounded-2xl text-white font-black text-[10px] sm:text-sm uppercase tracking-widest shadow-2xl flex items-center justify-center gap-2 sm:gap-3 transition-all active:scale-95 disabled:opacity-50 disabled:grayscale mt-2 sm:mt-8 ${loginMode === 'customer' ? 'bg-[#4f46e5] hover:bg-indigo-700 shadow-indigo-200' : 'bg-[#2dd4bf] hover:bg-[#14b8a6] shadow-teal-100'}`}
                        >
                            {loading ? <Loader2 className="animate-spin" size={18} /> : 'ATUALIZAR SENHA'}
                        </button>
                      </form>
                    ) : (
                      <form onSubmit={handleSubmit} className="space-y-3 sm:space-y-6">
                        {view === 'register' && (
                            <div className="space-y-3">
                                <div className="space-y-1">
                                  <label className="text-[8px] font-black text-slate-400 uppercase ml-2 tracking-widest">Seu Nome Completo</label>
                                  <input type="text" required placeholder="João Silva" className="w-full px-4 py-2.5 sm:px-5 sm:py-4 rounded-xl sm:rounded-2xl border border-slate-200 focus:ring-4 focus:ring-teal-50 focus:border-[#2dd4bf] outline-none transition-all font-bold text-sm bg-slate-50/50 text-slate-900" value={fullName} onChange={e => setFullName(e.target.value)} />
                                </div>
                                <div className="space-y-1">
                                  <label className="text-[8px] font-black text-slate-400 uppercase ml-2 tracking-widest">Nome da Empresa</label>
                                  <input type="text" required placeholder="Sua Loja" className="w-full px-4 py-2.5 sm:px-5 sm:py-4 rounded-xl sm:rounded-2xl border border-slate-200 focus:ring-4 focus:ring-teal-50 focus:border-[#2dd4bf] outline-none transition-all font-bold text-sm bg-slate-50/50 text-slate-900" value={storeName} onChange={e => setStoreName(e.target.value)} />
                                </div>
                                <div className="space-y-1">
                                  <label className="text-[8px] font-black text-slate-400 uppercase ml-2 tracking-widest">CPF / CNPJ</label>
                                  <input 
                                    type="text" 
                                    required 
                                    placeholder="00.000.000/0000-00" 
                                    className="w-full px-4 py-2.5 sm:px-5 sm:py-4 rounded-xl sm:rounded-2xl border border-slate-200 focus:ring-4 focus:ring-teal-50 focus:border-[#2dd4bf] outline-none transition-all font-mono text-sm bg-slate-50/50 text-slate-900" 
                                    value={cnpj} 
                                    onChange={e => setCnpj(maskCnpj(e.target.value))} 
                                  />
                                </div>
                            </div>
                        )}
                        
                        <div className="space-y-3 sm:space-y-6">
                          <div className="space-y-1">
                            <label className="text-[8px] font-black text-slate-400 uppercase ml-2 tracking-widest">E-mail</label>
                            <div className="relative group">
                              <Mail className="absolute left-4 sm:left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-slate-500 transition-colors" size={16} />
                              <input 
                                  type="email" 
                                  required 
                                  placeholder="seu@email.com" 
                                  className={`w-full pl-11 sm:pl-14 pr-4 sm:pr-5 py-2.5 sm:py-4 rounded-xl sm:rounded-2xl border border-slate-200 outline-none transition-all font-bold text-sm bg-white text-slate-900 focus:ring-4 ${loginMode === 'customer' ? 'focus:ring-indigo-50 focus:border-indigo-500' : 'focus:ring-teal-50 focus:border-[#2dd4bf]'}`} 
                                  value={email} 
                                  onChange={e => setEmail(e.target.value)} 
                              />
                            </div>
                          </div>
                          
                          <div className="space-y-1">
                            <div className="flex justify-between items-center pr-2">
                              <label className="text-[8px] sm:text-[10px] font-black text-slate-400 uppercase ml-2 tracking-widest">Senha</label>
                              {view === 'login' && loginMode === 'company' && (
                                <button 
                                  type="button" 
                                  onClick={() => setView('forgot-password')}
                                  className="text-[8px] sm:text-[10px] font-black text-[#2dd4bf] uppercase tracking-widest hover:underline"
                                >
                                  Esqueci minha senha
                                </button>
                              )}
                            </div>
                            <div className="relative group">
                              <Lock className="absolute left-4 sm:left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-slate-500 transition-colors" size={16} />
                              <input 
                                  type={showPassword ? "text" : "password"}
                                  required 
                                  placeholder="••••••••" 
                                  className={`w-full pl-11 sm:pl-14 pr-11 sm:pr-14 py-2.5 sm:py-4 rounded-xl sm:rounded-2xl border border-slate-200 outline-none transition-all font-bold text-sm bg-white text-slate-900 focus:ring-4 ${loginMode === 'customer' ? 'focus:ring-indigo-50 focus:border-indigo-500' : 'focus:ring-teal-50 focus:border-[#2dd4bf]'}`} 
                                  value={password} 
                                  onChange={e => setPassword(e.target.value)} 
                              />
                              <button 
                                type="button"
                                onClick={() => setShowPassword(!showPassword)}
                                className="absolute right-4 sm:right-5 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-500"
                              >
                                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                              </button>
                            </div>
                          </div>
                        </div>
                        
                        <button 
                            type="submit" 
                            disabled={loading} 
                            className={`w-full py-3.5 sm:py-5 rounded-xl sm:rounded-2xl text-white font-black text-[10px] sm:text-sm uppercase tracking-widest shadow-2xl flex items-center justify-center gap-2 sm:gap-3 transition-all active:scale-95 disabled:opacity-50 disabled:grayscale mt-2 sm:mt-8 ${loginMode === 'customer' ? 'bg-[#4f46e5] hover:bg-indigo-700 shadow-indigo-200' : 'bg-[#2dd4bf] hover:bg-[#14b8a6] shadow-teal-100'}`}
                        >
                            {loading ? <Loader2 className="animate-spin" size={18} /> : (view === 'login' ? 'ENTRAR AGORA' : 'CRIAR CONTA')}
                        </button>
                    </form>
                    )}
                    
                    <div className="mt-4 sm:mt-12 text-center">
                        {view === 'login' && loginMode === 'company' && (
                            <div className="flex flex-col gap-3 sm:gap-4">
                                <button onClick={() => setView('register')} className="text-[#2dd4bf] font-black text-[8px] sm:text-[10px] uppercase tracking-[0.2em] hover:underline">
                                    Quero registrar minha empresa
                                </button>
                                <button onClick={() => setView('forgot-password')} className="text-slate-400 font-black text-[8px] sm:text-[10px] uppercase tracking-[0.2em] hover:underline">
                                    Esqueci minha senha
                                </button>
                            </div>
                        )}
                        {view === 'register' && (
                            <button onClick={() => setView('login')} className="text-[#2dd4bf] font-black text-[8px] sm:text-[10px] uppercase tracking-[0.2em] hover:underline">
                                Já tenho conta empresarial
                            </button>
                        )}
                        {loginMode === 'customer' && view === 'login' && (
                            <div className="space-y-1.5 sm:space-y-4">
                                <p className="text-[8px] sm:text-[10px] font-black text-slate-300 uppercase tracking-widest">Esqueceu sua senha?</p>
                                <button 
                                  type="button"
                                  onClick={() => setView('forgot-password')}
                                  className="text-indigo-600 font-black text-[9px] sm:text-xs uppercase tracking-widest hover:underline hover:text-indigo-800 transition-colors"
                                >
                                  Recuperar Acesso
                                </button>
                            </div>
                        )}
                    </div>
                </>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
