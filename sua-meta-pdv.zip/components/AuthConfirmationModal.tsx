import React, { useState } from 'react';
import { X, Lock, Eye, EyeOff, Loader2, ShieldCheck, AlertCircle, Check } from 'lucide-react';
import { supabase } from '../supabaseClient';

interface AuthConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  userEmail: string;
}

const AuthConfirmationModal: React.FC<AuthConfirmationModalProps> = ({ isOpen, onClose, onSuccess, userEmail }) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleConfirm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password) return;

    setLoading(true);
    setError(null);

    try {
      // Re-autentica o usuário para validar a senha
      const { error: authError } = await supabase.auth.signInWithPassword({
        email: userEmail,
        password: password,
      });

      if (authError) throw new Error('Senha incorreta. Verifique e tente novamente.');

      setLoading(false);
      setPassword('');
      onSuccess();
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[250] flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] w-full max-sm:max-w-sm shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 border border-transparent dark:border-white/5 transition-colors">
        
        <div className="px-8 pt-10 pb-6 text-center">
          <div className="w-16 h-16 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <ShieldCheck size={32} />
          </div>
          <h3 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tighter italic leading-none">Confirmação</h3>
          <p className="text-[10px] font-bold text-slate-400 dark:text-gray-500 uppercase tracking-widest mt-3">INSIRA SUA SENHA PARA EDITAR A VENDA</p>
        </div>

        <form onSubmit={handleConfirm} className="px-8 pb-10 space-y-6">
          {error && (
            <div className="p-3 bg-rose-50 dark:bg-rose-500/10 border border-rose-100 dark:border-rose-500/20 rounded-xl flex gap-2 items-center text-rose-600 dark:text-rose-400 text-[10px] font-black uppercase animate-in shake duration-300">
              <AlertCircle size={14} />
              {error}
            </div>
          )}

          <div className="relative group">
            <label className="absolute -top-2 left-4 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-indigo-500 uppercase tracking-widest z-10 transition-all">Senha de Acesso</label>
            <div className="flex items-center border-2 border-slate-100 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] focus-within:border-indigo-400 transition-all">
              <Lock className="text-slate-200 mr-3" size={18} />
              <input 
                type={showPassword ? "text" : "password"}
                className="w-full bg-transparent outline-none text-base font-black text-slate-700 dark:text-white"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoFocus
              />
              <button 
                type="button"
                onClick={() => setShowPassword(!showPassword)} 
                className="text-slate-300 hover:text-indigo-600 transition-colors"
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <button 
              type="submit"
              disabled={loading || !password}
              className="w-full py-5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-indigo-100 dark:shadow-none transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50"
            >
              {/* Fix: Added missing 'Check' icon which is now imported above */}
              {loading ? <Loader2 className="animate-spin" size={20} /> : <Check size={20} strokeWidth={4} />}
              CONFIRMAR ACESSO
            </button>
            <button 
              type="button"
              onClick={onClose}
              className="w-full py-4 text-slate-400 dark:text-gray-500 font-bold text-[10px] uppercase hover:text-slate-600 dark:hover:text-white transition-colors tracking-widest"
            >
              CANCELAR
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AuthConfirmationModal;