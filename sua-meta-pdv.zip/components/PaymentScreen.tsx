
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  ArrowLeft, 
  Banknote, 
  CreditCard, 
  QrCode, 
  User,
  Loader2,
  ChevronRight,
  Check,
  Share2,
  FileText,
  AlertCircle,
  Copy,
  Printer,
  ChevronDown,
  Coins,
  Zap,
  ArrowRight,
  Wallet,
  Save
} from 'lucide-react';
import { CartItem, PaymentMethod, PaymentDetail, Customer, Company, Wallet as WalletType } from '../types';
import SaleDetailPanel from './SaleDetailPanel';
import { supabase } from '../supabaseClient';

interface PaymentScreenProps {
  cartItems: CartItem[];
  subtotal: number;
  onBack: () => void;
  onComplete: (payments: PaymentDetail[], change: number, notes: string) => Promise<void> | void;
  onSaveOrder: (notes: string) => Promise<void> | void;
  onDiscard: () => void;
  discount: number;
  onEditDiscount: (value: number) => void;
  customer: Customer | null;
  onSelectCustomer: (customer: Customer | null) => void;
  allCustomers: Customer[];
  onRegisterCustomer: (customer: Customer) => Promise<Customer | null>;
  portalUserIds: Set<string>;
}

type PaymentStep = 'methods' | 'confirm_pix' | 'success';

const PaymentScreen: React.FC<PaymentScreenProps> = ({ 
  cartItems, 
  subtotal, 
  onBack, 
  onComplete,
  onSaveOrder,
  discount,
  customer,
  portalUserIds
}) => {
  const totalVenda = Number(Math.max(0, subtotal - discount).toFixed(2));
  
  const [step, setStep] = useState<PaymentStep>('methods');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSavingOrder, setIsSavingOrder] = useState(false);
  const [showQRCode, setShowQRCode] = useState(false);
  const [showPixChoice, setShowPixChoice] = useState(false);
  
  const [primaryMethod, setPrimaryMethod] = useState<PaymentMethod>('money');
  const [primaryAmount, setPrimaryAmount] = useState<number>(totalVenda);
  const [secondaryMethod, setSecondaryMethod] = useState<PaymentMethod | null>(null);

  // Estados para Gestão de Carteiras
  const [wallets, setWallets] = useState<WalletType[]>([]);
  const [walletSettings, setWalletSettings] = useState<Record<string, string | string[]>>({});
  const [selectedWallets, setSelectedWallets] = useState<Record<string, string>>({}); // methodId -> walletId
  
  const [isReceiptOpen, setIsReceiptOpen] = useState(false);
  const [completedSale, setCompletedSale] = useState<any>(null);
  const isMounted = React.useRef(true);

  useEffect(() => {
    return () => { isMounted.current = false; };
  }, []);

  useEffect(() => {
    const loadWallets = async () => {
        try {
          const { data: { session } } = await supabase.auth.getSession();
          if (!session) return;

          const { data: { user }, error } = await supabase.auth.getUser();
          if (error || !user) return;

          const { data: profile } = await supabase.from('profiles').select('company_id').eq('id', user.id).single();
          if (!profile?.company_id) return;

          const [wRes, compRes] = await Promise.all([
              supabase.from('wallets').select('*').eq('company_id', profile.company_id),
              supabase.from('companies').select('wallet_settings').eq('id', profile.company_id).single()
          ]);

          if (wRes.data) setWallets(wRes.data);
          if (compRes.data?.wallet_settings) {
              setWalletSettings(compRes.data.wallet_settings);
              
              // Define carteira padrão (primeira da lista) para cada método
              const defaults: Record<string, string> = {};
              Object.entries(compRes.data.wallet_settings).forEach(([method, ids]) => {
                  if (Array.isArray(ids) && ids.length > 0) defaults[method] = ids[0];
                  else if (typeof ids === 'string') defaults[method] = ids;
              });
              setSelectedWallets(defaults);
          }
        } catch (err) {
          console.error("Failed to load wallets:", err);
        }
    };
    loadWallets();
  }, []);

  const diff = Number((primaryAmount - totalVenda).toFixed(2));
  const hasChange = primaryMethod === 'money' && diff > 0;
  const changeAmount = hasChange ? diff : 0;
  
  const remainingAmount = Number((totalVenda - primaryAmount).toFixed(2));
  const isSplit = remainingAmount > 0;

  const paymentMethods: { id: PaymentMethod; label: string; icon: React.ElementType }[] = [
    { id: 'money', label: 'Dinheiro', icon: Banknote }, 
    { id: 'pix', label: 'Pix', icon: QrCode },
    { id: 'debit', label: 'Débito', icon: CreditCard },
    { id: 'credit', label: 'Crédito', icon: CreditCard }, 
  ];

  const handleAdvance = () => {
    const isPixInvolved = primaryMethod === 'pix' || (isSplit && secondaryMethod === 'pix');
    if (isPixInvolved) setShowPixChoice(true);
    else handleFinish();
  };

  const handleSaveAsOrder = async () => {
      if (isSavingOrder) return;
      setIsSavingOrder(true);
      try {
          await onSaveOrder('Pedido salvo pelo PDV');
      } finally {
          setIsSavingOrder(false);
      }
  };

  const handleFinish = async () => {
    setIsProcessing(true);
    setShowPixChoice(false);
    const payments: PaymentDetail[] = [];
    const effectivePrimary = hasChange ? totalVenda : primaryAmount;
    
    payments.push({ 
        method: primaryMethod, 
        amount: effectivePrimary,
        wallet_id: selectedWallets[primaryMethod] 
    });
    
    if (isSplit && secondaryMethod) {
        payments.push({ 
            method: secondaryMethod, 
            amount: remainingAmount,
            wallet_id: selectedWallets[secondaryMethod]
        });
    }

    try {
        await onComplete(payments, changeAmount, '');
        if (!isMounted.current) return;
        setCompletedSale({
            code: Math.random().toString(36).substr(2, 6).toUpperCase(),
            total: totalVenda,
            date: new Date().toISOString(),
            clientName: customer ? customer.name : 'Cliente Balcão',
            items: cartItems,
            paymentMethod: primaryMethod,
            payments: payments,
            change: changeAmount
        });
        setStep('success');
    } catch (error) {
        if (!isMounted.current) return;
        alert("Erro ao finalizar venda.");
    } finally {
        if (isMounted.current) setIsProcessing(false);
    }
  };

  // Helper para renderizar seletor de carteira
  const renderWalletSelector = (methodId: string, isPrimary: boolean) => {
    const assoc = walletSettings[methodId];
    if (!assoc || (Array.isArray(assoc) && assoc.length <= 1) || typeof assoc === 'string') return null;
    
    const ids = assoc as string[];
    const currentId = selectedWallets[methodId];

    return (
        <div className="mt-4 animate-in fade-in slide-in-from-top-1">
            <div className="bg-gray-100 dark:bg-white/5 rounded-2xl p-3 flex items-center justify-between border border-gray-200 dark:border-white/10">
                <div className="flex items-center gap-2 text-gray-500 dark:text-gray-400">
                    <Wallet size={14} />
                    <span className="text-[10px] font-black uppercase tracking-widest">Receber em:</span>
                </div>
                <div className="relative">
                    <select 
                        value={currentId || ''}
                        onChange={(e) => setSelectedWallets(prev => ({ ...prev, [methodId]: e.target.value }))}
                        className="appearance-none bg-white dark:bg-[#1a1b2e] border border-gray-200 dark:border-white/10 rounded-lg px-4 py-1.5 text-[10px] font-black uppercase text-indigo-600 dark:text-indigo-400 outline-none pr-8 cursor-pointer"
                    >
                        {ids.map(id => {
                            const w = wallets.find(wal => wal.id === id);
                            return <option key={id} value={id}>{w?.name.toUpperCase() || 'CONTA'}</option>;
                        })}
                    </select>
                    <ChevronDown size={12} className="absolute right-2 top-1/2 -translate-y-1/2 text-indigo-400 pointer-events-none" />
                </div>
            </div>
        </div>
    );
  };

  if (step === 'success') {
      return (
          <div className="fixed inset-0 bg-white dark:bg-[#1a1b2e] z-[100] flex flex-col items-center justify-center p-8 animate-in fade-in duration-500 overflow-y-auto transition-colors">
              <div className="mb-10"><div className="w-24 h-24 bg-teal-50 dark:bg-teal-500/10 rounded-full flex items-center justify-center animate-in zoom-in duration-700"><Check size={48} className="text-[#2dd4bf]" strokeWidth={3} /></div></div>
              <h2 className="text-xl font-bold text-gray-700 dark:text-white uppercase tracking-[0.4em] mb-4">Venda Concluída</h2>
              <p className="text-6xl font-light text-gray-900 dark:text-[#2dd4bf] mb-20 tracking-tighter">R$ {totalVenda.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
              <div className="w-full max-w-xs space-y-4">
                  <button onClick={() => setIsReceiptOpen(true)} className="w-full py-4 border-2 border-gray-100 dark:border-white/5 rounded-2xl font-bold text-gray-700 dark:text-gray-300 flex items-center justify-center gap-3 hover:bg-gray-50 dark:hover:bg-white/5 transition-all uppercase text-xs tracking-widest"><FileText size={18} strokeWidth={2.5} /> Visualizar Recibo</button>
                  <button onClick={() => window.location.reload()} className="w-full py-5 bg-[#2dd4bf] text-white rounded-2xl font-black text-sm uppercase tracking-[0.25em] shadow-xl shadow-teal-500/10 active:scale-95 transition-all">Iniciar outra venda</button>
              </div>
              {completedSale && <SaleDetailPanel isOpen={isReceiptOpen} onClose={() => setIsReceiptOpen(false)} sale={completedSale} />}
          </div>
      );
  }

  if (step === 'confirm_pix') {
      const pixValue = primaryMethod === 'pix' ? primaryAmount : remainingAmount;
      return (
          <div className="flex flex-col h-full bg-white dark:bg-[#1a1b2e] animate-in slide-in-from-right duration-300 transition-colors">
              <header className="px-6 py-6 flex items-center gap-4 max-w-xl mx-auto w-full">
                  <button onClick={() => { setStep('methods'); setShowQRCode(false); }} className="p-1 hover:bg-gray-100 dark:hover:bg-white/5 rounded-full transition-colors text-gray-900 dark:text-white"><ArrowLeft size={24} strokeWidth={2.5} /></button>
                  <span className="text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-widest">Pagamento Pix</span>
              </header>
              <div className="flex-1 overflow-y-auto px-8 py-4 text-center flex flex-col items-center max-w-xl mx-auto w-full">
                  {!showQRCode ? (
                      <div className="animate-in fade-in duration-500 w-full">
                          <div className="w-20 h-20 bg-teal-50 dark:bg-teal-500/10 rounded-3xl flex items-center justify-center text-[#2dd4bf] mx-auto mb-10 transition-colors"><QrCode size={40} strokeWidth={2.5} /></div>
                          <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">Checkout PIX</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-12 font-bold">Confirme os dados para gerar o código</p>
                          <div className="bg-gray-50/50 dark:bg-[#23243a] rounded-[2.5rem] p-10 space-y-8 text-left mb-12 border border-gray-200 dark:border-white/5 transition-colors">
                              <div><p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Empresa Beneficiária</p><p className="text-base font-bold text-gray-800 dark:text-white uppercase tracking-tight">ESPAÇO DIGITAL PDV</p></div>
                              <div className="h-px bg-gray-200 dark:bg-white/5"></div>
                              <div><p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Valor do Recebimento</p><p className="text-4xl font-bold text-gray-900 dark:text-[#2dd4bf] tracking-tighter transition-colors">R$ {pixValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p></div>
                          </div>
                          <button onClick={() => setShowQRCode(true)} className="w-full py-5 bg-gray-900 dark:bg-[#2dd4bf] text-white dark:text-[#1a1b2e] rounded-[1.5rem] font-bold text-sm uppercase tracking-[0.3em] shadow-2xl transition-all active:scale-95">Gerar QR Code Agora</button>
                      </div>
                  ) : (
                      <div className="animate-in zoom-in-95 duration-500 w-full flex flex-col items-center">
                          <p className="text-[11px] font-black text-[#2dd4bf] uppercase tracking-[0.4em] mb-10">Escaneie para pagar</p>
                          <div className="bg-white p-8 border border-gray-200 dark:border-white/10 rounded-[3rem] shadow-2xl mb-10 transition-colors"><img src={`https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=ESPACO_DIGITAL_PIX_${pixValue}_${Date.now()}`} alt="QR Code" className="w-52 h-52 sm:w-60 sm:h-60" /></div>
                          <div className="flex gap-4 mb-12"><button className="flex items-center gap-2 bg-gray-100 dark:bg-white/5 text-gray-700 dark:text-gray-300 px-8 py-3.5 rounded-full text-[11px] font-black uppercase tracking-widest hover:bg-gray-200 dark:hover:bg-white/10 transition-all"><Copy size={16} /> Copiar Código</button></div>
                          <button onClick={handleFinish} disabled={isProcessing} className="w-full py-5 bg-[#2dd4bf] text-white rounded-[1.5rem] font-black text-sm uppercase tracking-[0.3em] shadow-xl shadow-teal-500/10 transition-all active:scale-95 flex items-center justify-center gap-3">{isProcessing ? <Loader2 className="animate-spin" /> : 'Confirmar Recebimento'}</button>
                      </div>
                  )}
              </div>
          </div>
      );
  }

  return (
    <div className="flex-1 flex flex-col h-full bg-white dark:bg-[#1a1b2e] overflow-hidden relative font-sans transition-colors">
      
      {showPixChoice && (
          <div className="fixed inset-0 bg-black/60 z-[150] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
              <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] w-full max-w-sm shadow-2xl p-8 text-center animate-in zoom-in-95 duration-300 border border-transparent dark:border-white/5">
                  <div className="w-20 h-20 bg-teal-50 dark:bg-teal-500/10 text-[#2dd4bf] rounded-full flex items-center justify-center mx-auto mb-6"><QrCode size={40} strokeWidth={2.5} /></div>
                  <h3 className="text-xl font-black text-gray-900 dark:text-white uppercase tracking-tight mb-2">QR Code PIX</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-8 leading-relaxed">Deseja gerar o <strong>QR Code</strong> para o cliente escanear ou apenas concluir a venda agora?</p>
                  <div className="flex flex-col gap-3">
                      <button onClick={() => { setStep('confirm_pix'); setShowPixChoice(false); }} className="w-full py-4 bg-gray-900 dark:bg-white dark:text-[#1a1b2e] text-white font-black rounded-2xl shadow-xl flex items-center justify-center gap-2 transition-all active:scale-95"><QrCode size={18} /> GERAR QR CODE</button>
                      <button onClick={handleFinish} className="w-full py-4 bg-[#2dd4bf] text-white font-black rounded-2xl shadow-xl shadow-teal-100 dark:shadow-none flex items-center justify-center gap-2 transition-all active:scale-95"><Check size={18} strokeWidth={3} /> APENAS CONCLUIR</button>
                      <button onClick={() => setShowPixChoice(false)} className="w-full py-3 mt-2 text-gray-400 dark:text-gray-500 font-bold text-xs uppercase hover:text-gray-600 dark:hover:text-white transition-colors">Voltar</button>
                  </div>
              </div>
          </div>
      )}

      <header className="px-6 py-4 flex justify-between items-center bg-white dark:bg-[#23243a] shrink-0 border-b border-gray-100 dark:border-white/5 transition-colors">
        <div className="flex items-center gap-4 max-w-5xl mx-auto w-full">
            <button onClick={onBack} className="p-1 hover:bg-gray-100 dark:hover:bg-white/5 rounded-full text-gray-800 dark:text-white transition-colors"><ArrowLeft size={24} strokeWidth={2.5} /></button>
            <h2 className="text-xs font-bold text-gray-700 dark:text-gray-400 uppercase tracking-[0.3em]">Finalizar Venda</h2>
            <div className="flex-1"></div>
            {customer && <div className="bg-gray-100 dark:bg-white/5 rounded-xl px-4 py-2 flex items-center gap-3 border border-gray-200 dark:border-white/10 transition-colors"><span className="text-[10px] font-bold text-gray-800 dark:text-gray-300 uppercase tracking-widest truncate max-w-[120px] flex items-center gap-1.5">{customer.name} {portalUserIds.has(customer.id) && <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_6px_rgba(16,185,129,0.6)]" title="Cadastro Habilitado no Portal" />}</span><User size={14} className="text-gray-500 dark:text-gray-400" /></div>}
        </div>
      </header>

      <div className="flex-1 overflow-y-auto custom-scrollbar flex flex-col items-center">
          <div className="w-full max-w-xl pb-32">
              
              <div className="text-center py-4 sm:py-8 px-8">
                  <div className="flex items-baseline justify-center gap-2 text-gray-400 dark:text-gray-600 mb-1"><span className="text-2xl font-bold tracking-tighter">R$</span><input type="number" step="0.01" className="text-6xl sm:text-8xl font-bold tracking-tighter bg-transparent outline-none w-full text-center transition-all focus:text-[#2dd4bf] text-gray-900 dark:text-white" value={primaryAmount} onChange={(e) => { const val = parseFloat(e.target.value) || 0; if (primaryMethod === 'money') setPrimaryAmount(val); else setPrimaryAmount(Math.min(val, totalVenda)); }} onBlur={() => primaryAmount <= 0 && setPrimaryAmount(totalVenda)} /></div>
                  <p className="text-[11px] font-bold text-gray-600 dark:text-gray-500 uppercase tracking-[0.4em]">Toque para editar o valor recebido</p>
                  {hasChange && <div className="mt-6 flex flex-col items-center animate-in zoom-in-95 duration-300"><div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10 px-6 py-2 rounded-full border border-emerald-100 dark:border-emerald-500/20 transition-colors"><Coins size={16} strokeWidth={3} /><span className="text-[11px] font-black uppercase tracking-[0.2em]">Troco a Devolver</span></div><span className="text-4xl font-black text-emerald-500 dark:text-emerald-400 mt-2 tracking-tighter">R$ {changeAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span></div>}
                  
                  {/* SELETOR DE CARTEIRA (Principal) */}
                  {renderWalletSelector(primaryMethod, true)}
              </div>

              <div className="px-8 mb-8">
                  <button 
                    onClick={handleSaveAsOrder} 
                    disabled={isSavingOrder}
                    className="w-full py-4 border-2 border-gray-200 dark:border-white/10 rounded-2xl text-gray-700 dark:text-gray-300 font-bold uppercase text-[11px] tracking-[0.2em] hover:bg-gray-50 dark:hover:bg-white/5 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                      {isSavingOrder ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                      Salvar Pedido
                  </button>
              </div>

              <div className="px-8 mb-4">
                  <h3 className="text-[11px] font-black text-gray-700 dark:text-gray-400 uppercase tracking-[0.3em] mb-5 transition-colors">{isSplit ? `1º Pagamento: R$ ${primaryAmount.toFixed(2)}` : 'Escolha a forma de pagamento'}</h3>
                  <div className="grid grid-cols-4 gap-4">
                      {paymentMethods.map((m) => {
                          const isActive = primaryMethod === m.id;
                          return (
                              <button key={m.id} onClick={() => { setPrimaryMethod(m.id); if (m.id !== 'money' && primaryAmount > totalVenda) setPrimaryAmount(totalVenda); }} className={`h-28 flex flex-col items-center justify-center gap-3 rounded-3xl transition-all border-2 ${isActive ? 'bg-teal-50/50 dark:bg-teal-500/10 border-[#2dd4bf] shadow-xl shadow-teal-500/10 dark:shadow-none' : 'bg-white dark:bg-[#23243a] border-gray-200 dark:border-white/5 hover:border-gray-400 dark:hover:border-white/20'}`}><div className={`transition-all ${isActive ? 'text-[#2dd4bf]' : 'text-gray-500 dark:text-gray-600'}`}><m.icon size={28} strokeWidth={isActive ? 3 : 2} /></div><span className={`text-[11px] font-black uppercase text-center px-1 tracking-tight leading-[1.1] transition-colors ${isActive ? 'text-[#2dd4bf]' : 'text-gray-700 dark:text-gray-400'}`}>{m.label.replace('Cartão de ', '')}</span></button>
                          );
                      })}
                  </div>
              </div>

              {isSplit && (
                  <div className="mt-8 animate-in slide-in-from-bottom-6 duration-500 mx-8">
                      <div className="px-8 py-6 bg-amber-50 dark:bg-amber-500/10 border-2 border-amber-300 dark:border-amber-500/30 flex items-center justify-between mb-2 rounded-[2rem] shadow-sm transition-colors"><div className="flex items-center gap-3 text-amber-800 dark:text-amber-400"><AlertCircle size={20} strokeWidth={3} /><span className="text-[11px] font-black uppercase tracking-[0.2em]">Saldo Restante</span></div><span className="text-2xl font-bold text-amber-900 dark:text-amber-300 tracking-tighter">R$ {remainingAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span></div>
                      
                      {/* SELETOR DE CARTEIRA (Secundária) */}
                      {secondaryMethod && renderWalletSelector(secondaryMethod, false)}

                      <div className="grid grid-cols-4 gap-4 mt-6">
                        {paymentMethods.map((m) => {
                            const isActive = secondaryMethod === m.id;
                            return (
                                <button key={`sec-${m.id}`} onClick={() => setSecondaryMethod(m.id)} className={`h-28 flex flex-col items-center justify-center gap-3 rounded-3xl transition-all border-2 ${isActive ? 'bg-amber-100/80 dark:bg-amber-500/20 border-amber-600 dark:border-amber-500/50 shadow-xl shadow-amber-500/10 dark:shadow-none' : 'bg-white dark:bg-[#23243a] border-gray-200 dark:border-white/5 hover:border-gray-400 dark:hover:border-white/20'}`}><div className={`transition-all ${isActive ? 'text-amber-800 dark:text-amber-400 scale-110' : 'text-gray-500 dark:text-gray-600'}`}><m.icon size={26} strokeWidth={isActive ? 3 : 2} /></div><span className={`text-[11px] font-black uppercase text-center px-1 tracking-tight leading-[1.1] transition-colors ${isActive ? 'text-amber-900 dark:text-amber-300' : 'text-gray-700 dark:text-gray-400'}`}>{m.label.replace('Cartão de ', '')}</span></button>
                            );
                        })}
                      </div>
                  </div>
              )}
          </div>
      </div>

      <footer className="p-8 border-t border-gray-100 dark:border-white/5 bg-white dark:bg-[#23243a] z-20 shadow-[0_-20px_50px_-20px_rgba(0,0,0,0.15)] transition-colors">
          <div className="max-w-xl mx-auto w-full">
              <button onClick={handleAdvance} disabled={isProcessing || (isSplit && !secondaryMethod) || primaryAmount === 0} className={`w-full py-6 rounded-[2rem] font-black uppercase tracking-[0.3em] shadow-2xl transition-all flex items-center justify-between px-10 active:scale-[0.98] ${((isSplit && !secondaryMethod) || primaryAmount === 0) ? 'bg-gray-200 dark:bg-white/5 text-gray-500 dark:text-gray-700 cursor-not-allowed border border-gray-300 dark:border-white/10' : 'bg-[#2dd4bf] text-white shadow-teal-500/30 hover:brightness-105'}`}><span className="flex items-center gap-5"><span className="text-sm">{isSplit ? 'Finalizar Pagamentos' : 'Concluir Venda'}</span><div className="w-1.5 h-1.5 bg-white/40 rounded-full"></div><span className="text-sm font-bold tracking-normal">R$ {totalVenda.toFixed(2)}</span></span><ChevronRight size={26} strokeWidth={4} /></button>
          </div>
      </footer>
    </div>
  );
};

export default PaymentScreen;
