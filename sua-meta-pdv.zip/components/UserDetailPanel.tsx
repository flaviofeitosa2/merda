
import React, { useState, useEffect, useMemo } from 'react';
import { 
  ArrowLeft, 
  HelpCircle, 
  User, 
  Mail, 
  Loader2,
  Info,
  Trash2,
  AlertTriangle,
  Save,
  Shield,
  ShoppingCart,
  Key,
  ShieldCheck,
  Eye,
  EyeOff,
  X,
  Lock,
  CheckCircle2
} from 'lucide-react';
import UserMenu from './UserMenu';
import { UserProfile, Sale } from '../types';
import { supabase } from '../supabaseClient';

interface UserDetailPanelProps {
  user: UserProfile;       
  currentUser: UserProfile; 
  onBack: () => void;
  companyId: string;
}

const UserDetailPanel: React.FC<UserDetailPanelProps> = ({ user, currentUser, onBack, companyId }) => {
  const [sales, setSales] = useState<Sale[]>([]);
  const [loadingSales, setLoadingSales] = useState(true);
  const [saving, setSaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [formName, setFormName] = useState(user.full_name || '');
  const [formEmail, setFormEmail] = useState(user.email || '');
  
  // Estados para alteração de senha
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isUpdatingPassword, setIsUpdatingPassword] = useState(false);

  const isViewerAdmin = currentUser.role === 'owner' || currentUser.role === 'admin' || currentUser.role === 'master';
  const isOwnProfile = currentUser.id === user.id;

  const [permissions, setPermissions] = useState({
      isAdmin: user.role === 'admin' || user.role === 'owner' || user.role === 'master',
      canUseMobile: true,
      canViewOthers: user.role !== 'operator',
      canDiscount: false,
      canManageProducts: user.role !== 'operator',
      canManageStock: false,
      canTab: false
  });

  const roleLabel = user.role === 'owner' ? 'Dono' : user.role === 'admin' ? 'Admin' : user.role === 'master' ? 'Master' : 'Operador';
  const roleColor = user.role === 'owner' ? 'bg-amber-100 dark:bg-amber-500/10 text-amber-800 dark:text-amber-400' : user.role === 'admin' ? 'bg-blue-100 dark:bg-blue-500/10 text-blue-800 dark:text-blue-400' : 'bg-gray-100 dark:bg-white/5 text-gray-600 dark:text-gray-400';

  useEffect(() => {
      const fetchProfileData = async () => {
          try {
              const { data, error } = await supabase
                  .from('profiles')
                  .select('email, full_name')
                  .eq('id', user.id)
                  .single();
              
              if (data && !error) {
                  if (data.email) setFormEmail(data.email);
                  if (data.full_name) setFormName(data.full_name);
              }
          } catch (e) {
              console.error("Erro ao atualizar perfil:", e);
          }
      };
      
      fetchProfileData();
  }, [user.id]);

  useEffect(() => {
      const initData = async () => {
          setLoadingSales(true);

          if (!formEmail && !user.email) {
             try {
               const { data: { session } } = await supabase.auth.getSession();
               if (!session) return;

               const { data: { user: authUser }, error } = await supabase.auth.getUser();
               if (!error && authUser && authUser.id === user.id) {
                   setFormEmail(authUser.email || '');
               }
             } catch (err) {
               console.error("Failed to get auth user:", err);
             }
          }

          const { data } = await supabase
            .from('sales')
            .select('*')
            .eq('company_id', companyId)
            .ilike('seller_name', user.full_name || '')
            .order('date', { ascending: false })
            .limit(50);

          if (data) {
              setSales(data.map((s: any) => ({
                  ...s,
                  items: s.items || [], 
              } as Sale)));
          }
          setLoadingSales(false);
      };
      
      initData();
  }, [user, companyId]); 

  const stats = useMemo(() => {
      const today = new Date();
      const yesterday = new Date();
      yesterday.setDate(today.getDate() - 1);
      
      const isSameDay = (d1: Date, d2: Date) => 
        d1.getDate() === d2.getDate() && 
        d1.getMonth() === d2.getMonth() && 
        d1.getFullYear() === d2.getFullYear();

      const todayTotal = sales.filter(s => isSameDay(new Date(s.date), today)).length;
      const yesterdayTotal = sales.filter(s => isSameDay(new Date(s.date), yesterday)).length;
      const thisMonth = sales.filter(s => new Date(s.date).getMonth() === today.getMonth()).length;
      const thirtyDaysRevenue = sales.reduce((acc, curr) => acc + (curr.total || 0), 0);

      return { today: todayTotal, yesterday: yesterdayTotal, week: 0, month: thisMonth, thirtyDays: thirtyDaysRevenue };
  }, [sales]);

  const handleSave = async () => {
      setSaving(true);
      try {
          const { error } = await supabase
            .from('profiles')
            .update({ 
                full_name: formName,
                email: formEmail
            }) 
            .eq('id', user.id);
          
          if (error) throw error;
          alert('Dados atualizados com sucesso!');
      } catch (err) {
          console.error(err);
          alert('Erro ao atualizar usuário');
      } finally {
          setSaving(false);
      }
  };

  const handleUpdatePassword = async () => {
    if (newPassword.length < 6) return alert("A senha deve ter pelo menos 6 caracteres.");
    if (newPassword !== confirmPassword) return alert("As senhas não coincidem.");
    
    setIsUpdatingPassword(true);
    try {
        // Nota: supabase.auth.admin requer permissões adequadas no Supabase
        const { error } = await supabase.auth.admin.updateUserById(
            user.id,
            { password: newPassword }
        );

        if (error) {
            // Fallback caso a API admin não esteja acessível pelo client comum
            if (error.status === 403 || error.message.includes("permission denied")) {
                throw new Error("Privilégios insuficientes. Para trocar a senha de outro usuário, é necessário permissão de Administrador de Serviço ou via Edge Functions.");
            }
            throw error;
        }

        alert("Senha do colaborador atualizada com sucesso!");
        setIsPasswordModalOpen(false);
        setNewPassword('');
        setConfirmPassword('');
    } catch (err: any) {
        console.error("Erro ao trocar senha:", err);
        alert(err.message);
    } finally {
        setIsUpdatingPassword(false);
    }
  };

  const handleDeleteUser = async () => {
      if (isOwnProfile) return alert("Você não pode excluir seu próprio perfil.");
      
      setIsDeleting(true);
      try {
          const { error } = await supabase
            .from('profiles')
            .delete()
            .eq('id', user.id);

          if (error) throw error;
          
          alert("Usuário removido da empresa com sucesso.");
          onBack();
      } catch (err: any) {
          console.error(err);
          alert("Erro ao excluir usuário: " + err.message);
      } finally {
          setIsDeleting(false);
          setShowDeleteConfirm(false);
      }
  };

  const ToggleItem = ({ label, desc, checked, onChange, disabled }: any) => (
      <div className="flex justify-between items-center py-4 border-b border-gray-100 dark:border-white/5 last:border-0 transition-colors">
          <div className="pr-4">
              <p className={`text-sm font-bold ${disabled ? 'text-gray-400 dark:text-gray-600' : 'text-gray-700 dark:text-gray-300'}`}>{label}</p>
              <p className="text-[10px] text-gray-400 dark:text-gray-500 mt-1 uppercase font-bold tracking-widest leading-relaxed">{desc}</p>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input 
                type="checkbox" 
                className="sr-only peer" 
                checked={checked} 
                onChange={(e) => onChange(e.target.checked)} 
                disabled={disabled}
            />
            <div className={`w-11 h-6 bg-gray-200 dark:bg-[#1a1b2e] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 dark:after:border-[#1a1b2e] after:border after:rounded-full after:h-5 after:w-5 after:transition-all ${checked ? 'peer-checked:bg-[#2dd4bf]' : ''} ${disabled ? 'opacity-50' : ''}`}></div>
          </label>
      </div>
  );

  return (
    <div className="flex-1 flex flex-col h-full bg-[#f8f9fa] dark:bg-[#1a1b2e] overflow-hidden transition-colors">
      
      {/* Modal de Alteração de Senha */}
      {isPasswordModalOpen && (
          <div className="fixed inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-sm z-[150] flex items-center justify-center p-4 animate-in fade-in duration-300">
              <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] w-full max-w-md shadow-2xl overflow-hidden animate-in zoom-in-95 border border-transparent dark:border-white/5 transition-colors">
                  <div className="p-10 pb-4 flex justify-between items-start">
                      <div>
                          <h3 className="text-2xl font-black text-[#1e293b] dark:text-white uppercase tracking-tighter italic leading-none">ALTERAR SENHA</h3>
                          <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mt-2">DEFINIR NOVA CREDENCIAL PARA O COLABORADOR</p>
                      </div>
                      <button onClick={() => setIsPasswordModalOpen(false)} className="text-slate-300 hover:text-slate-600 dark:hover:text-white transition-colors p-1">
                          <X size={28} />
                      </button>
                  </div>
                  <div className="p-10 space-y-6">
                      <div className="bg-amber-50 dark:bg-amber-500/10 p-4 rounded-2xl border border-amber-100 dark:border-amber-500/20 flex gap-3 mb-4">
                          <AlertTriangle className="text-amber-600 shrink-0" size={18} />
                          <p className="text-[10px] font-bold text-amber-700 dark:text-amber-400 uppercase leading-relaxed tracking-tight">
                              Atenção: Ao alterar a senha, o usuário será deslogado de todas as sessões ativas e precisará da nova credencial para entrar.
                          </p>
                      </div>

                      <div className="relative group">
                          <label className="absolute -top-2.5 left-5 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-indigo-500 uppercase tracking-widest z-10 transition-all">NOVA SENHA</label>
                          <div className="flex items-center border-2 border-indigo-100 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] focus-within:border-indigo-400 transition-all h-16">
                              <Lock className="text-slate-200 mr-4" size={20} />
                              <input 
                                type={showPassword ? "text" : "password"}
                                className="w-full bg-transparent outline-none text-base font-black text-slate-700 dark:text-white uppercase"
                                placeholder="Mínimo 6 dígitos"
                                value={newPassword}
                                onChange={(e) => setNewPassword(e.target.value)}
                                autoFocus
                              />
                              <button onClick={() => setShowPassword(!showPassword)} className="text-gray-300 hover:text-indigo-600">
                                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                              </button>
                          </div>
                      </div>

                      <div className="relative group">
                          <label className="absolute -top-2.5 left-5 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-indigo-500 uppercase tracking-widest z-10 transition-all">CONFIRMAR SENHA</label>
                          <div className="flex items-center border-2 border-slate-100 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] focus-within:border-indigo-400 transition-all h-16">
                              <ShieldCheck className="text-slate-200 mr-4" size={20} />
                              <input 
                                type={showPassword ? "text" : "password"}
                                className="w-full bg-transparent outline-none text-base font-black text-slate-700 dark:text-white uppercase"
                                placeholder="Repita a nova senha"
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                              />
                          </div>
                      </div>

                      <button 
                        onClick={handleUpdatePassword}
                        disabled={isUpdatingPassword || !newPassword || newPassword !== confirmPassword}
                        className={`w-full py-6 rounded-2xl font-black text-xs uppercase tracking-widest shadow-2xl transition-all flex items-center justify-center gap-3 active:scale-95 disabled:grayscale disabled:opacity-40 mt-4 ${(!newPassword || newPassword !== confirmPassword) ? 'bg-slate-300' : 'bg-indigo-600 text-white shadow-indigo-600/30'}`}
                      >
                          {isUpdatingPassword ? <Loader2 className="animate-spin" size={22} /> : <CheckCircle2 size={22} strokeWidth={3} />}
                          SALVAR NOVA SENHA
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* Modal de Confirmação de Exclusão */}
      {showDeleteConfirm && (
          <div className="fixed inset-0 bg-black/60 z-[150] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
              <div className="bg-white dark:bg-[#23243a] rounded-[2rem] w-full max-sm:max-w-sm shadow-2xl p-8 text-center animate-in zoom-in-95 duration-300 border border-transparent dark:border-white/5">
                  <div className="w-20 h-20 bg-rose-50 dark:bg-rose-500/10 text-rose-500 dark:text-rose-400 rounded-full flex items-center justify-center mx-auto mb-6">
                      <AlertTriangle size={40} />
                  </div>
                  <h3 className="text-xl font-black text-gray-900 dark:text-white uppercase tracking-tight mb-2">Excluir Usuário?</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-8 leading-relaxed font-medium">
                      Você está prestes a remover <strong>{formName}</strong> da sua empresa. Esta ação não pode ser desfeita.
                  </p>
                  <div className="flex flex-col gap-3">
                      <button 
                        onClick={handleDeleteUser}
                        disabled={isDeleting}
                        className="w-full py-4 bg-rose-500 hover:bg-rose-600 text-white font-black rounded-2xl shadow-xl shadow-rose-100 dark:shadow-none flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
                      >
                          {isDeleting ? <Loader2 className="animate-spin" size={20} /> : <Trash2 size={20} />}
                          SIM, EXCLUIR AGORA
                      </button>
                      <button 
                        onClick={() => setShowDeleteConfirm(false)}
                        disabled={isDeleting}
                        className="w-full py-4 bg-gray-100 dark:bg-white/5 text-gray-500 dark:text-gray-400 font-bold rounded-2xl hover:bg-gray-200 dark:hover:bg-white/10 transition-all"
                      >
                          CANCELAR
                      </button>
                  </div>
              </div>
          </div>
      )}

      <header className="bg-white dark:bg-[#23243a] border-b border-gray-200 dark:border-white/5 px-6 py-4 flex justify-between items-center sticky top-0 z-20 transition-colors">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-gray-100 dark:hover:bg-white/5 rounded-full text-gray-600 dark:text-gray-400 transition-colors">
            <ArrowLeft size={24} />
          </button>
          <div className="flex items-center gap-3">
             <h2 className="text-xl font-black text-gray-800 dark:text-white uppercase tracking-tighter leading-none">{formName || 'Usuário'}</h2>
             <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-widest ${roleColor} transition-colors`}>
                 {roleLabel}
             </span>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          {isViewerAdmin && !isOwnProfile && (
              <button 
                onClick={() => setShowDeleteConfirm(true)}
                className="p-2 text-gray-400 dark:text-gray-500 hover:text-rose-500 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-full transition-all"
                title="Excluir Usuário"
              >
                  <Trash2 size={20} />
              </button>
          )}
          <div className="h-6 w-px bg-gray-200 dark:bg-white/5 hidden sm:block"></div>
          <UserMenu />
        </div>
      </header>

      <div className="bg-gray-50 dark:bg-[#1a1b2e] border-b border-gray-200 dark:border-white/5 px-6 py-3 transition-colors">
          <div className="flex flex-wrap gap-8 text-sm">
              {[
                  { label: 'Hoje', val: stats.today },
                  { label: 'Ontem', val: stats.yesterday },
                  { label: 'Este mês', val: stats.month }
              ].map((item, idx) => (
                  <div key={idx} className="flex items-baseline gap-1.5">
                      <span className="text-gray-500 dark:text-gray-500 text-[10px] font-black uppercase tracking-widest">{item.label}:</span>
                      <span className="text-gray-800 dark:text-gray-300 font-bold">{item.val} vendas</span>
                  </div>
              ))}
          </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 custom-scrollbar transition-colors">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto pb-20">
              
              <div className="space-y-8">
                  
                  <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] shadow-sm border border-gray-200 dark:border-white/5 p-8 transition-colors">
                      <h3 className="text-xs font-black text-gray-800 dark:text-white uppercase tracking-[0.2em] mb-8 flex items-center gap-2">
                        <User size={16} className="text-indigo-600 dark:text-indigo-400" /> Identificação
                      </h3>
                      <div className="space-y-6">
                          <div className="relative">
                              <label className="absolute -top-2.5 left-3 bg-white dark:bg-[#23243a] px-1 text-[10px] font-black text-gray-500 dark:text-gray-400 uppercase tracking-widest z-10 transition-all">Nome Completo</label>
                              <div className="relative">
                                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300 dark:text-gray-600" size={18} />
                                  <input 
                                    type="text" 
                                    value={formName}
                                    onChange={e => setFormName(e.target.value)}
                                    className="w-full pl-12 pr-4 py-4 bg-gray-50 dark:bg-[#1a1b2e] border-2 border-transparent focus:border-[#2dd4bf] dark:focus:border-[#2dd4bf]/40 rounded-2xl text-sm text-gray-900 dark:text-white font-bold outline-none transition-all"
                                  />
                              </div>
                          </div>
                          <div className="relative">
                              <label className="absolute -top-2.5 left-3 bg-white dark:bg-[#23243a] px-1 text-[10px] font-black text-gray-500 dark:text-gray-400 uppercase tracking-widest z-10 transition-all">E-mail de Login</label>
                              <div className="relative">
                                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300 dark:text-gray-600" size={18} />
                                  <input 
                                    type="email" 
                                    value={formEmail}
                                    readOnly
                                    className="w-full pl-12 pr-4 py-4 bg-gray-100 dark:bg-[#1a1b2e]/60 border-2 border-transparent rounded-2xl text-sm text-gray-400 dark:text-gray-500 font-bold outline-none cursor-not-allowed transition-all"
                                  />
                              </div>
                              <div className="flex gap-2 mt-3 bg-blue-50 dark:bg-blue-500/10 text-blue-700 dark:text-blue-400 p-3 rounded-xl border border-blue-100 dark:border-blue-500/20 transition-colors">
                                  <Info size={14} className="shrink-0 mt-0.5" />
                                  <p className="text-[10px] font-bold uppercase tracking-tight leading-tight">
                                      O e-mail é a chave de acesso e não pode ser alterado por segurança.
                                  </p>
                              </div>
                          </div>
                          
                          <div className="flex justify-end pt-2">
                              <button 
                                onClick={handleSave}
                                disabled={saving}
                                className="bg-[#2dd4bf] hover:bg-[#14b8a6] text-white dark:text-[#1a1b2e] font-black py-3.5 px-8 rounded-2xl text-xs uppercase tracking-widest transition-all flex items-center gap-3 shadow-lg shadow-teal-500/20 active:scale-95"
                              >
                                  {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                                  Atualizar Perfil
                              </button>
                          </div>
                      </div>
                  </div>

                  {/* SEÇÃO DE SEGURANÇA: TROCAR SENHA DO COLABORADOR */}
                  {isViewerAdmin && !isOwnProfile && (
                    <div className="bg-white dark:bg-[#23243a] rounded-[2rem] shadow-sm border-2 border-indigo-50 dark:border-indigo-500/10 p-8 transition-colors relative overflow-hidden group">
                        <div className="absolute top-0 right-0 p-6 opacity-5 text-indigo-600 group-hover:scale-105 transition-transform duration-1000"><Key size={80} /></div>
                        <h3 className="text-xs font-black text-gray-800 dark:text-white uppercase tracking-[0.2em] mb-1 flex items-center gap-2 relative z-10">
                            <ShieldCheck size={16} className="text-indigo-600 dark:text-indigo-400" /> Segurança de Acesso
                        </h3>
                        <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 mb-6 uppercase tracking-widest relative z-10">CONTROLE DE CREDENCIAIS</p>
                        
                        <div className="space-y-4 relative z-10">
                            <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed font-medium">
                                Como administrador, você pode redefinir a senha de acesso deste colaborador em caso de esquecimento ou necessidade de bloqueio.
                            </p>
                            <button 
                                onClick={() => setIsPasswordModalOpen(true)}
                                className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-[10px] uppercase tracking-[0.2em] rounded-2xl shadow-xl shadow-indigo-200 dark:shadow-none transition-all active:scale-95 flex items-center justify-center gap-3"
                            >
                                <Key size={16} /> REDEFINIR SENHA DO USUÁRIO
                            </button>
                        </div>
                    </div>
                  )}

                  <div className="bg-white dark:bg-[#23243a] rounded-[2rem] shadow-sm border border-gray-200 dark:border-white/5 p-8 transition-colors">
                      <h3 className="text-xs font-black text-gray-800 dark:text-white uppercase tracking-[0.2em] mb-1 flex items-center gap-2">
                        <Shield size={16} className="text-indigo-600 dark:text-indigo-400" /> Permissões
                      </h3>
                      <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 mb-8 uppercase tracking-widest">Controle o nível de acesso do colaborador</p>
                      
                      {!isViewerAdmin && (
                          <div className="bg-amber-50 dark:bg-amber-500/10 border border-amber-100 dark:border-amber-500/20 rounded-xl p-3 mb-6 text-[10px] font-bold uppercase tracking-tight text-amber-700 dark:text-amber-400 transition-colors">
                              Você não tem privilégios para alterar níveis de acesso.
                          </div>
                      )}

                      <div className="space-y-1">
                          <ToggleItem 
                            label="Acesso Administrativo" 
                            desc="Libera todas as telas e configurações do sistema." 
                            checked={permissions.isAdmin}
                            onChange={(v: boolean) => setPermissions(p => ({...p, isAdmin: v}))}
                            disabled={!isViewerAdmin || user.role === 'owner'} 
                          />
                          <ToggleItem 
                            label="Venda em Dispositivos Móveis" 
                            desc="Permite login e vendas via celular ou tablet." 
                            checked={permissions.canUseMobile}
                            onChange={(v: boolean) => setPermissions(p => ({...p, canUseMobile: v}))}
                            disabled={!isViewerAdmin}
                          />
                          <ToggleItem 
                            label="Visibilidade Global" 
                            desc="Permite visualizar vendas de toda a equipe." 
                            checked={permissions.canViewOthers}
                            onChange={(v: boolean) => setPermissions(p => ({...p, canViewOthers: v}))}
                            disabled={!isViewerAdmin}
                          />
                          <ToggleItem 
                            label="Autonomia de Descontos" 
                            desc="Permite aplicar descontos livremente no PDV." 
                            checked={permissions.canDiscount}
                            onChange={(v: boolean) => setPermissions(p => ({...p, canDiscount: v}))}
                            disabled={!isViewerAdmin}
                          />
                          <ToggleItem 
                            label="Gestão de Produtos" 
                            desc="Permite cadastrar e editar itens do catálogo." 
                            checked={permissions.canManageProducts}
                            onChange={(v: boolean) => setPermissions(p => ({...p, canManageProducts: v}))}
                            disabled={!isViewerAdmin}
                          />
                          <ToggleItem 
                            label="Controle de Estoque" 
                            desc="Permite ajustes manuais de entrada e saída." 
                            checked={permissions.canManageStock}
                            onChange={(v: boolean) => setPermissions(p => ({...p, canManageStock: v}))}
                            disabled={!isViewerAdmin}
                          />
                          <ToggleItem 
                            label="Venda Fiado" 
                            desc="Permite autorizar vendas a prazo para clientes." 
                            checked={permissions.canTab}
                            onChange={(v: boolean) => setPermissions(p => ({...p, canTab: v}))}
                            disabled={!isViewerAdmin}
                          />
                      </div>
                  </div>

              </div>

              <div className="space-y-8">
                  
                  <div className="bg-indigo-600 dark:bg-indigo-700 rounded-[2.5rem] p-10 text-white shadow-xl shadow-indigo-100 dark:shadow-none text-center flex flex-col items-center justify-center min-h-[220px] relative overflow-hidden transition-all group">
                      <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                      <span className="text-[10px] font-black uppercase tracking-[0.4em] mb-4 text-indigo-100 relative z-10">Últimos 30 dias</span>
                      <span className="text-4xl lg:text-5xl font-black tracking-tighter relative z-10">
                          {stats.thirtyDays.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </span>
                      <div className="mt-6 flex items-center gap-2 bg-white/10 px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest relative z-10">
                          <ShoppingCart size={14} /> {sales.length} VENDAS CONCLUÍDAS
                      </div>
                  </div>

                  <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] shadow-sm border border-gray-200 dark:border-white/5 flex flex-col h-[580px] overflow-hidden transition-colors">
                      <div className="p-8 border-b border-gray-100 dark:border-white/5 flex justify-between items-center transition-colors">
                          <div>
                            <h3 className="font-black text-gray-800 dark:text-white uppercase text-sm tracking-widest">Atividade Recente</h3>
                            <p className="text-[10px] font-bold text-gray-400 mt-1 uppercase tracking-widest">Últimas vendas do colaborador</p>
                          </div>
                          <button className="text-indigo-600 dark:text-indigo-400 text-[10px] font-black uppercase tracking-widest hover:underline">Ver Histórico Completo</button>
                      </div>
                      
                      <div className="flex-1 overflow-y-auto custom-scrollbar">
                          {loadingSales ? (
                              <div className="flex flex-col items-center justify-center h-full text-gray-400 dark:text-gray-600">
                                  <Loader2 className="animate-spin mb-3" size={32} /> 
                                  <p className="text-[10px] font-black uppercase tracking-widest">Sincronizando faturamento...</p>
                              </div>
                          ) : sales.length === 0 ? (
                              <div className="flex flex-col items-center justify-center h-full text-gray-300 dark:text-gray-700 text-center p-10">
                                  <ShoppingCart size={48} className="mb-4 opacity-10" />
                                  <p className="text-[10px] font-black uppercase tracking-widest">Sem vendas registradas.</p>
                              </div>
                          ) : (
                              <div className="divide-y divide-gray-50 dark:divide-white/5">
                                  {sales.map((sale) => (
                                      <div key={sale.id} className="flex justify-between items-center p-6 hover:bg-gray-50 dark:hover:bg-white/5 transition-colors group">
                                          <div>
                                              <div className="flex items-center gap-2 mb-1.5">
                                                  <span className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-tight group-hover:text-indigo-500 transition-colors">#{sale.code}</span>
                                                  <div className="w-1 h-1 bg-gray-300 rounded-full"></div>
                                                  <span className="text-[10px] text-gray-400 dark:text-gray-500 font-bold uppercase">
                                                      {new Date(sale.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}, {new Date(sale.date).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                                                  </span>
                                              </div>
                                              <div className="text-xs font-black text-gray-700 dark:text-gray-300 uppercase tracking-tighter truncate max-w-[180px]">
                                                  {sale.clientName}
                                              </div>
                                          </div>
                                          <div className="text-right">
                                              <div className="font-black text-gray-800 dark:text-white text-sm tracking-tight">
                                                  {sale.total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                                              </div>
                                              <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">{sale.paymentMethod === 'credit' ? 'Crédito' : sale.paymentMethod === 'debit' ? 'Débito' : sale.paymentMethod === 'money' ? 'Dinheiro' : 'Pix'}</span>
                                          </div>
                                      </div>
                                  ))}
                              </div>
                          )}
                      </div>
                  </div>

              </div>
          </div>
      </div>
    </div>
  );
};

export default UserDetailPanel;
