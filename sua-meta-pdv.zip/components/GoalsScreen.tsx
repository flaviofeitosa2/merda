
import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import { 
  Target, 
  Loader2,
  X,
  BarChart3,
  Activity,
  Calendar,
  DollarSign,
  TrendingUp,
  Edit2,
  User,
  Users,
  ChevronRight,
  Clock,
  Briefcase,
  List,
  Plus,
  PlusCircle,
  TrendingDown,
  ChevronDown,
  History,
  Check,
  Save,
  CheckCircle2
} from 'lucide-react';
import { Sale, UserProfile, UserGoal, FinanceTransaction } from '../types';
import { supabase } from '../supabaseClient';
import UserMenu from './UserMenu';

interface GoalsScreenProps {
  sales: Sale[];
  toggleSidebar: () => void;
  userProfile: UserProfile;
}

const formatCurrency = (val: number) => val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const safeParse = (str: string | null, fallback: any) => {
  if (!str) return fallback;
  try {
    return JSON.parse(str);
  } catch (e) {
    console.error("Error parsing JSON:", e);
    return fallback;
  }
};

const getSafeTimestamp = (dateStr: any, origin: string = 'pos') => {
    if (!dateStr || typeof dateStr !== 'string') return 0;
    try {
        if (origin === 'pos' || dateStr.includes('T') || dateStr.includes('Z')) {
            const t = new Date(dateStr).getTime();
            return isNaN(t) ? 0 : t;
        }
        const datePart = dateStr.split(/[T ]/)[0];
        if (!datePart) return 0;
        const parts = datePart.split('-');
        if (parts.length < 3) return 0;
        const [y, m, d] = parts.map(Number);
        const t = new Date(y, m - 1, d, 12, 0, 0).getTime();
        return isNaN(t) ? 0 : t;
    } catch (e) {
        return 0;
    }
};

const GoalsScreen: React.FC<GoalsScreenProps> = ({ sales = [], toggleSidebar, userProfile }) => {
  const isOperator = userProfile.role === 'operator' || userProfile.role === 'operador';
  const [activeTab, setActiveTab] = useState<'METAS' | 'RESULTADO_ANUAL'>('METAS');
  const [loading, setLoading] = useState(true);
  const [includeSaturdays, setIncludeSaturdays] = useState(false);
  const [teamVisibility, setTeamVisibility] = useState(false);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [goals, setGoals] = useState<UserGoal[]>([]);
  const [financeTransactions, setFinanceTransactions] = useState<FinanceTransaction[]>([]);

  // Estados para Edição de Metas
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingTarget, setEditingTarget] = useState<{ type: 'company' | 'user', id?: string, name: string, currentValue: number, currentCommission: number } | null>(null);
  const [editGoalValue, setEditGoalValue] = useState('');
  const [editCommissionValue, setEditCommissionValue] = useState('');
  const [isSavingGoal, setIsSavingGoal] = useState(false);

  const [historicalData, setHistoricalData] = useState<Record<string, number>>({});
  const [isSavingHistorical, setIsSavingHistorical] = useState(false);
  const [editingCell, setEditingCell] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');

  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());

  const fetchData = useCallback(async () => {
    if (!userProfile?.company_id) return;
    setLoading(true);
    try {
      const [goalsRes, usersRes, finRes, companyRes] = await Promise.all([
        supabase.from('user_goals').select('*').eq('company_id', userProfile.company_id).eq('month', currentMonth).eq('year', currentYear),
        supabase.from('profiles').select('*').eq('company_id', userProfile.company_id).in('role', ['owner', 'admin', 'operator', 'master', 'mestre']),
        supabase.from('finance_transactions').select('*').eq('company_id', userProfile.company_id).or('status.eq.paid,status.is.null'),
        supabase.from('companies').select('wallet_settings').eq('id', userProfile.company_id).single()
      ]);

      if (goalsRes.data) setGoals(goalsRes.data);
      if (usersRes.data) setUsers(usersRes.data);
      if (finRes.data) setFinanceTransactions(finRes.data as any);
      
      // Carregar dados históricos do banco (prioridade) ou localStorage ou fallback
      let hData = {};
      if (companyRes.data?.wallet_settings?.historical_revenue) {
        hData = typeof companyRes.data.wallet_settings.historical_revenue === 'string' 
          ? safeParse(companyRes.data.wallet_settings.historical_revenue, {})
          : companyRes.data.wallet_settings.historical_revenue;
      } else {
        const saved = localStorage.getItem('goals_historical_data');
        hData = safeParse(saved, {
          // Dados padrão iniciais (2016-2026)
          "2026-0": 16977.90, "2026-1": 13002.60,
            "2025-0": 25132.32, "2025-1": 25873.95, "2025-2": 25197.00, "2025-3": 20093.70, "2025-4": 22622.76, "2025-5": 24923.15, "2025-6": 25803.55, "2025-7": 24561.51, "2025-8": 25712.65, "2025-9": 23381.20, "2025-10": 23196.79, "2025-11": 22853.44,
            "2024-0": 24739.12, "2024-1": 25776.10, "2024-2": 27862.70, "2024-3": 27407.20, "2024-4": 23247.65, "2024-5": 23041.45, "2024-6": 28739.17, "2024-7": 26290.95, "2024-8": 23719.59, "2024-9": 24564.10, "2024-10": 22106.05, "2024-11": 14985.20,
            "2023-0": 29040.00, "2023-1": 23843.40, "2023-2": 25966.95, "2023-3": 18617.25, "2023-4": 25991.10, "2023-5": 22474.46, "2023-6": 22259.11, "2023-7": 24485.37, "2023-8": 22036.50, "2023-9": 21894.55, "2023-10": 19723.70, "2023-11": 15602.20,
            "2022-0": 22710.85, "2022-1": 24784.14, "2022-2": 20917.80, "2022-3": 21278.85, "2022-4": 25017.38, "2022-5": 24971.84, "2022-6": 23645.45, "2022-7": 25512.10, "2022-8": 20060.69, "2022-9": 21125.35, "2022-10": 20655.05, "2022-11": 17849.30,
            "2021-0": 18417.70, "2021-1": 16375.05, "2021-2": 21761.95, "2021-3": 18039.00, "2021-4": 17369.85, "2021-5": 22296.31, "2021-6": 19763.85, "2021-7": 20633.09, "2021-8": 20534.60, "2021-9": 20652.00, "2021-10": 18137.59, "2021-11": 21315.08,
            "2020-0": 18696.15, "2020-1": 21076.76, "2020-2": 14723.65, "2020-3": 6461.90, "2020-4": 13258.05, "2020-5": 19278.20, "2020-6": 21559.05, "2020-7": 19423.90, "2020-8": 14701.00, "2020-9": 18742.29, "2020-10": 18908.55, "2020-11": 17026.39,
            "2019-0": 16841.80, "2019-1": 20302.49, "2019-2": 18365.40, "2019-3": 15519.70, "2019-4": 19800.85, "2019-5": 12884.45, "2019-6": 16360.32, "2019-7": 13926.05, "2019-8": 11671.05, "2019-9": 15565.35, "2019-10": 17891.15, "2019-11": 16153.15,
            "2018-0": 12369.20, "2018-1": 11908.41, "2018-2": 14538.44, "2018-3": 14940.30, "2018-4": 15803.95, "2018-5": 13357.95, "2018-6": 12920.75, "2018-7": 9209.40, "2018-8": 11598.75, "2018-9": 13048.60, "2018-10": 9717.43, "2018-11": 9858.80,
            "2017-0": 9357.50, "2017-1": 11401.00, "2017-2": 11669.00, "2017-3": 9481.20, "2017-4": 11602.91, "2017-5": 10068.15, "2017-6": 10724.95, "2017-7": 12726.66, "2017-8": 15804.36, "2017-9": 11427.46, "2017-10": 12132.75, "2017-11": 11882.20,
            "2016-0": 7491.10, "2016-1": 7861.00, "2016-2": 9691.50, "2016-3": 9000.80, "2016-4": 7927.00, "2016-5": 8286.35, "2016-6": 10148.45, "2016-7": 9280.75, "2016-8": 8507.45, "2016-9": 9257.00, "2016-10": 10183.15, "2016-11": 8626.75
        });
      }
      setHistoricalData(hData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [userProfile.company_id, currentMonth, currentYear]);

  useEffect(() => { fetchData(); }, [fetchData, sales]);

  const dayStats = useMemo(() => {
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const today = new Date();
    const isPastMonth = currentYear < today.getFullYear() || (currentYear === today.getFullYear() && currentMonth < today.getMonth());
    const isFutureMonth = currentYear > today.getFullYear() || (currentYear === today.getFullYear() && currentMonth > today.getMonth());
    const isCurrentMonth = currentYear === today.getFullYear() && currentMonth === today.getMonth();

    let businessDays = 0;
    let daysRemaining = 0;
    for (let d = 1; d <= daysInMonth; d++) {
        const date = new Date(currentYear, currentMonth, d);
        const dayOfWeek = date.getDay();
        const isWeekend = includeSaturdays ? dayOfWeek === 0 : (dayOfWeek === 0 || dayOfWeek === 6);
        if (!isWeekend) {
            businessDays++;
            if (isCurrentMonth) {
                if (d >= today.getDate()) daysRemaining++;
            } else if (isFutureMonth) {
                daysRemaining++;
            }
        }
    }
    return { total: businessDays, remaining: daysRemaining };
  }, [currentMonth, currentYear, includeSaturdays]);

  const performanceData = useMemo(() => {
      const monthStart = new Date(currentYear, currentMonth, 1, 0, 0, 0).getTime();
      const monthEnd = new Date(currentYear, currentMonth + 1, 0, 23, 59, 59).getTime();
      const filteredSales = sales.filter(s => {
          const t = getSafeTimestamp(s.date);
          return s.status === 'completed' && t >= monthStart && t <= monthEnd;
      });
      const manualRevenue = financeTransactions.filter(t => {
          const time = getSafeTimestamp(t.date, 'finance');
          return t.type === 'income' && t.origin !== 'pos' && time >= monthStart && time <= monthEnd;
      }).reduce((acc, t) => acc + Number(t.amount), 0);
      const totalRealized = filteredSales.reduce((acc, s) => acc + s.total, 0) + manualRevenue;
      const companyGoalObj = goals.find(g => !g.user_id);
      const companyGoal = companyGoalObj?.target_value || 0;
      const companyCommission = companyGoalObj?.commission_percentage || 0;

      const userMetrics = users.map(u => {
          const sold = filteredSales
            .filter(s => (s.sellerName || '').toLowerCase().trim() === (u.full_name || '').toLowerCase().trim())
            .reduce((acc, s) => acc + s.total, 0);
          const goalObj = goals.find(g => g.user_id === u.id);
          const goal = goalObj?.target_value || 0;
          const commission = goalObj?.commission_percentage || 0;
          
          // Ganhos potenciais
          const potentialIndividual = (goal * commission) / 100;
          const potentialCompany = (goal * companyCommission) / 100;

          return { 
            ...u, 
            sold, 
            goal, 
            commission,
            potentialIndividual,
            potentialCompany,
            progress: goal > 0 ? (sold / goal) * 100 : 0, 
            neededPerDay: dayStats.remaining > 0 ? (Math.max(0, goal - sold) / dayStats.remaining) : 0 
          };
      });
      return { totalRealized, companyGoal, companyCommission, userMetrics };
  }, [sales, financeTransactions, goals, users, currentMonth, currentYear, dayStats]);

  const companyProgress = performanceData.companyGoal > 0 ? (performanceData.totalRealized / performanceData.companyGoal) * 100 : 0;
  const companyNeededPerDay = dayStats.remaining > 0 ? (Math.max(0, performanceData.companyGoal - performanceData.totalRealized) / dayStats.remaining) : 0;

  // --- Lógica de Edição de Metas (Modal) ---
  const handleOpenEditGoal = (type: 'company' | 'user', user?: UserProfile) => {
      const goalObj = type === 'company' 
          ? goals.find(g => !g.user_id)
          : goals.find(g => g.user_id === user?.id);
      
      const currentValue = goalObj?.target_value || 0;
      const currentCommission = goalObj?.commission_percentage || 0;
      
      setEditingTarget({
          type,
          id: user?.id,
          name: type === 'company' ? 'Meta da Empresa' : `Meta de ${user?.full_name}`,
          currentValue,
          currentCommission
      });
      setEditGoalValue(currentValue > 0 ? currentValue.toString().replace('.', ',') : '');
      setEditCommissionValue(currentCommission > 0 ? currentCommission.toString().replace('.', ',') : '');
      setIsEditModalOpen(true);
  };

  const handleSaveGoal = async () => {
      if (!editingTarget) return;
      setIsSavingGoal(true);
      try {
          // Parsing robusto para valores monetários e porcentagens
          const parseValue = (val: string) => {
            if (!val) return 0;
            let raw = val.toString().replace(/[^\d.,]/g, '');
            const lastComma = raw.lastIndexOf(',');
            const lastDot = raw.lastIndexOf('.');
            if (lastComma > lastDot) {
                raw = raw.replace(/\./g, '').replace(',', '.');
            } else if (lastDot > lastComma) {
                if (lastComma === -1 && raw.length - lastDot === 4) {
                    raw = raw.replace(/\./g, '');
                } else {
                    raw = raw.replace(/,/g, '');
                }
            }
            return parseFloat(raw) || 0;
          };

          const cleanValue = parseValue(editGoalValue);
          const cleanCommission = parseValue(editCommissionValue);
          
          const userIdQuery = editingTarget.type === 'company' ? null : editingTarget.id;
          
          // Busca robusta considerando null/undefined para user_id (meta empresa)
          const existingGoal = goals.find(g => {
              if (editingTarget.type === 'company') {
                  return g.user_id === null || g.user_id === undefined;
              }
              return g.user_id === editingTarget.id;
          });

          const goalData = {
              company_id: userProfile.company_id,
              user_id: userIdQuery,
              month: currentMonth,
              year: currentYear,
              target_value: cleanValue,
              commission_percentage: cleanCommission
          };

          if (existingGoal) {
              const { error } = await supabase.from('user_goals')
                .update({ 
                  target_value: cleanValue,
                  commission_percentage: cleanCommission
                })
                .eq('id', existingGoal.id);
              
              if (error) {
                // Fallback caso a coluna commission_percentage não exista no banco
                if (error.message?.includes('column "commission_percentage" does not exist')) {
                  await supabase.from('user_goals')
                    .update({ target_value: cleanValue })
                    .eq('id', existingGoal.id);
                } else {
                  throw error;
                }
              }
          } else {
              const { error } = await supabase.from('user_goals').insert([goalData]);
              
              if (error) {
                // Fallback caso a coluna commission_percentage não exista no banco
                if (error.message?.includes('column "commission_percentage" does not exist')) {
                  const { commission_percentage, ...dataWithoutCommission } = goalData;
                  await supabase.from('user_goals').insert([dataWithoutCommission]);
                } else {
                  throw error;
                }
              }
          }

          await fetchData();
          setIsEditModalOpen(false);
          setEditingTarget(null);
      } catch (err: any) {
          alert('Erro ao salvar meta: ' + (err.message || 'Erro desconhecido'));
          console.error(err);
      } finally {
          setIsSavingGoal(false);
      }
  };

  // --- Lógica de Edição de Histórico (Tabela) ---
  const handleStartEdit = (year: number, monthIdx: number, currentVal: number) => {
    setEditingCell(`${year}-${monthIdx}`);
    setEditValue(currentVal === 0 ? "" : currentVal.toLocaleString('pt-BR', { minimumFractionDigits: 2, useGrouping: false }));
  };

  const handleFinishEdit = async () => {
    if (editingCell) {
        let raw = editValue.toString().replace(/[^\d.,]/g, '');
        const lastComma = raw.lastIndexOf(',');
        const lastDot = raw.lastIndexOf('.');
        if (lastComma > lastDot) {
            raw = raw.replace(/\./g, '').replace(',', '.');
        } else if (lastDot > lastComma) {
            if (lastComma === -1 && raw.length - lastDot === 4) {
                raw = raw.replace(/\./g, '');
            } else {
                raw = raw.replace(/,/g, '');
            }
        }
        const value = parseFloat(raw);
        const finalValue = isNaN(value) ? 0 : value;
        
        const newData = { ...historicalData, [editingCell]: finalValue };
        setHistoricalData(newData);
        localStorage.setItem('goals_historical_data', JSON.stringify(newData));
        
        // Salvar no banco de dados (wallet_settings como storage temporário/flexível)
        setIsSavingHistorical(true);
        try {
          const { data: company } = await supabase.from('companies').select('wallet_settings').eq('id', userProfile.company_id).single();
          const currentSettings = company?.wallet_settings || {};
          
          await supabase.from('companies').update({
            wallet_settings: {
              ...currentSettings,
              historical_revenue: newData
            }
          }).eq('id', userProfile.company_id);
        } catch (e) {
          console.error("Erro ao salvar dados históricos no banco", e);
        } finally {
          setIsSavingHistorical(false);
        }
    }
    setEditingCell(null);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
        e.preventDefault();
        handleFinishEdit();
    }
    if (e.key === 'Escape') {
        setEditingCell(null);
    }
  };

  const years = [2026, 2025, 2024, 2023, 2022, 2021, 2020, 2019, 2018, 2017, 2016];
  const chartYears = [...years].reverse(); 
  const monthsArr = ['JANEIRO', 'FEVEREIRO', 'MARÇO', 'ABRIL', 'MAIO', 'JUNHO', 'JULHO', 'AGOSTO', 'SETEMBRO', 'OUTUBRO', 'NOVEMBRO', 'DEZEMBRO'];

  const annualTotals = useMemo(() => {
    const totals: Record<number, number> = {};
    years.forEach(y => {
        let sum = 0;
        for (let m = 0; m < 12; m++) { sum += historicalData[`${y}-${m}`] || 0; }
        totals[y] = sum;
    });
    return totals;
  }, [historicalData, years]);

  if (loading) return <div className="h-full w-full flex items-center justify-center bg-white dark:bg-[#1a1b2e]"><Loader2 className="animate-spin text-indigo-600" size={40} /></div>;

  return (
    <div className="flex-1 flex flex-col h-full bg-[#f8fafc] dark:bg-[#1a1b2e] transition-colors overflow-hidden font-sans">
      
      {/* MODAL DE EDIÇÃO DE META */}
      {isEditModalOpen && editingTarget && (
          <div className="fixed inset-0 bg-black/60 z-[200] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
              <div className="bg-white dark:bg-[#23243a] rounded-[2rem] w-full max-sm:max-w-sm shadow-2xl p-8 border border-transparent dark:border-white/5 transition-all animate-in zoom-in-95 duration-200">
                  <div className="flex justify-between items-start mb-6">
                      <div>
                          <h3 className="text-xl font-black text-slate-800 dark:text-white uppercase tracking-tight leading-none">Definir Meta</h3>
                          <p className="text-[10px] text-gray-400 dark:text-gray-500 font-bold uppercase tracking-widest mt-2">{editingTarget.name}</p>
                      </div>
                      <button onClick={() => setIsEditModalOpen(false)} className="text-gray-400 hover:text-gray-600 dark:hover:text-white"><X size={24} /></button>
                  </div>
                  
                  <div className="space-y-6">
                      <div className="relative border-2 border-indigo-100 dark:border-indigo-500/20 rounded-2xl p-4 bg-gray-50 dark:bg-[#1a1b2e] focus-within:border-indigo-500 transition-all">
                          <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-indigo-500 uppercase tracking-widest">Valor da Meta</label>
                          <div className="flex items-center gap-2">
                              <span className="text-lg font-bold text-gray-400">R$</span>
                              <input 
                                  type="text" 
                                  autoFocus
                                  className="w-full bg-transparent text-2xl font-black text-slate-800 dark:text-white outline-none placeholder:text-gray-300"
                                  placeholder="0,00"
                                  value={editGoalValue}
                                  onChange={(e) => setEditGoalValue(e.target.value)}
                              />
                          </div>
                      </div>

                      <div className="relative border-2 border-indigo-100 dark:border-indigo-500/20 rounded-2xl p-4 bg-gray-50 dark:bg-[#1a1b2e] focus-within:border-indigo-500 transition-all">
                          <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-indigo-500 uppercase tracking-widest">Comissão (%)</label>
                          <div className="flex items-center gap-2">
                              <span className="text-lg font-bold text-gray-400">%</span>
                              <input 
                                  type="text" 
                                  className="w-full bg-transparent text-2xl font-black text-slate-800 dark:text-white outline-none placeholder:text-gray-300"
                                  placeholder="0,00"
                                  value={editCommissionValue}
                                  onChange={(e) => setEditCommissionValue(e.target.value)}
                              />
                          </div>
                      </div>

                      <button 
                          onClick={handleSaveGoal}
                          disabled={isSavingGoal}
                          className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs uppercase tracking-widest rounded-xl shadow-xl shadow-indigo-200 dark:shadow-none transition-all active:scale-95 flex items-center justify-center gap-2"
                      >
                          {isSavingGoal ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                          Salvar Meta
                      </button>
                  </div>
              </div>
          </div>
      )}

      <header className="bg-white dark:bg-[#23243a] h-[90px] px-4 lg:px-10 flex justify-between items-center shrink-0 border-b border-gray-100 dark:border-white/5 sticky top-0 z-50 transition-colors">
          <div className="flex items-center gap-4">
              <button onClick={toggleSidebar} className="lg:hidden p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-xl transition-colors">
                  <List size={26} />
              </button>
              <div>
                  <h1 className="text-[23px] font-mono font-black text-gray-900 dark:text-white tracking-tighter uppercase leading-none italic">Desempenho</h1>
                  <div className="flex items-center gap-2 mt-1">
                      <div className="flex items-center bg-slate-100 dark:bg-white/5 rounded-lg px-2 py-0.5 gap-2">
                          <select 
                            value={currentMonth} 
                            onChange={(e) => setCurrentMonth(parseInt(e.target.value))}
                            className="bg-transparent text-[9px] text-gray-500 dark:text-gray-400 font-black uppercase tracking-widest outline-none cursor-pointer hover:text-indigo-500 transition-colors"
                          >
                            {MONTHS_LABELS.map((label, idx) => (
                              <option key={label} value={idx} className="bg-white dark:bg-[#1a1b2e] text-gray-900 dark:text-white">{label}</option>
                            ))}
                          </select>
                          <div className="w-px h-3 bg-slate-300 dark:bg-white/10"></div>
                          <select 
                            value={currentYear} 
                            onChange={(e) => setCurrentYear(parseInt(e.target.value))}
                            className="bg-transparent text-[9px] text-gray-500 dark:text-gray-400 font-black uppercase tracking-widest outline-none cursor-pointer hover:text-indigo-500 transition-colors"
                          >
                            {[2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027].map(y => (
                              <option key={y} value={y} className="bg-white dark:bg-[#1a1b2e] text-gray-900 dark:text-white">{y}</option>
                            ))}
                          </select>
                      </div>
                      {(currentMonth !== new Date().getMonth() || currentYear !== new Date().getFullYear()) && (
                        <button 
                          onClick={() => {
                            setCurrentMonth(new Date().getMonth());
                            setCurrentYear(new Date().getFullYear());
                          }}
                          className="text-[8px] font-black text-indigo-500 uppercase tracking-widest hover:underline"
                        >
                          Hoje
                        </button>
                      )}
                  </div>
              </div>
          </div>
          <UserMenu />
      </header>

      <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-4 custom-scrollbar space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-3">
              <div className="flex bg-white dark:bg-[#23243a] p-0.5 rounded-full border border-slate-100 dark:border-white/5 shadow-sm transition-all overflow-x-auto no-scrollbar w-full sm:w-auto">
                  <button onClick={() => setActiveTab('METAS')} className={`px-4 py-1.5 rounded-full text-[8px] font-black uppercase tracking-widest transition-all ${activeTab === 'METAS' ? 'bg-indigo-600 text-white shadow-lg scale-105' : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-200'}`}>Metas</button>
                  {!isOperator && (
                    <button onClick={() => setActiveTab('RESULTADO_ANUAL')} className={`px-4 py-1.5 rounded-full text-[8px] font-black uppercase tracking-widest transition-all ${activeTab === 'RESULTADO_ANUAL' ? 'bg-indigo-600 text-white shadow-lg scale-105' : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-200'}`}>Resultado Anual</button>
                  )}
              </div>
              {!isOperator && (
                <button onClick={() => setTeamVisibility(!teamVisibility)} className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-[8px] font-black uppercase tracking-widest border transition-all ${teamVisibility ? 'bg-indigo-50 text-indigo-600 border-indigo-200' : 'bg-white dark:bg-[#23243a] text-gray-400 border-slate-100 dark:border-white/5'}`}>
                    <Activity size={12} strokeWidth={3} /> Equipe: {teamVisibility ? 'ON' : 'OFF'}
                </button>
              )}
          </div>

          {(activeTab === 'METAS' || isOperator) ? (
              <div className="max-w-[1600px] mx-auto space-y-4 animate-in fade-in duration-700">
                  <div className="bg-[#1e293b] rounded-[1rem] p-3 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-4 border border-white/5">
                      <div className="flex items-center gap-6 text-white">
                          <div className="text-center">
                              <p className="text-[7px] font-black text-slate-400 uppercase tracking-widest mb-0.5 opacity-60">Ciclo Mensal</p>
                              <div className="flex items-baseline gap-1.5"><span className="text-2xl font-black tabular-nums tracking-tighter">{dayStats.total}</span><span className="text-[8px] font-bold text-slate-500 uppercase tracking-widest">Dias</span></div>
                          </div>
                          <div className="h-8 w-px bg-slate-700/50"></div>
                          <div className="text-center">
                              <p className="text-[7px] font-black text-[#c1ff72] uppercase tracking-widest mb-0.5 italic">Restante</p>
                              <div className="flex items-baseline gap-1.5"><span className="text-2xl font-black text-[#c1ff72] tabular-nums tracking-tighter">{dayStats.remaining}</span><span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Dias</span></div>
                          </div>
                      </div>
                      <div className="flex items-center gap-2 bg-black/20 p-1.5 rounded-lg border border-white/5">
                          <span className="text-[8px] font-black text-slate-400 uppercase ml-1 tracking-widest">Sábados</span>
                          <button onClick={() => setIncludeSaturdays(!includeSaturdays)} className={`w-8 h-4 rounded-full p-0.5 transition-all ${includeSaturdays ? 'bg-[#c1ff72]' : 'bg-slate-700'}`}>
                              <div className={`w-3 h-3 bg-white rounded-full transition-transform ${includeSaturdays ? 'translate-x-4' : 'translate-x-0'} shadow-sm`}></div>
                          </button>
                      </div>
                  </div>

                  <div className="bg-white dark:bg-[#23243a] rounded-[1.5rem] p-4 sm:p-5 lg:p-6 shadow-2xl border border-slate-100 dark:border-white/5 relative overflow-hidden transition-all group">
                      <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-4 lg:gap-8">
                          <div className="flex-1 space-y-3 lg:space-y-4 w-full">
                              <div className="flex justify-between items-start">
                                  <div><h2 className="text-xl sm:text-2xl lg:text-3xl font-black text-slate-900 dark:text-white tracking-tighter uppercase italic leading-none">Meta Empresa</h2><p className="text-[8px] text-indigo-500 font-black uppercase tracking-[0.2em] mt-1.5">Objetivo Estratégico Consolidado</p></div>
                                  {!isOperator && (
                                    <button onClick={() => handleOpenEditGoal('company')} className="p-2 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 rounded-xl hover:scale-110 transition-transform shadow-sm"><Edit2 size={16}/></button>
                                  )}
                              </div>
                              <div className="grid grid-cols-2 gap-4">
                                  <div className="space-y-0.5">
                                      <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest mb-1">Realizado</p>
                                      <p className="text-base sm:text-xl lg:text-2xl font-black text-slate-900 dark:text-white tabular-nums tracking-tighter leading-none">{isOperator ? 'R$ ***' : formatCurrency(performanceData.totalRealized)}</p>
                                  </div>
                                  <div className="text-right space-y-0.5">
                                      <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest mb-1">Objetivo</p>
                                      <p className="text-base sm:text-xl lg:text-2xl font-black text-indigo-600 dark:text-indigo-400 tabular-nums tracking-tighter leading-none">{isOperator ? 'R$ ***' : formatCurrency(performanceData.companyGoal)}</p>
                                  </div>
                              </div>
                              <div className="space-y-2">
                                  <div className="flex justify-between items-end">
                                      <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Progresso</span>
                                      <span className="text-xl sm:text-2xl lg:text-3xl font-black italic text-slate-900 dark:text-white tracking-tighter leading-none">{companyProgress.toFixed(0)}%</span>
                                  </div>
                                  <div className="w-full bg-slate-100 dark:bg-white/5 h-3 rounded-full overflow-hidden p-0.5 shadow-inner transition-colors">
                                      <div className="h-full rounded-full bg-indigo-600 shadow-[0_0_10px_rgba(79,70,229,0.5)] transition-all duration-1000 ease-out" style={{ width: `${Math.min(companyProgress, 100)}%` }}></div>
                                  </div>
                              </div>
                          </div>
                          <div className="w-full lg:w-[240px] xl:w-[280px] shrink-0">
                              <div className="bg-[#f8fafc] dark:bg-[#1a1b2e] rounded-[1.2rem] p-4 border border-slate-100 dark:border-white/5 text-center space-y-3 shadow-sm transition-all hover:shadow-xl">
                                  <div className="w-10 h-10 bg-emerald-50 dark:bg-emerald-500/10 rounded-full flex items-center justify-center text-emerald-500 mx-auto transition-transform group-hover:scale-110"><TrendingUp size={20} strokeWidth={3} /></div>
                                  <div>
                                      <p className="text-[8px] font-black text-slate-400 uppercase tracking-[0.1em] mb-1">Necessário por dia</p>
                                      <p className="text-lg sm:text-xl lg:text-2xl font-black text-slate-900 dark:text-white tabular-nums tracking-tighter">{isOperator ? 'R$ ***' : formatCurrency(companyNeededPerDay)}</p>
                                      <p className="text-[8px] font-bold text-gray-400 uppercase tracking-widest mt-1">Até o fechamento</p>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 pb-6">
                      {performanceData.userMetrics
                        .map((user) => {
                          const isOwnCard = user.id === userProfile.id;
                          const shouldHideValues = isOperator && !isOwnCard;

                          return (
                            <div key={user.id} className="bg-white dark:bg-[#23243a] rounded-[1.2rem] p-4 shadow-sm border border-slate-100 dark:border-white/5 flex flex-col transition-all hover:shadow-xl hover:-translate-y-1 group/card">
                                <div className="flex justify-between items-start mb-3">
                                    <div className="flex items-center gap-2.5"><div className="w-10 h-10 rounded-[0.8rem] bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-black text-sm shadow-sm uppercase">{user.full_name?.substring(0, 2)}</div><div><h4 className="text-xs font-black text-gray-800 dark:text-white uppercase tracking-tighter mb-0">{user.full_name}</h4><p className="text-[8px] text-gray-400 font-bold uppercase tracking-widest opacity-80">{user.role}</p></div></div>
                                    {!isOperator && (
                                      <button onClick={() => handleOpenEditGoal('user', user)} className="p-1 text-gray-300 hover:text-indigo-500 transition-colors"><Edit2 size={12}/></button>
                                    )}
                                </div>
                                <div className="flex justify-between items-end mb-1.5"><span className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Individual</span><span className="text-xl font-black italic text-slate-900 dark:text-white tracking-tighter leading-none">{user.progress.toFixed(0)}%</span></div>
                                <div className="w-full bg-slate-50 dark:bg-white/5 h-1.5 rounded-full overflow-hidden mb-3 p-0.5"><div className="h-full bg-indigo-600 rounded-full transition-all duration-1000 ease-out" style={{ width: `${Math.min(user.progress, 100)}%` }}></div></div>
                                  <div className="grid grid-cols-2 gap-3 mb-3">
                                    <div className="space-y-0"><p className="text-[8px] font-black text-gray-400 uppercase tracking-widest mb-0">Vendido</p><p className="text-xs font-black text-gray-900 dark:text-white tabular-nums tracking-tight">{shouldHideValues ? 'R$ ***' : formatCurrency(user.sold)}</p></div>
                                    <div className="text-right space-y-0"><p className="text-[8px] font-black text-gray-400 uppercase tracking-widest mb-0">Meta</p><p className="text-xs font-black text-slate-300 dark:text-gray-600 tabular-nums tracking-tight">{shouldHideValues ? 'R$ ***' : formatCurrency(user.goal)}</p></div>
                                </div>

                                {/* PREVISÃO DE GANHOS */}
                                <div className="mb-4 p-3 bg-indigo-50/50 dark:bg-indigo-500/5 rounded-2xl border border-indigo-100/50 dark:border-indigo-500/10">
                                    <p className="text-[7px] font-black text-indigo-500 uppercase tracking-[0.2em] mb-2 text-center">Previsão de Ganhos (Meta 100%)</p>
                                    <div className="space-y-2">
                                        <div className="flex justify-between items-center">
                                            <span className="text-[8px] font-bold text-gray-500 dark:text-gray-400 uppercase tracking-tight">Meta Individual ({user.commission}%)</span>
                                            <span className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 tabular-nums">{shouldHideValues ? 'R$ ***' : formatCurrency(user.potentialIndividual)}</span>
                                        </div>
                                        <div className="flex justify-between items-center">
                                            <span className="text-[8px] font-bold text-gray-500 dark:text-gray-400 uppercase tracking-tight">Bônus Empresa ({performanceData.companyCommission}%)</span>
                                            <span className="text-[10px] font-black text-emerald-600 dark:text-emerald-400 tabular-nums">{shouldHideValues ? 'R$ ***' : formatCurrency(user.potentialCompany)}</span>
                                        </div>
                                        <div className="pt-1 mt-1 border-t border-indigo-100 dark:border-indigo-500/10 flex justify-between items-center">
                                            <span className="text-[8px] font-black text-slate-700 dark:text-white uppercase tracking-widest">Total Possível</span>
                                            <span className="text-xs font-black text-slate-900 dark:text-white tabular-nums">{shouldHideValues ? 'R$ ***' : formatCurrency(user.potentialIndividual + user.potentialCompany)}</span>
                                        </div>
                                    </div>
                                </div>

                                <div className="mt-auto grid grid-cols-2 gap-1.5">
                                    <div className="bg-slate-50/50 dark:bg-white/5 rounded-xl p-2 text-center group-hover/card:bg-white dark:group-hover/card:bg-[#1a1b2e] transition-colors"><p className="text-[7px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Dias</p><p className="text-sm font-black text-slate-700 dark:text-white">{dayStats.total}</p></div>
                                    <div className="bg-slate-50/50 dark:bg-white/5 rounded-xl p-2 text-center group-hover/card:bg-white dark:group-hover/card:bg-[#1a1b2e] transition-colors"><p className="text-[7px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Meta/Dia</p><p className="text-sm font-black text-slate-700 dark:text-white tabular-nums tracking-tighter">{shouldHideValues ? 'R$ ***' : `R$ ${user.neededPerDay.toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`}</p></div>
                                </div>
                            </div>
                          );
                        })}
                  </div>
              </div>
          ) : (
              !isOperator && (
                <div className="max-w-full mx-auto space-y-6 animate-in fade-in slide-in-from-right-4 duration-700 pb-10">
                  <div className="bg-white dark:bg-[#23243a] rounded-[2rem] shadow-2xl border border-slate-100 dark:border-white/5 overflow-hidden transition-all">
                      <div className="px-6 py-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                          <div>
                              <h3 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tighter italic leading-none">Resultado Histórico</h3>
                              <p className="text-[8px] text-slate-400 font-bold uppercase tracking-[0.3em] mt-2">Série Histórica Consolidada (Preenchimento Manual)</p>
                          </div>
                          <div className="flex items-center gap-4">
                             <div className="text-right hidden sm:block">
                                <p className="text-[9px] font-black text-emerald-500 uppercase tracking-widest flex items-center justify-end gap-1">
                                  {isSavingHistorical ? <Loader2 size={10} className="animate-spin" /> : <CheckCircle2 size={10}/>} 
                                  {isSavingHistorical ? 'Salvando...' : 'Sincronizado com Nuvem'}
                                </p>
                                <p className="text-[8px] text-slate-400 font-medium">Dados compartilhados com toda a empresa</p>
                             </div>
                             <button className="bg-[#00a86b] hover:bg-[#008f5d] text-white px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 shadow-lg shadow-emerald-500/10 active:scale-95 transition-all"><Plus size={16} strokeWidth={4} /> Lançar Dados</button>
                          </div>
                      </div>
                      <div className="overflow-x-auto custom-scrollbar px-4 sm:px-6 pb-4">
                        <table className="w-full text-left border-separate border-spacing-0">
                            <thead className="bg-[#5d5fe3] text-white">
                                <tr className="text-[9px] font-black uppercase tracking-[0.15em]">
                                    <th className="px-4 py-4 min-w-[120px] rounded-tl-xl">Mês / Ano</th>
                                    {years.map((y, i) => (
                                        <th key={y} className={`px-2 py-4 text-center min-w-[90px] ${y === currentYear ? 'bg-[#4f46e5] border-x border-white/10' : ''} ${i === years.length - 1 ? 'rounded-tr-xl' : ''}`}>{y}</th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-50 dark:divide-white/5">
                                {monthsArr.map((monthLabel, mIdx) => (
                                    <tr key={monthLabel} className="hover:bg-gray-50/50 dark:hover:bg-white/5 transition-colors group">
                                        <td className="px-4 py-3 text-[10px] font-black text-slate-400 uppercase tracking-widest border-l dark:border-white/5">{monthLabel}</td>
                                        {years.map(y => {
                                            const cellKey = `${y}-${mIdx}`;
                                            const val = historicalData[cellKey] || 0;
                                            const isEditing = editingCell === cellKey;
                                            const isCurrentYear = y === currentYear;
                                            return (
                                                <td key={cellKey} className={`px-2 py-3 text-center text-[11px] tabular-nums transition-all ${isCurrentYear ? 'bg-indigo-50/20' : ''} ${y === 2016 ? 'border-r dark:border-white/5' : ''}`}>
                                                    {isEditing ? (
                                                        <div className="flex items-center gap-1">
                                                            <input 
                                                                autoFocus 
                                                                type="text" 
                                                                className="w-full bg-white dark:bg-[#1a1b2e] border-2 border-indigo-500 rounded-lg py-1 px-1 text-[10px] font-black outline-none shadow-lg text-center text-indigo-600 dark:text-indigo-400" 
                                                                value={editValue} 
                                                                onChange={(e) => setEditValue(e.target.value)} 
                                                                onBlur={handleFinishEdit} 
                                                                onKeyDown={handleKeyDown}
                                                            />
                                                            <button onMouseDown={handleFinishEdit} className="text-emerald-500 hover:scale-110 transition-transform shrink-0"><Check size={14} strokeWidth={4}/></button>
                                                        </div>
                                                    ) : (
                                                        <div 
                                                            onClick={() => handleStartEdit(y, mIdx, val)} 
                                                            className={`cursor-pointer group/cell relative py-0.5 px-1 rounded-lg transition-all hover:bg-white dark:hover:bg-white/10 hover:shadow-sm ${isCurrentYear ? 'font-black text-slate-900 dark:text-white' : 'text-gray-400 font-bold'}`}
                                                        >
                                                            {val > 0 ? val.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) : '0,00'}
                                                            <div className="absolute top-0 right-0 p-0.5 opacity-0 group-hover/cell:opacity-100 transition-opacity text-indigo-400"><Edit2 size={6}/></div>
                                                        </div>
                                                    )}
                                                </td>
                                            );
                                        })}
                                    </tr>
                                ))}
                            </tbody>
                            <tfoot className="bg-gray-50 dark:bg-white/5">
                                <tr className="text-[10px] font-black uppercase tracking-widest">
                                    <td className="px-4 py-6 text-indigo-600 border-l dark:border-white/5 rounded-bl-xl">Total Anual</td>
                                    {years.map((y, i) => (<td key={`total-${y}`} className={`px-2 py-6 text-center tabular-nums text-xs whitespace-nowrap ${y === currentYear ? 'text-indigo-600 font-black' : 'text-slate-500'} ${i === years.length - 1 ? 'border-r dark:border-white/5 rounded-br-xl' : ''}`}>{formatCurrency(annualTotals[y] || 0)}</td>))}
                                </tr>
                            </tfoot>
                        </table>
                      </div>
                  </div>

                  <div className="grid grid-cols-1 gap-6">
                      <div className="bg-[#11121d] rounded-[1.5rem] p-4 sm:p-6 shadow-2xl border border-white/5 transition-all overflow-hidden">
                          <div className="flex flex-col sm:flex-row justify-between items-start mb-6 sm:mb-8 gap-4">
                              <div>
                                  <h3 className="text-xl sm:text-2xl font-black text-white uppercase tracking-tighter italic flex items-center gap-3"><Activity className="text-[#c1ff72]" /> Evolução Total Histórica</h3>
                                  <p className="text-[7px] text-indigo-400 font-bold uppercase tracking-[0.3em] mt-2">Análise Consolidada 2016 — 2026 (Processamento em Tempo Real)</p>
                              </div>
                              <div className="flex items-center gap-2 bg-white/5 px-3 py-1 rounded-full border border-white/10"><div className="w-1.5 h-1.5 rounded-full bg-[#c1ff72] shadow-[0_0_8px_#c1ff72]"></div><span className="text-[7px] font-black text-white uppercase tracking-widest">Sincronizado</span></div>
                          </div>
                          <div className="w-full relative">
                              <div className="overflow-x-auto no-scrollbar">
                                  <div className="min-w-[700px] h-48">
                                      <svg className="w-full h-full overflow-visible" viewBox="0 0 1000 200" preserveAspectRatio="none">
                                          <defs><linearGradient id="glowGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#c1ff72" stopOpacity="0.2" /><stop offset="100%" stopColor="#c1ff72" stopOpacity="0" /></linearGradient></defs>
                                          {(() => {
                                                const vals = chartYears.map(y => annualTotals[y] || 0);
                                                const max = Math.max(...vals, 100000);
                                                const points = vals.map((v, i) => ({ x: 40 + (i * (920 / (vals.length - 1))), y: 160 - (v / max) * 120 }));
                                                const pathD = points.reduce((acc, p, i) => acc + (i === 0 ? `M${p.x},${p.y} ` : `L${p.x},${p.y} `), "");
                                                return (<><path d={pathD} fill="none" stroke="#c1ff72" strokeWidth="4" strokeLinecap="round" className="drop-shadow-[0_0_8px_rgba(193,255,114,0.8)] transition-all duration-700" /><path d={pathD + `V200 H40 Z`} fill="url(#glowGrad)" className="transition-all duration-700" />{points.map((p, i) => (<circle key={i} cx={p.x} cy={p.y} r="5" fill="#11121d" stroke="#c1ff72" strokeWidth="3" className="transition-all duration-700" />))}</>);
                                            })()}
                                      </svg>
                                  </div>
                              </div>
                              <div className="overflow-x-auto no-scrollbar mt-4">
                                  <div className="min-w-[700px] flex justify-between px-[4%]">
                                      {chartYears.map(y => (<span key={y} className="text-[7px] sm:text-[8px] font-black text-slate-600 uppercase tracking-widest w-10 text-center">{y}</span>))}
                                  </div>
                              </div>
                          </div>
                      </div>

                      <div className="bg-white dark:bg-[#23243a] rounded-[1.5rem] p-4 sm:p-6 shadow-2xl border border-slate-100 dark:border-white/5 transition-all overflow-hidden">
                          <div className="flex flex-col sm:flex-row justify-between items-start mb-6 sm:mb-8 gap-4">
                              <div>
                                  <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tighter italic leading-none">Análise Sazonal</h3>
                                  <p className="text-[8px] text-slate-400 font-bold uppercase tracking-[0.3em] mt-2">Performance Mensal: {currentYear} vs {currentYear - 1}</p>
                              </div>
                              <div className="flex flex-row gap-3"><div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-indigo-600"></div><span className="text-[7px] font-black text-slate-500 uppercase tracking-widest">{currentYear}</span></div><div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-slate-200"></div><span className="text-[7px] font-black text-slate-400 uppercase tracking-widest">{currentYear - 1}</span></div></div>
                          </div>
                          <div className="w-full relative">
                              <div className="overflow-x-auto no-scrollbar">
                                  <div className="min-w-[700px] h-48">
                                      <svg className="w-full h-full overflow-visible" viewBox="0 0 1000 150" preserveAspectRatio="none">
                                          {(() => {
                                                const currVals = monthsArr.map((_, i) => historicalData[`${currentYear}-${i}`] || 0);
                                                const prevVals = monthsArr.map((_, i) => historicalData[`${currentYear - 1}-${i}`] || 0);
                                                const max = Math.max(...currVals, ...prevVals, 10000);
                                                const getPoints = (vals: number[]) => vals.map((v, i) => ({ x: 40 + (i * (920 / 11)), y: 130 - (v / max) * 100 }));
                                                const currPoints = getPoints(currVals); const prevPoints = getPoints(prevVals);
                                                const pathPrev = prevPoints.reduce((acc, p, i) => acc + (i === 0 ? `M${p.x},${p.y} ` : `L${p.x},${p.y} `), "");
                                                const pathCurr = currPoints.reduce((acc, p, i) => acc + (i === 0 ? `M${p.x},${p.y} ` : `L${p.x},${p.y} `), "");
                                                return (<><path d={pathPrev} fill="none" stroke="#e2e8f0" strokeWidth="3" strokeDasharray="6,4" className="transition-all duration-700" /><path d={pathCurr} fill="none" stroke="#4f46e5" strokeWidth="5" strokeLinecap="round" className="drop-shadow-lg transition-all duration-700" />{currPoints.map((p, i) => (<circle key={i} cx={p.x} cy={p.y} r="5" fill="white" stroke="#4f46e5" strokeWidth="3" className="transition-all duration-700" />))}</>);
                                            })()}
                                      </svg>
                                  </div>
                              </div>
                              <div className="overflow-x-auto no-scrollbar mt-4"><div className="min-w-[700px] flex justify-between px-[4%]">{monthsArr.map(m => (<span key={m} className="text-[7px] sm:text-[8px] font-black text-slate-400 uppercase tracking-widest w-10 text-center">{m.substring(0,3)}</span>))}</div></div>
                          </div>
                      </div>
                  </div>
                </div>
              )
          )}
      </div>
    </div>
  );
};

const MONTHS_LABELS = ['JANEIRO', 'FEVEREIRO', 'MARÇO', 'ABRIL', 'MAIO', 'JUNHO', 'JULHO', 'AGOSTO', 'SETEMBRO', 'OUTUBRO', 'NOVEMBRO', 'DEZEMBRO'];

export default GoalsScreen;
