
import React, { useState } from 'react';
import { X, Search, Plus, Edit2, Trash2, Check, Loader2, AlertTriangle } from 'lucide-react';
import { Category } from '../types';

interface CategoryPanelProps {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
  onAddCategory: (name: string) => Promise<void>;
  onEditCategory: (id: string, name: string) => Promise<void>;
  onDeleteCategory: (id: string) => Promise<void>;
}

const CategoryPanel: React.FC<CategoryPanelProps> = ({
  isOpen,
  onClose,
  categories,
  onAddCategory,
  onEditCategory,
  onDeleteCategory
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [newValue, setNewValue] = useState('');
  const [loading, setLoading] = useState(false);
  
  const [categoryToDelete, setCategoryToDelete] = useState<{ id: string; name: string } | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const filteredCategories = categories.filter(
    (cat) =>
      cat.id !== 'all' && 
      cat.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSaveEdit = async (id: string) => {
    if (!editValue.trim() || loading) return;
    setLoading(true);
    try {
        await onEditCategory(id, editValue);
        setEditingId(null);
    } catch (e) {
        console.error(e);
    } finally {
        setLoading(false);
    }
  };

  const handleAdd = async () => {
    if (!newValue.trim() || loading) return;
    setLoading(true);
    try {
        await onAddCategory(newValue.trim());
        setNewValue('');
        setIsAdding(false);
    } catch (e) {
        console.error(e);
    } finally {
        setLoading(false);
    }
  };

  const handleDeleteClick = (e: React.MouseEvent, id: string, name: string) => {
    e.preventDefault();
    e.stopPropagation();
    if (loading) return;
    setCategoryToDelete({ id, name });
  };

  const handleConfirmDelete = async () => {
      if (!categoryToDelete) return;
      setIsDeleting(true);
      try {
          await onDeleteCategory(categoryToDelete.id);
          setCategoryToDelete(null);
      } catch (error) {
          console.error("Erro ao excluir:", error);
          alert("Não foi possível excluir a categoria. Verifique se existem produtos vinculados.");
      } finally {
          setIsDeleting(false);
      }
  };

  const handleKeyDownEdit = (e: React.KeyboardEvent, id: string) => {
      if (e.key === 'Enter') handleSaveEdit(id);
      if (e.key === 'Escape') setEditingId(null);
  };

  return (
    <>
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-[100] transition-opacity backdrop-blur-[2px]"
          onClick={onClose}
        />
      )}

      {categoryToDelete && (
          <div className="fixed inset-0 bg-black/60 z-[150] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
              <div className="bg-white dark:bg-[#23243a] rounded-2xl w-full max-w-sm shadow-2xl p-6 relative animate-in zoom-in-95 duration-200 border border-transparent dark:border-white/5">
                  <div className="flex flex-col items-center text-center">
                      <div className="w-16 h-16 bg-red-100 dark:bg-rose-500/10 rounded-full flex items-center justify-center mb-4 text-red-500 dark:text-rose-500">
                          <AlertTriangle size={32} />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Excluir Categoria?</h3>
                      <p className="text-gray-500 dark:text-gray-400 text-sm mb-6">
                          Você vai excluir <span className="font-bold text-gray-800 dark:text-gray-200">"{categoryToDelete.name}"</span>. 
                          <br/><span className="text-xs mt-1 block">Produtos nesta categoria podem ficar sem classificação.</span>
                      </p>
                      
                      <div className="flex gap-3 w-full">
                          <button onClick={() => setCategoryToDelete(null)} className="flex-1 py-3 bg-gray-100 dark:bg-white/5 hover:bg-gray-200 dark:hover:bg-white/10 text-gray-700 dark:text-gray-300 font-bold rounded-xl transition-colors" disabled={isDeleting}>Cancelar</button>
                          <button onClick={handleConfirmDelete} className="flex-1 py-3 bg-red-500 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-all" disabled={isDeleting}>
                              {isDeleting ? <Loader2 size={18} className="animate-spin" /> : <Trash2 size={18} />} Excluir
                          </button>
                      </div>
                  </div>
              </div>
          </div>
      )}

      <div
        className={`fixed inset-y-0 right-0 w-full max-w-[380px] bg-white dark:bg-[#23243a] shadow-2xl z-[110] transform transition-transform duration-300 ease-in-out flex flex-col border-l border-gray-100 dark:border-white/5 ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100 dark:border-white/5">
          <h2 className="text-xl font-bold text-slate-800 dark:text-white uppercase tracking-tight">Categorias</h2>
          <div className="flex items-center gap-3">
            {!isAdding ? (
                <button onClick={() => setIsAdding(true)} className="p-1 text-teal-500 dark:text-[#c1ff72] hover:scale-110 transition-all" disabled={loading} title="Adicionar categoria"><Plus size={28} strokeWidth={2.5} /></button>
            ) : (
                <button onClick={() => setIsAdding(false)} className="p-1 text-rose-400 hover:text-rose-600 transition-colors" disabled={loading}><X size={24} /></button>
            )}
            <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors"><X size={24} /></button>
          </div>
        </div>

        <div className="px-6 py-6 space-y-4">
          {!isAdding && (
            <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 dark:text-slate-600" size={20} />
                <input type="text" placeholder="Buscar categorias..." className="w-full pl-12 pr-4 py-3 bg-slate-50 dark:bg-[#1a1b2e] dark:text-white border border-slate-100 dark:border-white/10 rounded-2xl outline-none focus:border-teal-400/50 transition-all text-slate-600 font-medium" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} disabled={loading} />
            </div>
          )}

          {isAdding && (
            <div className="flex items-center gap-2 p-3 bg-teal-50 dark:bg-teal-500/5 rounded-2xl animate-in slide-in-from-top-2 border border-teal-100 dark:border-teal-500/20">
                <input autoFocus type="text" placeholder="Digite o nome..." className="flex-1 bg-transparent border-none outline-none text-[#2dd4bf] dark:text-[#c1ff72] font-bold placeholder:text-[#2dd4bf]/40 dark:placeholder-[#c1ff72]/30 px-2 py-1 uppercase" value={newValue} onChange={(e) => setNewValue(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleAdd()} disabled={loading} />
                <button onClick={handleAdd} className="bg-[#2dd4bf] dark:bg-[#c1ff72] text-white dark:text-[#1a1b2e] p-2 rounded-xl hover:brightness-105 transition-all shadow-sm disabled:opacity-50" disabled={loading || !newValue.trim()}>
                    {loading ? <Loader2 size={18} className="animate-spin" /> : <Check size={18} strokeWidth={3} />}
                </button>
            </div>
          )}
        </div>

        <div className="flex-1 overflow-y-auto px-2 custom-scrollbar">
          <div className="divide-y divide-slate-50 dark:divide-white/5">
            {filteredCategories.length === 0 ? (
                <div className="p-10 text-center text-slate-400 dark:text-gray-600 italic">
                    {searchQuery ? 'Nenhuma categoria encontrada.' : 'Crie sua primeira categoria no botão + acima.'}
                </div>
            ) : (
                filteredCategories.map((cat) => (
                <div key={cat.id} className="px-6 py-5 flex items-center justify-between hover:bg-slate-50/50 dark:hover:bg-white/5 transition-colors group">
                    {editingId === cat.id ? (
                    <div className="flex-1 flex items-center gap-2 animate-in fade-in duration-200">
                        <input autoFocus type="text" className="flex-1 border-b-2 border-teal-400 dark:border-[#c1ff72] outline-none py-1 font-bold text-slate-700 dark:text-white bg-transparent uppercase" value={editValue} onChange={(e) => setEditValue(e.target.value)} onKeyDown={(e) => handleKeyDownEdit(e, cat.id)} disabled={loading} />
                        <button onClick={() => handleSaveEdit(cat.id)} className="text-teal-600 dark:text-[#c1ff72] p-2 hover:bg-teal-50 dark:hover:bg-white/5 rounded-lg disabled:opacity-50 transition-colors" disabled={loading}>
                            {loading ? <Loader2 size={18} className="animate-spin" /> : <Check size={18} strokeWidth={3} />}
                        </button>
                        <button onClick={() => setEditingId(null)} className="text-slate-400 p-2 hover:bg-slate-100 dark:hover:bg-white/5 rounded-lg transition-colors" disabled={loading}><X size={18} /></button>
                    </div>
                    ) : (
                    <>
                        <div className="flex-1 cursor-pointer py-1" onClick={() => { setEditingId(cat.id); setEditValue(cat.name); }}>
                            <span className="text-base font-bold text-slate-700 dark:text-gray-200 uppercase tracking-tight group-hover:text-teal-600 dark:group-hover:text-[#c1ff72] transition-colors">
                                {cat.name}
                            </span>
                        </div>
                        <div className="flex items-center gap-1 ml-4">
                            <button onClick={(e) => { e.stopPropagation(); setEditingId(cat.id); setEditValue(cat.name); }} className="p-2 text-slate-400 dark:text-gray-600 hover:text-teal-500 dark:hover:text-[#c1ff72] hover:bg-teal-50 dark:hover:bg-white/5 rounded-lg transition-colors" disabled={loading} title="Editar"><Edit2 size={18} /></button>
                            <button onClick={(e) => handleDeleteClick(e, cat.id, cat.name)} className="p-2 text-slate-400 dark:text-gray-600 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-white/5 rounded-lg transition-colors" disabled={loading} title="Excluir"><Trash2 size={18} /></button>
                        </div>
                    </>
                    )}
                </div>
                ))
            )}
          </div>
        </div>

        <div className="p-6 border-t border-slate-50 dark:border-white/5 bg-slate-50/30 dark:bg-white/5">
          <button onClick={onClose} className="w-full py-4 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-600 dark:text-gray-400 font-bold rounded-2xl hover:bg-slate-50 dark:hover:bg-white/10 transition-all shadow-sm disabled:opacity-50" disabled={loading}>Fechar</button>
        </div>
      </div>
    </>
  );
};

export default CategoryPanel;
