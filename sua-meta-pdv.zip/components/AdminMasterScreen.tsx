
import React, { useState, useEffect, useMemo } from 'react';
import { 
  Search, 
  ShieldCheck, 
  Building2, 
  Users, 
  TrendingUp, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle,
  CreditCard,
  Lock,
  Unlock,
  Eye,
  LogIn,
  List,
  Loader2,
  Briefcase,
  Layers,
  ExternalLink,
  Settings2,
  DollarSign,
  Crown,
  Palette,
  Globe,
  Mail,
  Phone,
  Save,
  ImageIcon,
  X,
  Calendar,
  Shield
} from 'lucide-react';
import { Company, ResellerSettings } from '../types';
import { supabase } from '../supabaseClient';
import UserMenu from './UserMenu';
import Toast from './Toast';

const getSafeTimestamp = (dateStr: any, origin: string = 'pos') => {
    if (!dateStr || typeof dateStr !== 'string') return 0;
    try {
        if (origin === 'pos' || dateStr.includes('T') || dateStr.includes('Z')) {
            const t = new Date(dateStr).getTime();
            return isNaN(t) ? 0 : t;
        }
        const datePart = dateStr.split(/[T ]/)[0];
        if (!datePart) return 0;
        const parts = datePart.split('-');
        if (parts.length < 3) return 0;
        const [y, m, d] = parts.map(Number);
        const t = new Date(y, m - 1, d, 12, 0, 0).getTime();
        return isNaN(t) ? 0 : t;
    } catch (e) {
        return 0;
    }
};

interface AdminMasterScreenProps {
  toggleSidebar: () => void;
  isResellerMode?: boolean; // Se true, o componente age como Painel de Revenda
  resellerCompanyId?: string;
  onImpersonate?: (companyId: string) => void;
}

const AdminMasterScreen: React.FC<AdminMasterScreenProps> = ({ toggleSidebar, isResellerMode = false, resellerCompanyId, onImpersonate }) => {
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingSettings, setSavingSettings] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'companies' | 'resellers' | 'settings'>(isResellerMode ? 'companies' : 'resellers');
  
  // States para Edição de Empresa
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingCompany, setEditingCompany] = useState<Company | null>(null);
  const [isSavingCompany, setIsSavingCompany] = useState(false);

  // States para Revenda
  const [resellerSettings, setResellerSettings] = useState<Partial<ResellerSettings>>({
    custom_primary_color: '#6366f1',
    max_clients_allowed: 50,
    commission_percentage: 10
  });
  
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  useEffect(() => {
    fetchData();
  }, [isResellerMode, resellerCompanyId]);

  const fetchData = async () => {
    setLoading(true);
    try {
      let query = supabase.from('companies').select('*');
      
      if (isResellerMode && resellerCompanyId) {
          query = query.eq('parent_company_id', resellerCompanyId);
          const { data: setts } = await supabase
            .from('reseller_settings')
            .select('*')
            .eq('company_id', resellerCompanyId)
            .maybeSingle();
            
          if (setts) setResellerSettings(setts);
      }

      const { data, error } = await query.order('created_at', { ascending: false });

      if (error) throw error;
      setCompanies(data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      setToastMessage('Erro ao carregar dados.');
      setShowToast(true);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenEdit = (company: Company) => {
    setEditingCompany({ ...company });
    setIsEditModalOpen(true);
  };

  const handleSaveCompany = async () => {
    if (!editingCompany) return;
    setIsSavingCompany(true);
    try {
      const { error } = await supabase
        .from('companies')
        .update({
          name: editingCompany.name,
          social_reason: editingCompany.social_reason,
          cnpj: editingCompany.cnpj,
          subscription_status: editingCompany.subscription_status,
          subscription_plan: editingCompany.subscription_plan,
          next_due_date: editingCompany.next_due_date,
          type: editingCompany.type
        })
        .eq('id', editingCompany.id);

      if (error) throw error;
      
      setToastMessage('Empresa atualizada com sucesso!');
      setShowToast(true);
      setIsEditModalOpen(false);
      fetchData();
    } catch (err) {
      console.error(err);
      setToastMessage('Erro ao salvar alterações.');
      setShowToast(true);
    } finally {
      setIsSavingCompany(false);
    }
  };

  const handleSaveResellerSettings = async () => {
    if (!resellerCompanyId) return;
    setSavingSettings(true);
    try {
        const { error } = await supabase
            .from('reseller_settings')
            .upsert({
                company_id: resellerCompanyId,
                custom_logo_url: resellerSettings.custom_logo_url,
                custom_primary_color: resellerSettings.custom_primary_color,
                custom_domain: resellerSettings.custom_domain,
                support_email: resellerSettings.support_email,
                support_phone: resellerSettings.support_phone,
                custom_branding_enabled: true
            }, { onConflict: 'company_id' });

        if (error) throw error;
        setToastMessage('Configurações de marca salvas com sucesso!');
        setShowToast(true);
    } catch (err) {
        console.error(err);
        setToastMessage('Erro ao salvar personalização.');
        setShowToast(true);
    } finally {
        setSavingSettings(false);
    }
  };

  const stats = useMemo(() => {
      const active = companies.filter(c => c.subscription_status === 'active').length;
      const resellers = companies.filter(c => c.type === 'reseller').length;
      return { total: companies.length, active, resellers };
  }, [companies]);

  const filteredCompanies = useMemo(() => {
    return companies.filter(c => {
      const name = (c.name || '').toLowerCase();
      const cnpj = (c.cnpj || '');
      const query = searchQuery.toLowerCase();
      
      const matchesSearch = name.includes(query) || cnpj.includes(query);
      const matchesTab = activeTab === 'resellers' ? c.type === 'reseller' : c.type === 'client';
      
      return matchesSearch && matchesTab;
    });
  }, [companies, searchQuery, activeTab]);

  const handleMakeReseller = async (company: Company) => {
      try {
          const newType = company.type === 'reseller' ? 'client' : 'reseller';
          const { error } = await supabase.from('companies').update({ type: newType }).eq('id', company.id);
          if (error) throw error;
          
          if (newType === 'reseller') {
              await supabase.from('reseller_settings').upsert({ company_id: company.id });
          }

          setToastMessage(`Empresa agora é ${newType === 'reseller' ? 'Revendedora' : 'Cliente'}`);
          setShowToast(true);
          fetchData();
      } catch (e) {
          setToastMessage('Erro ao alterar tipo de empresa');
          setShowToast(true);
      }
  };

  const getStatusBadge = (status: string | undefined) => {
      if (status === 'blocked') return <span className="bg-gray-800 text-white px-2 py-0.5 rounded text-[10px] font-black uppercase">Bloqueada</span>;
      if (status === 'active') return <span className="bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-500/20 px-2 py-0.5 rounded text-[10px] font-black uppercase transition-colors">Ativa</span>;
      return <span className="bg-red-50 dark:bg-rose-500/10 text-red-600 dark:text-rose-400 border border-red-100 dark:border-rose-500/20 px-2 py-0.5 rounded text-[10px] font-black uppercase transition-colors">Inativa</span>;
  };

  const formatCurrency = (val: number) => val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  return (
    <div className="flex-1 flex flex-col h-full bg-[#f8fafc] dark:bg-[#1a1b2e] font-sans transition-colors">
      <Toast message={toastMessage} isVisible={showToast} onClose={() => setShowToast(false)} />

      {/* MODAL DE EDIÇÃO DE EMPRESA */}
      {isEditModalOpen && editingCompany && (
        <div className="fixed inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-sm z-[150] flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] w-full max-w-2xl shadow-2xl overflow-hidden animate-in zoom-in-95 border border-slate-100 dark:border-white/5 transition-colors">
            <div className="px-8 pt-10 pb-6 flex justify-between items-start bg-gray-50/50 dark:bg-white/5 border-b border-gray-100 dark:border-white/5">
              <div>
                <h3 className="text-2xl font-black text-[#1e293b] dark:text-white uppercase tracking-tighter">Gerenciar Empresa</h3>
                <p className="text-[10px] font-bold text-indigo-500 dark:text-indigo-400 uppercase tracking-[0.2em] mt-2">Configurações Administrativas</p>
              </div>
              <button onClick={() => setIsEditModalOpen(false)} className="text-slate-300 dark:text-gray-500 hover:text-slate-600 dark:hover:text-white p-2 transition-colors"><X size={32} /></button>
            </div>
            
            <div className="p-10 space-y-8 overflow-y-auto max-h-[70vh] custom-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Identificação */}
                <div className="space-y-6">
                  <h4 className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest flex items-center gap-2"><Building2 size={14}/> Dados Cadastrais</h4>
                  <div className="space-y-4">
                    <div className="relative">
                      <label className="absolute -top-2 left-3 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest">Nome da Empresa</label>
                      <input 
                        type="text" 
                        className="w-full border border-gray-200 dark:border-white/10 rounded-xl p-4 text-sm font-bold text-gray-700 dark:text-white bg-transparent outline-none focus:border-indigo-500 transition-all"
                        value={editingCompany.name}
                        onChange={e => setEditingCompany({...editingCompany, name: e.target.value})}
                      />
                    </div>
                    <div className="relative">
                      <label className="absolute -top-2 left-3 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest">Razão Social</label>
                      <input 
                        type="text" 
                        className="w-full border border-gray-200 dark:border-white/10 rounded-xl p-4 text-sm font-bold text-gray-700 dark:text-white bg-transparent outline-none focus:border-indigo-500 transition-all"
                        value={editingCompany.social_reason || ''}
                        onChange={e => setEditingCompany({...editingCompany, social_reason: e.target.value})}
                      />
                    </div>
                    <div className="relative">
                      <label className="absolute -top-2 left-3 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest">CNPJ</label>
                      <input 
                        type="text" 
                        className="w-full border border-gray-200 dark:border-white/10 rounded-xl p-4 text-sm font-bold text-gray-700 dark:text-white bg-transparent outline-none focus:border-indigo-500 transition-all"
                        value={editingCompany.cnpj || ''}
                        onChange={e => setEditingCompany({...editingCompany, cnpj: e.target.value})}
                      />
                    </div>
                  </div>
                </div>

                {/* Assinatura */}
                <div className="space-y-6">
                  <h4 className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest flex items-center gap-2"><CreditCard size={14}/> Plano & Assinatura</h4>
                  <div className="space-y-4">
                    <div className="relative">
                      <label className="absolute -top-2 left-3 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest">Status do Acesso</label>
                      <select 
                        className="w-full border border-gray-200 dark:border-white/10 rounded-xl p-4 text-sm font-bold text-gray-700 dark:text-white bg-transparent outline-none focus:border-indigo-500 transition-all"
                        value={editingCompany.subscription_status || 'inactive'}
                        onChange={e => setEditingCompany({...editingCompany, subscription_status: e.target.value as any})}
                      >
                        <option value="active">ATIVO</option>
                        <option value="inactive">INATIVO</option>
                        <option value="blocked">BLOQUEADO</option>
                      </select>
                    </div>
                    <div className="relative">
                      <label className="absolute -top-2 left-3 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest">Plano Contratado</label>
                      <input 
                        type="text" 
                        className="w-full border border-gray-200 dark:border-white/10 rounded-xl p-4 text-sm font-bold text-gray-700 dark:text-white bg-transparent outline-none focus:border-indigo-500 transition-all"
                        value={editingCompany.subscription_plan || ''}
                        onChange={e => setEditingCompany({...editingCompany, subscription_plan: e.target.value})}
                        placeholder="Ex: Diamond / Pro"
                      />
                    </div>
                    <div className="relative">
                      <label className="absolute -top-2 left-3 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest">Vencimento Próxima Fatura</label>
                      <input 
                        type="date" 
                        className="w-full border border-gray-200 dark:border-white/10 rounded-xl p-4 text-sm font-bold text-gray-700 dark:text-white bg-transparent outline-none focus:border-indigo-500 transition-all"
                        value={editingCompany.next_due_date ? editingCompany.next_due_date.split('T')[0] : ''}
                        onChange={e => setEditingCompany({...editingCompany, next_due_date: e.target.value})}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Tipo de Empresa (Apenas Master) */}
              {!isResellerMode && (
                <div className="p-6 bg-indigo-50 dark:bg-indigo-500/10 rounded-3xl border border-indigo-100 dark:border-indigo-500/20 flex items-center justify-between transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-white dark:bg-[#23243a] flex items-center justify-center text-indigo-600 dark:text-indigo-400 shadow-sm transition-colors">
                      <Shield size={24} />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-indigo-400 dark:text-indigo-500 uppercase tracking-widest">Tipo de Entidade</p>
                      <p className="text-sm font-bold text-indigo-900 dark:text-indigo-100 uppercase">Configuração de Hierarquia</p>
                    </div>
                  </div>
                  <select 
                    className="bg-white dark:bg-[#1a1b2e] border-2 border-indigo-200 dark:border-indigo-500/20 rounded-xl px-6 py-2 text-xs font-black uppercase outline-none focus:border-indigo-500 text-indigo-600 dark:text-indigo-400 transition-all"
                    value={editingCompany.type}
                    onChange={e => setEditingCompany({...editingCompany, type: e.target.value as any})}
                  >
                    <option value="client">CLIENTE FINAL</option>
                    <option value="reseller">PARCEIRO REVENDA</option>
                  </select>
                </div>
              )}
            </div>

            <div className="p-8 bg-gray-50 dark:bg-white/5 border-t border-gray-100 dark:border-white/5 flex gap-4 transition-colors">
              <button 
                onClick={() => setIsEditModalOpen(false)}
                className="flex-1 py-4 bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 text-gray-400 dark:text-gray-500 font-black text-[11px] uppercase rounded-2xl hover:bg-gray-100 dark:hover:bg-white/10 transition-all"
              >
                CANCELAR
              </button>
              <button 
                onClick={handleSaveCompany}
                disabled={isSavingCompany}
                className="flex-[2] py-4 bg-indigo-600 text-white font-black text-[11px] uppercase rounded-2xl shadow-xl flex items-center justify-center gap-3 active:scale-95 transition-all"
              >
                {isSavingCompany ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                SALVAR ALTERAÇÕES
              </button>
            </div>
          </div>
        </div>
      )}

      <header className="bg-white dark:bg-[#23243a] h-[90px] px-4 lg:px-10 flex justify-between items-center shrink-0 border-b border-gray-100 dark:border-white/5 sticky top-0 z-50 transition-colors">
          <div className="flex items-center gap-4">
              <button onClick={toggleSidebar} className="lg:hidden p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-xl transition-colors">
                  <List size={26} />
              </button>
              <div>
                  <h1 className="text-[23px] font-mono font-black text-gray-900 dark:text-white tracking-tighter uppercase leading-none italic flex items-center gap-2">
                      {isResellerMode ? <><Briefcase className="text-indigo-600 dark:text-indigo-400" /> Painel de Revenda</> : <><Crown className="text-amber-500" /> Gestão Master</>}
                  </h1>
                  <p className="text-[10px] text-gray-400 font-black uppercase tracking-[0.3em] mt-1 hidden sm:block">SuaMeta White-Label Engine</p>
              </div>
          </div>
          <UserMenu />
      </header>

      <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
          <div className="max-w-7xl mx-auto space-y-8 pb-20">
              
              {/* KPIs de Rede */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="bg-white dark:bg-[#23243a] p-6 rounded-[2rem] shadow-sm border border-gray-100 dark:border-white/5 transition-colors">
                      <p className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-1">Empresas na Rede</p>
                      <h3 className="text-3xl font-black text-gray-900 dark:text-white">{stats.total}</h3>
                      <div className="mt-2 flex items-center gap-1 text-[10px] font-bold text-emerald-500">
                          <TrendingUp size={12} /> +12% este mês
                      </div>
                  </div>
                  {!isResellerMode && (
                    <div className="bg-white dark:bg-[#23243a] p-6 rounded-[2rem] shadow-sm border border-gray-100 dark:border-white/5 transition-colors">
                        <p className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-1">Revendedores</p>
                        <h3 className="text-3xl font-black text-indigo-600 dark:text-indigo-400">{stats.resellers}</h3>
                        <p className="text-[10px] text-gray-400 dark:text-gray-500 mt-2 font-medium">Parceiros ativos</p>
                    </div>
                  )}
                  <div className="bg-indigo-600 p-6 rounded-[2rem] shadow-xl text-white relative overflow-hidden">
                      <div className="relative z-10">
                        <p className="text-[10px] font-black text-indigo-200 uppercase tracking-widest mb-1">Recorrência Total</p>
                        <h3 className="text-3xl font-black">{formatCurrency(stats.active * 150)}</h3>
                        <p className="text-[10px] mt-2 opacity-60">Base estimada</p>
                      </div>
                      <DollarSign className="absolute -bottom-4 -right-4 w-24 h-24 opacity-10" />
                  </div>
                  <div className="bg-white dark:bg-[#23243a] p-6 rounded-[2rem] shadow-sm border border-gray-100 dark:border-white/5 transition-colors">
                      <p className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-1">Licenças Usadas</p>
                      <h3 className="text-3xl font-black text-gray-900 dark:text-white">
                          {isResellerMode ? `${stats.total} / ${resellerSettings.max_clients_allowed || 50}` : stats.total}
                      </h3>
                      <div className="w-full bg-gray-100 dark:bg-white/5 h-1.5 rounded-full mt-3 overflow-hidden">
                          <div className="bg-indigo-500 h-full" style={{ width: `${(stats.total / (resellerSettings.max_clients_allowed || 50)) * 100}%` }}></div>
                      </div>
                  </div>
              </div>

              {/* Tabs e Busca */}
              <div className="flex flex-col sm:flex-row gap-4 items-center justify-between animate-in fade-in slide-in-from-top-2 duration-300">
                  <div className="flex bg-white dark:bg-[#23243a] p-1.5 rounded-2xl border border-gray-100 dark:border-white/5 shadow-sm w-full sm:w-auto transition-colors">
                      {!isResellerMode && (
                        <button 
                            onClick={() => setActiveTab('resellers')}
                            className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'resellers' ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300'}`}
                        >
                            Revendedores
                        </button>
                      )}
                      <button 
                        onClick={() => setActiveTab('companies')}
                        className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'companies' ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300'}`}
                      >
                          Empresas Clientes
                      </button>
                      {isResellerMode && (
                        <button 
                            onClick={() => setActiveTab('settings')}
                            className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'settings' ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300'}`}
                        >
                            Minha Marca
                        </button>
                      )}
                  </div>
                  {activeTab !== 'settings' && (
                    <div className="relative w-full sm:w-80 group">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300 dark:text-gray-600 group-focus-within:text-indigo-500 transition-colors" size={18} />
                        <input 
                            type="text"
                            placeholder="Buscar empresa..."
                            className="w-full pl-11 pr-4 py-3 bg-white dark:bg-[#23243a] dark:text-white border border-gray-100 dark:border-white/10 rounded-2xl outline-none focus:border-indigo-400 transition-all text-sm font-bold shadow-sm"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                    </div>
                  )}
              </div>

              {/* Lista de Empresas */}
              {(activeTab === 'companies' || activeTab === 'resellers') && (
                <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] shadow-xl shadow-slate-200/50 dark:shadow-none border border-gray-100 dark:border-white/5 overflow-hidden transition-colors">
                    <div className="overflow-x-auto">
                        <table className="w-full text-left border-separate border-spacing-0">
                            <thead className="bg-gray-50/50 dark:bg-white/5 border-b border-gray-100 dark:border-white/5 text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-[0.2em] transition-colors">
                                <tr>
                                    <th className="px-8 py-6">Nome / Identificação</th>
                                    <th className="px-8 py-6">Status</th>
                                    <th className="px-8 py-6">Vencimento</th>
                                    {!isResellerMode && <th className="px-8 py-6">Tipo</th>}
                                    <th className="px-8 py-6 text-right">Ações</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-50 dark:divide-white/5">
                                {loading ? (
                                    <tr><td colSpan={6} className="p-20 text-center text-gray-400 dark:text-gray-600 animate-pulse uppercase font-black text-xs">Sincronizando Rede...</td></tr>
                                ) : filteredCompanies.length === 0 ? (
                                    <tr><td colSpan={6} className="p-20 text-center text-gray-300 dark:text-gray-700 italic">Nenhum registro encontrado.</td></tr>
                                ) : (
                                    filteredCompanies.map(c => (
                                        <tr key={c.id} className="hover:bg-gray-50/50 dark:hover:bg-white/5 transition-colors group">
                                            <td className="px-8 py-5">
                                                <div className="flex items-center gap-4">
                                                    <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-black uppercase shadow-inner">
                                                        {c.name.substring(0, 2)}
                                                    </div>
                                                    <div>
                                                        <p className="text-sm font-black text-gray-800 dark:text-white uppercase tracking-tighter transition-colors">{c.name}</p>
                                                        <p className="text-[10px] text-gray-400 dark:text-gray-500 font-mono">{c.cnpj || 'Sem Documento'}</p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="px-8 py-5">{getStatusBadge(c.subscription_status)}</td>
                                            <td className="px-8 py-5 text-xs font-bold text-gray-500 dark:text-gray-400">
                                                {c.next_due_date ? new Date(getSafeTimestamp(c.next_due_date)).toLocaleDateString('pt-BR') : '-'}
                                            </td>
                                            {!isResellerMode && (
                                                <td className="px-8 py-5">
                                                    <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase transition-colors ${c.type === 'reseller' ? 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400' : 'bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-400'}`}>
                                                        {c.type === 'reseller' ? 'Revenda' : 'Cliente'}
                                                    </span>
                                                </td>
                                            )}
                                            <td className="px-8 py-5 text-right">
                                                <div className="flex justify-end gap-2">
                                                    <button 
                                                      onClick={() => handleOpenEdit(c)}
                                                      className="p-2 text-gray-300 dark:text-gray-600 hover:text-indigo-600 dark:hover:text-indigo-400 transition-all" 
                                                      title="Ver Detalhes / Editar"
                                                    >
                                                      <Eye size={18} />
                                                    </button>
                                                    <button 
                                                        onClick={() => onImpersonate?.(c.id)}
                                                        className="p-2 text-gray-300 dark:text-gray-600 hover:text-emerald-500 dark:hover:text-emerald-400 transition-all" 
                                                        title="Impersonate (Acessar)"
                                                    >
                                                        <LogIn size={18} />
                                                    </button>
                                                    {!isResellerMode && (
                                                        <button 
                                                            onClick={() => handleMakeReseller(c)}
                                                            className="p-2 text-gray-300 dark:text-gray-600 hover:text-amber-500 dark:hover:text-amber-400 transition-all" 
                                                            title={c.type === 'reseller' ? "Remover Revenda" : "Tornar Revendedor"}
                                                        >
                                                            <Briefcase size={18} />
                                                        </button>
                                                    )}
                                                </div>
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
              )}

              {/* ABA DE CONFIGURAÇÕES WHITE-LABEL (Apenas no modo Revenda) */}
              {isResellerMode && activeTab === 'settings' && (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
                      
                      <div className="lg:col-span-8 space-y-8">
                          <div className="bg-white dark:bg-[#23243a] p-10 rounded-[3rem] shadow-sm border border-gray-100 dark:border-white/5 transition-colors">
                              <h3 className="text-xl font-black text-gray-800 dark:text-white uppercase tracking-tighter mb-8 flex items-center gap-3">
                                  <Palette className="text-indigo-600 dark:text-indigo-400" /> Identidade Visual
                              </h3>
                              
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                  <div className="space-y-6">
                                      <div className="relative group">
                                          <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-2 text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest group-focus-within:text-indigo-600 transition-all">URL da Logomarca (PNG/SVG)</label>
                                          <div className="flex items-center gap-3 border-2 border-gray-100 dark:border-white/10 rounded-2xl p-4 focus-within:border-indigo-400 transition-all">
                                              <ImageIcon className="text-gray-300 dark:text-gray-600" size={20} />
                                              <input 
                                                type="text" 
                                                className="w-full bg-transparent outline-none text-sm font-bold text-gray-700 dark:text-white"
                                                placeholder="https://sua-logo.com/logo.png"
                                                value={resellerSettings.custom_logo_url || ''}
                                                onChange={e => setResellerSettings({...resellerSettings, custom_logo_url: e.target.value})}
                                              />
                                          </div>
                                      </div>
                                      
                                      <div className="relative group">
                                          <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-2 text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest group-focus-within:text-indigo-600 transition-all">Cor Primária do Sistema</label>
                                          <div className="flex items-center gap-3 border-2 border-gray-100 dark:border-white/10 rounded-2xl p-4 focus-within:border-indigo-400 transition-all">
                                              <div className="w-6 h-6 rounded-full border border-gray-100 dark:border-white/20 shadow-inner" style={{ backgroundColor: resellerSettings.custom_primary_color }}></div>
                                              <input 
                                                type="text" 
                                                className="w-full bg-transparent outline-none text-sm font-bold text-gray-700 dark:text-white font-mono"
                                                placeholder="#HEXADECIMAL"
                                                value={resellerSettings.custom_primary_color || ''}
                                                onChange={e => setResellerSettings({...resellerSettings, custom_primary_color: e.target.value})}
                                              />
                                          </div>
                                      </div>
                                  </div>

                                  <div className="bg-gray-50/50 dark:bg-white/5 rounded-3xl p-6 border border-dashed border-gray-200 dark:border-white/10 flex flex-col items-center justify-center text-center transition-colors">
                                      <p className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-4">Prévia do Logo</p>
                                      {resellerSettings.custom_logo_url ? (
                                          <img src={resellerSettings.custom_logo_url} alt="Logo Preview" className="max-h-24 object-contain" />
                                      ) : (
                                          <div className="w-20 h-20 bg-white dark:bg-[#1a1b2e] rounded-2xl flex items-center justify-center text-gray-200 dark:text-gray-700 shadow-sm transition-colors">
                                              <ImageIcon size={40} />
                                          </div>
                                      )}
                                      <p className="text-[9px] text-gray-400 dark:text-gray-500 mt-4 max-w-[180px]">Recomendamos fundos transparentes e proporções horizontais.</p>
                                  </div>
                              </div>
                          </div>

                          <div className="bg-white dark:bg-[#23243a] p-10 rounded-[3rem] shadow-sm border border-gray-100 dark:border-white/5 transition-colors">
                              <h3 className="text-xl font-black text-gray-800 dark:text-white uppercase tracking-tighter mb-8 flex items-center gap-3">
                                  <Globe className="text-indigo-600 dark:text-indigo-400" /> Endereço & Suporte
                              </h3>
                              
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                  <div className="relative group">
                                      <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-2 text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest">Domínio Personalizado (Opcional)</label>
                                      <div className="flex items-center gap-3 border-2 border-gray-100 dark:border-white/10 rounded-2xl p-4 focus-within:border-indigo-400 transition-all">
                                          <Globe className="text-gray-300 dark:text-gray-600" size={20} />
                                          <input 
                                            type="text" 
                                            className="w-full bg-transparent outline-none text-sm font-bold text-gray-700 dark:text-white"
                                            placeholder="app.seusistema.com.br"
                                            value={resellerSettings.custom_domain || ''}
                                            onChange={e => setResellerSettings({...resellerSettings, custom_domain: e.target.value})}
                                          />
                                      </div>
                                  </div>
                                  
                                  <div className="relative group">
                                      <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-2 text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest">E-mail de Suporte</label>
                                      <div className="flex items-center gap-3 border-2 border-gray-100 dark:border-white/10 rounded-2xl p-4 focus-within:border-indigo-400 transition-all">
                                          <Mail className="text-gray-300 dark:text-gray-600" size={20} />
                                          <input 
                                            type="email" 
                                            className="w-full bg-transparent outline-none text-sm font-bold text-gray-700 dark:text-white"
                                            placeholder="suporte@sua-marca.com"
                                            value={resellerSettings.support_email || ''}
                                            onChange={e => setResellerSettings({...resellerSettings, support_email: e.target.value})}
                                          />
                                      </div>
                                  </div>

                                  <div className="relative group">
                                      <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-2 text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest">WhatsApp de Suporte</label>
                                      <div className="flex items-center gap-3 border-2 border-gray-100 dark:border-white/10 rounded-2xl p-4 focus-within:border-indigo-400 transition-all">
                                          <Phone className="text-gray-300 dark:text-gray-600" size={20} />
                                          <input 
                                            type="text" 
                                            className="w-full bg-transparent outline-none text-sm font-bold text-gray-700 dark:text-white"
                                            placeholder="(00) 00000-0000"
                                            value={resellerSettings.support_phone || ''}
                                            onChange={e => setResellerSettings({...resellerSettings, support_phone: e.target.value})}
                                          />
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>

                      <div className="lg:col-span-4 space-y-8">
                          <div className="bg-indigo-600 p-8 rounded-[3rem] shadow-xl text-white relative overflow-hidden">
                              <h4 className="text-xs font-black uppercase tracking-widest opacity-60 mb-6">Status do Plano</h4>
                              <div className="space-y-6 relative z-10">
                                  <div>
                                      <p className="text-[10px] font-bold uppercase tracking-widest mb-1">Cota de Clientes</p>
                                      <p className="text-4xl font-black">{stats.total} / {resellerSettings.max_clients_allowed}</p>
                                  </div>
                                  <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
                                      <div className="h-full bg-[#c1ff72] shadow-[0_0_15px_rgba(193,255,114,0.5)]" style={{ width: `${(stats.total / (resellerSettings.max_clients_allowed || 50)) * 100}%` }}></div>
                                  </div>
                                  <div className="flex justify-between items-center bg-black/10 p-4 rounded-2xl border border-white/5">
                                      <span className="text-[10px] font-black uppercase">Sua Comissão</span>
                                      <span className="text-xl font-black text-[#c1ff72]">{resellerSettings.commission_percentage}%</span>
                                  </div>
                                  <p className="text-[9px] opacity-60 leading-relaxed italic">
                                      * Estes limites são definidos pelo Administrador Master. Entre em contato se precisar de upgrade.
                                  </p>
                              </div>
                          </div>

                          <div className="bg-white dark:bg-[#23243a] p-8 rounded-[3rem] shadow-sm border border-gray-100 dark:border-white/5 transition-colors">
                               <button 
                                 onClick={handleSaveResellerSettings}
                                 disabled={savingSettings}
                                 className="w-full py-5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-[1.5rem] font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-indigo-100 transition-all flex items-center justify-center gap-3 active:scale-95"
                               >
                                   {savingSettings ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                                   Salvar Identidade
                               </button>
                               <p className="text-[10px] text-gray-400 dark:text-gray-500 text-center mt-6 font-bold uppercase tracking-widest">
                                   As alterações serão aplicadas a todos os seus clientes em instantes.
                               </p>
                          </div>
                      </div>
                  </div>
              )}

          </div>
      </div>
    </div>
  );
};

export default AdminMasterScreen;
