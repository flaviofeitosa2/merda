
import React, { useState, useEffect } from 'react';
// Added Loader2 to the imports
import { X, Save, Calendar, User, CreditCard, Loader2 } from 'lucide-react';
import { Sale, UserProfile, PaymentMethod } from '../types';

interface SaleEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  sale: Sale | null;
  users: UserProfile[];
  onSave: (saleId: string, data: any) => Promise<void>;
}

const SaleEditModal: React.FC<SaleEditModalProps> = ({ isOpen, onClose, sale, users, onSave }) => {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    date: '',
    sellerName: '',
    paymentMethod: '' as PaymentMethod
  });

  useEffect(() => {
    if (sale && isOpen) {
      // Extrai YYYY-MM-DD da string ISO para o input type="date" de forma robusta
      let dateVal = '';
      if (sale.date) {
        // Se for exatamente YYYY-MM-DD (sem horário), retorna direto
        if (/^\d{4}-\d{2}-\d{2}$/.test(sale.date)) {
          dateVal = sale.date;
        } else {
          const d = new Date(sale.date);
          if (!isNaN(d.getTime())) {
            const year = d.getFullYear();
            const month = String(d.getMonth() + 1).padStart(2, '0');
            const day = String(d.getDate()).padStart(2, '0');
            dateVal = `${year}-${month}-${day}`;
          } else {
            // Fallback
            const match = sale.date.match(/^(\d{4}-\d{2}-\d{2})/);
            if (match) dateVal = match[1];
          }
        }
      }
      
      setFormData({
        date: dateVal,
        sellerName: sale.sellerName || '',
        paymentMethod: sale.paymentMethod || (sale.payments && sale.payments.length > 0 ? sale.payments[0].method : 'money')
      });
    }
  }, [sale, isOpen]);

  const paymentOptions: { id: PaymentMethod; label: string }[] = [
    { id: 'money', label: 'Dinheiro' },
    { id: 'pix', label: 'Pix' },
    { id: 'debit', label: 'Débito' },
    { id: 'credit', label: 'Crédito' },
    { id: 'others', label: 'Outros' },
    { id: 'credit_tab', label: 'Venda Fiado' },
    { id: 'link', label: 'Link de Pagamento' },
  ];

  const handleSave = async () => {
    if (!sale) return;
    setLoading(true);
    try {
      // CORREÇÃO DE FUSO HORÁRIO BLINDADA
      // Ao invés de manter o horário original (que pode causar bugs de virada de dia em UTC),
      // forçamos a data selecionada para o MEIO-DIA (12:00) do fuso local.
      // Isso garante que, ao converter para UTC (toISOString), o dia permaneça o mesmo
      // para todas as timezones das Américas/Europa.
      
      const [year, month, day] = formData.date.split('-').map(Number);
      // Forçamos a data selecionada para o MEIO-DIA (12:00) do fuso local.
      // Isso garante que, ao converter para UTC (toISOString), o dia permaneça o mesmo
      // para todas as timezones das Américas/Europa.
      const noonDate = new Date(year, month - 1, day, 12, 0, 0, 0);
      const updatedDate = noonDate.toISOString();
      
      await onSave(sale.id, {
        date: updatedDate,
        sellerName: formData.sellerName,
        paymentMethod: formData.paymentMethod
      });
      onClose();
    } catch (error) {
      console.error(error);
      alert('Erro ao salvar alterações');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen || !sale) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4 transition-all">
      <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] w-full max-w-md shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 border border-slate-100 dark:border-white/5 transition-colors">
        
        {/* Header */}
        <div className="px-8 pt-10 pb-6 flex justify-between items-start">
          <div>
            <h2 className="text-3xl font-black text-[#1e293b] dark:text-white uppercase tracking-tighter italic leading-none">EDITAR VENDA</h2>
            <p className="text-[10px] font-bold text-indigo-50 dark:text-indigo-400 uppercase tracking-[0.2em] mt-3">ALTERAR INFORMAÇÕES DO REGISTRO</p>
          </div>
          <button onClick={onClose} className="text-slate-300 hover:text-slate-500 dark:hover:text-white p-1 transition-colors">
            <X size={32} />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-8 pt-0 space-y-8">
          
          <div className="relative group">
            <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-1 text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest z-10 transition-all group-focus-within:text-indigo-500">
              DATA DA VENDA
            </label>
            <div className="flex items-center border border-gray-200 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] focus-within:border-indigo-500 transition-all">
              <input 
                type="date" 
                className="w-full bg-transparent outline-none text-base font-black text-gray-800 dark:text-white uppercase"
                value={formData.date}
                onChange={e => setFormData({...formData, date: e.target.value})}
              />
              <Calendar className="text-gray-300 ml-2" size={20} />
            </div>
          </div>

          <div className="relative group">
            <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-1 text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest z-10 transition-all group-focus-within:text-indigo-500">
              VENDEDOR
            </label>
            <div className="flex items-center border border-gray-200 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] focus-within:border-indigo-500 transition-all">
              <select 
                className="w-full bg-transparent outline-none text-base font-black text-gray-800 dark:text-white uppercase appearance-none"
                value={formData.sellerName}
                onChange={e => setFormData({...formData, sellerName: e.target.value})}
              >
                {users.map(u => (
                  <option key={u.id} value={u.full_name}>{u.full_name}</option>
                ))}
              </select>
              <User className="text-gray-300 ml-2" size={20} />
            </div>
          </div>

          <div className="relative group">
            <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-1 text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest z-10 transition-all group-focus-within:text-indigo-500">
              FORMA DE PAGAMENTO PRINCIPAL
            </label>
            <div className="flex items-center border border-gray-200 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] focus-within:border-indigo-500 transition-all">
              <select 
                className="w-full bg-transparent outline-none text-base font-black text-gray-800 dark:text-white uppercase appearance-none"
                value={formData.paymentMethod}
                onChange={e => setFormData({...formData, paymentMethod: e.target.value as PaymentMethod})}
              >
                {paymentOptions.map(opt => (
                  <option key={opt.id} value={opt.id}>{opt.label}</option>
                ))}
              </select>
              <CreditCard className="text-gray-300 ml-2" size={20} />
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="px-8 py-8 bg-slate-50 dark:bg-white/5 border-t dark:border-white/5 flex gap-4 transition-colors">
          <button 
            onClick={onClose}
            className="flex-1 py-4 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-400 dark:text-gray-500 font-black text-[11px] uppercase rounded-2xl transition-all hover:bg-slate-50 dark:hover:bg-white/10"
          >
            CANCELAR
          </button>
          <button 
            onClick={handleSave}
            disabled={loading}
            className="flex-[2] py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-black text-[11px] uppercase tracking-widest shadow-xl shadow-indigo-200 dark:shadow-none transition-all flex items-center justify-center gap-3 disabled:opacity-50"
          >
            {loading ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />}
            SALVAR
          </button>
        </div>
      </div>
    </div>
  );
};

export default SaleEditModal;
