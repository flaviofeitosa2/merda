
import React, { useState, useEffect } from 'react';
import { X, Check } from 'lucide-react';
import { Category } from '../types';

export interface ProductFilters {
  stockStatus: string[]; // 'out', 'min', 'available', 'no_control'
  categories: string[];  
  sortBy: 'stock_asc' | 'stock_desc' | 'name_asc' | 'name_desc';
}

interface ProductFilterPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyFilters: (filters: ProductFilters) => void;
  currentFilters: ProductFilters;
}

const ProductFilterPanel: React.FC<ProductFilterPanelProps> = ({
  isOpen,
  onClose,
  onApplyFilters,
  currentFilters
}) => {
  const [stockStatus, setStockStatus] = useState<string[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<ProductFilters['sortBy']>('name_asc');

  useEffect(() => {
    if (isOpen) {
      setStockStatus(currentFilters.stockStatus || []);
      setSelectedCategories(currentFilters.categories || []);
      setSortBy(currentFilters.sortBy || 'name_asc');
    }
  }, [isOpen, currentFilters]);

  const toggleStock = (value: string) => {
    setStockStatus(prev => 
      prev.includes(value) ? prev.filter(item => item !== value) : [...prev, value]
    );
  };

  const toggleCategory = (cat: string) => {
    setSelectedCategories(prev => 
      prev.includes(cat) ? prev.filter(item => item !== cat) : [...prev, cat]
    );
  };

  const handleApply = () => {
    onApplyFilters({ stockStatus, categories: selectedCategories, sortBy });
    onClose();
  };

  const handleClear = () => {
      setStockStatus([]);
      setSelectedCategories([]);
      setSortBy('name_asc');
  };

  return (
    <>
      <div 
        className={`fixed inset-0 bg-black/40 z-[100] transition-opacity backdrop-blur-[2px] ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} 
        onClick={onClose} 
      />
      
      <div className={`fixed inset-y-0 right-0 w-full sm:w-[400px] bg-white dark:bg-[#23243a] shadow-2xl z-[110] transform transition-transform duration-300 ease-in-out flex flex-col font-sans border-l border-gray-100 dark:border-white/5 ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100 dark:border-white/5 bg-white dark:bg-[#23243a] sticky top-0 z-10 transition-colors">
          <div className="flex items-center gap-4">
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-white transition-colors p-1"><X size={28} /></button>
            <h2 className="text-xl font-bold text-gray-700 dark:text-white uppercase tracking-tight">Filtros</h2>
          </div>
          <button onClick={handleClear} className="text-[#2ebc7d] dark:text-[#c1ff72] font-bold text-sm hover:underline">Limpar</button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-8 space-y-10 pb-32 custom-scrollbar">
          
          <section>
            <h3 className="font-bold text-gray-600 dark:text-gray-500 mb-5 text-sm uppercase tracking-widest">Estoque</h3>
            <div className="space-y-4">
               {[
                 { id: 'out', label: 'Sem estoque', dot: 'bg-rose-500' },
                 { id: 'min', label: 'Mínimo', dot: 'bg-amber-500' },
                 { id: 'available', label: 'Acima do mínimo', dot: 'bg-emerald-500' },
                 { id: 'no_control', label: 'Sem controle', dot: 'bg-gray-300 dark:bg-gray-700' },
               ].map((item) => (
                 <label key={item.id} className="flex items-center gap-4 cursor-pointer group">
                    <div className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all ${stockStatus.includes(item.id) ? 'bg-[#2ebc7d] dark:bg-[#c1ff72] border-[#2ebc7d] dark:border-[#c1ff72] shadow-md' : 'border-gray-200 dark:border-white/10 group-hover:border-gray-300 dark:group-hover:border-white/20'}`}>
                        {stockStatus.includes(item.id) && <Check size={16} className="text-white dark:text-[#1a1b2e]" strokeWidth={4} />}
                    </div>
                    <input type="checkbox" className="hidden" checked={stockStatus.includes(item.id)} onChange={() => toggleStock(item.id)} />
                    <span className={`text-base font-medium flex items-center gap-2 transition-colors ${stockStatus.includes(item.id) ? 'text-[#2ebc7d] dark:text-[#c1ff72]' : 'text-gray-500 dark:text-gray-400'}`}>
                        {item.label}
                        <div className={`w-1.5 h-1.5 rounded-full ${item.dot}`}></div>
                    </span>
                 </label>
               ))}
            </div>
          </section>

          <section>
            <h3 className="font-bold text-gray-600 dark:text-gray-500 mb-5 text-sm uppercase tracking-widest">Tipo de Item</h3>
            <div className="grid grid-cols-2 gap-4">
              {['Produto', 'Serviço'].map((cat) => (
                <label key={cat} className={`flex items-center gap-4 cursor-pointer group p-3 border rounded-xl transition-all hover:bg-gray-50 dark:hover:bg-white/5 active:scale-95 ${selectedCategories.includes(cat) ? 'border-[#2ebc7d] dark:border-[#c1ff72] bg-emerald-50/30 dark:bg-emerald-500/5' : 'border-gray-100 dark:border-white/10'}`}>
                   <div className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all ${selectedCategories.includes(cat) ? 'bg-[#2ebc7d] dark:bg-[#c1ff72] border-[#2ebc7d] dark:border-[#c1ff72]' : 'border-gray-200 dark:border-white/10'}`}>
                        {selectedCategories.includes(cat) && <Check size={16} className="text-white dark:text-[#1a1b2e]" strokeWidth={4} />}
                    </div>
                    <input type="checkbox" className="hidden" checked={selectedCategories.includes(cat)} onChange={() => toggleCategory(cat)} />
                    <span className={`text-base font-bold transition-colors ${selectedCategories.includes(cat) ? 'text-[#2ebc7d] dark:text-[#c1ff72]' : 'text-gray-500 dark:text-gray-400'}`}>{cat}</span>
                </label>
              ))}
            </div>
          </section>

          <section>
            <h3 className="font-bold text-gray-600 dark:text-gray-500 mb-5 text-sm uppercase tracking-widest">Ordenar por</h3>
            <div className="grid grid-cols-1 border border-gray-100 dark:border-white/5 rounded-2xl overflow-hidden bg-white dark:bg-[#1a1b2e] shadow-sm transition-colors">
                {[
                    { id: 'name_asc', label: 'Nome: A - Z' },
                    { id: 'name_desc', label: 'Nome: Z - A' },
                    { id: 'stock_asc', label: 'Estoque: Menor primeiro' },
                    { id: 'stock_desc', label: 'Estoque: Maior primeiro' },
                ].map((opt) => (
                    <button
                        key={opt.id}
                        type="button"
                        onClick={() => setSortBy(opt.id as any)}
                        className={`py-4 px-5 text-sm font-bold border-b border-gray-50 dark:border-white/5 last:border-b-0 text-left transition-all flex items-center justify-between group ${sortBy === opt.id ? 'bg-emerald-50/50 dark:bg-[#c1ff72]/5 text-[#2ebc7d] dark:text-[#c1ff72]' : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-white/10'}`}
                    >
                        {opt.label}
                        {sortBy === opt.id && <Check size={18} className="text-[#2ebc7d] dark:text-[#c1ff72]" strokeWidth={3} />}
                    </button>
                ))}
            </div>
          </section>
        </div>

        <div className="p-6 bg-white dark:bg-[#23243a] border-t border-gray-100 dark:border-white/5 sticky bottom-0 left-0 right-0 z-20 transition-colors">
           <button 
             onClick={handleApply}
             className="w-full bg-[#2ebc7d] hover:bg-[#25a36b] text-white dark:text-[#1a1b2e] dark:bg-[#c1ff72] font-black py-4 rounded-2xl transition-all text-xs uppercase tracking-widest shadow-xl shadow-emerald-500/20 active:scale-[0.98]"
           >
             Aplicar Filtros
           </button>
        </div>
      </div>
    </>
  );
};

export default ProductFilterPanel;
