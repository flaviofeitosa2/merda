
import React, { useState, useMemo, useEffect } from 'react';
import { 
  DollarSign, 
  ShoppingBag, 
  TrendingUp, 
  TrendingDown, 
  Zap, 
  Wallet, 
  List,
  BarChart3,
  Calendar,
  Box, 
  CreditCard,
  QrCode,
  Banknote,
  ArrowUpRight,
  ChevronRight,
  Clock,
  User
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip 
} from 'recharts';
import { format, startOfDay, endOfDay, eachDayOfInterval, isSameDay, subDays, subMonths, subYears, startOfMonth, endOfMonth, startOfYear, endOfYear, isWeekend } from 'date-fns';
import { ptBR } from 'date-fns/locale/pt-BR';
import UserMenu from './UserMenu';
import { Sale, Product, Customer, UserProfile, FinanceTransaction } from '../types';
import { supabase } from '../supabaseClient';

interface DashboardScreenProps {
  sales: Sale[];
  products: Product[];
  customers: Customer[];
  toggleSidebar: () => void;
  userProfile: UserProfile;
  onNavigate: (view: string) => void;
  users?: UserProfile[];
  portalUserIds: Set<string>;
  permissions?: any;
}

const formatCurrency = (val: number) => {
  if (!isFinite(val) || isNaN(val)) return 'R$ 0,00';
  return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
};

const getSafeTimestamp = (dateStr: string, origin: string = 'pos') => {
    if (!dateStr) return 0;
    
    try {
        // Se a data já contém T ou Z, é um ISO string (UTC)
        if (dateStr.includes('T') || dateStr.includes('Z')) {
            const date = new Date(dateStr);
            if (!isNaN(date.getTime())) return date.getTime();
        }

        // Tenta parsear formatos comuns como YYYY-MM-DD HH:mm:ss
        // Se não tiver T/Z, o JS pode interpretar como local ou UTC dependendo do browser
        // Para garantir consistência, vamos forçar interpretação local se não houver indicação de fuso
        const datePart = dateStr.split(/[T ]/)[0];
        const timePart = dateStr.split(/[T ]/)[1] || '00:00:00';
        
        const [y, m, d] = datePart.split(/[-/]/).map(Number);
        const [hh, mm, ss] = timePart.split(':').map(Number);

        // Verifica se o ano está na posição correta (YYYY-MM-DD)
        if (y > 31) {
            const date = new Date(y, m - 1, d, hh || 0, mm || 0, ss || 0);
            if (!isNaN(date.getTime())) return date.getTime();
        } else if (d > 31) {
            // Formato DD-MM-YYYY
            const date = new Date(d, m - 1, y, hh || 0, mm || 0, ss || 0);
            if (!isNaN(date.getTime())) return date.getTime();
        }
        
        const fallbackDate = new Date(dateStr);
        return isNaN(fallbackDate.getTime()) ? 0 : fallbackDate.getTime();
    } catch (e) {
        console.error("Error parsing date:", dateStr, e);
        return 0;
    }
};

const KPICard = ({ title, value, subtext, trend, icon: Icon, color }: any) => (
  <div className="bg-white dark:bg-[#23243a] rounded-3xl p-5 sm:p-8 border border-slate-100 dark:border-white/5 shadow-sm transition-all hover:shadow-md">
    <div className="flex justify-between items-start mb-4 sm:mb-6">
        <div className={`p-2 sm:p-3 rounded-2xl ${color.bg} ${color.text} shadow-sm`}>
            <Icon size={20} className="sm:w-6 sm:h-6" />
        </div>
        <div className="flex items-center gap-1 text-[9px] sm:text-[10px] font-black text-emerald-500 bg-emerald-50 dark:bg-emerald-500/10 px-2 sm:px-3 py-1 rounded-full border border-emerald-100 dark:border-emerald-500/20 uppercase tracking-widest">
            <TrendingUp size={10} className="sm:w-3 sm:h-3" strokeWidth={3} /> {trend}%
        </div>
    </div>
    <div className="space-y-1">
        <p className="text-gray-400 dark:text-gray-500 text-[9px] sm:text-[10px] font-black uppercase tracking-[0.2em]">{title}</p>
        <h3 className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white tracking-tighter tabular-nums">{value}</h3>
        <p className="text-[9px] sm:text-[10px] text-gray-400 font-bold uppercase tracking-tight">{subtext}</p>
    </div>
  </div>
);

type RangeType = 'today' | 'yesterday' | 'month' | 'last_month' | 'year';

const DashboardScreen: React.FC<DashboardScreenProps> = ({ sales = [], products = [], customers = [], toggleSidebar, userProfile, onNavigate, users = [], portalUserIds, permissions }) => {
  const isOperator = userProfile.role === 'operator' || userProfile.role === 'operador';
  const isAdminOrMaster = userProfile.role === 'admin' || userProfile.role === 'master' || userProfile.role === 'owner' || userProfile.role === 'dono';
  const [mounted, setMounted] = useState(false);
  
  useEffect(() => {
    const timer = setTimeout(() => setMounted(true), 300);
    return () => clearTimeout(timer);
  }, []);

  // Se for operador, inicia no hoje, senão no mês
  const [timeRange, setTimeRange] = useState<RangeType>(isOperator ? 'today' : 'month');
  const [financeTransactions, setFinanceTransactions] = useState<FinanceTransaction[]>([]);
  const [selectedSellers, setSelectedSellers] = useState<string[]>(isOperator ? [userProfile.full_name] : []);
  const [isUserFilterOpen, setIsUserFilterOpen] = useState(false);

  useEffect(() => {
    const fetchFinance = async () => {
        if (!userProfile?.company_id) return;
        const { data } = await supabase.from('finance_transactions').select('*').eq('company_id', userProfile.company_id).or('status.eq.paid,status.is.null');
        if (data) setFinanceTransactions(data as any);
    };
    fetchFinance();
  }, [userProfile?.company_id, sales]);

  const ranges = useMemo(() => {
    const now = new Date();
    let start: Date;
    let end: Date;
    let prevStart: Date;
    let prevEnd: Date;

    // Proteção de segurança: Se operador tentar acessar ranges proibidos, força 'today'
    // REMOVIDO: Se o operador tem acesso ao Dashboard via permissões da empresa, ele deve ver o range selecionado.
    // A restrição deve ser feita no Sidebar/Navegação, não aqui se ele já conseguiu entrar.
    let effectiveRange = timeRange;

    switch (effectiveRange) {
        case 'today':
            start = startOfDay(now);
            end = endOfDay(now);
            prevStart = startOfDay(subDays(now, 1));
            prevEnd = endOfDay(subDays(now, 1));
            break;
        case 'yesterday':
            const yesterday = subDays(now, 1);
            start = startOfDay(yesterday);
            end = endOfDay(yesterday);
            prevStart = startOfDay(subDays(yesterday, 1));
            prevEnd = endOfDay(subDays(yesterday, 1));
            break;
        case 'last_month':
            const firstOfLastMonth = startOfMonth(subDays(startOfMonth(now), 1));
            start = firstOfLastMonth;
            end = endOfMonth(firstOfLastMonth);
            prevStart = startOfMonth(subMonths(start, 1));
            prevEnd = endOfMonth(subMonths(start, 1));
            break;
        case 'year':
            start = startOfYear(now);
            end = endOfYear(now);
            prevStart = startOfYear(subYears(now, 1));
            prevEnd = endOfYear(subYears(now, 1));
            break;
        default: // Este mês
            start = startOfMonth(now);
            end = endOfMonth(now);
            prevStart = startOfMonth(subMonths(start, 1));
            prevEnd = endOfMonth(subMonths(start, 1));
    }
    
    return {
        start: start.getTime(),
        end: end.getTime(),
        prevStart: prevStart.getTime(),
        prevEnd: prevEnd.getTime(),
        label: `${format(start, 'dd/MM/yyyy')} — ${format(end, 'dd/MM/yyyy')}`,
        interval: { start, end },
        prevInterval: { start: prevStart, end: prevEnd }
    };
  }, [timeRange, isOperator]);

  const chartData = useMemo(() => {
    const currentSales = sales.filter(s => {
        const sTime = getSafeTimestamp(s.date, 'pos');
        const matchesTime = s.status === 'completed' && sTime >= ranges.start && sTime <= ranges.end;
        const matchesUser = selectedSellers.length === 0 || selectedSellers.includes(s.sellerName);
        return matchesTime && matchesUser;
    });

    const previousSales = sales.filter(s => {
        const sTime = getSafeTimestamp(s.date, 'pos');
        const matchesTime = s.status === 'completed' && sTime >= ranges.prevStart && sTime <= ranges.prevEnd;
        const matchesUser = selectedSellers.length === 0 || selectedSellers.includes(s.sellerName);
        return matchesTime && matchesUser;
    });

    if (timeRange === 'today' || timeRange === 'yesterday') {
        // Agrupar por hora
        const hours = Array.from({ length: 24 }, (_, i) => ({
            name: `${i}h`,
            total: 0,
            previousTotal: 0
        }));
        currentSales.forEach(s => {
            const hour = new Date(getSafeTimestamp(s.date, 'pos')).getHours();
            hours[hour].total += Number(s.total) || 0;
        });
        previousSales.forEach(s => {
            const hour = new Date(getSafeTimestamp(s.date, 'pos')).getHours();
            hours[hour].previousTotal += Number(s.total) || 0;
        });
        return hours;
    }

    // Agrupar por dia útil (Business Day Index)
    const currentBusinessDays = eachDayOfInterval(ranges.interval).filter(day => !isWeekend(day));
    const previousBusinessDays = eachDayOfInterval(ranges.prevInterval).filter(day => !isWeekend(day));

    const maxDays = Math.max(currentBusinessDays.length, previousBusinessDays.length);
    
    return Array.from({ length: maxDays }, (_, i) => {
        const currentDay = currentBusinessDays[i];
        const previousDay = previousBusinessDays[i];
        
        const currentTotal = currentDay ? currentSales
            .filter(s => isSameDay(new Date(getSafeTimestamp(s.date, 'pos')), currentDay))
            .reduce((acc, s) => acc + (Number(s.total) || 0), 0) : 0;

        const previousTotal = previousDay ? previousSales
            .filter(s => isSameDay(new Date(getSafeTimestamp(s.date, 'pos')), previousDay))
            .reduce((acc, s) => acc + (Number(s.total) || 0), 0) : 0;

        return {
            name: `${i + 1}º DU`,
            total: currentTotal,
            previousTotal: previousTotal,
            currentDate: currentDay ? format(currentDay, 'dd/MM') : '',
            previousDate: previousDay ? format(previousDay, 'dd/MM') : ''
        };
    });
  }, [sales, ranges, timeRange, selectedSellers]);

  const metrics = useMemo(() => {
      const filteredSales = sales.filter(s => {
          const sTime = getSafeTimestamp(s.date, 'pos');
          const matchesTime = s.status === 'completed' && sTime >= ranges.start && sTime <= ranges.end;
          const matchesUser = selectedSellers.length === 0 || selectedSellers.includes(s.sellerName);
          return matchesTime && matchesUser;
      });

      const ignoredSales = sales.filter(s => {
          const sTime = getSafeTimestamp(s.date, 'pos');
          const matchesTime = sTime >= ranges.start && sTime <= ranges.end;
          const matchesUser = selectedSellers.length === 0 || selectedSellers.includes(s.sellerName);
          return matchesTime && matchesUser && s.status !== 'completed';
      });
      
      const posRevenue = filteredSales.reduce((acc, s) => acc + (Number(s.total) || 0), 0);
      const ignoredRevenue = ignoredSales.reduce((acc, s) => acc + (Number(s.total) || 0), 0);
      
      const manualRevenue = financeTransactions
          .filter(t => {
              const tTime = getSafeTimestamp(t.date, t.origin || 'manual');
              return t.type === 'income' && t.origin !== 'pos' && tTime >= ranges.start && tTime <= ranges.end;
          })
          .reduce((acc, t) => acc + Number(t.amount), 0);

      const totalRevenue = posRevenue + manualRevenue;
      const salesCount = filteredSales.length;
      const totalItems = filteredSales.reduce((acc, s) => acc + (s.items?.reduce((sum, i) => sum + i.quantity, 0) || 0), 0);
      const avgTicket = salesCount > 0 ? posRevenue / salesCount : 0;

      const liquidity: Record<string, number> = { pix: 0, debit: 0, money: 0, credit: 0 };
      filteredSales.forEach(s => {
          if (Array.isArray(s.payments)) {
              s.payments.forEach(p => {
                  const method = (p.method === 'others' || p.method === 'link' || p.method === 'credit_tab') ? 'credit' : p.method;
                  if (liquidity[method] !== undefined) liquidity[method] += Number(p.amount);
              });
          } else {
              const method = (s.paymentMethod === 'others' || s.paymentMethod === 'link' || s.paymentMethod === 'credit_tab') ? 'credit' : s.paymentMethod;
              if (liquidity[method] !== undefined) liquidity[method] += Number(s.total);
          }
      });

      const productMap = new Map<string, { name: string; qty: number; total: number; image?: string }>();
      filteredSales.forEach(s => {
          s.items?.forEach(item => {
              const curr = productMap.get(item.id) || { name: item.name, qty: 0, total: 0, image: item.image };
              curr.qty += item.quantity;
              curr.total += item.price * item.quantity;
              productMap.set(item.id, curr);
          });
      });
      const topProducts = Array.from(productMap.values()).sort((a, b) => b.total - a.total).slice(0, 5);

      return { totalRevenue, salesCount, totalItems, avgTicket, liquidity, topProducts, ignoredRevenue };
  }, [sales, financeTransactions, ranges, selectedSellers]);

  const recentSales = useMemo(() => {
    return sales
        .filter(s => {
            const sTime = getSafeTimestamp(s.date, 'pos');
            const matchesTime = s.status === 'completed' && sTime >= ranges.start && sTime <= ranges.end;
            const matchesUser = selectedSellers.length === 0 || selectedSellers.includes(s.sellerName);
            return matchesTime && matchesUser;
        })
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, 10);
  }, [sales, ranges, selectedSellers]);

  const filterOptions = useMemo(() => {
    const all = [
      { id: 'today', label: 'HOJE' },
      { id: 'yesterday', label: 'ONTEM' },
      { id: 'month', label: 'ESTE MÊS' },
      { id: 'last_month', label: 'MÊS PASSADO' },
      { id: 'year', label: 'ESTE ANO' }
    ];
    
    // Se for operador, verifica se tem permissão para ver dashboard completo
    // Se não tiver a permissão explícita de dashboard no objeto de permissões, restringe
    if (isOperator && permissions?.dashboard === false) return all.slice(0, 2);
    
    return all;
  }, [isOperator, permissions]);

  return (
    <div className="flex-1 flex flex-col h-full bg-[#f8fafc] dark:bg-[#1a1b2e] transition-colors overflow-hidden font-sans">
      <header className="bg-white dark:bg-[#23243a] h-[90px] px-4 lg:px-10 flex justify-between items-center shrink-0 border-b border-gray-100 dark:border-white/5 sticky top-0 z-50 transition-colors">
          <div className="flex items-center gap-4">
              <button onClick={toggleSidebar} className="lg:hidden p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-xl transition-colors">
                  <List size={26} />
              </button>
              <div>
                  <h1 className="text-[23px] font-mono font-black text-gray-900 dark:text-white tracking-tighter uppercase leading-none italic">Dashboard</h1>
                  <p className="text-[10px] text-gray-400 font-black uppercase tracking-[0.3em] mt-1 hidden sm:block">Consolidado em tempo real</p>
              </div>
          </div>
          <UserMenu />
      </header>

      <div className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-10 pb-20 custom-scrollbar">
          <div className="max-w-[1800px] mx-auto space-y-6 sm:space-y-10">
              
              <div className="flex flex-col xl:flex-row justify-between items-center gap-4 sm:gap-6 mt-4">
                  <div className="flex flex-col md:flex-row items-center gap-4 w-full xl:w-auto">
                      <div className="flex bg-white dark:bg-[#23243a] p-1 sm:p-1.5 rounded-full border border-slate-100 dark:border-white/5 shadow-sm overflow-x-auto no-scrollbar w-full xl:w-auto">
                          {filterOptions.map(t => (
                              <button 
                                key={t.id} 
                                onClick={() => setTimeRange(t.id as any)} 
                                className={`px-4 sm:px-8 py-2.5 sm:py-3 rounded-full text-[9px] sm:text-[10px] font-black tracking-[0.15em] sm:tracking-[0.2em] transition-all whitespace-nowrap ${timeRange === t.id ? 'bg-[#ceffab] text-slate-900 shadow-lg sm:shadow-xl scale-105' : 'text-gray-400 hover:text-gray-600 dark:hover:text-white'}`}
                              >
                                  {t.label}
                              </button>
                          ))}
                      </div>

                      {isAdminOrMaster && (
                          <div className="relative w-full md:w-auto">
                              <button 
                                onClick={() => setIsUserFilterOpen(!isUserFilterOpen)}
                                className={`flex items-center justify-center md:justify-start gap-3 w-full md:w-auto px-6 py-3.5 rounded-full border shadow-sm transition-all text-[9px] sm:text-[10px] font-black uppercase tracking-widest ${selectedSellers.length > 0 ? 'bg-indigo-500 text-white border-indigo-400' : 'bg-white dark:bg-[#23243a] text-gray-500 dark:text-gray-400 border-slate-100 dark:border-white/5'}`}
                              >
                                  <User size={16} />
                                  {selectedSellers.length === 0 ? 'TODOS OS VENDEDORES' : `${selectedSellers.length} VENDEDOR(ES)`}
                              </button>

                              {isUserFilterOpen && (
                                  <div className="absolute top-full left-0 mt-2 w-64 bg-white dark:bg-[#23243a] rounded-2xl shadow-2xl border border-slate-100 dark:border-white/5 z-50 p-4 max-h-80 overflow-y-auto custom-scrollbar">
                                      <div className="space-y-2">
                                          <button 
                                            onClick={() => setSelectedSellers([])}
                                            className={`w-full text-left px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-colors ${selectedSellers.length === 0 ? 'bg-[#ceffab] text-slate-900' : 'text-gray-500 hover:bg-gray-50 dark:hover:bg-white/5'}`}
                                          >
                                              TODOS
                                          </button>
                                          {users.map(u => (
                                              <button 
                                                key={u.id}
                                                onClick={() => {
                                                    if (selectedSellers.includes(u.full_name)) {
                                                        setSelectedSellers(prev => prev.filter(name => name !== u.full_name));
                                                    } else {
                                                        setSelectedSellers(prev => [...prev, u.full_name]);
                                                    }
                                                }}
                                                className={`w-full text-left px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-colors ${selectedSellers.includes(u.full_name) ? 'bg-indigo-500 text-white' : 'text-gray-500 hover:bg-gray-50 dark:hover:bg-white/5'}`}
                                              >
                                                  {u.full_name}
                                              </button>
                                          ))}
                                      </div>
                                  </div>
                              )}
                          </div>
                      )}
                  </div>

                  <div className="bg-white dark:bg-[#23243a] px-8 py-3.5 rounded-full border border-slate-100 dark:border-white/5 shadow-sm flex items-center gap-4 transition-colors">
                      <Calendar size={18} className="text-[#ceffab]" />
                      <span className="text-[11px] font-black text-gray-500 dark:text-gray-400 uppercase tracking-widest tabular-nums">{ranges.label}</span>
                  </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-8">
                  <KPICard 
                    title="Faturamento Bruto" 
                    value={formatCurrency(metrics.totalRevenue)} 
                    subtext={metrics.ignoredRevenue > 0 ? `PDV + Tesouraria (Exclui ${formatCurrency(metrics.ignoredRevenue)} não concluídos)` : "PDV + Tesouraria"} 
                    trend={23} 
                    icon={DollarSign} 
                    color={{ bg: 'bg-emerald-50 dark:bg-emerald-500/10', text: 'text-emerald-500' }} 
                  />
                  <KPICard title="Fluxo de Vendas" value={metrics.salesCount} subtext={`${metrics.salesCount} Clientes Atendidos`} trend={1} icon={ShoppingBag} color={{ bg: 'bg-blue-50 dark:bg-blue-500/10', text: 'text-blue-500' }} />
                  <KPICard title="Volume de Itens" value={metrics.totalItems} subtext="Unidades vendidas" trend={22} icon={Box} color={{ bg: 'bg-emerald-50 dark:bg-emerald-500/10', text: 'text-emerald-500' }} />
                  <KPICard title="Ticket Médio" value={formatCurrency(metrics.avgTicket)} subtext="Média por pedido" trend={24} icon={Wallet} color={{ bg: 'bg-orange-50 dark:bg-orange-500/10', text: 'text-orange-500' }} />
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8">
                  <div className="lg:col-span-8 bg-white dark:bg-[#23243a] rounded-[2rem] sm:rounded-[3rem] border border-slate-100 dark:border-white/5 p-6 sm:p-10 shadow-sm transition-all relative group">
                      <div className="flex flex-col sm:flex-row justify-between items-start gap-4 mb-8 sm:mb-12">
                          <div>
                              <h3 className="text-xl sm:text-2xl font-black text-gray-800 dark:text-white uppercase tracking-tighter italic">Curva de Faturamento</h3>
                              <p className="text-[9px] sm:text-[10px] text-emerald-500 font-black uppercase tracking-[0.2em] mt-2">+ Auditoria por dia civil</p>
                          </div>
                          <div className="flex gap-4 sm:gap-6">
                              <div className="flex items-center gap-2"><div className="w-2.5 h-2.5 rounded-full bg-[#ceffab] shadow-[0_0_10px_rgba(206,255,171,0.5)]"></div><span className="text-[8px] sm:text-[9px] font-black text-gray-400 uppercase tracking-widest">Período Atual</span></div>
                              <div className="flex items-center gap-2"><div className="w-2.5 h-2.5 rounded-full bg-slate-400 shadow-[0_0_10px_rgba(148,163,184,0.3)]"></div><span className="text-[8px] sm:text-[9px] font-black text-gray-400 uppercase tracking-widest">Anterior</span></div>
                          </div>
                      </div>
                      <div className="h-60 sm:h-72 w-full relative">
                          {mounted && (
                            <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0} debounce={50}>
                                <AreaChart data={chartData}>
                                    <defs>
                                        <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#ceffab" stopOpacity={0.3}/>
                                            <stop offset="95%" stopColor="#ceffab" stopOpacity={0}/>
                                        </linearGradient>
                                        <linearGradient id="colorPrevTotal" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#94a3b8" stopOpacity={0.1}/>
                                            <stop offset="95%" stopColor="#94a3b8" stopOpacity={0}/>
                                        </linearGradient>
                                    </defs>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" opacity={0.5} />
                                    <XAxis 
                                      dataKey="name" 
                                      axisLine={false} 
                                      tickLine={false} 
                                      tick={{ fontSize: 10, fill: '#94a3b8', fontWeight: 600 }}
                                      dy={10}
                                    />
                                    <YAxis 
                                      hide 
                                    />
                                    <Tooltip 
                                      content={({ active, payload, label }) => {
                                          if (active && payload && payload.length) {
                                              const data = payload[0].payload;
                                              return (
                                                  <div className="bg-slate-900/95 backdrop-blur-md p-4 rounded-2xl border border-white/10 shadow-2xl">
                                                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">{label}</p>
                                                      <div className="space-y-2">
                                                          <div className="flex items-center justify-between gap-8">
                                                              <div className="flex items-center gap-2">
                                                                  <div className="w-2 h-2 rounded-full bg-[#ceffab]"></div>
                                                                  <span className="text-[10px] font-bold text-white uppercase tracking-wider">Atual {data.currentDate ? `(${data.currentDate})` : ''}</span>
                                                              </div>
                                                              <span className="text-xs font-black text-[#ceffab] tabular-nums">{formatCurrency(data.total)}</span>
                                                          </div>
                                                          <div className="flex items-center justify-between gap-8">
                                                              <div className="flex items-center gap-2">
                                                                  <div className="w-2 h-2 rounded-full bg-slate-500"></div>
                                                                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Anterior {data.previousDate ? `(${data.previousDate})` : ''}</span>
                                                              </div>
                                                              <span className="text-xs font-black text-slate-400 tabular-nums">{formatCurrency(data.previousTotal)}</span>
                                                          </div>
                                                      </div>
                                                  </div>
                                              );
                                          }
                                          return null;
                                      }}
                                    />
                                    <Area 
                                      type="monotone" 
                                      dataKey="previousTotal" 
                                      stroke="#94a3b8" 
                                      strokeWidth={2}
                                      strokeDasharray="5 5"
                                      fillOpacity={1} 
                                      fill="url(#colorPrevTotal)" 
                                      animationDuration={1500}
                                    />
                                    <Area 
                                      type="monotone" 
                                      dataKey="total" 
                                      stroke="#ceffab" 
                                      strokeWidth={4}
                                      fillOpacity={1} 
                                      fill="url(#colorTotal)" 
                                      animationDuration={1500}
                                    />
                                </AreaChart>
                            </ResponsiveContainer>
                          )}
                      </div>
                  </div>

                  <div className="lg:col-span-4 bg-white dark:bg-[#23243a] rounded-[2rem] sm:rounded-[3rem] border border-slate-100 dark:border-white/5 p-6 sm:p-10 shadow-sm transition-all">
                      <div className="flex items-center gap-3 mb-8 sm:mb-10">
                          <div className="p-2 bg-indigo-50 dark:bg-indigo-500/10 rounded-xl text-indigo-600">
                             <BarChart3 size={20} className="sm:w-6 sm:h-6" strokeWidth={3} />
                          </div>
                          <h3 className="text-lg sm:text-xl font-black text-gray-800 dark:text-white uppercase tracking-[0.2em] italic">Liquidez</h3>
                      </div>
                      <div className="space-y-6 sm:space-y-8">
                          {[
                              { label: 'PIX', key: 'pix', icon: QrCode, color: 'bg-[#ceffab]' },
                              { label: 'DÉBITO', key: 'debit', icon: CreditCard, color: 'bg-blue-500' },
                              { label: 'DINHEIRO', key: 'money', icon: Banknote, color: 'bg-emerald-500' },
                              { label: 'CRÉDITO', key: 'credit', icon: CreditCard, color: 'bg-slate-300' }
                          ].map(method => {
                              const amount = metrics.liquidity[method.key] || 0;
                              const share = metrics.totalRevenue > 0 ? (amount / metrics.totalRevenue) * 100 : 0;
                              return (
                                  <div key={method.key} className="space-y-2 sm:space-y-3">
                                      <div className="flex justify-between items-end">
                                          <div className="flex items-center gap-2 sm:gap-3">
                                              <method.icon size={16} className="sm:w-[18px] sm:h-[18px] text-gray-300" />
                                              <span className="text-[10px] sm:text-[11px] font-black text-gray-500 dark:text-gray-400 uppercase tracking-widest">{method.label}</span>
                                          </div>
                                          <span className="text-xs sm:text-sm font-black text-gray-800 dark:text-white tabular-nums tracking-tighter">{formatCurrency(amount)}</span>
                                      </div>
                                      <div className="h-1.5 w-full bg-slate-50 dark:bg-white/5 rounded-full overflow-hidden shadow-inner">
                                          <div className={`h-full ${method.color} transition-all duration-1000 ease-out shadow-sm`} style={{ width: `${share}%` }}></div>
                                      </div>
                                      <p className="text-[8px] sm:text-[9px] font-black text-gray-400 text-right uppercase tracking-widest opacity-80">{share.toFixed(1)}% Participação</p>
                                  </div>
                              );
                          })}
                      </div>
                  </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 mb-6 sm:mb-12">
                  <div className="lg:col-span-8 bg-white dark:bg-[#23243a] rounded-[2rem] sm:rounded-[3rem] border border-slate-100 dark:border-white/5 p-6 sm:p-10 shadow-sm transition-all">
                      <div className="flex justify-between items-center mb-8 sm:mb-10">
                          <h3 className="text-lg sm:text-xl font-black text-gray-800 dark:text-white uppercase tracking-[0.2em] italic">Best Sellers</h3>
                          <span className="text-[9px] sm:text-[10px] font-black text-gray-400 bg-slate-50 dark:bg-white/5 px-3 sm:px-4 py-1 sm:py-1.5 rounded-full border dark:border-white/5 uppercase tracking-widest">Ranking Top 5</span>
                      </div>
                      <div className="space-y-6 sm:space-y-8">
                          {metrics.topProducts.map((p, idx) => (
                              <div key={idx} className="flex items-center justify-between group cursor-default">
                                  <div className="flex items-center gap-4 sm:gap-6">
                                      <div className="w-12 h-12 sm:w-16 sm:h-16 bg-slate-50 dark:bg-white/5 rounded-xl sm:rounded-2xl flex items-center justify-center p-2 sm:p-3 border dark:border-white/5 transition-transform group-hover:scale-105">
                                          <img src={p.image || 'https://cdn-icons-png.flaticon.com/512/1256/1256650.png'} className="max-w-full max-h-full object-contain" referrerPolicy="no-referrer" />
                                      </div>
                                      <div>
                                          <h4 className="text-xs sm:text-sm font-black text-gray-800 dark:text-white uppercase tracking-tighter leading-none mb-1 sm:mb-2">{p.name}</h4>
                                          <p className="text-[9px] sm:text-[10px] text-gray-400 font-bold uppercase tracking-tight">
                                              {p.qty} unid. <span className="mx-1 sm:mx-2 text-slate-200 dark:text-white/10">|</span> <span className="text-emerald-500 font-black">{((p.total / (metrics.totalRevenue || 1)) * 100).toFixed(1)}%</span>
                                          </p>
                                      </div>
                                  </div>
                                  <div className="text-right">
                                      <p className="text-lg sm:text-xl font-black text-gray-900 dark:text-white tracking-tighter tabular-nums">{formatCurrency(p.total)}</p>
                                      <p className="text-[8px] sm:text-[9px] font-black text-gray-400 uppercase tracking-widest mt-1">Volume Bruto</p>
                                  </div>
                              </div>
                          ))}
                          {metrics.topProducts.length === 0 && (
                              <div className="text-center py-12 sm:py-20 bg-slate-50/50 dark:bg-white/5 rounded-3xl border border-dashed dark:border-white/10 transition-colors">
                                  <p className="text-[10px] sm:text-[11px] font-black text-gray-400 uppercase tracking-[0.3em] italic">Nenhum dado de venda para o período</p>
                              </div>
                          )}
                      </div>
                  </div>

                  <div className="lg:col-span-4 bg-[#ceffab] rounded-[2rem] sm:rounded-[3rem] p-8 sm:p-12 flex flex-col justify-between shadow-[0_25px_60px_-15px_rgba(206,255,171,0.4)] relative overflow-hidden group transition-all">
                      <div className="relative z-10 space-y-6 sm:space-y-10">
                          <div className="inline-flex items-center gap-3 bg-slate-900/10 px-4 sm:px-5 py-2 rounded-full text-[9px] sm:text-[10px] font-black text-slate-900 uppercase tracking-widest">
                              <Zap size={12} className="sm:w-[14px] sm:h-[14px]" fill="currentColor" strokeWidth={0} /> Insight Pro
                          </div>
                          <div>
                              <h3 className="text-3xl sm:text-5xl font-black text-slate-900 tracking-tighter leading-[0.9] uppercase italic mb-6 sm:mb-8">Estratégia & Dados</h3>
                              <p className="text-slate-900/80 text-sm sm:text-base font-bold leading-relaxed tracking-tight">
                                  Sua performance geral está sendo monitorada. O ticket médio consolidado de <span className="underline decoration-2">{formatCurrency(metrics.avgTicket)}</span> indica a saúde financeira atual do seu negócio.
                              </p>
                          </div>
                      </div>
                      <button className="w-full bg-slate-900 text-white py-4 sm:py-6 rounded-2xl sm:rounded-[1.8rem] font-black text-[10px] sm:text-xs uppercase tracking-[0.2em] sm:tracking-[0.3em] flex items-center justify-between px-6 sm:px-10 group-hover:bg-slate-800 transition-all active:scale-95 shadow-2xl relative z-10 mt-8">
                          <span>Relatório Global</span>
                          <ChevronRight size={20} className="sm:w-6 sm:h-6" strokeWidth={3} />
                      </button>
                      
                      <div className="absolute top-0 right-0 w-48 h-48 sm:w-64 sm:h-64 bg-white/30 rounded-full blur-[60px] sm:blur-[80px] -translate-y-1/2 translate-x-1/2"></div>
                      <div className="absolute bottom-0 left-0 w-24 h-24 sm:w-32 sm:h-32 bg-slate-900/5 rounded-full blur-[30px] sm:blur-[40px] translate-y-1/2 -translate-x-1/2"></div>
                  </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 mb-12">
                  <div className="col-span-1 lg:col-span-12 bg-white dark:bg-[#23243a] rounded-[2rem] sm:rounded-[3rem] border border-slate-100 dark:border-white/5 p-6 sm:p-10 shadow-sm transition-all">
                      <div className="flex justify-between items-center mb-6 sm:mb-8">
                          <h3 className="text-lg sm:text-xl font-black text-gray-800 dark:text-white uppercase tracking-[0.2em] italic">Vendas Recentes</h3>
                          <button onClick={() => onNavigate('history')} className="text-[9px] sm:text-[10px] font-black text-indigo-500 hover:text-indigo-600 uppercase tracking-widest flex items-center gap-1">
                              Ver Histórico <ChevronRight size={12} className="sm:w-[14px] sm:h-[14px]" />
                          </button>
                      </div>
                      <div className="overflow-x-auto no-scrollbar -mx-6 px-6">
                          <table className="w-full text-left min-w-[600px] sm:min-w-0">
                              <thead>
                                  <tr className="text-[9px] sm:text-[10px] font-black text-gray-400 uppercase tracking-widest border-b border-slate-100 dark:border-white/5">
                                      <th className="pb-4 pl-2 sm:pl-4">Hora</th>
                                      <th className="pb-4">Cliente</th>
                                      <th className="pb-4 hidden md:table-cell">Vendedor</th>
                                      <th className="pb-4">Pagamento</th>
                                      <th className="pb-4 text-right pr-2 sm:pr-4">Valor</th>
                                  </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-50 dark:divide-white/5">
                                  {recentSales.map(sale => (
                                      <tr key={sale.id} className="group hover:bg-slate-50 dark:hover:bg-white/5 transition-colors">
                                          <td className="py-4 pl-2 sm:pl-4">
                                              <div className="flex items-center gap-1.5 sm:gap-2 text-[10px] sm:text-xs font-bold text-slate-500 dark:text-slate-400">
                                                  <Clock size={12} className="sm:w-[14px] sm:h-[14px] text-slate-300" />
                                                  {new Date(sale.date).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                                              </div>
                                          </td>
                                          <td className="py-4">
                                              <div className="flex items-center gap-2">
                                                <span className="text-[10px] sm:text-xs font-bold text-slate-700 dark:text-slate-300 uppercase truncate max-w-[100px] sm:max-w-none">{sale.clientName}</span>
                                                {portalUserIds.has(sale.customerId) && (
                                                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_6px_rgba(16,185,129,0.6)] shrink-0" title="Cadastro Habilitado no Portal" />
                                                )}
                                              </div>
                                          </td>
                                          <td className="py-4 hidden md:table-cell">
                                              <span className="text-[9px] sm:text-[10px] font-bold text-slate-400 uppercase">{sale.sellerName}</span>
                                          </td>
                                          <td className="py-4">
                                              <span className="text-[8px] sm:text-[10px] font-black uppercase tracking-wider px-1.5 sm:px-2 py-0.5 sm:py-1 rounded-md bg-slate-100 dark:bg-white/10 text-slate-500 dark:text-slate-400">
                                                  {sale.paymentMethod === 'credit_tab' ? 'FIADO' : sale.paymentMethod}
                                              </span>
                                          </td>
                                          <td className="py-4 text-right pr-2 sm:pr-4">
                                              <span className="text-xs sm:text-sm font-black text-slate-900 dark:text-white tabular-nums">{formatCurrency(sale.total)}</span>
                                          </td>
                                      </tr>
                                  ))}
                                  {recentSales.length === 0 && (
                                      <tr>
                                          <td colSpan={5} className="py-8 text-center text-[11px] font-black text-gray-400 uppercase tracking-widest italic">
                                              Nenhuma venda registrada neste período
                                          </td>
                                      </tr>
                                  )}
                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>

          </div>
      </div>
    </div>
  );
};

export default DashboardScreen;
