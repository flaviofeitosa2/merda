
import React, { useState, useEffect, useMemo } from 'react';
import { 
  LayoutGrid, 
  CreditCard, 
  LogOut, 
  Calendar, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  QrCode, 
  Copy, 
  Check, 
  MessageSquare,
  MessageCircle,
  FileText,
  Lock,
  Download,
  ShieldCheck,
  Loader2,
  X,
  Key,
  Eye,
  EyeOff,
  Wallet,
  ArrowUpRight,
  Shield,
  FileCode,
  AlertTriangle,
  Building2,
  Globe,
  Briefcase,
  ExternalLink,
  Send,
  Sun,
  Moon,
  Smartphone,
  Landmark,
  FileSearch,
  Bell,
  Users,
  TrendingUp,
  ChevronRight,
  Mail,
  FileX
} from 'lucide-react';
import { supabase } from '../supabaseClient';
import { UserProfile, Subscription, Sale, Customer, Company } from '../types';
import SaleDetailPanel from './SaleDetailPanel';
import Toast from './Toast';

const formatCurrency = (val: number) => val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const safeParse = (str: string | null, fallback: any) => {
  if (!str) return fallback;
  try {
    return JSON.parse(str);
  } catch (e) {
    console.error("Error parsing JSON:", e);
    return fallback;
  }
};

const getSafeTimestamp = (dateStr: any, origin: string = 'pos') => {
    if (!dateStr || typeof dateStr !== 'string') return 0;
    try {
        if (origin === 'pos' || dateStr.includes('T') || dateStr.includes('Z')) {
            const t = new Date(dateStr).getTime();
            return isNaN(t) ? 0 : t;
        }
        const datePart = dateStr.split(/[T ]/)[0];
        if (!datePart) return 0;
        const parts = datePart.split('-');
        if (parts.length < 3) return 0;
        const [y, m, d] = parts.map(Number);
        const t = new Date(y, m - 1, d, 12, 0, 0).getTime();
        return isNaN(t) ? 0 : t;
    } catch (e) {
        return 0;
    }
};

interface SubscriberPortalProps {
  userProfile: UserProfile;
}

const SubscriberPortal: React.FC<SubscriberPortalProps> = ({ userProfile }) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'billing' | 'support'>('dashboard');
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [invoices, setInvoices] = useState<Sale[]>([]);
  const [customerData, setCustomerData] = useState<Customer | null>(null);
  const [companyData, setCompanyData] = useState<Company | null>(null);
  const [loading, setLoading] = useState(true);
  const [theme, setTheme] = useState<'light' | 'dark'>(() => (localStorage.getItem('theme') as any) || 'dark');
  
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);

  const [isPixModalOpen, setIsPixModalOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<Sale | null>(null);
  const [viewingReceipt, setViewingReceipt] = useState<Sale | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (theme === 'dark') document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
    localStorage.setItem('theme', theme);
  }, [theme]);

  useEffect(() => {
    const loadPortalData = async () => {
      if (!userProfile.customer_id) {
          setLoading(false);
          return;
      }
      setLoading(true);
      try {
          // As queries abaixo agora são protegidas por RLS no banco de dados
          const [subRes, invRes, custRes, compRes] = await Promise.all([
            supabase.from('subscriptions').select('*').eq('customer_id', userProfile.customer_id).eq('status', 'active'),
            supabase.from('sales').select('*').eq('customer_id', userProfile.customer_id).order('date', { ascending: false }),
            supabase.from('customers').select('*').eq('id', userProfile.customer_id).single(),
            supabase.from('companies').select('name, logo_url, whatsapp, support_email').eq('id', userProfile.company_id).single()
          ]);

          if (subRes.data) setSubscriptions(subRes.data);
          if (invRes.data) {
              const parsedSales = invRes.data.map((s: any) => ({
                  ...s,
                  items: typeof s.items === 'string' ? safeParse(s.items, []) : (s.items || []),
                  payments: typeof s.payments === 'string' ? safeParse(s.payments, []) : (s.payments || [])
              }));
              setInvoices(parsedSales);
          }
          if (custRes.data) setCustomerData(custRes.data as Customer);
          if (compRes.data) setCompanyData(compRes.data as Company);
      } catch (err) {
          console.error("Erro Portal:", err);
      } finally {
          setLoading(false);
      }
    };
    loadPortalData();
  }, [userProfile.customer_id, userProfile.company_id]);

  const handleUpdatePassword = async () => {
    if (newPassword.length < 6) return alert("A senha deve ter pelo menos 6 caracteres.");
    if (newPassword !== confirmPassword) return alert("As senhas não coincidem.");
    setIsUpdating(true);
    try {
        const { error } = await supabase.auth.updateUser({ password: newPassword });
        if (error) throw error;
        alert("Senha atualizada com sucesso!");
        setIsPasswordModalOpen(false);
        setNewPassword('');
        setConfirmPassword('');
    } catch (err: any) {
        alert("Erro: " + err.message);
    } finally {
        setIsUpdating(false);
    }
  };

  const handleDownloadCert = async () => {
    if (!customerData?.digital_certificate_url) return;
    try {
        const { data, error } = await supabase.storage.from('certificates').download(customerData.digital_certificate_url);
        if (error) throw error;
        const url = URL.createObjectURL(data);
        const a = document.createElement('a');
        a.href = url;
        a.download = customerData.digital_certificate_url.split('/').pop() || 'certificado.pfx';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    } catch (err) { alert("Erro ao baixar arquivo. O arquivo pode ter sido removido ou você não tem permissão."); }
  };

  const nextInvoice = useMemo(() => {
    const pending = [...subscriptions]
      .filter(s => !s.payment_date)
      .sort((a, b) => getSafeTimestamp(a.end_date) - getSafeTimestamp(b.end_date));
    return pending[0] || null;
  }, [subscriptions]);

  const govLinks = [
    { label: 'E-CAC', icon: Shield, url: 'https://cav.receita.fazenda.gov.br/' },
    { label: 'PORTAL GOV.BR', icon: Globe, url: 'https://www.gov.br/' },
    { label: 'ESOCIAL', icon: Briefcase, url: 'https://login.esocial.gov.br/' },
    { label: 'CONECTIVIDADE', icon: Building2, url: 'https://conectividadesocialv2.caixa.gov.br/' },
    { label: 'EMPREGADOR WEB', icon: Users, url: 'https://sd.mte.gov.br/' },
    { label: 'VALIDADOR ITI', icon: FileSearch, url: 'https://verificador.iti.br/' },
  ];

  const totalPaid = useMemo(() => {
      return invoices.filter(i => i.status === 'completed' || !i.status).reduce((acc, curr) => acc + curr.total, 0);
  }, [invoices]);

  const hasCertificate = !!customerData?.digital_certificate_url;

  if (loading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-[#1c1d31]">
        <Loader2 className="w-10 h-10 text-indigo-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-[#f8fafc] dark:bg-[#1a1b2e] font-sans transition-colors overflow-hidden">
      
      {/* SIDEBAR DESKTOP (Fixa à esquerda) */}
      <aside className="hidden lg:flex flex-col w-72 bg-[#1c1d31] dark:bg-[#23243a] text-white border-r border-white/5 transition-all">
          <div className="p-8 border-b border-white/5 flex items-center gap-4">
              <div className="bg-indigo-600 p-2.5 rounded-2xl text-white shadow-lg shadow-indigo-500/20">
                  <ShieldCheck size={28} strokeWidth={2.5} />
              </div>
              <h1 className="text-sm font-black uppercase tracking-tighter italic">SuaMeta<br/>Portal</h1>
          </div>
          
          <nav className="flex-1 p-6 space-y-2">
              <button 
                  onClick={() => setActiveTab('dashboard')}
                  className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl font-bold transition-all ${activeTab === 'dashboard' ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-500/20' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
              >
                  <LayoutGrid size={20} strokeWidth={activeTab === 'dashboard' ? 3 : 2} /> Dashboard
              </button>
              <button 
                  onClick={() => setActiveTab('billing')}
                  className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl font-bold transition-all ${activeTab === 'billing' ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-500/20' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
              >
                  <CreditCard size={20} strokeWidth={activeTab === 'billing' ? 3 : 2} /> Financeiro
              </button>
              <button 
                  onClick={() => setActiveTab('support')}
                  className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl font-bold transition-all ${activeTab === 'support' ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-500/20' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
              >
                  <MessageSquare size={20} strokeWidth={activeTab === 'support' ? 3 : 2} /> Suporte
              </button>
          </nav>

          <div className="p-6 border-t border-white/5">
              <button 
                onClick={async () => {
                  try {
                    await supabase.auth.signOut();
                  } catch (e) {
                    console.warn("Error during signOut:", e);
                  }
                }}
                className="w-full flex items-center gap-4 px-6 py-4 rounded-2xl font-bold text-rose-400 hover:bg-rose-500/10 transition-all"
              >
                  <LogOut size={20} /> Encerrar Sessão
              </button>
          </div>
      </aside>

      {/* ÁREA DE CONTEÚDO PRINCIPAL (HEADER + MAIN) */}
      <div className="flex-1 flex flex-col min-w-0">
          
          {/* HEADER UNIFICADO */}
          <header className="bg-white/80 dark:bg-[#23243a]/80 backdrop-blur-xl border-b border-slate-200 dark:border-white/5 px-6 lg:px-10 py-5 flex justify-between items-center sticky top-0 z-50 transition-all">
              <div className="flex items-center gap-4">
                  {/* Visível apenas no Mobile */}
                  <div className="lg:hidden bg-indigo-600 p-2 rounded-xl text-white">
                      <ShieldCheck size={20} strokeWidth={2.5} />
                  </div>
                  <div>
                      <h1 className="text-xs lg:text-sm font-black text-slate-800 dark:text-white uppercase tracking-tighter leading-none truncate max-w-[120px] lg:max-w-none">
                          {companyData?.name || 'MINHA CONTA'}
                      </h1>
                      <p className="hidden lg:block text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-1">Portal Exclusivo do Assinante</p>
                  </div>
              </div>

              <div className="flex items-center gap-3 sm:gap-6">
                  {/* Toggle Tema */}
                  <button 
                    onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                    className="p-2.5 text-slate-400 hover:text-indigo-500 bg-gray-100 dark:bg-[#1a1b2e] rounded-xl transition-all"
                  >
                      {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
                  </button>
                  
                  {/* Info Usuário */}
                  <div className="flex items-center gap-3 bg-gray-100 dark:bg-[#1a1b2e] pl-4 pr-1.5 py-1.5 rounded-2xl border border-slate-200 dark:border-white/5 transition-colors">
                      <button onClick={() => setIsPasswordModalOpen(true)} className="text-slate-400 hover:text-indigo-500 transition-colors p-1" title="Redefinir Senha">
                          <Key size={18} />
                      </button>
                      <div className="h-6 w-px bg-slate-200 dark:bg-white/10"></div>
                      <div className="flex flex-col items-start leading-none mr-2 hidden sm:flex">
                          <span className="text-[10px] font-black text-slate-800 dark:text-white uppercase truncate max-w-[120px]">{userProfile.full_name}</span>
                          <span className="text-[8px] font-bold text-slate-400 dark:text-gray-500 truncate max-w-[150px] mt-0.5 lowercase">{userProfile.email}</span>
                      </div>
                      <div className="w-9 h-9 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-black text-xs uppercase shadow-md shrink-0">
                          {userProfile.full_name.substring(0,2)}
                      </div>
                  </div>
              </div>
          </header>

          {/* MAIN SCROLLABLE CONTENT */}
          <main className="flex-1 overflow-y-auto custom-scrollbar px-6 lg:px-10 py-8 space-y-10 pb-32 lg:pb-12">
            
            {activeTab === 'dashboard' && (
              <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-10 max-w-6xl mx-auto">
                
                {/* GRID DE CARDS PRINCIPAIS */}
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 lg:gap-10">
                    
                    {/* HERO CARD FATURA */}
                    <div className="bg-[#2a2b42] dark:bg-[#23243a] rounded-[3rem] p-10 shadow-2xl relative overflow-hidden group border border-white/5">
                        <div className="relative z-10 space-y-10">
                            <div className="flex items-center gap-3">
                                <div className="bg-indigo-500/10 text-indigo-400 text-[9px] font-black uppercase tracking-[0.2em] px-4 py-2 rounded-full border border-indigo-500/20">
                                    {nextInvoice ? `FATURA DE ${new Date(nextInvoice.end_date).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' }).toUpperCase()}` : 'TUDO EM DIA'}
                                </div>
                                {nextInvoice && !nextInvoice.payment_date && (
                                    <div className="bg-amber-500/10 text-amber-400 text-[9px] font-black uppercase tracking-[0.2em] px-4 py-2 rounded-full border border-amber-500/20">
                                        VENCIMENTO PRÓXIMO
                                    </div>
                                )}
                            </div>

                            <div>
                                <h2 className="text-4xl lg:text-5xl font-black text-white tracking-tighter italic uppercase leading-none">
                                    {nextInvoice ? new Date(nextInvoice.end_date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long' }) : 'Sem pendências'}
                                </h2>
                                <div className="mt-8">
                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2">VALOR DO PAGAMENTO</p>
                                    <p className="text-5xl font-black text-white tracking-tighter">
                                        {nextInvoice ? formatCurrency(nextInvoice.value) : 'R$ 0,00'}
                                    </p>
                                </div>
                            </div>

                            {nextInvoice ? (
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <button 
                                        onClick={() => { setSelectedInvoice(nextInvoice); setIsPixModalOpen(true); }}
                                        className="bg-[#5d5fe3] hover:brightness-110 text-white py-6 rounded-[1.8rem] font-black text-xs uppercase tracking-[0.2em] shadow-2xl transition-all flex items-center justify-center gap-4 group/btn"
                                    >
                                        <QrCode size={22} strokeWidth={3} /> PAGAR COM PIX
                                    </button>
                                    <button 
                                        onClick={() => window.open(`https://wa.me/${companyData?.whatsapp?.replace(/\D/g, '') || ''}`, '_blank')}
                                        className="bg-[#1c1d31] hover:bg-[#25263a] text-white py-6 rounded-[1.8rem] font-black text-[10px] uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-4 border border-white/5"
                                    >
                                        <MessageSquare size={20} className="text-emerald-400" /> ENVIAR COMPROVANTE
                                    </button>
                                </div>
                            ) : (
                                <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-center gap-3">
                                    <CheckCircle2 size={24} className="text-emerald-400" />
                                    <span className="text-xs font-bold text-emerald-300 uppercase">Você não possui faturas pendentes.</span>
                                </div>
                            )}
                        </div>
                        <div className="absolute top-0 right-0 p-8 opacity-[0.03] text-white pointer-events-none group-hover:scale-110 transition-transform duration-1000">
                            <Wallet size={320} />
                        </div>
                    </div>

                    {/* CARD CERTIFICADO */}
                    <div className="bg-[#1c1d31] dark:bg-[#1e2235] rounded-[3rem] p-10 shadow-2xl relative overflow-hidden group border border-white/5">
                        <div className="relative z-10 flex flex-col h-full">
                            <div className="w-16 h-16 bg-white/5 backdrop-blur-md rounded-2xl flex items-center justify-center mb-12 border border-white/10 group-hover:scale-110 transition-transform">
                                <Shield size={32} className={hasCertificate ? "text-teal-400" : "text-gray-500"} />
                            </div>
                            <div>
                                <h3 className="text-3xl font-black text-white uppercase tracking-tighter italic leading-none">Certificado Digital</h3>
                                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.2em] mt-3">Área Segura e Auditada em Nuvem</p>
                            </div>
                            
                            <div className="mt-8 mb-12">
                                {hasCertificate ? (
                                    <div className="inline-flex items-center gap-2 bg-emerald-500/10 text-emerald-400 px-4 py-2 rounded-full border border-emerald-500/20">
                                        <Check size={16} strokeWidth={3} />
                                        <span className="text-[9px] font-black uppercase tracking-widest">ARQUIVO DISPONÍVEL</span>
                                    </div>
                                ) : (
                                    <div className="inline-flex items-center gap-2 bg-rose-500/10 text-rose-400 px-4 py-2 rounded-full border border-rose-500/20">
                                        <FileX size={16} strokeWidth={3} />
                                        <span className="text-[9px] font-black uppercase tracking-widest">NENHUM ARQUIVO</span>
                                    </div>
                                )}
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <button 
                                    onClick={handleDownloadCert}
                                    disabled={!hasCertificate}
                                    className={`py-6 rounded-[1.8rem] font-black text-xs uppercase tracking-[0.2em] shadow-xl transition-all flex items-center justify-center gap-4 ${hasCertificate ? 'bg-teal-400 hover:brightness-110 text-slate-900 shadow-teal-400/20' : 'bg-gray-700 text-gray-400 cursor-not-allowed opacity-50'}`}
                                >
                                    <Download size={22} strokeWidth={3} /> BAIXAR PFX
                                </button>
                                <button 
                                    disabled={!hasCertificate}
                                    className="bg-[#2a2b42] hover:bg-[#343555] text-white py-6 rounded-[1.8rem] font-black text-[10px] uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-4 border border-white/5 disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                    <Send size={20} /> ENVIAR CONTADOR
                                </button>
                            </div>
                        </div>
                        <div className="absolute -bottom-10 -right-10 opacity-[0.02] text-white pointer-events-none group-hover:rotate-12 transition-transform duration-1000">
                            <ShieldCheck size={300} />
                        </div>
                    </div>
                </div>

                {/* HUB GOVERNO (Grid dinâmico) */}
                <section className="space-y-8">
                    <div className="flex items-center gap-6 px-4">
                        <h3 className="text-[11px] font-black text-slate-400 dark:text-gray-500 uppercase tracking-[0.4em] whitespace-nowrap">Hub do Governo Federal</h3>
                        <div className="h-px bg-slate-200 dark:bg-white/5 flex-1"></div>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-6">
                        {govLinks.map((link, idx) => (
                            <a 
                                key={idx} 
                                href={link.url} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="bg-white dark:bg-[#23243a] p-8 rounded-[2.5rem] border border-slate-100 dark:border-white/5 shadow-sm hover:shadow-2xl hover:-translate-y-1.5 transition-all group flex flex-col items-center text-center gap-6"
                            >
                                <div className="w-16 h-16 bg-slate-50 dark:bg-[#1a1b2e] rounded-[1.8rem] flex items-center justify-center text-slate-400 group-hover:bg-indigo-600 group-hover:text-white transition-all shadow-inner">
                                    <link.icon size={28} />
                                </div>
                                <span className="text-[10px] font-black text-slate-800 dark:text-white uppercase tracking-tighter leading-tight group-hover:text-indigo-600 transition-colors">
                                    {link.label}
                                </span>
                            </a>
                        ))}
                    </div>
                </section>
              </div>
            )}

            {activeTab === 'billing' && (
              <div className="animate-in fade-in slide-in-from-right-4 duration-500 space-y-10 max-w-6xl mx-auto">
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                      <div>
                        <h2 className="text-5xl font-black text-slate-900 dark:text-white uppercase tracking-tighter leading-none italic">Financeiro</h2>
                        <p className="text-[11px] font-black text-slate-400 uppercase tracking-[0.4em] mt-4">Histórico detalhado de faturas e liquidações</p>
                      </div>
                      <button 
                        onClick={() => window.open(`https://wa.me/${companyData?.whatsapp?.replace(/\D/g, '') || ''}`, '_blank')}
                        className="bg-[#22c55e] text-white px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-3 shadow-xl shadow-emerald-500/20 active:scale-95 transition-all"
                      >
                          <MessageCircle size={20} strokeWidth={3} /> Suporte Financeiro
                      </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="bg-white dark:bg-[#23243a] p-10 rounded-[3rem] shadow-sm border border-slate-100 dark:border-white/5 flex items-center justify-between transition-colors">
                          <div><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Liquidado</p><p className="text-3xl font-black text-emerald-500 tabular-nums">{formatCurrency(totalPaid)}</p></div>
                          <div className="w-14 h-14 bg-emerald-50 dark:bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-600 transition-colors"><TrendingUp size={28} /></div>
                      </div>
                      <div className="bg-white dark:bg-[#23243a] p-10 rounded-[3rem] shadow-sm border border-slate-100 dark:border-white/5 flex items-center justify-between transition-colors">
                          <div><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Faturas em Aberto</p><p className="text-3xl font-black text-amber-500 tabular-nums">{subscriptions.filter(s => !s.payment_date).length}</p></div>
                          <div className="w-14 h-14 bg-amber-50 dark:bg-amber-500/10 rounded-2xl flex items-center justify-center text-emerald-600 transition-colors"><Clock size={28} /></div>
                      </div>
                      <div className="bg-white dark:bg-[#23243a] p-10 rounded-[3rem] shadow-sm border border-slate-100 dark:border-white/5 flex items-center justify-between transition-colors">
                          <div><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Status de Acesso</p><p className="text-3xl font-black text-indigo-500 uppercase tracking-tighter">ATIVO</p></div>
                          <div className="w-14 h-14 bg-indigo-50 dark:bg-indigo-500/10 rounded-2xl flex items-center justify-center text-indigo-600 transition-colors"><ShieldCheck size={28} /></div>
                      </div>
                  </div>

                  <div className="bg-white dark:bg-[#23243a] rounded-[3rem] shadow-2xl border border-slate-100 dark:border-white/5 overflow-hidden transition-colors">
                      <div className="px-10 py-6 border-b dark:border-white/5 bg-gray-50/50 dark:bg-white/5">
                          <h3 className="text-xs font-black text-slate-800 dark:text-white uppercase tracking-widest italic">Extrato Financeiro Completo</h3>
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-left">
                            <thead className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-[0.2em] border-b dark:border-white/5">
                                <tr>
                                    <th className="px-10 py-6">Status</th>
                                    <th className="px-10 py-6">Vencimento</th>
                                    <th className="px-10 py-6">Fatura</th>
                                    <th className="px-10 py-6 text-right">Valor Total</th>
                                    <th className="px-10 py-6 text-center">Ações</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-50 dark:divide-white/5">
                                {invoices.length === 0 ? (
                                    <tr><td colSpan={5} className="py-24 text-center text-slate-300 font-black uppercase text-sm tracking-[0.3em]">Nenhuma fatura encontrada</td></tr>
                                ) : (
                                    invoices.map(inv => {
                                        const isPaid = inv.status === 'completed' || !inv.status;
                                        return (
                                            <tr key={inv.id} className="hover:bg-gray-50/50 dark:hover:bg-white/5 transition-colors group">
                                                <td className="px-10 py-6">
                                                    <div className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-[10px] font-black uppercase w-fit ${isPaid ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-500/20' : 'bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-400 border border-amber-100 dark:border-emerald-500/20'}`}>
                                                        {isPaid ? <CheckCircle2 size={14} strokeWidth={3}/> : <Clock size={14} strokeWidth={3}/>}
                                                        {isPaid ? 'Liquidada' : 'Aguardando'}
                                                    </div>
                                                </td>
                                                <td className="px-10 py-6">
                                                    <div className="flex flex-col">
                                                        <span className="text-sm font-bold text-slate-800 dark:text-white">{new Date(inv.date).toLocaleDateString('pt-BR')}</span>
                                                        <span className="text-[10px] font-black text-slate-400 uppercase">{isPaid ? 'Data de Pagamento' : 'Prazo Limite'}</span>
                                                    </div>
                                                </td>
                                                <td className="px-10 py-6"><span className="bg-slate-100 dark:bg-[#1a1b2e] px-3 py-1 rounded-lg text-[10px] font-black text-slate-400 border border-slate-200 dark:border-white/5 transition-colors">#{inv.code}</span></td>
                                                <td className="px-10 py-6 text-right"><span className={`text-lg font-black tabular-nums ${isPaid ? 'text-slate-800 dark:text-white' : 'text-indigo-600'}`}>{formatCurrency(inv.total)}</span></td>
                                                <td className="px-10 py-6">
                                                    <div className="flex justify-center gap-3">
                                                        <button 
                                                            onClick={() => setViewingReceipt(inv)}
                                                            className="px-6 py-2.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-black text-[9px] uppercase tracking-widest hover:scale-105 active:scale-95 transition-all shadow-lg"
                                                        >
                                                            Visualizar Recibo
                                                        </button>
                                                        {!isPaid && (
                                                            <button 
                                                                onClick={() => { setSelectedInvoice(inv); setIsPixModalOpen(true); }}
                                                                className="px-6 py-2.5 bg-indigo-600 text-white rounded-xl font-black text-[9px] uppercase tracking-widest hover:scale-105 active:scale-95 transition-all shadow-lg"
                                                            >
                                                                Pagar com PIX
                                                            </button>
                                                        )}
                                                    </div>
                                                </td>
                                            </tr>
                                        );
                                    })
                                )}
                            </tbody>
                        </table>
                      </div>
                  </div>
              </div>
            )}

            {activeTab === 'support' && (
              <div className="animate-in fade-in slide-in-from-right-4 duration-500 space-y-10 max-w-6xl mx-auto">
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-10 items-start">
                      <div className="lg:col-span-2 bg-white dark:bg-[#23243a] p-10 lg:p-14 rounded-[3rem] border border-slate-100 dark:border-white/5 shadow-sm transition-all">
                          <h3 className="text-3xl font-black text-slate-900 dark:text-white mb-12 uppercase tracking-tighter italic">Base de Conhecimento</h3>
                          <div className="space-y-12">
                              {[
                                { q: "Onde encontro o recibo da mensalidade?", a: "No menu 'Financeiro', localize a fatura liquidada e clique no botão 'Visualizar Recibo'. O sistema gerará um cupom digital para download imediato." },
                                { q: "Como renovo meu certificado digital?", a: "No seu dashboard inicial, clique em 'Baixar PFX'. Se o arquivo não estiver disponível ou estiver expirado, nossa equipe técnica entrará em contato automaticamente via e-mail." },
                                { q: "O pagamento PIX é compensado na hora?", a: "Sim. O sistema monitora o banco em tempo real. Assim que o pagamento for confirmado pelo Banco Central, sua fatura será marcada como liquidada em até 2 minutos." }
                              ].map((item, i) => (
                                <div key={i} className="flex gap-8 group">
                                    <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-500/10 rounded-full flex items-center justify-center text-indigo-600 dark:text-indigo-400 font-black text-2xl group-hover:scale-110 transition-transform">?</div>
                                    <div className="flex-1">
                                        <p className="text-lg font-black text-slate-800 dark:text-white mb-4 uppercase tracking-tighter leading-tight">{item.q}</p>
                                        <p className="text-sm text-slate-500 dark:text-gray-400 leading-relaxed font-medium">{item.a}</p>
                                    </div>
                                </div>
                              ))}
                          </div>
                      </div>

                      <div className="space-y-8">
                          {/* WHATSAPP CARD */}
                          <div className="bg-[#22c55e] rounded-[3rem] p-10 shadow-2xl text-white flex flex-col gap-10 group overflow-hidden relative">
                              <div className="absolute -top-10 -right-10 opacity-10 group-hover:scale-110 transition-transform duration-1000 rotate-12"><MessageCircle size={220} /></div>
                              <div className="relative z-10 flex items-center gap-6">
                                  <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center border border-white/20 shrink-0 group-hover:scale-110 transition-all">
                                      <Smartphone size={32} strokeWidth={3} />
                                  </div>
                                  <div>
                                      <h4 className="text-2xl font-black uppercase tracking-tighter leading-none italic">WhatsApp</h4>
                                      <p className="text-[10px] font-bold opacity-80 mt-2 uppercase tracking-widest">Suporte Direto</p>
                                  </div>
                              </div>
                              <button 
                                onClick={() => window.open(`https://wa.me/${companyData?.whatsapp?.replace(/\D/g, '') || ''}`, '_blank')}
                                className="w-full bg-white text-[#22c55e] py-6 rounded-[1.8rem] font-black text-[11px] uppercase tracking-[0.25em] shadow-xl transition-all flex items-center justify-center gap-3 active:scale-95 relative z-10"
                              >
                                  ABRIR ATENDIMENTO <ExternalLink size={20} strokeWidth={3} />
                              </button>
                          </div>

                          <div className="bg-white dark:bg-[#23243a] p-10 rounded-[3rem] border border-slate-100 dark:border-white/5 shadow-sm text-center space-y-6 transition-all">
                              <div className="w-14 h-14 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 rounded-full flex items-center justify-center mx-auto transition-colors"><Mail size={28} /></div>
                              <div>
                                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Atendimento via E-mail</p>
                                  <p className="text-sm font-bold text-slate-700 dark:text-white mt-2">{companyData?.support_email || 'suporte@suameta.com.br'}</p>
                              </div>
                              <p className="text-[9px] text-slate-400 font-bold leading-relaxed px-4">Resposta em até 24h úteis para solicitações administrativas.</p>
                          </div>
                      </div>
                  </div>
              </div>
            )}

          </main>
      </div>

      {/* FLOATING BOTTOM NAV (Somente Mobile) */}
      <div className="lg:hidden fixed bottom-6 left-1/2 -translate-x-1/2 w-fit z-50 animate-in slide-in-from-bottom-10 duration-700">
          <nav className="bg-[#1c1d31]/95 dark:bg-[#23243a]/95 backdrop-blur-2xl px-6 py-4 flex items-center gap-8 rounded-full shadow-[0_20px_50px_-10px_rgba(0,0,0,0.5)] border border-white/10">
              <button 
                onClick={() => setActiveTab('dashboard')} 
                className={`relative p-2.5 rounded-2xl transition-all duration-500 ${activeTab === 'dashboard' ? 'text-white bg-indigo-600 shadow-[0_0_20px_rgba(93,95,227,0.4)] scale-110' : 'text-slate-500 hover:text-slate-300'}`}
              >
                  <LayoutGrid size={24} strokeWidth={activeTab === 'dashboard' ? 3 : 2} />
                  {activeTab === 'dashboard' && <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-1 h-1 bg-white rounded-full"></span>}
              </button>
              
              <button 
                onClick={() => setActiveTab('billing')} 
                className={`relative p-2.5 rounded-2xl transition-all duration-500 ${activeTab === 'billing' ? 'text-white bg-indigo-600 shadow-[0_0_20px_rgba(93,95,227,0.4)] scale-110' : 'text-slate-500 hover:text-slate-300'}`}
              >
                  <CreditCard size={24} strokeWidth={activeTab === 'billing' ? 3 : 2} />
                  {activeTab === 'billing' && <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-1 h-1 bg-white rounded-full"></span>}
              </button>

              <button 
                onClick={() => setActiveTab('support')} 
                className={`relative p-2.5 rounded-2xl transition-all duration-500 ${activeTab === 'support' ? 'text-white bg-indigo-600 shadow-[0_0_20px_rgba(93,95,227,0.4)] scale-110' : 'text-slate-500 hover:text-slate-300'}`}
              >
                  <MessageSquare size={24} strokeWidth={activeTab === 'support' ? 3 : 2} />
                  {activeTab === 'support' && <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-1 h-1 bg-white rounded-full"></span>}
              </button>

              <div className="h-6 w-px bg-white/10 mx-1"></div>

              <button 
                onClick={async () => {
                  try {
                    await supabase.auth.signOut();
                  } catch (e) {
                    console.warn("Error during signOut:", e);
                  }
                }} 
                className="text-rose-400 p-2.5 transition-transform hover:scale-110 active:scale-95"
              >
                  <LogOut size={24} />
              </button>
          </nav>
      </div>

      {/* MODAL TROCAR SENHA */}
      {isPasswordModalOpen && (
          <div className="fixed inset-0 bg-slate-900/60 dark:bg-black/80 backdrop-blur-sm z-[200] flex items-center justify-center p-4 animate-in fade-in duration-300">
              <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] w-full max-w-md shadow-2xl overflow-hidden animate-in zoom-in-95 border border-transparent dark:border-white/5 transition-colors">
                  <div className="p-10 pb-4 flex justify-between items-start">
                      <div>
                          <h3 className="text-2xl font-black text-[#1e293b] dark:text-white uppercase tracking-tighter italic leading-none">TROCAR SENHA</h3>
                          <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mt-2">ATUALIZE SEU ACESSO POR SEGURANÇA</p>
                      </div>
                      <button onClick={() => setIsPasswordModalOpen(false)} className="text-slate-300 hover:text-slate-600 dark:hover:text-white transition-colors p-1">
                          <X size={28} />
                      </button>
                  </div>
                  <div className="p-10 space-y-6">
                      <div className="relative group">
                          <label className="absolute -top-2.5 left-5 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-indigo-500 uppercase tracking-widest z-10 transition-all">NOVA SENHA</label>
                          <div className="flex items-center border-2 border-indigo-100 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] focus-within:border-indigo-400 transition-all h-16">
                              <Lock className="text-slate-200 mr-4" size={20} />
                              <input 
                                type={showPassword ? "text" : "password"}
                                className="w-full bg-transparent outline-none text-base font-black text-slate-700 dark:text-white"
                                placeholder="Mínimo 6 dígitos"
                                value={newPassword}
                                onChange={(e) => setNewPassword(e.target.value)}
                                autoFocus
                              />
                              <button onClick={() => setShowPassword(!showPassword)} className="text-slate-300 hover:text-indigo-600">
                                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                              </button>
                          </div>
                      </div>
                      <div className="relative group">
                          <label className="absolute -top-2.5 left-5 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-indigo-500 uppercase tracking-widest z-10 transition-all">CONFIRMAR SENHA</label>
                          <div className="flex items-center border-2 border-slate-100 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] focus-within:border-indigo-400 transition-all h-16">
                              <ShieldCheck className="text-slate-200 mr-4" size={20} />
                              <input 
                                type={showPassword ? "text" : "password"}
                                className="w-full bg-transparent outline-none text-base font-black text-slate-700 dark:text-white"
                                placeholder="Repita a nova senha"
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                              />
                          </div>
                      </div>
                      <button 
                        onClick={handleUpdatePassword}
                        disabled={isUpdating || !newPassword || newPassword !== confirmPassword}
                        className={`w-full py-6 rounded-2xl font-black text-xs uppercase tracking-widest shadow-2xl transition-all flex items-center justify-center gap-3 active:scale-95 disabled:grayscale disabled:opacity-40 mt-4 ${(!newPassword || newPassword !== confirmPassword) ? 'bg-slate-300' : 'bg-indigo-600 text-white shadow-indigo-600/30'}`}
                      >
                          {isUpdating ? <Loader2 className="animate-spin" size={22} /> : <ShieldCheck size={22} strokeWidth={3} />}
                          SALVAR NOVA SENHA
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* MODAL PIX CHECKOUT */}
      {isPixModalOpen && selectedInvoice && (
          <div className="fixed inset-0 bg-slate-900/95 z-[200] flex items-center justify-center p-6 backdrop-blur-2xl animate-in fade-in duration-500">
              <div className="bg-white dark:bg-[#23243a] w-full max-w-sm rounded-[3rem] overflow-hidden animate-in zoom-in-95 shadow-2xl border border-transparent dark:border-white/5 transition-all">
                  <div className="px-8 py-8 flex justify-between items-center bg-slate-50 dark:bg-white/5 border-b border-slate-100 dark:border-white/5 transition-colors">
                      <div className="flex items-center gap-4">
                          <div className="bg-indigo-600 p-4 rounded-2xl text-white shadow-2xl"><QrCode size={28} strokeWidth={3} /></div>
                          <div>
                            <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tighter uppercase leading-none italic">Checkout PIX</h3>
                            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mt-2">DOC: #{selectedInvoice.code}</p>
                          </div>
                      </div>
                      <button onClick={() => setIsPixModalOpen(false)} className="text-slate-300 hover:text-rose-500 transition-colors p-1"><X size={32} /></button>
                  </div>
                  <div className="p-10 space-y-10 text-center">
                      <div className="space-y-4">
                          <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.4em]">Escaneie p/ Pagar</p>
                          <div className="bg-white p-6 rounded-[2.5rem] shadow-2xl relative inline-block border-2 border-indigo-50">
                              <img src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=ESPACO_DIGITAL_PIX_${selectedInvoice.total}`} alt="PIX" className="w-48 h-48 mx-auto rounded-xl" />
                          </div>
                      </div>
                      <div className="space-y-4">
                        <div className="flex justify-between items-baseline mb-2">
                            <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">A Liquidar</span>
                            <span className="text-3xl font-black text-slate-900 dark:text-white tracking-tighter">{formatCurrency(selectedInvoice.total)}</span>
                        </div>
                        <button onClick={() => { navigator.clipboard.writeText("00020101021226850014br.gov.bcb.pix011161999695005520400005303986540510.005802BR5925ESPACO DIGITAL6008BRASILIA62070503***6304ABCD"); setCopied(true); setTimeout(() => setCopied(false), 2000); }} className={`w-full py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-3 transition-all transform active:scale-95 shadow-2xl ${copied ? 'bg-emerald-500 text-white' : 'bg-[#1c1d31] text-white hover:brightness-110'}`}>
                            {copied ? <>Código Copiado! <Check size={20} strokeWidth={4} /></> : <>Copiar Código PIX <Copy size={20} strokeWidth={3} /></>}
                        </button>
                      </div>
                  </div>
              </div>
          </div>
      )}

      <SaleDetailPanel isOpen={!!viewingReceipt} onClose={() => setViewingReceipt(null)} sale={viewingReceipt} />
    </div>
  );
};

export default SubscriberPortal;
