
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  Users, 
  Search, 
  Download, 
  Upload, 
  Loader2, 
  Edit2, 
  Trash2, 
  Calendar,
  HelpCircle,
  Plus,
  ChevronRight,
  MessageCircle,
  ChevronDown,
  Check,
  X,
  ChevronLeft,
  CalendarDays,
  Phone,
  Mail,
  AlertTriangle,
  Briefcase,
  Star,
  CheckCircle2,
  List,
  AlertOctagon,
  Settings,
  XCircle,
  Clock,
  RefreshCcw,
  MoreHorizontal
} from 'lucide-react';
import { Customer, Subscription } from '../types';
import { supabase } from '../supabaseClient';
import UserMenu from './UserMenu';
import CustomerModal from './CustomerModal';
import CustomerImportModal from './CustomerImportModal';
import Toast from './Toast';
import SubscriptionForm from './SubscriptionForm';

const getSafeDateObj = (val: string) => {
    if (!val) return null;
    const cleanVal = val.split('T')[0];
    const parts = cleanVal.split('-');
    if (parts.length < 3) return null;
    const [y, m, d] = parts.map(Number);
    return new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
};

const parseSafeDate = (dateStr: string) => {
    if (!dateStr) return null;
    const cleanDate = dateStr.split('T')[0];
    const parts = cleanDate.split('-');
    if (parts.length < 3) return null;
    const [y, m, d] = parts.map(Number);
    return new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
};

const getDateBadge = (dateStr?: string) => {
    if (!dateStr) return { day: '--', month: '---' };
    const date = getSafeDateObj(dateStr);
    if (!date || isNaN(date.getTime())) return { day: '--', month: '---' };
    const day = date.getUTCDate().toString().padStart(2, '0');
    const months = ['JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN', 'JUL', 'AGO', 'SET', 'OUT', 'NOV', 'DEZ'];
    const month = months[date.getUTCMonth()];
    return { day, month };
};

const getStatusColor = (sub: Subscription & { _isGhost?: boolean }) => {
    if (sub._isGhost) return { bg: 'bg-amber-50', text: 'text-amber-700', label: 'Configurar', icon: Settings, border: 'border-amber-200' };
    if (sub.status === 'cancelled') return { bg: 'bg-gray-100', text: 'text-gray-500', label: 'Cancelado', icon: XCircle, border: 'border-gray-200' };
    if (!sub.end_date) return { bg: 'bg-gray-100', text: 'text-gray-600', label: 'Sem Data', icon: Settings, border: 'border-gray-200' };

    const today = new Date();
    today.setHours(0,0,0,0);
    const end = getSafeDateObj(sub.end_date);
    if (end) end.setHours(23, 59, 59);

    const isPaid = !!sub.payment_date;
    if (isPaid) return { bg: 'bg-emerald-100', text: 'text-emerald-700', label: 'Pago', icon: CheckCircle2, border: 'border-emerald-200' };
    if (end && today > end) return { bg: 'bg-rose-100', text: 'text-rose-700', label: 'Vencido', icon: AlertOctagon, border: 'border-rose-200' };
    return { bg: 'bg-indigo-50', text: 'text-indigo-700', label: 'Aguardando', icon: Clock, border: 'border-indigo-100' };
};

interface CustomersScreenProps {
  customers: Customer[];
  subscriptions?: Subscription[];
  onAddCustomer: (customer: Customer) => Promise<Customer | null>;
  onUpdateCustomer: (customer: Customer, silent?: boolean) => Promise<boolean>;
  onImportCustomers: (customers: Customer[]) => Promise<void>;
  onDeleteCustomer: (id: string) => Promise<void>;
  onBulkDeleteByDate?: (startDate: string, endDate: string) => Promise<{ success: boolean; count: number; skipped?: number }>;
  toggleSidebar: () => void;
  companyId: string;
  onNavigate?: (view: string) => void;
  refreshData?: () => void;
  portalUserIds: Set<string>;
}

const ITEMS_PER_PAGE = 50;

const CustomersScreen: React.FC<CustomersScreenProps> = ({
  customers,
  subscriptions = [],
  onAddCustomer,
  onUpdateCustomer,
  onImportCustomers,
  onDeleteCustomer,
  onBulkDeleteByDate,
  toggleSidebar,
  companyId,
  onNavigate,
  refreshData,
  portalUserIds
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [editingCustomerId, setEditingCustomerId] = useState<string | null>(null);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedMonth, setSelectedMonth] = useState('all');
  const [customerTypeFilter, setCustomerTypeFilter] = useState<'all' | 'subscribers' | 'partners' | 'portal'>('all');
  const [isMonthPickerOpen, setIsMonthPickerOpen] = useState(false);
  const [showSubscriptionColumns, setShowSubscriptionColumns] = useState(false);
  
  const [customerToDelete, setCustomerToDelete] = useState<{ id: string; name: string } | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showBulkDeleteModal, setShowBulkDeleteModal] = useState(false);
  const [isBulkDeleting, setIsBulkDeleting] = useState(false);
  const [bulkDeleteStartDate, setBulkDeleteStartDate] = useState('');
  const [bulkDeleteEndDate, setBulkDeleteEndDate] = useState('');

  const [isSubFormOpen, setIsSubFormOpen] = useState(false);
  const [editingSubscription, setEditingSubscription] = useState<Subscription | null>(null);
  const [isRenewing, setIsRenewing] = useState(false);

  // Resetar para a primeira página ao filtrar
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, selectedMonth, customerTypeFilter]);

  const currentEditingCustomer = useMemo(() => {
    if (!editingCustomerId) return null;
    return customers.find(c => c.id === editingCustomerId) || null;
  }, [customers, editingCustomerId]);

  const months = [
    { id: 'all', label: 'TODOS OS MESES' },
    { id: '01', label: 'JANEIRO' }, { id: '02', label: 'FEVEREIRO' },
    { id: '03', label: 'MARÇO' }, { id: '04', label: 'ABRIL' },
    { id: '05', label: 'MAIO' }, { id: '06', label: 'JUNHO' },
    { id: '07', label: 'JULHO' }, { id: '08', label: 'AGOSTO' },
    { id: '09', label: 'SETEMBRO' }, { id: '10', label: 'OUTUBRO' },
    { id: '11', label: 'NOVEMBRO' }, { id: '12', label: 'DEZEMBRO' },
  ];

  const filteredCustomers = useMemo(() => {
    const query = searchQuery.toLowerCase().trim();
    return customers.filter(c => {
      const sub = (subscriptions || []).find(s => s.customer_id === c.id);
      const planName = sub?.provider || '';

      const matchesSearch = !query || 
        c.name.toLowerCase().includes(query) || 
        (c.cpf || '').includes(query) || 
        (c.cnpj || '').includes(query) || 
        (c.phone || '').includes(query) ||
        (c.socialReason || '').toLowerCase().includes(query) ||
        (c.fantasyName || '').toLowerCase().includes(query) ||
        planName.toLowerCase().includes(query);
      
      if (!matchesSearch) return false;

      if (selectedMonth !== 'all') {
        const date = new Date(c.createdAt || '');
        return (date.getMonth() + 1).toString().padStart(2, '0') === selectedMonth;
      }

      if (customerTypeFilter === 'subscribers') return c.isSubscriber;
      if (customerTypeFilter === 'partners') return c.isPartner;
      if (customerTypeFilter === 'portal') return portalUserIds.has(c.id);

      return true;
    }).sort((a, b) => new Date(b.createdAt || '').getTime() - new Date(a.createdAt || '').getTime());
  }, [customers, searchQuery, selectedMonth, customerTypeFilter, subscriptions, portalUserIds]);

  const totalPages = Math.ceil(filteredCustomers.length / ITEMS_PER_PAGE);
  const paginatedCustomers = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredCustomers.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredCustomers, currentPage]);

  // Merge customer with their subscription
  const customersWithSubs = useMemo(() => {
    return paginatedCustomers.map(customer => {
      const sub = subscriptions.find(s => s.customer_id === customer.id);
      
      // If marked as subscriber but no record in subscriptions table, create a "ghost" subscription
      let finalSub = sub;
      if (!sub && customer.isSubscriber) {
          finalSub = {
              id: `ghost-${customer.id}`,
              customer_id: customer.id,
              company_id: companyId,
              status: 'active',
              frequency: 'Mensal',
              value: 0,
              _isGhost: true // Custom flag for UI
          } as any;
      }
      
      return { ...customer, subscription: finalSub };
    });
  }, [paginatedCustomers, subscriptions, companyId]);

  const stats = useMemo(() => {
    const now = new Date();
    const thisMonth = now.getMonth();
    const newThisMonth = customers.filter(c => {
      const d = new Date(c.createdAt || '');
      return d.getMonth() === thisMonth && d.getFullYear() === now.getFullYear();
    }).length;
    return { 
        total: customers.length, 
        newThisMonth, 
        subscribers: customers.filter(c => c.isSubscriber).length,
        partners: customers.filter(c => c.isPartner).length,
        portal: customers.filter(c => portalUserIds.has(c.id)).length
    };
  }, [customers, portalUserIds]);

  const handleEditClick = (customer: Customer) => {
    setEditingCustomerId(customer.id);
    setIsFormOpen(true);
  };

  const handleToggleSubscriber = async (customer: Customer) => {
    const newState = !customer.isSubscriber;
    await onUpdateCustomer({ ...customer, isSubscriber: newState }, true);
    if (newState) {
        setShowSubscriptionColumns(true);
    }
  };

  const handleTogglePartner = async (customer: Customer) => {
    await onUpdateCustomer({ ...customer, isPartner: !customer.isPartner }, true);
  };

  const handleConfirmDelete = async () => {
    if (!customerToDelete) return;
    setIsDeleting(true);
    try {
      await onDeleteCustomer(customerToDelete.id);
      setCustomerToDelete(null);
      setToastMessage("Cliente excluído com sucesso!");
      setShowToast(true);
    } catch (error: any) {
      console.error(error);
      if (error.message === 'ACTIVE_SALES_EXIST') {
          alert("Não é possível excluir: Este cliente possui vendas ativas ou pendentes no sistema.");
      } else if (error.message === 'ACTIVE_SUBS_EXIST') {
          alert("Não é possível excluir: Este cliente possui assinaturas ativas.");
      } else if (error.code === '23503') {
          alert("Não é possível excluir este cliente pois existem registros vinculados a ele.");
      } else {
          alert("Erro ao excluir cliente: " + (error.message || "Erro desconhecido"));
      }
    } finally {
      setIsDeleting(false);
    }
  };

  const handleBulkDelete = async () => {
    if (!onBulkDeleteByDate) return;
    if (!bulkDeleteStartDate || !bulkDeleteEndDate) {
      alert("Por favor, selecione o período inicial e final.");
      return;
    }
    
    console.log(`Solicitando exclusão em massa: ${bulkDeleteStartDate} até ${bulkDeleteEndDate}`);
    
    setIsBulkDeleting(true);
    try {
      // Garantir que as datas cubram o dia inteiro
      const startDate = `${bulkDeleteStartDate}T00:00:00Z`;
      const endDate = `${bulkDeleteEndDate}T23:59:59Z`;
      
      const result = await onBulkDeleteByDate(startDate, endDate);
      console.log("Resultado da exclusão em massa:", result);
      
      if (result.success) {
        setToastMessage(`Exclusão concluída: ${result.count} removidos, ${result.skipped || 0} ignorados.`);
        setShowToast(true);
        setShowBulkDeleteModal(false);
        setBulkDeleteStartDate('');
        setBulkDeleteEndDate('');
      } else {
        alert("Erro ao realizar exclusão em massa.");
      }
    } catch (error) {
      console.error("Erro ao chamar onBulkDeleteByDate:", error);
      alert("Erro ao processar solicitação.");
    } finally {
      setIsBulkDeleting(false);
    }
  };

  const handleSaveSubscription = async (subData: Partial<Subscription>) => {
      try {
          const { id, ...data } = subData;
          const payload = { ...data, company_id: companyId };
          
          // Se o subData trouxer um ID próprio, usamos ele. 
          // Caso contrário, usamos o editingSubscription.id (comportamento original)
          const targetId = id || (editingSubscription?.id && !editingSubscription.id.startsWith('ghost-') ? editingSubscription.id : null);

          if (targetId && !isRenewing) {
             const { error } = await supabase.from('subscriptions').update(payload).eq('id', targetId);
             if (error) throw error;
          } else {
             const { error } = await supabase.from('subscriptions').insert([payload]);
             if (error) throw error;
          }
          if (refreshData) refreshData();
          setToastMessage("Assinatura salva com sucesso!");
          setShowToast(true);
      } catch (error: any) {
          console.error("Erro ao salvar assinatura", error);
          alert(`Erro ao salvar assinatura: ${error.message || 'Verifique sua conexão'}`);
      }
  };

  const handleDeleteSubscription = async (id: string) => {
      if (id.startsWith('ghost-')) {
          const customerId = id.replace('ghost-', '');
          if (window.confirm("Remover status de assinante deste cliente?")) {
              await supabase.from('customers').update({ is_subscriber: false }).eq('id', customerId);
              if (refreshData) refreshData();
          }
          return;
      }
      if (window.confirm("Deseja excluir permanentemente esta assinatura?")) {
          await supabase.from('subscriptions').delete().eq('id', id);
          if (refreshData) refreshData();
      }
  };

  const handleRenovarClick = (sub: Subscription) => {
      const oldEndStr = sub.end_date?.split('T')[0];
      if (!oldEndStr) return;
      
      const newStart = parseSafeDate(oldEndStr)!;
      const newEnd = new Date(newStart);
      
      if (sub.frequency === 'Anual') newEnd.setUTCFullYear(newEnd.getUTCFullYear() + 1);
      else newEnd.setUTCMonth(newEnd.getUTCMonth() + 1);
      
      setEditingSubscription({ 
          ...sub, 
          id: '', 
          start_date: oldEndStr, 
          end_date: newEnd.toISOString().split('T')[0], 
          payment_date: null, 
          commission_payment_date: null, 
          status: 'active' 
      }); 
      setIsRenewing(true); 
      setIsSubFormOpen(true);
  };

  const formatDateCell = (dateStr?: string) => {
    if (!dateStr) return { day: '--', month: '---', year: '----' };
    const date = new Date(dateStr);
    // Usar métodos UTC para garantir que a data exibida seja a mesma que foi salva,
    // evitando deslocamentos de fuso horário que podem subtrair um dia.
    const day = date.getUTCDate().toString().padStart(2, '0');
    const monthNames = ['JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN', 'JUL', 'AGO', 'SET', 'OUT', 'NOV', 'DEZ'];
    return { day, month: monthNames[date.getUTCMonth()], year: date.getUTCFullYear() };
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#F3F6F9] dark:bg-[#1a1b2e] overflow-hidden transition-colors">
      <header className="bg-white dark:bg-[#23243a] h-[90px] px-4 lg:px-10 flex justify-between items-center shrink-0 border-b border-gray-100 dark:border-white/5 sticky top-0 z-50 transition-colors">
          <div className="flex items-center gap-4">
              <button onClick={toggleSidebar} className="lg:hidden p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-xl transition-colors">
                  <List size={26} />
              </button>
              <div>
                  <h1 className="text-[23px] font-mono font-black text-gray-900 dark:text-white tracking-tighter uppercase leading-none italic">Clientes</h1>
                  <p className="text-[10px] text-gray-400 font-black uppercase tracking-[0.3em] mt-1 hidden sm:block">Gestão de Relacionamento</p>
              </div>
          </div>
          <div className="flex items-center gap-4">
              <button className="hidden sm:flex items-center gap-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400 bg-white dark:bg-white/5 px-4 py-2 rounded-xl border border-slate-200 dark:border-white/5 hover:bg-slate-50 transition-all">
                  <HelpCircle size={14} /> Ajuda
              </button>
              <UserMenu />
          </div>
      </header>

      {/* FILTROS TIPO DE CLIENTE */}
      <div className="px-4 md:px-8 mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex bg-white dark:bg-[#23243a] p-1.5 rounded-2xl border border-slate-100 dark:border-white/5 shadow-sm transition-all overflow-x-auto no-scrollbar w-full sm:w-auto">
              <button 
                onClick={() => setCustomerTypeFilter('all')}
                className={`px-4 sm:px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${customerTypeFilter === 'all' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'text-slate-400 hover:text-slate-600 dark:hover:text-white'}`}
              >
                  Todos ({stats.total})
              </button>
              <button 
                onClick={() => {
                  setCustomerTypeFilter('subscribers');
                  setShowSubscriptionColumns(true);
                }}
                className={`px-4 sm:px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap flex items-center gap-2 ${customerTypeFilter === 'subscribers' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'text-slate-400 hover:text-slate-600 dark:hover:text-white'}`}
              >
                  <CalendarDays size={12} /> Assinantes ({stats.subscribers})
              </button>
              <button 
                onClick={() => setCustomerTypeFilter('partners')}
                className={`px-4 sm:px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap flex items-center gap-2 ${customerTypeFilter === 'partners' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'text-slate-400 hover:text-slate-600 dark:hover:text-white'}`}
              >
                  <Star size={12} /> Parceiros ({stats.partners})
              </button>
              <button 
                onClick={() => setCustomerTypeFilter('portal')}
                className={`px-4 sm:px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap flex items-center gap-2 ${customerTypeFilter === 'portal' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'text-slate-400 hover:text-slate-600 dark:hover:text-white'}`}
              >
                  <Users size={12} /> Portal ({stats.portal})
              </button>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
            <button 
              onClick={() => setShowSubscriptionColumns(!showSubscriptionColumns)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border ${showSubscriptionColumns ? 'bg-teal-500 text-white border-teal-600 shadow-lg shadow-teal-100' : 'bg-white dark:bg-[#23243a] text-slate-400 border-slate-100 dark:border-white/5'}`}
            >
              <List size={14} /> {showSubscriptionColumns ? 'Ocultar Assinaturas' : 'Ver Assinaturas'}
            </button>
            <div className="hidden sm:flex items-center gap-2 text-[10px] font-bold text-indigo-500 uppercase tracking-widest">
                <CheckCircle2 size={14} /> Visualizando {filteredCustomers.length} de {stats.total}
            </div>
          </div>
      </div>

      <div className="px-4 md:px-8 mb-4 flex flex-col md:flex-row items-center gap-3 md:gap-4 shrink-0">
        <div className="flex-1 relative group w-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="BUSCAR POR NOME, FANTASIA, RAZÃO, CPF, CNPJ OU TELEFONE..." 
            className="w-full bg-white dark:bg-[#23243a] dark:text-white border-none rounded-xl pl-12 pr-4 py-3 md:py-3.5 text-[11px] font-bold shadow-sm outline-none focus:ring-2 focus:ring-teal-500/20 transition-all placeholder:text-slate-300"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="flex items-center gap-2 md:gap-4 w-full md:w-auto overflow-x-auto no-scrollbar pb-1 md:pb-0">
          <div className="relative flex-1 min-w-[110px] md:min-w-[200px]">
            <button 
              onClick={() => setIsMonthPickerOpen(!isMonthPickerOpen)}
              className="w-full flex items-center justify-between px-3 md:px-5 py-3 md:py-3.5 bg-white dark:bg-[#23243a] dark:text-white rounded-xl shadow-sm text-[10px] md:text-[11px] font-bold text-slate-600 whitespace-nowrap"
            >
              <span className="truncate">{months.find(m => m.id === selectedMonth)?.label}</span>
              <ChevronDown size={14} className="ml-1 md:ml-2 text-slate-400 shrink-0" />
            </button>
            {isMonthPickerOpen && (
              <div className="absolute top-full right-0 mt-2 w-full bg-white dark:bg-[#23243a] rounded-xl shadow-xl border border-slate-100 dark:border-white/5 z-50 py-2 animate-in fade-in zoom-in-95">
                {months.map(m => (
                  <button key={m.id} onClick={() => { setSelectedMonth(m.id); setIsMonthPickerOpen(false); }} className="w-full text-left px-5 py-2.5 text-[10px] font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5 uppercase">
                    {m.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          <button onClick={() => setIsImportOpen(true)} className="p-3 md:p-3.5 bg-white dark:bg-[#23243a] text-slate-400 rounded-xl shadow-sm border border-slate-100 dark:border-white/5 hover:text-slate-600 transition-all shrink-0"><Download size={18} className="md:w-5 md:h-5"/></button>
          <button 
            onClick={() => setShowBulkDeleteModal(true)}
            className="p-3 md:p-3.5 bg-white dark:bg-[#23243a] text-rose-400 rounded-xl shadow-sm border border-slate-100 dark:border-white/5 hover:text-rose-600 transition-all shrink-0"
            title="Limpeza por Período"
          >
            <Trash2 size={18} className="md:w-5 md:h-5"/>
          </button>
          <button 
            onClick={() => { setEditingCustomerId(null); setIsFormOpen(true); }}
            className="flex items-center justify-center gap-1.5 md:gap-2 bg-[#2dd4bf] hover:bg-[#14b8a6] text-white px-4 md:px-6 py-3 md:py-3.5 rounded-xl text-[10px] md:text-[11px] font-black uppercase tracking-widest shadow-lg shadow-teal-500/20 transition-all active:scale-95 shrink-0 whitespace-nowrap"
          >
            <Plus size={16} strokeWidth={3} className="md:w-[18px] md:h-[18px]" /> <span className="hidden sm:inline">Novo Cliente</span><span className="sm:hidden">Novo</span>
          </button>
        </div>
      </div>

      <div className="hidden lg:flex flex-1 overflow-hidden px-8 pb-6">
        <div className="h-full bg-white dark:bg-[#1a1b2e] rounded-[1rem] shadow-2xl border border-slate-200 dark:border-white/5 overflow-hidden flex flex-col">
          <div className="flex-1 overflow-auto relative custom-scrollbar">
            <table className="w-full text-left border-separate border-spacing-0 min-w-[1400px]">
              <thead className="sticky top-0 z-30">
                <tr className="bg-[#1a1b2e] text-white text-[10px] font-black uppercase tracking-widest">
                  <th className="sticky left-0 z-40 bg-[#1a1b2e] px-4 py-3 border-b border-r border-white/10 text-center w-12">#</th>
                  <th className="sticky left-12 z-40 bg-[#1a1b2e] px-6 py-3 border-b border-r border-white/10 min-w-[120px]">DATA</th>
                  <th className="sticky left-[10.5rem] z-40 bg-[#1a1b2e] px-6 py-3 border-b border-r border-white/10 min-w-[250px]">Contato (Responsável)</th>
                  
                  {showSubscriptionColumns ? (
                    <>
                      <th className="px-6 py-3 border-b border-r border-white/10 min-w-[120px] text-center">Vencimento</th>
                      <th className="px-6 py-3 border-b border-r border-white/10 min-w-[200px]">Dados do Assinante</th>
                      <th className="px-6 py-3 border-b border-r border-white/10 min-w-[250px]">Plano & Progresso</th>
                      <th className="px-6 py-3 border-b border-r border-white/10 min-w-[120px] text-center">Status</th>
                      <th className="px-6 py-3 border-b border-r border-white/10 min-w-[150px]">Valor da Fatura</th>
                      <th className="px-6 py-3 border-b border-r border-white/10 min-w-[150px]">Origem / Indicação</th>
                    </>
                  ) : (
                    <>
                      <th className="px-6 py-3 border-b border-r border-white/10 min-w-[250px]">Empresa (Razão Social)</th>
                      <th className="px-6 py-3 border-b border-r border-white/10 min-w-[250px]">Empresa (Nome de Fantasia)</th>
                      <th className="px-6 py-3 border-b border-r border-white/10 min-w-[200px]">e-mail</th>
                      <th className="px-6 py-3 border-b border-r border-white/10 min-w-[150px]">Telefone</th>
                    </>
                  )}
                  
                  <th className="px-6 py-3 border-b border-r border-white/10 text-center w-24">Assinante</th>
                  <th className="px-6 py-3 border-b border-r border-white/10 text-center w-24">Parceiro</th>
                  <th className="sticky right-0 z-40 bg-[#1a1b2e] px-6 py-3 border-b border-white/10 text-right w-32">Ações</th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-[#1a1b2e]">
                {customersWithSubs.length === 0 ? (
                  <tr><td colSpan={showSubscriptionColumns ? 13 : 10} className="py-20 text-center text-slate-300 font-bold uppercase text-xs tracking-widest bg-white dark:bg-[#23243a]">Nenhum cliente encontrado</td></tr>
                ) : (
                  customersWithSubs.map((customer, index) => {
                    const dateInfo = formatDateCell(customer.createdAt);
                    const sub = customer.subscription;
                    const statusColor = sub ? getStatusColor(sub) : null;
                    const dateBadge = sub && !sub._isGhost ? getDateBadge(sub.end_date) : null;
                    
                    let progress = 0;
                    if (sub && !sub._isGhost && sub.start_date && sub.end_date) {
                        const start = parseSafeDate(sub.start_date)?.getTime() || 0;
                        const end = parseSafeDate(sub.end_date)?.getTime() || 0;
                        const now = new Date().getTime();
                        if (end > start) progress = Math.min(Math.max(((now - start) / (end - start)) * 100, 0), 100);
                    }

                    return (
                      <tr key={customer.id} className="hover:bg-teal-50/30 dark:hover:bg-teal-500/5 transition-colors group">
                        <td className="sticky left-0 z-20 bg-white dark:bg-[#1a1b2e] px-4 py-2 border-b border-r border-slate-100 dark:border-white/5 text-center text-[10px] font-bold text-slate-400">
                          {(currentPage - 1) * ITEMS_PER_PAGE + index + 1}
                        </td>
                        <td className="sticky left-12 z-20 bg-white dark:bg-[#1a1b2e] px-6 py-2 border-b border-r border-slate-100 dark:border-white/5">
                          <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400">{dateInfo.day}/{dateInfo.month}/{dateInfo.year}</span>
                        </td>
                        <td className="sticky left-[10.5rem] z-20 bg-white dark:bg-[#1a1b2e] px-6 py-2 border-b border-r border-slate-100 dark:border-white/5 shadow-[4px_0_8px_-4px_rgba(0,0,0,0.05)]">
                          <div className="flex flex-col">
                            <div className="flex items-center gap-2">
                              <span className="text-[11px] font-black text-indigo-900 dark:text-slate-200 uppercase truncate block max-w-[230px]" title={customer.name}>{customer.name}</span>
                              {portalUserIds.has(customer.id) && (
                                <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)] animate-pulse shrink-0" title="Cadastro habilitado na área do assinante" />
                              )}
                            </div>
                            {showSubscriptionColumns && (
                              <div className="flex items-center gap-2 mt-0.5 opacity-70">
                                <span className="text-[9px] font-bold text-indigo-700 dark:text-indigo-400 flex items-center gap-1"><Phone size={8}/> {customer.phone || '-'}</span>
                              </div>
                            )}
                          </div>
                        </td>

                        {showSubscriptionColumns ? (
                          <>
                            <td className="px-6 py-2 border-b border-r border-slate-100 dark:border-white/5 text-center">
                              {dateBadge ? (
                                <div className={`inline-flex flex-col items-center justify-center rounded-lg w-10 h-10 border shadow-sm ${statusColor?.label === 'Vencido' ? 'bg-rose-50 text-rose-700 border-rose-100' : statusColor?.label === 'Pago' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-indigo-50 text-indigo-700 border-indigo-100'}`}>
                                  <span className="text-base font-black leading-none">{dateBadge.day}</span>
                                  <span className="text-[7px] font-bold leading-none mt-0.5 uppercase">{dateBadge.month}</span>
                                </div>
                              ) : sub?._isGhost ? (
                                <span className="text-[10px] font-bold text-amber-500 uppercase">Pendente</span>
                              ) : '-'}
                            </td>
                            <td className="px-6 py-2 border-b border-r border-slate-100 dark:border-white/5">
                              <div className="flex flex-col gap-0.5">
                                <span className="text-[10px] font-bold text-slate-600 dark:text-slate-300 uppercase truncate">{customer.cpf || customer.cnpj || 'Sem Documento'}</span>
                                <span className="text-[9px] font-medium text-slate-400 truncate">{customer.email || 'Sem e-mail'}</span>
                              </div>
                            </td>
                            <td className="px-6 py-2 border-b border-r border-slate-100 dark:border-white/5">
                              {sub && !sub._isGhost ? (
                                <div className="space-y-1">
                                  <div className="flex flex-col gap-0.5">
                                    <span className="text-[10px] font-black text-indigo-900 dark:text-slate-200 uppercase truncate max-w-[200px]" title={sub.provider}>
                                      {sub.provider}
                                    </span>
                                    <span className="inline-flex items-center w-fit px-1.5 py-0.5 rounded text-[8px] font-black bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-500/20 uppercase tracking-wide">
                                      {sub.frequency || 'Mensal'}
                                    </span>
                                  </div>
                                  <div className="flex items-center justify-between gap-2">
                                    <div className="flex-1 h-1 bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden">
                                      <div className={`h-full transition-all duration-1000 ${progress > 90 ? 'bg-rose-500' : progress > 70 ? 'bg-amber-500' : 'bg-indigo-500'}`} style={{ width: `${progress}%` }} />
                                    </div>
                                    <span className="text-[8px] font-black text-slate-400">{Math.round(progress)}%</span>
                                  </div>
                                </div>
                              ) : sub?._isGhost ? (
                                <button 
                                  onClick={() => {
                                      setEditingSubscription({ customer_id: customer.id, company_id: companyId, status: 'active', frequency: 'Mensal', value: 0 } as any);
                                      setIsRenewing(false);
                                      setIsSubFormOpen(true);
                                  }}
                                  className="text-[9px] font-black text-amber-600 hover:text-amber-700 underline uppercase tracking-widest"
                                >
                                  Configurar Plano
                                </button>
                              ) : '-'}
                            </td>
                            <td className="px-6 py-2 border-b border-r border-slate-100 dark:border-white/5 text-center">
                              {statusColor ? (
                                <div className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest ${statusColor.bg} ${statusColor.text} border ${statusColor.border}`}>
                                  <statusColor.icon size={8} strokeWidth={3} />
                                  {statusColor.label}
                                </div>
                              ) : '-'}
                            </td>
                            <td className="px-6 py-2 border-b border-r border-slate-100 dark:border-white/5">
                              <span className="text-[11px] font-black text-indigo-900 dark:text-slate-200">
                                {sub?.value ? sub.value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : '-'}
                              </span>
                            </td>
                            <td className="px-6 py-2 border-b border-r border-slate-100 dark:border-white/5">
                              <span className="text-[10px] font-bold text-indigo-900 dark:text-slate-300 uppercase truncate block max-w-[150px]">{sub?.referral || '-'}</span>
                            </td>
                          </>
                        ) : (
                          <>
                            <td className="px-6 py-2 border-b border-r border-slate-100 dark:border-white/5">
                              <span className="text-[10px] font-bold text-indigo-900 dark:text-slate-300 uppercase truncate block max-w-[230px]">{customer.socialReason || '-'}</span>
                            </td>
                            <td className="px-6 py-2 border-b border-r border-slate-100 dark:border-white/5">
                              <span className="text-[10px] font-bold text-indigo-900 dark:text-slate-300 uppercase truncate block max-w-[230px]">{customer.fantasyName || '-'}</span>
                            </td>
                            <td className="px-6 py-2 border-b border-r border-slate-100 dark:border-white/5">
                              <span className="text-[10px] font-bold text-indigo-700 underline truncate block max-w-[180px]">{customer.email || '-'}</span>
                            </td>
                            <td className="px-6 py-2 border-b border-r border-slate-100 dark:border-white/5">
                              <span className="text-[10px] font-bold text-indigo-900 dark:text-slate-300">{customer.phone || '-'}</span>
                            </td>
                          </>
                        )}

                        <td className="px-6 py-2 border-b border-r border-slate-100 dark:border-white/5">
                           <div className="flex justify-center">
                              <button 
                                onClick={() => handleToggleSubscriber(customer)}
                                className={`relative w-8 h-4 rounded-full transition-all duration-300 ${customer.isSubscriber ? 'bg-indigo-600 shadow-lg shadow-indigo-200' : 'bg-slate-200 dark:bg-white/10'}`}
                              >
                                <div className={`absolute top-0.5 left-0.5 w-3 h-3 bg-white rounded-full transition-transform duration-300 ${customer.isSubscriber ? 'translate-x-4' : 'translate-x-0'}`}></div>
                              </button>
                           </div>
                        </td>
                        <td className="px-6 py-2 border-b border-r border-slate-100 dark:border-white/5">
                           <div className="flex justify-center">
                              <button 
                                onClick={() => handleTogglePartner(customer)}
                                className={`relative w-8 h-4 rounded-full transition-all duration-300 ${customer.isPartner ? 'bg-amber-500 shadow-lg shadow-amber-100' : 'bg-slate-200 dark:bg-white/10'}`}
                              >
                                <div className={`absolute top-0.5 left-0.5 w-3 h-3 bg-white rounded-full transition-transform duration-300 ${customer.isPartner ? 'translate-x-4' : 'translate-x-0'}`}></div>
                              </button>
                           </div>
                        </td>
                        <td className="sticky right-0 z-20 px-6 py-2 border-b border-slate-100 dark:border-white/5 text-right bg-white dark:bg-[#1a1b2e] shadow-[-4px_0_8px_-4px_rgba(0,0,0,0.05)]">
                          <div className="flex justify-end gap-1.5">
                            {showSubscriptionColumns && sub && !sub._isGhost && (
                              <button 
                                onClick={() => handleRenovarClick(sub)}
                                className="p-1.5 text-indigo-500 hover:bg-indigo-50 dark:hover:bg-white/5 rounded-lg transition-colors"
                                title="Renovar"
                              >
                                <RefreshCcw size={14}/>
                              </button>
                            )}
                            <button 
                              onClick={() => {
                                if (showSubscriptionColumns && sub) {
                                  setEditingSubscription(sub._isGhost ? { ...sub, id: '' } : sub);
                                  setIsRenewing(false);
                                  setIsSubFormOpen(true);
                                } else {
                                  handleEditClick(customer);
                                }
                              }} 
                              className="p-1.5 text-slate-400 hover:text-indigo-600 transition-colors"
                              title={showSubscriptionColumns ? "Editar Assinatura" : "Editar Cliente"}
                            >
                              {showSubscriptionColumns && sub ? <Settings size={14}/> : <Edit2 size={14}/>}
                            </button>
                            <button onClick={() => setCustomerToDelete({ id: customer.id, name: customer.name })} className="p-1.5 text-slate-400 hover:text-rose-500 transition-colors"><Trash2 size={14}/></button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* MOBILE VIEW */}
      <div className="flex lg:hidden flex-1 overflow-hidden px-2 sm:px-4 pb-6">
        <div className="h-full w-full bg-white dark:bg-[#1a1b2e] rounded-[1rem] shadow-2xl border border-slate-200 dark:border-white/5 overflow-hidden flex flex-col">
          <div className="flex-1 overflow-auto relative custom-scrollbar">
            <table className="w-full text-left border-separate border-spacing-0 table-fixed">
              <thead className="sticky top-0 z-30">
                <tr className="bg-[#1a1b2e] text-white text-[10px] font-black uppercase tracking-widest">
                  <th className="bg-[#1a1b2e] px-2 py-3 border-b border-white/10 w-[18%] text-center">Data</th>
                  <th className="bg-[#1a1b2e] px-2 py-3 border-b border-white/10 w-[52%]">Contato</th>
                  <th className="bg-[#1a1b2e] px-2 py-3 border-b border-white/10 w-[30%] text-right">Telefone</th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-[#1a1b2e]">
                {customersWithSubs.length === 0 ? (
                  <tr><td colSpan={3} className="py-10 text-center text-slate-300 font-bold uppercase text-xs tracking-widest">Nenhum cliente encontrado</td></tr>
                ) : (
                  customersWithSubs.map((customer) => {
                    const dateInfo = formatDateCell(customer.createdAt);
                    return (
                      <tr 
                        key={customer.id} 
                        onClick={() => { setEditingCustomerId(customer.id); setIsFormOpen(true); }}
                        className="hover:bg-teal-50/30 dark:hover:bg-teal-500/5 transition-colors active:bg-slate-50 dark:active:bg-white/5 cursor-pointer"
                      >
                        <td className="px-1 py-3 border-b border-slate-100 dark:border-white/5 align-top text-center">
                          <div className="flex flex-col items-center justify-center bg-slate-50 dark:bg-white/5 rounded-lg w-10 h-10 mx-auto border border-slate-100 dark:border-white/10">
                            <span className="text-sm font-black text-slate-700 dark:text-slate-200 leading-none">{dateInfo.day}</span>
                            <span className="text-[8px] font-bold text-slate-500 dark:text-slate-400 uppercase mt-0.5">{dateInfo.month}</span>
                          </div>
                        </td>
                        <td className="px-2 py-3 border-b border-slate-100 dark:border-white/5 align-top">
                          <div className="flex flex-col gap-0.5 min-w-0">
                            <span className="text-[11px] font-black text-indigo-900 dark:text-slate-200 uppercase truncate">{customer.name}</span>
                            <span className="text-[9px] font-semibold text-slate-500 dark:text-slate-400 uppercase truncate">{customer.socialReason || '-'}</span>
                            <span className="text-[9px] font-medium text-slate-400 dark:text-slate-500 uppercase truncate">{customer.fantasyName || '-'}</span>
                          </div>
                        </td>
                        <td className="px-2 py-3 border-b border-slate-100 dark:border-white/5 align-top text-right">
                          {customer.phone ? (
                            <a 
                              href={`https://wa.me/${customer.phone.replace(/\D/g, '').startsWith('55') ? customer.phone.replace(/\D/g, '') : '55' + customer.phone.replace(/\D/g, '')}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 hover:underline whitespace-nowrap truncate block"
                            >
                              {customer.phone}
                            </a>
                          ) : (
                            <span className="text-[10px] font-bold text-slate-600 dark:text-slate-300 whitespace-nowrap truncate block">-</span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* BARRA DE PAGINAÇÃO FLUTUANTE (FLOATING UI) */}
      {totalPages > 1 && (
          <div className="fixed bottom-8 left-1/2 -translate-x-1/2 w-[90%] max-w-lg z-[60] animate-in slide-in-from-bottom-6 fade-in duration-500">
              <div className="bg-white/80 dark:bg-[#23243a]/90 backdrop-blur-md border border-slate-200/50 dark:border-white/10 rounded-full px-6 py-3 shadow-[0_20px_50px_rgba(0,0,0,0.15)] dark:shadow-[0_20px_50px_rgba(0,0,0,0.3)] flex items-center justify-between gap-4 transition-all">
                  
                  <div className="flex items-center gap-1.5 shrink-0">
                      <span className="flex h-2 w-2 rounded-full bg-indigo-500 animate-pulse"></span>
                      <p className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest hidden sm:block">
                          {filteredCustomers.length} clientes
                      </p>
                  </div>
                  
                  <div className="flex items-center gap-2">
                      <button 
                          onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                          disabled={currentPage === 1}
                          className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${currentPage === 1 ? 'text-slate-300 dark:text-slate-700 cursor-not-allowed' : 'text-indigo-600 dark:text-indigo-400 hover:bg-slate-100 dark:hover:bg-white/10 active:scale-90 shadow-sm'}`}
                      >
                          <ChevronLeft size={22} strokeWidth={3} />
                      </button>
                      
                      <div className="px-5 py-1.5 bg-slate-50 dark:bg-black/20 rounded-full border border-slate-200 dark:border-white/5">
                          <span className="text-xs font-black text-slate-800 dark:text-white uppercase tracking-tighter whitespace-nowrap">
                              Pág. {currentPage} <span className="text-slate-300 dark:text-slate-600 mx-1">/</span> {totalPages}
                          </span>
                      </div>

                      <button 
                          onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                          disabled={currentPage === totalPages}
                          className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${currentPage === totalPages ? 'text-slate-300 dark:text-slate-700 cursor-not-allowed' : 'text-indigo-600 dark:text-indigo-400 hover:bg-slate-100 dark:hover:bg-white/10 active:scale-90 shadow-sm'}`}
                      >
                          <ChevronRight size={22} strokeWidth={3} />
                      </button>
                  </div>

                  <div className="hidden sm:block shrink-0">
                       <div className="text-[9px] font-black text-white bg-indigo-600 px-3 py-1 rounded-full uppercase tracking-tighter">
                          {ITEMS_PER_PAGE} p/ pág.
                       </div>
                  </div>
              </div>
          </div>
      )}

      <SubscriptionForm 
        isOpen={isSubFormOpen}
        onClose={() => setIsSubFormOpen(false)}
        customers={customers}
        onSave={handleSaveSubscription}
        initialData={editingSubscription}
        isRenewing={isRenewing}
        companyId={companyId}
        onDelete={editingSubscription && editingSubscription.id && !editingSubscription.id.startsWith('ghost-') && !isRenewing ? () => handleDeleteSubscription(editingSubscription.id) : undefined}
      />

      {customerToDelete && (
        <div className="fixed inset-0 bg-black/60 z-[150] flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white dark:bg-[#23243a] rounded-[2rem] w-full max-sm:max-w-sm shadow-2xl p-10 text-center animate-in zoom-in-95 border dark:border-white/5">
            <div className="w-20 h-20 bg-rose-50 dark:bg-rose-500/10 rounded-full flex items-center justify-center mx-auto mb-6 text-rose-500">
              <AlertTriangle size={40} />
            </div>
            <h3 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tight mb-2">Excluir Cliente?</h3>
            <p className="text-sm text-slate-400 mb-8 leading-relaxed">Deseja remover <b>{customerToDelete.name}</b> permanentemente?</p>
            <div className="flex flex-col gap-3">
              <button onClick={handleConfirmDelete} disabled={isDeleting} className="w-full py-4 bg-rose-500 text-white font-black rounded-2xl shadow-xl transition-all active:scale-95 flex items-center justify-center gap-2">
                {isDeleting ? <Loader2 className="animate-spin" size={20}/> : <Trash2 size={20}/>} EXCLUIR AGORA
              </button>
              <button onClick={() => setCustomerToDelete(null)} className="w-full py-4 bg-slate-100 text-slate-500 font-bold rounded-2xl">CANCELAR</button>
            </div>
          </div>
        </div>
      )}

      <CustomerImportModal 
        isOpen={isImportOpen} 
        onClose={() => setIsImportOpen(false)} 
        onImport={async (list) => { await onImportCustomers(list); setIsImportOpen(false); }} 
        existingCustomers={customers} 
      />
      <Toast message={toastMessage} isVisible={showToast} onClose={() => setShowToast(false)} />

      {showBulkDeleteModal && (
        <div className="fixed inset-0 bg-black/60 z-[150] flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white dark:bg-[#23243a] rounded-[2rem] w-full max-w-md shadow-2xl p-10 text-center animate-in zoom-in-95 border dark:border-white/5">
            <div className="w-20 h-20 bg-rose-50 dark:bg-rose-500/10 rounded-full flex items-center justify-center mx-auto mb-6 text-rose-500">
              <AlertTriangle size={40} />
            </div>
            <h3 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tight mb-2">Limpeza em Massa</h3>
            <p className="text-sm text-slate-400 mb-6 leading-relaxed">
              Escolha o período de criação dos clientes que deseja remover permanentemente.
            </p>

            {bulkDeleteStartDate && bulkDeleteEndDate && (
              <div className="mb-6 p-3 bg-rose-50 dark:bg-rose-500/10 rounded-xl border border-rose-100 dark:border-rose-500/20">
                <p className="text-[10px] font-black text-rose-600 dark:text-rose-400 uppercase tracking-widest">
                  Período Selecionado:
                </p>
                <p className="text-xs font-bold text-slate-700 dark:text-white mt-1">
                  {new Date(bulkDeleteStartDate + 'T12:00:00').toLocaleDateString('pt-BR')} até {new Date(bulkDeleteEndDate + 'T12:00:00').toLocaleDateString('pt-BR')}
                </p>
              </div>
            )}

            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="text-left">
                <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 ml-1">Data Inicial</label>
                <div className="relative">
                  <Calendar size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    type="date" 
                    value={bulkDeleteStartDate}
                    onChange={(e) => setBulkDeleteStartDate(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl pl-9 pr-3 py-3 text-xs font-bold text-slate-700 dark:text-white outline-none focus:ring-2 focus:ring-rose-500/20 transition-all"
                  />
                </div>
              </div>
              <div className="text-left">
                <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 ml-1">Data Final</label>
                <div className="relative">
                  <Calendar size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    type="date" 
                    value={bulkDeleteEndDate}
                    onChange={(e) => setBulkDeleteEndDate(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-xl pl-9 pr-3 py-3 text-xs font-bold text-slate-700 dark:text-white outline-none focus:ring-2 focus:ring-rose-500/20 transition-all"
                  />
                </div>
              </div>
            </div>

            <div className="bg-amber-50 dark:bg-amber-500/5 border border-amber-100 dark:border-amber-500/10 rounded-2xl p-4 mb-8">
              <p className="text-[10px] font-bold text-amber-700 dark:text-amber-400 uppercase leading-relaxed text-center">
                Atenção: Clientes com vendas ou assinaturas ativas serão preservados automaticamente.
              </p>
            </div>

            <div className="flex flex-col gap-3">
              <button 
                onClick={handleBulkDelete} 
                disabled={isBulkDeleting} 
                className="w-full py-4 bg-rose-500 text-white font-black rounded-2xl shadow-xl transition-all active:scale-95 flex items-center justify-center gap-2"
              >
                {isBulkDeleting ? <Loader2 className="animate-spin" size={20}/> : <Trash2 size={20}/>} CONFIRMAR EXCLUSÃO
              </button>
              <button 
                onClick={() => setShowBulkDeleteModal(false)} 
                disabled={isBulkDeleting}
                className="w-full py-4 bg-slate-100 text-slate-500 font-bold rounded-2xl"
              >
                CANCELAR
              </button>
            </div>
          </div>
        </div>
      )}

      <CustomerModal 
        isOpen={isFormOpen}
        onClose={() => { setIsFormOpen(false); setEditingCustomerId(null); }}
        companyId={companyId}
        initialData={currentEditingCustomer}
        customers={customers}
        subscriptions={subscriptions}
        portalUserIds={portalUserIds}
        onSave={async (c) => {
          console.log("CustomersScreen onSave triggered", { editingCustomerId, customer: c });
          let success = false;
          if (editingCustomerId) {
            success = await onUpdateCustomer(c);
          } else {
            const res = await onAddCustomer(c);
            success = !!res;
          }
          console.log("CustomersScreen onSave result:", success);
          if (success) {
            setToastMessage(editingCustomerId ? "Cliente atualizado com sucesso!" : "Cliente cadastrado com sucesso!");
            setShowToast(true);
          }
          return success;
        }}
      />
    </div>
  );
};

export default CustomersScreen;
