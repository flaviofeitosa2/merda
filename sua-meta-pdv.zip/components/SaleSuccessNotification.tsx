
import React, { useEffect } from 'react';
import { X, FileText, Printer, Check } from 'lucide-react';
import { Sale, PaymentMethod } from '../types';

interface SaleSuccessNotificationProps {
  isVisible: boolean;
  sale: Sale | null;
  onClose: () => void;
  onViewReceipt: () => void;
}

const SaleSuccessNotification: React.FC<SaleSuccessNotificationProps> = ({ 
  isVisible, 
  sale, 
  onClose, 
  onViewReceipt 
}) => {
  
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        onClose();
      }, 5000); 
      return () => clearTimeout(timer);
    }
  }, [isVisible, onClose]);

  const handlePrint = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!sale) return;

    const paymentMethodLabels: Record<PaymentMethod, string> = {
        money: 'Dinheiro',
        debit: 'Cartão de Débito',
        credit: 'Cartão de Crédito',
        pix: 'Pix',
        others: 'Outros',
        credit_tab: 'Venda Fiado',
        link: 'Link de Pagamento'
    };

    const currency = (val: number) => val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    const dateStr = new Date(sale.date).toLocaleString('pt-BR');
    const subtotalValue = sale.subtotal ?? sale.total;
    const discountValue = sale.discount ?? 0;

    const itemsHtml = sale.items.map(item => `
      <div style="margin-bottom: 5px;">
        <div style="font-weight: 800; width: 100%; word-wrap: break-word; font-size: 13px;">${item.name.toUpperCase()}</div>
        <div style="display: flex; justify-content: space-between; font-size: 12px;">
          <span>${item.quantity} x ${currency(item.price)}</span>
          <span>${currency(item.price * item.quantity)}</span>
        </div>
      </div>
    `).join('');

    let paymentDetailsHtml = '';
    if (sale.payments && sale.payments.length > 0) {
        paymentDetailsHtml = sale.payments.map(p => `
            <div style="display: flex; justify-content: space-between; margin-top: 2px;">
                <span>${paymentMethodLabels[p.method].toUpperCase()}</span>
                <span>${currency(p.amount)}</span>
            </div>
        `).join('');
    } else {
        paymentDetailsHtml = `
            <div style="display: flex; justify-content: space-between; margin-top: 2px;">
                <span>${paymentMethodLabels[sale.paymentMethod].toUpperCase()}</span>
                <span>${currency(sale.total)}</span>
            </div>
        `;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            @page { margin: 0; size: 80mm auto; }
            * { box-sizing: border-box; -webkit-print-color-adjust: exact; }
            body { 
              font-family: ui-monospace, 'Cascadia Code', 'Source Code Pro', Menlo, Consolas, 'Courier New', monospace; 
              margin: 0; 
              padding: 5mm; 
              width: 80mm; 
              font-size: 12px; 
              line-height: 1.3;
              color: #000;
              background: #fff;
            }
            .content-wrapper { width: 70mm; margin: 0 auto; }
            .center { text-align: center; }
            .bold { font-weight: 800; }
            .divider { border-top: 1.5px dashed #000; margin: 10px 0; width: 100%; }
            .header { margin-bottom: 12px; }
            .footer { margin-top: 20px; font-size: 11px; }
            .flex { display: flex; justify-content: space-between; }
            h1 { font-size: 18px; margin: 0 0 4px 0; padding: 0; text-transform: uppercase; letter-spacing: -0.5px; }
            p { margin: 3px 0; }
            .total-row { font-size: 15px; margin-top: 6px; border-top: 1px solid #000; padding-top: 4px; }
          </style>
        </head>
        <body>
          <div class="content-wrapper">
            <div class="header center">
              <h1>ESPAÇO DIGITAL</h1>
              <p class="bold">Informática e Serviços</p>
              <p>Vicente Pires - Brasília/DF</p>
              <p>CNPJ: 11.353.879/0001-71</p>
            </div>
            <div class="divider"></div>
            <div>
              <p><span class="bold">CUPOM:</span> #${sale.code}</p>
              <p><span class="bold">DATA:</span> ${dateStr}</p>
              <p><span class="bold">CLIENTE:</span> ${sale.clientName.toUpperCase()}</p>
            </div>
            <div class="divider"></div>
            <div style="font-size: 11px; text-transform: uppercase; margin-bottom: 6px;" class="flex bold">
              <span>DESCRIÇÃO / QTD</span>
              <span>TOTAL</span>
            </div>
            <div>${itemsHtml}</div>
            <div class="divider"></div>
            <div class="flex"><span>SUBTOTAL</span><span>${currency(subtotalValue)}</span></div>
            <div class="flex"><span>DESCONTOS</span><span>- ${currency(discountValue)}</span></div>
            <div class="flex bold total-row">
              <span>TOTAL PAGO</span>
              <span>${currency(sale.total)}</span>
            </div>
            <div class="divider"></div>
            <div class="bold" style="margin-bottom: 4px; text-decoration: underline;">PAGAMENTO</div>
            ${paymentDetailsHtml}
            ${sale.change && sale.change > 0 ? `<div class="flex bold" style="margin-top: 4px;"><span>TROCO</span><span>${currency(sale.change)}</span></div>` : ''}
            <div class="divider"></div>
            <div class="footer center">
              <p class="bold" style="font-size: 12px;">*** RECIBO DE PAGAMENTO ***</p>
              <p>Obrigado pela preferência!</p>
            </div>
          </div>
        </body>
      </html>
    `;

    const printWindow = window.open('', '_blank', 'width=450,height=600');
    if (printWindow) {
        printWindow.document.write(htmlContent);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
            printWindow.print();
        }, 500);
    }
  };

  if (!isVisible || !sale) return null;

  return (
    <div className="fixed bottom-8 left-1/2 transform -translate-x-1/2 z-[70] animate-in slide-in-from-bottom-10 fade-in duration-300">
      <div className="bg-[#4ade80] dark:bg-[#22c55e] text-gray-800 dark:text-white rounded-xl shadow-2xl p-3 pr-4 flex items-center gap-4 min-w-[320px] sm:min-w-[400px] border border-[#22c55e]/20 dark:border-white/10 transition-colors">
        <div className="relative flex-shrink-0 ml-2">
            <div className="w-10 h-10 rounded-full border-2 border-white/40 flex items-center justify-center">
                <Check size={20} className="text-white font-bold" strokeWidth={3} />
            </div>
            <div className="absolute inset-0 rounded-full border-t-2 border-white animate-spin opacity-60"></div>
        </div>
        <div className="flex-1 flex flex-col justify-center">
            <span className="text-xs font-semibold text-emerald-900 dark:text-emerald-50 uppercase tracking-wide">Venda concluída!</span>
            <span className="text-xl font-extrabold text-gray-800 dark:text-white tracking-tight">
                {sale.total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </span>
        </div>
        <div className="flex items-center gap-2">
            <button 
                onClick={handlePrint}
                className="bg-white/20 hover:bg-white/40 dark:bg-black/20 dark:hover:bg-black/40 text-emerald-900 dark:text-white p-2.5 rounded-lg font-bold shadow-sm transition-colors"
                title="Imprimir Cupom"
            >
                <Printer size={20} />
            </button>
            <button 
                onClick={onViewReceipt}
                className="bg-white dark:bg-[#23243a] hover:bg-gray-50 dark:hover:bg-[#2d2e42] text-gray-700 dark:text-white px-4 py-2.5 rounded-lg font-bold text-sm shadow-sm flex items-center gap-2 transition-colors whitespace-nowrap"
            >
                <FileText size={16} />
                <span className="hidden sm:inline">Ver recibo</span>
            </button>
        </div>
        <button onClick={onClose} className="text-emerald-900/40 dark:text-white/40 hover:text-emerald-900 dark:hover:text-white transition-colors -mt-8 -mr-1">
            <X size={16} />
        </button>
      </div>
    </div>
  );
};

export default SaleSuccessNotification;
