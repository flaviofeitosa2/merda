
import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { 
  Wallet, PieChart, List, Plus, ChevronDown as ChevronDownIcon, ChevronRight, ChevronLeft, ChevronUp,
  Eye, EyeOff, Landmark, Folder, Trash2, Edit2, X, Loader2, Search, Scale, 
  Utensils, Car, ShoppingBasket, Home, Zap, Book, CornerDownRight, Calendar, 
  CreditCard as CreditCardIcon, Tag, Activity, History, Building, 
  TrendingDown, TrendingUp, RefreshCw, AlertTriangle, CheckCircle2, AlertCircle, Paperclip, MoreVertical,
  PlusCircle, Pencil, ArrowDownLeft, ArrowUpRight as ArrowUpRightIcon,
  Check, Scan, Layers, ArrowRightLeft, Target, Award, BarChart3,
  DollarSign, FileText, Smartphone, ChevronsLeft, ChevronsRight,
  Calculator, PenLine, Pin, Repeat, CreditCard, Bookmark, Filter
} from 'lucide-react';
import { startOfMonth, endOfMonth, startOfDay, endOfDay } from 'date-fns';
import { Wallet as WalletType, FinanceCategory, FinanceTransaction, UserProfile } from '../types';
import UserMenu from './UserMenu';
import { supabase } from '../supabaseClient';
import Toast from './Toast';

const PRESET_COLORS = [
  { id: 'blue', hex: '#0099ff' },
  { id: 'purple', hex: '#9933cc' },
  { id: 'green', hex: '#669900' },
  { id: 'orange', hex: '#ff8800' },
  { id: 'rose', hex: '#e11d48' },
  { id: 'teal', hex: '#0d9488' },
  { id: 'amber', hex: '#d97706' },
  { id: 'slate', hex: '#475569' }
];

const PRESET_ICONS = [
  { id: 'food', icon: Utensils, label: 'Alimentação' },
  { id: 'transport', icon: Car, label: 'Transporte' },
  { id: 'shopping', icon: ShoppingBasket, label: 'Compras' },
  { id: 'home', icon: Home, label: 'Casa' },
  { id: 'health', icon: Activity, label: 'Saúde' },
  { id: 'energy', icon: Zap, label: 'Energia/Luz' },
  { id: 'education', icon: Book, label: 'Educação' },
  { id: 'leisure', icon: Landmark, label: 'Lazer' },
  { id: 'services', icon: Scan, label: 'Serviços' },
  { id: 'card', icon: CreditCardIcon, label: 'Cartões' },
  { id: 'tag', icon: Tag, label: 'Geral' }
];

const MONTHS_LABELS_LOCAL = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
];

const ITEMS_PER_PAGE = 50;

/**
 * MOTOR DE DATAS BLINDADO V6
 */
const toLocalISO = (date: Date) => {
    try {
        if (!date || isNaN(date.getTime())) return new Date().toISOString().split('T')[0];
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    } catch (e) {
        return new Date().toISOString().split('T')[0];
    }
};

const getLocalDateISO = () => toLocalISO(new Date());

const formatCurrency = (val: number) => {
  if (val === undefined || val === null || !isFinite(val) || isNaN(val)) return 'R$ 0,00';
  return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
};

const initialTxState = {
    description: '', amount: '', type: 'expense' as 'income' | 'expense' | 'transfer',
    walletId: '', categoryId: '', date: getLocalDateISO(), status: 'paid' as 'paid' | 'pending' | 'cancelled', 
    notes: '', tags: [] as string[], isFixed: false, isInstallment: false, installments_count: 1,
    ignore_transaction: false, targetWalletId: '', origin: 'manual' as 'manual' | 'pos' | 'transfer'
};

const getSafeTimestamp = (dateStr: any, origin: string = 'pos') => {
  if (!dateStr || typeof dateStr !== 'string') return 0;
  try {
      if (origin === 'pos' || dateStr.includes('T') || dateStr.includes('Z')) {
          const t = new Date(dateStr).getTime();
          return isNaN(t) ? 0 : t;
      }
      const datePart = dateStr.split(/[T ]/)[0];
      if (!datePart) return 0;
      const parts = datePart.split('-');
      if (parts.length < 3) return 0;
      const [y, m, d] = parts.map(Number);
      const t = new Date(y, m - 1, d, 12, 0, 0).getTime();
      return isNaN(t) ? 0 : t;
  } catch (e) {
      return 0;
  }
};

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs));
}

const FinanceScreen: React.FC<{ 
  toggleSidebar?: () => void; 
  userProfile: UserProfile; 
  sales: Sale[];
  initialWallets?: WalletType[];
  initialCategories?: FinanceCategory[];
  initialTransactions?: FinanceTransaction[];
  onRefresh?: (options?: { only?: ('products' | 'customers' | 'sales' | 'finance' | 'users' | 'wallets' | 'categories' | 'subscriptions')[] }) => void;
  onNavigate?: (view: string) => void;
}> = ({ toggleSidebar, userProfile, sales = [], initialWallets = [], initialCategories = [], initialTransactions = [], onRefresh, onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'transactions' | 'wallets' | 'credit_cards' | 'categories'>('dashboard'); 
  const [isLoading, setIsLoading] = useState(false);
  const isLoadingRef = useRef(false);
  const [wallets, setWallets] = useState<WalletType[]>(initialWallets);
  const [categories, setCategories] = useState<FinanceCategory[]>(initialCategories);
  const [transactions, setTransactions] = useState<FinanceTransaction[]>(initialTransactions);

  // Sync with props if they change
  useEffect(() => {
    setWallets(initialWallets);
  }, [initialWallets]);

  useEffect(() => {
    setCategories(initialCategories);
  }, [initialCategories]);

  useEffect(() => {
    setTransactions(initialTransactions);
  }, [initialTransactions]);
  
  // Combinar transações manuais com vendas do PDV (sincronia total)
  const allTransactions = useMemo(() => {
    // 1. Filtrar transações manuais e transferências (ignorando as que vieram do POS para evitar duplicidade)
    const manualAndTransfers = transactions.filter(t => t.origin !== 'pos');
    
    // 2. Converter Vendas do PDV em transações financeiras virtuais
    const posTransactions: FinanceTransaction[] = [];
    sales.forEach(sale => {
      const payments = sale.payments || [];
      if (payments.length > 0) {
        payments.forEach((p, idx) => {
          // Tentar encontrar wallet_id se estiver vazio
          let finalWalletId = p.wallet_id;
          if (!finalWalletId) {
            const method = p.method || sale.paymentMethod;
            const matchingWallet = wallets.find(w => 
              w.name.toLowerCase().includes(method.toLowerCase()) ||
              (method === 'money' && w.name.toLowerCase().includes('dinheiro')) ||
              (method === 'pix' && w.name.toLowerCase().includes('pix'))
            );
            finalWalletId = matchingWallet?.id || '';
          }

          posTransactions.push({
            id: `sale-${sale.id}-${idx}`,
            description: `VENDA PDV #${sale.code} - ${sale.clientName}`.toUpperCase(),
            amount: p.amount,
            type: 'income',
            wallet_id: finalWalletId,
            date: sale.date,
            status: sale.status === 'completed' ? 'paid' : (sale.status === 'cancelled' ? 'cancelled' : 'pending'),
            company_id: sale.company_id || '',
            origin: 'pos',
            notes: `Venda Ref: ${sale.code}`
          });
        });
      } else {
        // Tentar encontrar wallet_id por método se não houver pagamentos detalhados
        const matchingWallet = wallets.find(w => 
          w.name.toLowerCase().includes(sale.paymentMethod.toLowerCase()) ||
          (sale.paymentMethod === 'money' && w.name.toLowerCase().includes('dinheiro')) ||
          (sale.paymentMethod === 'pix' && w.name.toLowerCase().includes('pix'))
        );

        posTransactions.push({
          id: `sale-${sale.id}`,
          description: `VENDA PDV #${sale.code} - ${sale.clientName}`.toUpperCase(),
          amount: sale.total,
          type: 'income',
          wallet_id: matchingWallet?.id || '',
          date: sale.date,
          status: sale.status === 'completed' ? 'paid' : (sale.status === 'cancelled' ? 'cancelled' : 'pending'),
          company_id: sale.company_id || '',
          origin: 'pos',
          notes: `Venda Ref: ${sale.code}`
        });
      }
    });
    
    return [...manualAndTransfers, ...posTransactions].sort((a, b) => getSafeTimestamp(b.date) - getSafeTimestamp(a.date));
  }, [transactions, sales, wallets]);

  const getStatementTransactions = useCallback((cardId: string, refDate: Date) => {
    const card = wallets.find(w => w.id === cardId);
    if (!card) return [];
    
    const closingDay = card.closing_day || 5;
    const targetMonth = refDate.getMonth();
    const targetYear = refDate.getFullYear();
    
    return allTransactions.filter(t => {
      if (t.wallet_id !== cardId) return false;
      
      const tDate = new Date(getSafeTimestamp(t.date));
      const tDay = tDate.getDate();
      const tMonth = tDate.getMonth();
      const tYear = tDate.getFullYear();
      
      if (tMonth === targetMonth && tYear === targetYear && tDay <= closingDay) return true;
      
      const prevMonthDate = new Date(targetYear, targetMonth - 1, 1);
      if (tMonth === prevMonthDate.getMonth() && tYear === prevMonthDate.getFullYear() && tDay > closingDay) return true;
      
      return false;
    });
  }, [wallets, allTransactions]);

  const [showValues, setShowValues] = useState(true);
  
  const [isFabOpen, setIsFabOpen] = useState(false);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [mobileActionTx, setMobileActionTx] = useState<FinanceTransaction | null>(null);
  const [isModalExpanded, setIsModalExpanded] = useState(false);
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  
  const [viewDate, setViewDate] = useState(() => {
      const d = new Date(); d.setDate(1); d.setHours(12, 0, 0, 0); return d;
  });
  
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);
  const [cardStatementDate, setCardStatementDate] = useState(new Date());
  const [categoryViewType, setCategoryViewType] = useState<'expense' | 'income'>('expense');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'expense' | 'income' | 'transfer'>('all');
  const [filterWallet, setFilterWallet] = useState<string>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [isFilterDropdownOpen, setIsFilterDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsFilterDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Modais
  const [isTxModalOpen, setIsTxModalOpen] = useState(false);
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [isCategoryPickerOpen, setIsCategoryPickerOpen] = useState(false);
  const [categorySearch, setCategorySearch] = useState('');

  const [editingCategory, setEditingCategory] = useState<FinanceCategory | null>(null);
  const [editingWallet, setEditingWallet] = useState<WalletType | null>(null);
  const [editingTx, setEditingTx] = useState<FinanceTransaction | null>(null);
  const [categoryToDelete, setCategoryToDelete] = useState<FinanceCategory | null>(null);
  const [txToDelete, setTxToDelete] = useState<FinanceTransaction | null>(null);
  const [walletToDelete, setWalletToDelete] = useState<WalletType | null>(null);

  // Forms
  const [txForm, setTxForm] = useState(initialTxState);
  const [walletForm, setWalletForm] = useState({ 
    name: '', 
    type: 'bank', 
    balance: '', 
    color: '#6366f1', 
    initial_balance: '', 
    closing_day: 1, 
    due_day: 5 
  });
  const [categoryForm, setCategoryForm] = useState({ 
      name: '', type: 'expense' as 'income' | 'expense', color: '#0099ff', icon: 'tag', parentId: null as string | null, description: ''
  });

  const fetchData = useCallback(async (options?: any) => {
      if (onRefresh) {
          onRefresh(options);
      }
      const companyId = userProfile?.company_id;
      if (!companyId) return;
      // Para carteiras e categorias, buscamos localmente se necessário, mas geralmente App.tsx já as provê
      if (!options || options.only?.includes('wallets') || options.only?.includes('categories')) {
          setIsLoading(true);
          try {
              const [wRes, cRes] = await Promise.all([
                  supabase.from('wallets').select('*').eq('company_id', companyId).order('name'),
                  supabase.from('finance_categories').select('*').eq('company_id', companyId).order('name')
              ]);
              if (wRes.data) {
                  setWallets((wRes.data as any[]).map((w: any) => ({ ...w, balance: Number(w.balance || 0) })));
              }
              if (cRes.data) setCategories(cRes.data as FinanceCategory[]);
          } catch (err) {
              console.error("Error fetching data", err);
          } finally { 
              setIsLoading(false); 
          }
      }
  }, [userProfile?.company_id, onRefresh]);

  useEffect(() => { fetchData(); }, [fetchData]);

  // Helper para lidar com datas de forma robusta (evita problemas de fuso horário)

  // Resetar página quando os filtros mudam
  useEffect(() => {
    setCurrentPage(1);
  }, [viewDate, filterType, filterWallet, searchQuery, activeTab]);

  // Filtro base de transações
  const filteredTransactions = useMemo(() => {
    const start = startOfMonth(viewDate).getTime();
    const end = endOfMonth(viewDate).getTime();

    return allTransactions.filter(t => {
        const time = getSafeTimestamp(t.date);
        const matchesPeriod = time >= start && time <= end;
        const matchesType = filterType === 'all' || t.type === filterType;
        const matchesWallet = filterWallet === 'all' || t.wallet_id === filterWallet || t.target_wallet_id === filterWallet;
        const matchesSearch = !searchQuery || 
                             t.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                             t.amount.toString().includes(searchQuery);
        return matchesPeriod && matchesType && matchesWallet && matchesSearch;
    }).sort((a, b) => {
        const timeA = getSafeTimestamp(a.date);
        const timeB = getSafeTimestamp(b.date);
        return sortOrder === 'desc' ? timeB - timeA : timeA - timeB;
    });
  }, [allTransactions, viewDate, filterType, filterWallet, searchQuery, sortOrder]);

  // Estatísticas do Mês
  const stats = useMemo(() => {
    const start = startOfMonth(viewDate).getTime();
    const end = endOfMonth(viewDate).getTime();

    // 1. Estatísticas Globais do Mês (Independente de filtros de busca/wallet)
    // Sincronizado com a lógica do Dashboard
    const monthTxs = allTransactions.filter(t => {
        const time = getSafeTimestamp(t.date);
        return time >= start && time <= end && (t.status === 'paid' || !t.status);
    });

    const income = monthTxs.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0);
    const expense = monthTxs.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0);
    
    // Saldo Total é sempre a soma de todas as carteiras (exceto crédito)
    // Isso representa o patrimônio líquido imediato
    const totalBalance = wallets.reduce((acc, w) => acc + (w.type === 'credit' ? 0 : w.balance), 0);

    // 2. Estatísticas Filtradas (O que aparece nos cards do dashboard lateral)
    const filteredMonthTxs = filteredTransactions.filter(t => t.status === 'paid' || !t.status);
    
    let filteredIncome = 0;
    let filteredExpense = 0;

    filteredMonthTxs.forEach(t => {
        const amount = Number(t.amount);
        if (filterWallet === 'all') {
            // Visão Global: Apenas entradas e saídas reais (transferências são neutras no consolidado)
            if (t.type === 'income') filteredIncome += amount;
            else if (t.type === 'expense') filteredExpense += amount;
        } else {
            // Visão de Carteira Específica: Entradas, Saídas e Transferências que afetam esta conta
            // Como um professor de matemática diria: "Estamos somando os vetores que incidem sobre este ponto"
            if (t.type === 'income' && t.wallet_id === filterWallet) {
                filteredIncome += amount;
            } else if (t.type === 'expense' && t.wallet_id === filterWallet) {
                filteredExpense += amount;
            } else if (t.type === 'transfer') {
                if (t.target_wallet_id === filterWallet) {
                    filteredIncome += amount; // Fluxo de entrada para a carteira
                } else if (t.wallet_id === filterWallet) {
                    filteredExpense += amount; // Fluxo de saída da carteira
                }
            }
        }
    });

    // 3. Previsões (A Pagar / A Receber)
    const pendingTxs = filteredTransactions.filter(t => t.status === 'pending');
    let toReceive = 0;
    let toPay = 0;

    pendingTxs.forEach(t => {
        const amount = Number(t.amount);
        if (t.type === 'income') toReceive += amount;
        else if (t.type === 'expense') toPay += amount;
    });

    return { 
      income, 
      expense, 
      monthBalance: income - expense, 
      totalBalance,
      filteredIncome,
      filteredExpense,
      filteredBalance: filteredIncome - filteredExpense,
      toReceive,
      toPay
    };
  }, [allTransactions, wallets, viewDate, filteredTransactions, filterWallet]);

  const totalPages = Math.ceil(filteredTransactions.length / ITEMS_PER_PAGE);

  // Agrupamento de Transações paginadas por Dia
  const groupedTransactions = useMemo(() => {
    const startIdx = (currentPage - 1) * ITEMS_PER_PAGE;
    const paginatedItems = filteredTransactions.slice(startIdx, startIdx + ITEMS_PER_PAGE);

    const groups: Record<string, FinanceTransaction[]> = {};
    paginatedItems.forEach(t => {
        const day = t.date.split('T')[0];
        if (!groups[day]) groups[day] = [];
        groups[day].push(t);
    });
    return Object.entries(groups).sort((a, b) => {
        return sortOrder === 'desc' ? b[0].localeCompare(a[0]) : a[0].localeCompare(b[0]);
    });
  }, [filteredTransactions, currentPage, sortOrder]);

  // OrganizedCategories for category management tab
  const organizedCategories = useMemo(() => {
    const parents = categories.filter(c => !c.parent_id && c.type === categoryViewType);
    return parents.map(p => ({
        ...p,
        subcategories: categories.filter(c => c.parent_id === p.id)
    }));
  }, [categories, categoryViewType]);

  const expenseBreakdown = useMemo(() => {
      const breakdown: any[] = [];
      const parentCategories = categories.filter(c => !c.parent_id && c.type === 'expense');
      
      const start = new Date(viewDate.getFullYear(), viewDate.getMonth(), 1, 0, 0, 0).getTime();
      const end = new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 0, 23, 59, 59).getTime();
      
      const monthExpenses = allTransactions.filter(t => {
          const time = getSafeTimestamp(t.date);
          return time >= start && time <= end && t.type === 'expense' && (t.status === 'paid' || !t.status);
      });

      parentCategories.forEach(parent => {
          const subcats = categories.filter(c => c.parent_id === parent.id);
          const subIds = subcats.map(s => s.id);
          
          const parentTxs = monthExpenses.filter(t => t.category_id === parent.id);
          const childrenTxs = monthExpenses.filter(t => subIds.includes(t.category_id || ''));
          
          const parentAmount = parentTxs.reduce((acc, t) => acc + t.amount, 0);
          const childrenAmount = childrenTxs.reduce((acc, t) => acc + t.amount, 0);
          const totalCategoryAmount = parentAmount + childrenAmount;
          const totalTxsCount = parentTxs.length + childrenTxs.length;

          const subsList = subcats.map(s => {
              const sTxs = monthExpenses.filter(t => t.category_id === s.id);
              const amt = sTxs.reduce((acc, t) => acc + t.amount, 0);
              return { name: s.name, amount: amt, count: sTxs.length };
          }).sort((a, b) => b.amount - a.amount);

          if (parentAmount > 0) {
              subsList.push({ name: `${parent.name} (OUTROS)`, amount: parentAmount, count: parentTxs.length });
          }

          breakdown.push({
              id: parent.id,
              name: parent.name,
              icon: parent.icon || 'tag',
              color: parent.color || '#6366f1',
              total: totalCategoryAmount,
              count: totalTxsCount,
              subcategories: subsList
          });
      });

      return breakdown.sort((a, b) => b.total - a.total);
  }, [categories, allTransactions, viewDate]);

  const handleSaveTransaction = async (keepOpen = false) => {
    console.log("handleSaveTransaction called, editingTx:", editingTx ? editingTx.id : 'new', "amount:", txForm.amount);
    if (isLoadingRef.current) {
        console.log("handleSaveTransaction blocked by isLoadingRef");
        return;
    }
    isLoadingRef.current = true;
    setIsLoading(true);
    if (!txForm.description || !txForm.amount || !txForm.walletId) {
        isLoadingRef.current = false;
        setIsLoading(false);
        setToastMessage("Preencha os campos obrigatórios");
        setShowToast(true);
        return;
    }
    if (txForm.type === 'transfer' && !txForm.targetWalletId) {
        isLoadingRef.current = false;
        setIsLoading(false);
        setToastMessage("Selecione a conta de destino");
        setShowToast(true);
        return;
    }
    if (txForm.type === 'transfer' && txForm.walletId === txForm.targetWalletId) {
        isLoadingRef.current = false;
        setIsLoading(false);
        setToastMessage("As contas de origem e destino devem ser diferentes");
        setShowToast(true);
        return;
    }
    
    try {
        let rawAmount = txForm.amount.toString().replace(/[^\d.,]/g, '');
        const lastComma = rawAmount.lastIndexOf(',');
        const lastDot = rawAmount.lastIndexOf('.');
        
        if (lastComma > lastDot) {
            rawAmount = rawAmount.replace(/\./g, '').replace(',', '.');
        } else if (lastDot > lastComma) {
            if (lastComma === -1 && rawAmount.length - lastDot === 4) {
                rawAmount = rawAmount.replace(/\./g, '');
            } else {
                rawAmount = rawAmount.replace(/,/g, '');
            }
        }
        const amount = parseFloat(rawAmount) || 0;
        console.log("Parsed amount:", amount);
        const payload = {
            description: txForm.description.trim().toUpperCase(),
            amount,
            type: txForm.type,
            wallet_id: txForm.walletId,
            target_wallet_id: txForm.type === 'transfer' ? txForm.targetWalletId : null,
            category_id: txForm.categoryId || null,
            date: txForm.date + (txForm.date.includes('T') ? '' : 'T12:00:00Z'),
            status: txForm.status,
            company_id: userProfile.company_id,
            origin: editingTx ? editingTx.origin : 'manual',
            notes: txForm.notes,
            is_fixed: txForm.isFixed,
            installments_count: txForm.isInstallment ? txForm.installments_count : 1,
            tags: txForm.tags
        };

        if (editingTx) {
            // ... (logica de update mantida, mas agora vamos atualizar o estado local tambem)
             const { error } = await supabase.from('finance_transactions').update(payload).eq('id', editingTx.id);
             if (error) throw error;
             
             // Atualização otimista do estado local
             setTransactions(prev => prev.map(t => t.id === editingTx.id ? { ...t, ...payload, amount: payload.amount } as any : t));
        } else {
            console.log("Inserting new transaction:", payload);
            const { data: newTx, error } = await supabase.from('finance_transactions').insert([payload]).select().single();
            if (error) throw error;
            
            // Atualização otimista do estado local
            if (newTx) {
                setTransactions(prev => [newTx as any, ...prev]);
            }
        }

        // Não esperar o refresh total para fechar o modal
        fetchData({ only: ['finance', 'wallets'] });
        
        if (!keepOpen) {
            setIsTxModalOpen(false);
            setEditingTx(null);
            setIsModalExpanded(false);
        }
        setTxForm(initialTxState);
        setToastMessage(editingTx ? "Transação atualizada!" : "Transação registrada!");
        setShowToast(true);
    } catch (err: any) {
        setToastMessage("Erro ao salvar: " + err.message);
        setShowToast(true);
    } finally {
        isLoadingRef.current = false;
        setIsLoading(false);
    }
  };

  const handleToggleTxStatus = async (tx: FinanceTransaction) => {
    if (isLoading) return;
    if (tx.status === 'cancelled') return;
    setIsLoading(true);
    try {
        const newStatus = (tx.status === 'paid' || !tx.status) ? 'pending' : 'paid';
        const amount = Number(tx.amount);
        const { error } = await supabase.from('finance_transactions').update({ status: newStatus }).eq('id', tx.id);
        if (error) throw error;

        if (tx.type === 'transfer') {
            const source = wallets.find(w => w.id === tx.wallet_id);
            const target = wallets.find(w => w.id === tx.target_wallet_id);
            if (source && target) {
                let newSourceBal = Number(source.balance);
                let newTargetBal = Number(target.balance);
                if (newStatus === 'paid') {
                    newSourceBal -= amount;
                    newTargetBal += amount;
                } else {
                    newSourceBal += amount;
                    newTargetBal -= amount;
                }
                const [res1, res2] = await Promise.all([
                    supabase.from('wallets').update({ balance: newSourceBal }).eq('id', source.id),
                    supabase.from('wallets').update({ balance: newTargetBal }).eq('id', target.id)
                ]);
                if (res1.error) throw res1.error;
                if (res2.error) throw res2.error;
            }
        } else {
            const wallet = wallets.find(w => w.id === tx.wallet_id);
            if (wallet) {
                let newBalance = Number(wallet.balance);
                if (newStatus === 'paid') {
                    if (tx.type === 'income') newBalance += amount;
                    else if (tx.type === 'expense') newBalance -= amount;
                } else {
                    if (tx.type === 'income') newBalance -= amount;
                    else if (tx.type === 'expense') newBalance += amount;
                }
                const { error: walletError } = await supabase.from('wallets').update({ balance: newBalance }).eq('id', wallet.id);
                if (walletError) throw walletError;
            }
        }

        await fetchData();
        setToastMessage(`Status alterado para ${newStatus === 'paid' ? 'Pago' : 'Pendente'}`);
        setShowToast(true);
    } catch (err: any) {
        console.error("Erro ao alterar status:", err);
        setToastMessage("Erro ao alterar status: " + (err.message || "Erro desconhecido"));
        setShowToast(true);
    } finally {
        setIsLoading(false);
    }
  };

  const handleDeleteTransaction = async () => {
    if (isLoading) return;
    if (!txToDelete) return;

    // Prevent deleting virtual POS transactions
    if (txToDelete.id.startsWith('sale-')) {
        setToastMessage("Vendas do PDV devem ser canceladas no Histórico.");
        setShowToast(true);
        setTxToDelete(null);
        return;
    }

    // Prevent cancelling already cancelled transactions
    if (txToDelete.status === 'cancelled') {
        setToastMessage("Esta transação já está cancelada.");
        setShowToast(true);
        setTxToDelete(null);
        return;
    }

    setIsLoading(true);
    try {
        const { error } = await supabase.from('finance_transactions').delete().eq('id', txToDelete.id);
        if (error) throw error;

        await fetchData();
        setTxToDelete(null);
        setToastMessage("Transação cancelada e valor estornado.");
        setShowToast(true);
    } catch (err: any) {
        console.error("Erro ao cancelar:", err);
        setToastMessage("Erro ao cancelar: " + (err.message || "Erro desconhecido"));
        setShowToast(true);
    } finally {
        setIsLoading(false);
    }
  };

  const handleEditTx = (tx: FinanceTransaction) => {
    // Prevent editing virtual POS transactions
    if (tx.id.startsWith('sale-')) {
        setToastMessage("Transações do PDV não podem ser editadas manualmente.");
        setShowToast(true);
        return;
    }
    setEditingTx(tx);
    setTxForm({
        description: tx.description,
        amount: tx.amount.toString(),
        type: tx.type,
        walletId: tx.wallet_id,
        targetWalletId: tx.target_wallet_id || '',
        categoryId: tx.category_id || '',
        date: tx.date.split('T')[0],
        status: tx.status || 'paid',
        notes: tx.notes || '',
        tags: tx.tags || [],
        isFixed: !!tx.is_fixed,
        isInstallment: (tx.installments_count || 1) > 1,
        installments_count: tx.installments_count || 1,
        ignore_transaction: false,
        origin: tx.origin || 'manual'
    });
    setIsModalExpanded(false);
    setIsTxModalOpen(true);
  };

  const handleSaveWallet = async () => {
    if (isLoading) return;
    if (!walletForm.name.trim()) {
        setToastMessage("Nome é obrigatório");
        setShowToast(true);
        return;
    }
    setIsLoading(true);
    try {
        const parseAmount = (val: string | number | undefined | null) => {
            if (val === undefined || val === null) return 0;
            let raw = val.toString().replace(/[^\d.,\-]/g, '');
            const lastComma = raw.lastIndexOf(',');
            const lastDot = raw.lastIndexOf('.');
            if (lastComma > lastDot) {
                raw = raw.replace(/\./g, '').replace(',', '.');
            } else if (lastDot > lastComma) {
                if (lastComma === -1 && raw.length - lastDot === 4) {
                    raw = raw.replace(/\./g, '');
                } else {
                    raw = raw.replace(/,/g, '');
                }
            }
            return parseFloat(raw) || 0;
        };

        if (!userProfile || !userProfile.company_id) {
            setToastMessage("Erro: Perfil do usuário ou empresa não encontrado.");
            setShowToast(true);
            setIsLoading(false);
            isLoadingRef.current = false;
            return;
        }

        const payload = {
            name: walletForm.name.trim().toUpperCase(),
            type: walletForm.type,
            color: walletForm.color,
            balance: parseAmount(walletForm.balance),
            initial_balance: parseAmount(walletForm.initial_balance),
            closing_day: isNaN(Number(walletForm.closing_day)) ? 1 : Number(walletForm.closing_day),
            due_day: isNaN(Number(walletForm.due_day)) ? 5 : Number(walletForm.due_day),
            company_id: userProfile.company_id
        };
        console.log("Payload:", payload);
        if (editingWallet) {
            const { error } = await supabase.from('wallets').update(payload).eq('id', editingWallet.id);
            if (error) throw error;
        } else {
            const { error } = await supabase.from('wallets').insert([payload]);
            if (error) throw error;
        }
        await fetchData();
        setIsWalletModalOpen(false);
        setEditingWallet(null);
        setWalletForm({ name: '', type: 'bank', balance: '', color: '#6366f1', initial_balance: '', closing_day: 1, due_day: 5 });
        setToastMessage("Carteira salva!");
        setShowToast(true);
    } catch (err: any) {
        console.error("Erro ao salvar carteira:", err);
        setToastMessage("Erro: " + (err.message || "Erro desconhecido"));
        setShowToast(true);
    } finally {
        setIsLoading(false);
    }
  };

  const handleDeleteWallet = async () => {
    if (!walletToDelete) return;
    setIsLoading(true);
    try {
        const { error } = await supabase.from('wallets').delete().eq('id', walletToDelete.id);
        if (error) throw error;

        await fetchData();
        setWalletToDelete(null);
        setToastMessage("Carteira excluída com sucesso.");
        setShowToast(true);
    } catch (err: any) {
        console.error("Erro ao excluir carteira:", err);
        setToastMessage("Erro ao excluir: " + (err.message || "Erro desconhecido"));
        setShowToast(true);
    } finally {
        setIsLoading(false);
    }
  };

  const handleSaveCategory = async () => {
    if (isLoading) return;
    if (!categoryForm.name.trim()) {
        setToastMessage("Nome é obrigatório");
        setShowToast(true);
        return;
    }
    setIsLoading(true);
    try {
        const payload = {
            name: categoryForm.name.trim().toUpperCase(),
            type: categoryForm.type,
            color: categoryForm.color,
            icon: categoryForm.icon,
            parent_id: categoryForm.parentId,
            description: categoryForm.description,
            company_id: userProfile.company_id
        };
        
        if (editingCategory) {
            await supabase.from('finance_categories').update(payload).eq('id', editingCategory.id);
        } else {
            await supabase.from('finance_categories').insert([payload]);
        }
        
        await fetchData();
        setIsCategoryModalOpen(false);
        setEditingCategory(null);
        setCategoryForm({ name: '', type: 'expense', color: '#0099ff', icon: 'tag', parentId: null, description: '' });
        setToastMessage("Categoria salva com sucesso!");
        setShowToast(true);
    } catch (err: any) {
        setToastMessage("Erro: " + err.message);
        setShowToast(true);
    } finally {
        setIsLoading(false);
    }
  };

  const handleDeleteCategory = async () => {
    if (isLoading) return;
    if (!categoryToDelete) return;
    setIsLoading(true);
    try {
        const { error } = await supabase.from('finance_categories').delete().eq('id', categoryToDelete.id);
        if (error) throw error;
        
        await fetchData();
        setCategoryToDelete(null);
        setToastMessage("Categoria removida.");
        setShowToast(true);
    } catch (err: any) {
        setToastMessage("Erro ao excluir: " + err.message);
        setShowToast(true);
    } finally {
        setIsLoading(false);
    }
  };

  const filteredPickerCategories = useMemo(() => {
    const matching = categories.filter(c => {
        const matchesType = txForm.type === 'transfer' ? true : c.type === txForm.type;
        const matchesSearch = !categorySearch || c.name.toLowerCase().includes(categorySearch.toLowerCase());
        return matchesType && matchesSearch;
    });

    const parents = matching.filter(c => !c.parent_id);
    return parents.map(p => ({
        ...p,
        subcategories: matching.filter(c => c.parent_id === p.id)
    }));
  }, [categories, txForm.type, categorySearch]);

  const selectedCategoryData = useMemo(() => {
    return categories.find(c => c.id === txForm.categoryId);
  }, [categories, txForm.categoryId]);

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#EEF2F6] dark:bg-[#1a1b2e] font-sans transition-colors">
      <header className="bg-white dark:bg-[#23243a] h-[90px] px-4 lg:px-10 flex justify-between items-center shrink-0 border-b border-gray-100 dark:border-white/5 sticky top-0 z-50 transition-colors">
          <div className="flex items-center gap-4">
              <button onClick={() => toggleSidebar?.()} className="lg:hidden p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-xl transition-colors">
                  <List size={26} />
              </button>
              <div>
                  <h1 className="text-[23px] font-mono font-black text-gray-900 dark:text-white tracking-tighter uppercase leading-none italic flex items-center gap-3">
                      Finanças 
                      <button onClick={() => setShowValues(!showValues)} className="text-gray-400 hover:text-gray-600 dark:hover:text-white transition-colors">
                          {showValues ? <Eye size={18} /> : <EyeOff size={18} />}
                      </button>
                  </h1>
                  <p className="text-[10px] text-gray-400 font-black uppercase tracking-[0.3em] mt-1 hidden sm:block">Gestão de Fluxo de Caixa e Carteiras</p>
              </div>
          </div>
          <UserMenu />
      </header>

      {/* TABS DE NAVEGAÇÃO SUPERIOR */}
      <div className="px-4 sm:px-8 py-4 flex gap-4 overflow-x-auto no-scrollbar shrink-0 border-b border-gray-200 dark:border-white/5 bg-[#EEF2F6] dark:bg-[#1a1b2e] z-10 transition-colors">
          {[
              { id: 'dashboard', label: 'Dashboard', icon: Activity },
              { id: 'transactions', label: 'Transações', icon: History },
              { id: 'wallets', label: 'Carteiras', icon: Wallet },
              { id: 'credit_cards', label: 'Cartões', icon: CreditCardIcon },
              { id: 'categories', label: 'Categorias', icon: Layers }
          ].map((tab) => (
              <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-4 sm:px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap flex items-center gap-2 ${
                      activeTab === tab.id 
                      ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200 dark:shadow-none scale-105' 
                      : 'bg-white dark:bg-white/5 text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-white/10'
                  }`}
              >
                  <tab.icon size={14} /> {tab.label}
              </button>
          ))}
      </div>

      <div className="flex-1 overflow-y-auto relative custom-scrollbar scroll-smooth">
          {isLoading && <div className="absolute inset-0 bg-white/50 dark:bg-black/50 z-[60] flex items-center justify-center backdrop-blur-sm"><Loader2 className="animate-spin text-indigo-600 dark:text-indigo-400" size={32} /></div>}

          <div className="py-6 px-4 sm:px-8">
              <div className="max-w-[1600px] mx-auto">
                  
                  {/* DASHBOARD - KPI CARDS + GRÁFICO + TABELA */}
                  {activeTab === 'dashboard' && (
                      <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
                          {/* Period Selector */}
                          <div className="flex justify-between items-center bg-white dark:bg-[#23243a] p-4 rounded-3xl border border-gray-100 dark:border-white/5 shadow-sm transition-colors">
                              <button onClick={() => { const d = new Date(viewDate); d.setMonth(d.getMonth() - 1); setViewDate(d); }} className="p-2 hover:bg-gray-100 dark:hover:bg-white/10 rounded-xl transition-all"><ChevronLeft size={20}/></button>
                              <span className="text-[10px] sm:text-sm font-black text-slate-800 dark:text-white uppercase tracking-widest">{MONTHS_LABELS_LOCAL[viewDate.getMonth()]} {viewDate.getFullYear()}</span>
                              <button onClick={() => { const d = new Date(viewDate); d.setMonth(d.getMonth() + 1); setViewDate(d); }} className="p-2 hover:bg-gray-100 dark:hover:bg-white/10 rounded-xl transition-all"><ChevronRight size={20}/></button>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                              <div className="bg-white dark:bg-[#23243a] p-6 sm:p-8 rounded-[2rem] sm:rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-white/5 flex flex-col justify-between h-40 sm:h-44 transition-all hover:shadow-xl relative overflow-hidden group">
                                  <div className="flex justify-between items-start">
                                      <div className="p-2 sm:p-3 bg-emerald-50 dark:bg-emerald-500/10 rounded-2xl text-emerald-600 dark:text-emerald-400 shadow-sm"><TrendingUp size={24} /></div>
                                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Receitas</span>
                                  </div>
                                  <div>
                                      <h3 className="text-2xl sm:text-3xl font-black text-slate-800 dark:text-white tracking-tighter tabular-nums">{showValues ? formatCurrency(stats.income) : '****'}</h3>
                                      <p className="text-[10px] font-bold text-emerald-500 uppercase mt-1">Ganhos no mês</p>
                                  </div>
                              </div>
                              <div className="bg-white dark:bg-[#23243a] p-6 sm:p-8 rounded-[2rem] sm:rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-white/5 flex flex-col justify-between h-40 sm:h-44 transition-all hover:shadow-xl relative overflow-hidden group">
                                  <div className="flex justify-between items-start">
                                      <div className="p-2 sm:p-3 bg-rose-50 dark:bg-rose-500/10 rounded-2xl text-rose-600 dark:text-rose-400 shadow-sm"><TrendingDown size={24} /></div>
                                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Despesas</span>
                                  </div>
                                  <div>
                                      <h3 className="text-2xl sm:text-3xl font-black text-slate-800 dark:text-white tracking-tighter tabular-nums">{showValues ? formatCurrency(stats.expense) : '****'}</h3>
                                      <p className="text-[10px] font-bold text-rose-500 uppercase mt-1">Gastos no mês</p>
                                  </div>
                              </div>
                              <div className="bg-[#1e293b] p-6 sm:p-8 rounded-[2rem] sm:rounded-[2.5rem] shadow-xl text-white flex flex-col justify-between h-40 sm:h-44 relative overflow-hidden group transition-all hover:scale-[1.02]">
                                  <div className="flex justify-between items-start relative z-10">
                                      <div className="p-2 sm:p-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/10 shadow-lg"><Scale size={24} /></div>
                                      <span className="text-[10px] font-black text-indigo-300 uppercase tracking-widest">Balanço</span>
                                  </div>
                                  <div className="relative z-10">
                                      <h3 className="text-2xl sm:text-3xl font-black tracking-tighter tabular-nums">{showValues ? formatCurrency(stats.monthBalance) : '****'}</h3>
                                      <p className="text-[10px] font-bold text-indigo-300 uppercase mt-1">Resultado Mensal</p>
                                  </div>
                                  <div className="absolute -bottom-4 -right-4 text-white/5 pointer-events-none group-hover:scale-110 transition-transform duration-700"><PieChart size={120} /></div>
                              </div>
                              <div className="bg-white dark:bg-[#23243a] p-6 sm:p-8 rounded-[2rem] sm:rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-white/5 flex flex-col justify-between h-40 sm:h-44 transition-all hover:shadow-xl relative overflow-hidden">
                                  <div className="flex justify-between items-start">
                                      <div className="p-2 sm:p-3 bg-indigo-50 dark:bg-indigo-500/10 rounded-2xl text-indigo-600 dark:text-indigo-400 shadow-sm"><Wallet size={24} /></div>
                                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Saldo Geral</span>
                                  </div>
                                  <div>
                                      <h3 className="text-2xl sm:text-3xl font-black text-slate-800 dark:text-white tracking-tighter tabular-nums">{showValues ? formatCurrency(stats.totalBalance) : '****'}</h3>
                                      <p className="text-[10px] font-bold text-slate-400 uppercase mt-1">Patrimônio Líquido</p>
                                  </div>
                              </div>
                          </div>

                          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                             {/* Mini Histórico */}
                             <div className="lg:col-span-5 bg-white dark:bg-[#23243a] rounded-[2rem] sm:rounded-[3rem] shadow-sm border border-slate-100 dark:border-white/5 p-6 sm:p-10 transition-colors">
                                 <div className="flex justify-between items-center mb-6 sm:mb-10">
                                     <h3 className="text-lg sm:text-xl font-black text-slate-800 dark:text-white uppercase tracking-tighter italic">Lançamentos Recentes</h3>
                                     <button onClick={() => setActiveTab('transactions')} className="text-indigo-600 font-bold text-[10px] uppercase tracking-widest hover:underline">Ver Todos</button>
                                 </div>
                                 <div className="space-y-4 sm:space-y-6">
                                     {allTransactions.slice(0, 7).map(t => {
                                         const cat = categories.find(c => c.id === t.category_id);
                                         const isIncome = t.type === 'income';
                                         const isTransfer = t.type === 'transfer';
                                         return (
                                             <div key={t.id} className="flex items-center justify-between group">
                                                 <div className="flex items-center gap-3 sm:gap-4 min-w-0">
                                                     <div className={`w-10 h-10 sm:w-11 sm:h-11 rounded-xl sm:rounded-2xl flex items-center justify-center text-white shadow-sm shrink-0 ${isTransfer ? 'bg-indigo-600' : isIncome ? 'bg-emerald-500' : 'bg-rose-500'}`}>
                                                        {isTransfer ? <ArrowRightLeft size={16}/> : isIncome ? <ArrowDownLeft size={16}/> : <ArrowUpRightIcon size={16}/>}
                                                     </div>
                                                     <div className="min-w-0">
                                                         <p className="text-[11px] sm:text-xs font-black text-slate-800 dark:text-white uppercase truncate tracking-tight">{t.description}</p>
                                                         <p className="text-[8px] sm:text-[9px] font-bold text-slate-400 uppercase tracking-widest">{cat?.name || 'Sem Categoria'}</p>
                                                     </div>
                                                 </div>
                                                 <div className="text-right shrink-0">
                                                     <p className={`text-xs sm:text-sm font-black tabular-nums tracking-tighter ${isTransfer ? 'text-indigo-600' : isIncome ? 'text-emerald-500' : 'text-rose-500'}`}>{formatCurrency(t.amount)}</p>
                                                     <p className="text-[8px] sm:text-[9px] font-bold text-slate-400 uppercase tracking-widest">{new Date(getSafeTimestamp(t.date)).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}</p>
                                                 </div>
                                             </div>
                                         );
                                     })}
                                 </div>
                             </div>

                             {/* GRÁFICO DE COMPOSIÇÃO DE GASTOS */}
                             <div className="lg:col-span-7 bg-white dark:bg-[#23243a] rounded-[2rem] sm:rounded-[3rem] shadow-sm border border-slate-100 dark:border-white/5 p-6 sm:p-10 transition-colors">
                                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 sm:mb-10 gap-4">
                                    <div>
                                        <h3 className="text-lg sm:text-xl font-black text-slate-800 dark:text-white uppercase tracking-tighter italic">Composição de Gastos</h3>
                                        <p className="text-[9px] sm:text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Sincronizado com Detalhamento Financeiro</p>
                                    </div>
                                    <div className="bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 px-3 py-1.5 sm:px-4 sm:py-2 rounded-2xl border border-rose-100 dark:border-rose-500/20">
                                        <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest">{formatCurrency(stats.expense)}</span>
                                    </div>
                                </div>

                                <div className="space-y-8 sm:space-y-12 max-h-[500px] sm:max-h-[600px] overflow-y-auto custom-scrollbar pr-2 sm:pr-4 pb-4">
                                    {expenseBreakdown.filter(c => c.total > 0).length === 0 ? (
                                        <div className="py-24 text-center">
                                            <BarChart3 size={48} className="mx-auto text-slate-100 dark:text-slate-800 mb-4" />
                                            <p className="text-sm font-black text-slate-300 dark:text-slate-700 uppercase tracking-[0.3em] italic">Sem despesas no período</p>
                                        </div>
                                    ) : (
                                        expenseBreakdown.filter(c => c.total > 0).map(cat => {
                                            const categoryPct = (cat.total / (stats.expense || 1)) * 100;
                                            return (
                                                <div key={cat.id} className="space-y-4 sm:space-y-5 group/item animate-in fade-in slide-in-from-left-4 duration-500">
                                                    <div className="flex items-center justify-between">
                                                        <div className="flex items-center gap-3 sm:gap-4 min-w-0">
                                                            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl flex items-center justify-center text-white shadow-lg shrink-0 transition-transform group-hover/item:scale-110 duration-300" style={{ backgroundColor: cat.color }}>
                                                                {React.createElement(PRESET_ICONS.find(i => i.id === cat.icon)?.icon || Tag, { size: 20 })}
                                                            </div>
                                                            <div className="min-w-0">
                                                                <span className="text-sm sm:text-base font-black text-slate-800 dark:text-white uppercase tracking-tight italic truncate block">{cat.name}</span>
                                                                <div className="flex items-center gap-1.5 sm:gap-2 mt-0.5">
                                                                    <span className="text-[7px] sm:text-[8px] font-black text-slate-400 uppercase tracking-widest">{cat.count} lançamentos</span>
                                                                    <div className="w-1 h-1 rounded-full bg-slate-200"></div>
                                                                    <span className="text-[7px] sm:text-[8px] font-black text-indigo-500 uppercase tracking-widest">{categoryPct.toFixed(1)}% do mês</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="text-right shrink-0">
                                                            <span className="text-base sm:text-lg font-black text-slate-900 dark:text-white tabular-nums tracking-tighter">{formatCurrency(cat.total)}</span>
                                                        </div>
                                                    </div>

                                                    <div className="relative h-2.5 sm:h-3 w-full bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden shadow-inner">
                                                        <div 
                                                            className="h-full rounded-full transition-all duration-1000 ease-out shadow-[0_0_15px_rgba(0,0,0,0.1)] relative overflow-hidden" 
                                                            style={{ 
                                                                width: `${categoryPct}%`, 
                                                                backgroundColor: cat.color,
                                                                backgroundImage: `linear-gradient(to right, ${cat.color}aa, ${cat.color})`
                                                            }}
                                                        >
                                                            <div className="absolute inset-0 bg-white/10 animate-pulse"></div>
                                                        </div>
                                                    </div>

                                                    <div className="pl-12 sm:pl-16 grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3">
                                                        {cat.subcategories.filter((s: any) => s.amount > 0).map((sub: any, sIdx: number) => {
                                                            const subPct = (sub.amount / cat.total) * 100;
                                                            return (
                                                                <div key={sIdx} className="flex flex-col gap-1 p-2 sm:p-3 rounded-xl sm:rounded-2xl bg-gray-50/50 dark:bg-white/5 border border-transparent hover:border-indigo-100 dark:hover:border-indigo-500/20 transition-all group/sub">
                                                                    <div className="flex justify-between items-center">
                                                                        <div className="flex items-center gap-1.5 min-w-0">
                                                                            <CornerDownRight size={10} className="text-slate-300 shrink-0" />
                                                                            <span className="text-[9px] sm:text-[10px] font-bold text-slate-600 dark:text-gray-300 uppercase truncate tracking-tight">{sub.name}</span>
                                                                        </div>
                                                                        <span className="text-[9px] sm:text-[10px] font-black text-slate-800 dark:text-white tabular-nums shrink-0">{formatCurrency(sub.amount)}</span>
                                                                    </div>
                                                                    <div className="flex items-center gap-2">
                                                                        <div className="flex-1 h-1 bg-slate-200 dark:bg-white/10 rounded-full overflow-hidden">
                                                                            <div 
                                                                                className="h-full transition-all duration-700 opacity-60 group-hover/sub:opacity-100" 
                                                                                style={{ width: `${subPct}%`, backgroundColor: cat.color }}
                                                                            ></div>
                                                                        </div>
                                                                        <span className="text-[7px] sm:text-[8px] font-black text-slate-400 uppercase">{subPct.toFixed(0)}%</span>
                                                                    </div>
                                                                </div>
                                                            );
                                                        })}
                                                    </div>
                                                </div>
                                            );
                                        })
                                    )}
                                </div>
                             </div>
                          </div>

                          {/* TABELA DETALHAMENTO FINANCEIRO */}
                          <div className="bg-white dark:bg-[#23243a] rounded-[2rem] sm:rounded-[3.5rem] shadow-xl border border-slate-100 dark:border-white/5 overflow-hidden transition-all">
                              <div className="p-6 sm:p-10 border-b border-gray-50 dark:border-white/5 bg-gray-50/20 dark:bg-white/5 flex flex-col sm:flex-row justify-between items-start sm:items-center transition-colors gap-4">
                                  <div>
                                      <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tighter italic leading-none">Detalhamento Financeiro</h3>
                                      <p className="text-[9px] sm:text-[10px] text-slate-400 font-bold uppercase mt-2 tracking-[0.4em]">Visão Analítica de todas as despesas cadastradas</p>
                                  </div>
                                  <div className="flex flex-col items-start sm:items-end">
                                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Saldo do Plano de Contas</span>
                                      <span className="text-base sm:text-lg font-black text-rose-600 dark:text-rose-400 tabular-nums leading-none mt-1">{formatCurrency(stats.expense)}</span>
                                  </div>
                              </div>
                              <div className="overflow-x-auto custom-scrollbar">
                                  <table className="w-full text-left border-separate border-spacing-0">
                                      <thead className="bg-[#f8fafc] dark:bg-white/5 text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] transition-colors">
                                          <tr>
                                              <th className="px-6 sm:px-10 py-4 sm:py-6 border-b border-gray-50 dark:border-white/5">Categoria</th>
                                              <th className="px-6 sm:px-10 py-4 sm:py-6 border-b border-gray-50 dark:border-white/5 text-center hidden sm:table-cell">Tipo</th>
                                              <th className="px-6 sm:px-10 py-4 sm:py-6 border-b border-gray-50 dark:border-white/5 text-center">Op.</th>
                                              <th className="px-6 sm:px-10 py-4 sm:py-6 border-b border-gray-50 dark:border-white/5 text-right hidden md:table-cell">Share</th>
                                              <th className="px-6 sm:px-10 py-4 sm:py-6 border-b border-gray-50 dark:border-white/5 text-right">Total</th>
                                          </tr>
                                      </thead>
                                      <tbody className="divide-y divide-gray-50 dark:divide-white/5">
                                          {expenseBreakdown.length === 0 ? (
                                              <tr>
                                                  <td colSpan={5} className="py-24 text-center">
                                                      <Folder size={48} className="mx-auto text-slate-200 dark:text-slate-800 mb-4" />
                                                      <p className="text-sm font-black text-slate-300 dark:text-slate-700 uppercase tracking-[0.3em]">Nenhuma categoria cadastrada</p>
                                                  </td>
                                              </tr>
                                          ) : (
                                              expenseBreakdown.map(cat => {
                                                  const categoryPct = (cat.total / (stats.expense || 1)) * 100;
                                                  return (
                                                      <React.Fragment key={cat.id}>
                                                          <tr className="bg-slate-50/30 dark:bg-white/5 transition-colors">
                                                              <td className="px-6 sm:px-10 py-4 sm:py-5">
                                                                  <div className="flex items-center gap-3 sm:gap-4">
                                                                      <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center text-white shadow-md shrink-0" style={{ backgroundColor: cat.color }}>
                                                                          {React.createElement(PRESET_ICONS.find(i => i.id === cat.icon)?.icon || Tag, { size: 18 })}
                                                                      </div>
                                                                      <span className="text-xs sm:text-base font-black text-slate-900 dark:text-white uppercase tracking-tight italic truncate">{cat.name}</span>
                                                                  </div>
                                                              </td>
                                                              <td className="px-6 sm:px-10 py-4 sm:py-5 text-center hidden sm:table-cell">
                                                                  <span className="px-2 py-1 bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 rounded-lg text-[8px] sm:text-[9px] font-black uppercase tracking-widest border border-rose-100 dark:border-rose-500/20">Despesa</span>
                                                              </td>
                                                              <td className="px-6 sm:px-10 py-4 sm:py-5 text-center">
                                                                  <span className="text-xs sm:text-sm font-bold text-slate-500 dark:text-gray-400">{cat.count}</span>
                                                              </td>
                                                              <td className="px-6 sm:px-10 py-4 sm:py-5 text-right hidden md:table-cell">
                                                                  <div className="flex flex-col items-end">
                                                                      <span className="text-xs sm:text-sm font-black text-slate-800 dark:text-white tabular-nums">{categoryPct.toFixed(1)}%</span>
                                                                      <div className="w-12 h-1 bg-slate-100 dark:bg-white/10 rounded-full mt-1.5 overflow-hidden">
                                                                          <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${categoryPct}%`, backgroundColor: cat.color }}></div>
                                                                      </div>
                                                                  </div>
                                                              </td>
                                                              <td className="px-6 sm:px-10 py-4 sm:py-5 text-right">
                                                                  <span className="text-sm sm:text-lg font-black text-slate-900 dark:text-white tabular-nums tracking-tighter whitespace-nowrap">{formatCurrency(cat.total)}</span>
                                                              </td>
                                                          </tr>
                                                          {cat.subcategories.map((sub: any, idx: number) => {
                                                              const subGlobalPct = (sub.amount / (stats.expense || 1)) * 100;
                                                              return (
                                                                  <tr key={`${cat.id}-sub-${idx}`} className="hover:bg-gray-50/50 dark:hover:bg-white/5 transition-colors group">
                                                                      <td className="px-6 sm:px-10 py-3 sm:py-4 pl-12 sm:pl-24 relative">
                                                                          <div className="absolute left-[30px] sm:left-[70px] top-0 bottom-0 w-px bg-slate-200 dark:bg-white/5"></div>
                                                                          <div className="flex items-center gap-2 sm:gap-3">
                                                                              <CornerDownRight size={12} className="text-slate-300 dark:text-slate-600 shrink-0" />
                                                                              <span className="text-[10px] sm:text-xs font-bold text-slate-600 dark:text-gray-300 uppercase tracking-tight truncate">{sub.name}</span>
                                                                          </div>
                                                                      </td>
                                                                      <td className="px-6 sm:px-10 py-3 sm:py-4 text-center hidden sm:table-cell">
                                                                          <span className="text-[10px] font-medium text-slate-400 uppercase tracking-widest">-</span>
                                                                      </td>
                                                                      <td className="px-6 sm:px-10 py-3 sm:py-4 text-center">
                                                                          <span className="text-[10px] sm:text-xs font-medium text-slate-400 dark:text-gray-500">{sub.count}</span>
                                                                      </td>
                                                                      <td className="px-6 sm:px-10 py-3 sm:py-4 text-right hidden md:table-cell">
                                                                          <span className="text-[10px] sm:text-xs font-bold text-slate-400 dark:text-gray-500 tabular-nums">{subGlobalPct.toFixed(2)}%</span>
                                                                      </td>
                                                                      <td className="px-6 sm:px-10 py-3 sm:py-4 text-right">
                                                                          <span className="text-[11px] sm:text-sm font-black text-slate-600 dark:text-gray-300 tabular-nums whitespace-nowrap">{formatCurrency(sub.amount)}</span>
                                                                      </td>
                                                                  </tr>
                                                              );
                                                          })}
                                                      </React.Fragment>
                                                  );
                                              })
                                          )}
                                      </tbody>
                                  </table>
                              </div>
                              <div className="p-6 sm:p-8 bg-gray-50/50 dark:bg-white/5 border-t border-gray-100 dark:border-white/5 text-center transition-colors">
                                  <p className="text-[9px] sm:text-[10px] font-black text-gray-400 uppercase tracking-[0.4em]">Auditado: Pagos em {MONTHS_LABELS_LOCAL[viewDate.getMonth()].toUpperCase()} {viewDate.getFullYear()}</p>
                              </div>
                          </div>
                      </div>
                  )}

                  {/* TRANSAÇÕES - HISTÓRICO AGRUPADO */}
                  {activeTab === 'transactions' && (
                      <div className="space-y-6 lg:space-y-8 animate-in fade-in slide-in-from-right-4 duration-500 pb-32 relative">
                          {/* FAB (Floating Action Button) */}
                          <div className="fixed bottom-10 right-10 z-[60]">
                              <div className="relative">
                                  <AnimatePresence>
                                      {isFabOpen && (
                                          <motion.div 
                                              initial={{ opacity: 0, y: 20, scale: 0.95 }}
                                              animate={{ opacity: 1, y: 0, scale: 1 }}
                                              exit={{ opacity: 0, y: 20, scale: 0.95 }}
                                              className="absolute bottom-16 right-0 bg-white dark:bg-[#23243a] rounded-3xl shadow-2xl border border-gray-100 dark:border-white/5 py-3 w-56 overflow-hidden"
                                          >
                                              {[
                                                  { id: 'expense', label: 'Despesa', icon: ArrowUpRightIcon, color: 'text-rose-500', bg: 'bg-rose-50 dark:bg-rose-500/10' },
                                                  { id: 'income', label: 'Receita', icon: ArrowDownLeft, color: 'text-emerald-500', bg: 'bg-emerald-50 dark:bg-emerald-500/10' },
                                                  { id: 'card', label: 'Despesa Cartão', icon: CreditCard, color: 'text-cyan-500', bg: 'bg-cyan-50 dark:bg-cyan-500/10' },
                                                  { id: 'transfer', label: 'Transferência', icon: ArrowRightLeft, color: 'text-indigo-500', bg: 'bg-indigo-50 dark:bg-indigo-500/10' }
                                              ].map((item) => (
                                                  <button
                                                      key={item.id}
                                                      onClick={() => {
                                                          setTxForm({
                                                              ...initialTxState,
                                                              type: item.id === 'card' ? 'expense' : (item.id as any),
                                                              walletId: item.id === 'card' ? wallets.find(w => w.type === 'credit')?.id || '' : ''
                                                          });
                                                          setIsTxModalOpen(true);
                                                          setIsFabOpen(false);
                                                      }}
                                                      className="w-full px-6 py-3.5 flex items-center gap-4 hover:bg-gray-50 dark:hover:bg-white/5 transition-colors text-left group"
                                                  >
                                                      <div className={cn("p-2 rounded-xl transition-transform group-hover:scale-110", item.bg)}>
                                                          <item.icon size={18} className={item.color} />
                                                      </div>
                                                      <span className="text-[11px] font-black uppercase tracking-widest text-slate-600 dark:text-gray-300">{item.label}</span>
                                                  </button>
                                              ))}
                                          </motion.div>
                                      )}
                                  </AnimatePresence>
                                  <motion.button 
                                      whileTap={{ scale: 0.9 }}
                                      onClick={() => setIsFabOpen(!isFabOpen)}
                                      className={cn(
                                          "w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-2xl transition-all duration-300",
                                          isFabOpen ? 'bg-rose-500 rotate-45' : 'bg-[#2dd4bf] hover:scale-110'
                                      )}
                                  >
                                      <Plus size={32} strokeWidth={3} />
                                  </motion.button>
                              </div>
                          </div>

                          {/* Financial Summary (Mobile First) */}
                          <div className="lg:hidden flex overflow-x-auto no-scrollbar gap-4 px-4 pb-4 -mx-4">
                              <motion.div 
                                  initial={{ opacity: 0, x: 20 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  className="min-w-[280px] bg-gradient-to-br from-indigo-600 to-indigo-800 p-7 rounded-[2.5rem] shadow-xl text-white relative overflow-hidden shrink-0"
                              >
                                  <div className="relative z-10">
                                      <div className="flex items-center gap-2 mb-1">
                                          <div className="w-1.5 h-1.5 rounded-full bg-indigo-300 animate-pulse"></div>
                                          <p className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-200">Saldo Consolidado</p>
                                      </div>
                                      <h3 className="text-3xl font-black tabular-nums tracking-tighter mb-4">{showValues ? formatCurrency(stats.totalBalance) : '****'}</h3>
                                      <div className="flex items-center gap-2">
                                          <div className="px-3 py-1 bg-white/10 rounded-full border border-white/10 backdrop-blur-sm">
                                              <span className="text-[9px] font-black uppercase tracking-widest text-white/80">Atualizado agora</span>
                                          </div>
                                      </div>
                                  </div>
                                  <div className="absolute -bottom-6 -right-6 text-white/5 rotate-12"><Wallet size={120} /></div>
                                  <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16 blur-3xl"></div>
                              </motion.div>

                              <motion.div 
                                  initial={{ opacity: 0, x: 20 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={{ delay: 0.1 }}
                                  className="min-w-[240px] bg-white dark:bg-[#23243a] p-7 rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-white/5 shrink-0 flex flex-col justify-between"
                              >
                                  <div className="flex justify-between items-start">
                                      <div className="p-3 bg-emerald-50 dark:bg-emerald-500/10 rounded-2xl text-emerald-600 dark:text-emerald-400 shadow-sm"><TrendingUp size={24} /></div>
                                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Receitas</span>
                                  </div>
                                  <div className="mt-6">
                                      <h3 className="text-2xl font-black text-slate-800 dark:text-white tabular-nums tracking-tighter">{showValues ? formatCurrency(stats.income) : '****'}</h3>
                                      <p className="text-[9px] font-bold text-emerald-500 uppercase tracking-widest mt-1">Total do mês</p>
                                  </div>
                              </motion.div>

                              <motion.div 
                                  initial={{ opacity: 0, x: 20 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={{ delay: 0.2 }}
                                  className="min-w-[240px] bg-white dark:bg-[#23243a] p-7 rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-white/5 shrink-0 flex flex-col justify-between"
                              >
                                  <div className="flex justify-between items-start">
                                      <div className="p-3 bg-rose-50 dark:bg-rose-500/10 rounded-2xl text-rose-600 dark:text-rose-400 shadow-sm"><TrendingDown size={24} /></div>
                                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Despesas</span>
                                  </div>
                                  <div className="mt-6">
                                      <h3 className="text-2xl font-black text-slate-800 dark:text-white tabular-nums tracking-tighter">{showValues ? formatCurrency(stats.expense) : '****'}</h3>
                                      <p className="text-[9px] font-bold text-rose-500 uppercase tracking-widest mt-1">Total do mês</p>
                                  </div>
                              </motion.div>
                          </div>

                          {/* Financial Summary (Desktop) */}
                          <div className="hidden lg:grid grid-cols-4 gap-6">
                              <motion.div 
                                  initial={{ opacity: 0, y: 20 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  className="bg-gradient-to-br from-indigo-600 to-indigo-800 p-8 rounded-[2.5rem] shadow-xl text-white relative overflow-hidden"
                              >
                                  <div className="relative z-10">
                                      <div className="flex items-center gap-2 mb-1">
                                          <div className="w-1.5 h-1.5 rounded-full bg-indigo-300 animate-pulse"></div>
                                          <p className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-200">Saldo Consolidado</p>
                                      </div>
                                      <h3 className="text-3xl font-black tabular-nums tracking-tighter mb-4">{showValues ? formatCurrency(stats.totalBalance) : '****'}</h3>
                                      <div className="px-3 py-1 bg-white/10 rounded-full border border-white/10 backdrop-blur-sm inline-block">
                                          <span className="text-[9px] font-black uppercase tracking-widest text-white/80">Atualizado agora</span>
                                      </div>
                                  </div>
                                  <div className="absolute -bottom-6 -right-6 text-white/5 rotate-12"><Wallet size={120} /></div>
                              </motion.div>

                              <motion.div 
                                  initial={{ opacity: 0, y: 20 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  transition={{ delay: 0.1 }}
                                  className="bg-white dark:bg-[#23243a] p-8 rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-white/5 flex flex-col justify-between"
                              >
                                  <div className="flex justify-between items-start">
                                      <div className="p-3 bg-emerald-50 dark:bg-emerald-500/10 rounded-2xl text-emerald-600 dark:text-emerald-400 shadow-sm"><TrendingUp size={24} /></div>
                                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Receitas</span>
                                  </div>
                                  <div className="mt-6">
                                      <h3 className="text-2xl font-black text-slate-800 dark:text-white tabular-nums tracking-tighter">{showValues ? formatCurrency(stats.income) : '****'}</h3>
                                      <p className="text-[9px] font-bold text-emerald-500 uppercase tracking-widest mt-1">Total do mês</p>
                                  </div>
                              </motion.div>

                              <motion.div 
                                  initial={{ opacity: 0, y: 20 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  transition={{ delay: 0.2 }}
                                  className="bg-white dark:bg-[#23243a] p-8 rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-white/5 flex flex-col justify-between"
                              >
                                  <div className="flex justify-between items-start">
                                      <div className="p-3 bg-rose-50 dark:bg-rose-500/10 rounded-2xl text-rose-600 dark:text-rose-400 shadow-sm"><TrendingDown size={24} /></div>
                                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Despesas</span>
                                  </div>
                                  <div className="mt-6">
                                      <h3 className="text-2xl font-black text-slate-800 dark:text-white tabular-nums tracking-tighter">{showValues ? formatCurrency(stats.expense) : '****'}</h3>
                                      <p className="text-[9px] font-bold text-rose-500 uppercase tracking-widest mt-1">Total do mês</p>
                                  </div>
                              </motion.div>

                              <motion.div 
                                  initial={{ opacity: 0, y: 20 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  transition={{ delay: 0.3 }}
                                  className="bg-white dark:bg-[#23243a] p-8 rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-white/5 flex flex-col justify-between"
                              >
                                  <div className="flex justify-between items-start">
                                      <div className="p-3 bg-indigo-50 dark:bg-indigo-500/10 rounded-2xl text-indigo-600 dark:text-indigo-400 shadow-sm"><Activity size={24} /></div>
                                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Balanço Mensal</span>
                                  </div>
                                  <div className="mt-6">
                                      <h3 className={cn(
                                          "text-2xl font-black tabular-nums tracking-tighter",
                                          stats.monthBalance >= 0 ? "text-emerald-500" : "text-rose-500"
                                      )}>{showValues ? formatCurrency(stats.monthBalance) : '****'}</h3>
                                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-1">Resultado líquido</p>
                                  </div>
                              </motion.div>
                          </div>

                          {/* Sticky Header with Search, Sort and Wallet Filter */}
                          <div className="sticky top-0 z-40 bg-slate-50/80 dark:bg-[#1a1b2e]/80 backdrop-blur-xl -mx-4 px-4 py-4 lg:static lg:bg-transparent lg:backdrop-blur-none lg:mx-0 lg:px-0 lg:py-0">
                              <div className="flex flex-col lg:flex-row justify-between items-stretch lg:items-center gap-4">
                                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full lg:w-auto">
                                      <div className="relative flex-1 lg:w-96 group">
                                          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={18} />
                                          <input 
                                              type="text" 
                                              className="w-full pl-12 pr-14 py-4 bg-white dark:bg-[#23243a] border-2 border-slate-100 dark:border-white/10 rounded-2xl outline-none focus:border-indigo-400 text-xs font-bold uppercase transition-all shadow-sm placeholder:text-slate-300"
                                              placeholder="Buscar transação..."
                                              value={searchQuery}
                                              onChange={(e) => setSearchQuery(e.target.value)}
                                          />
                                          <button 
                                              onClick={() => setIsFilterOpen(!isFilterOpen)}
                                              className={cn(
                                                  "lg:hidden absolute right-3 top-1/2 -translate-y-1/2 p-2.5 rounded-xl transition-all",
                                                  isFilterOpen ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-50 dark:bg-white/5 text-slate-400'
                                              )}
                                          >
                                              <Filter size={18} />
                                          </button>
                                      </div>
                                      
                                      <div className="hidden lg:flex items-center gap-2">
                                          <button 
                                              onClick={() => setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')}
                                              className="h-12 px-4 bg-white dark:bg-[#23243a] rounded-2xl flex items-center justify-center gap-2 text-slate-400 hover:text-indigo-600 shadow-sm border border-slate-100 dark:border-white/5 transition-all"
                                              title={sortOrder === 'asc' ? 'Crescente' : 'Decrescente'}
                                          >
                                              <List size={18} className={sortOrder === 'asc' ? 'rotate-180' : ''} />
                                          </button>
                                          <div className="relative">
                                              <select 
                                                  value={filterWallet}
                                                  onChange={(e) => setFilterWallet(e.target.value)}
                                                  className="bg-white dark:bg-[#23243a] border-2 border-slate-100 dark:border-white/10 rounded-2xl px-6 py-3.5 text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-gray-300 outline-none focus:border-indigo-400 shadow-sm appearance-none cursor-pointer pr-12"
                                              >
                                                  <option value="all">TODAS AS CONTAS</option>
                                                  {wallets.map(w => <option key={w.id} value={w.id}>{w.name.toUpperCase()}</option>)}
                                              </select>
                                              <ChevronDownIcon size={14} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                                          </div>
                                      </div>
                                  </div>

                                  <div className="hidden lg:flex items-center bg-white dark:bg-[#23243a] p-1 rounded-2xl shadow-sm border border-slate-100 dark:border-white/5">
                                      {[
                                          { id: 'all', label: 'TUDO' },
                                          { id: 'income', label: 'RECEITAS' },
                                          { id: 'expense', label: 'DESPESAS' },
                                          { id: 'transfer', label: 'TRANSF.' }
                                      ].map((item) => (
                                          <button
                                              key={item.id}
                                              onClick={() => setFilterType(item.id as any)}
                                              className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${filterType === item.id ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}
                                          >
                                              {item.label}
                                          </button>
                                      ))}
                                  </div>
                              </div>

                                  {/* Mobile Filter Expandable */}
                                  <AnimatePresence>
                                      {isFilterOpen && (
                                          <motion.div 
                                              initial={{ opacity: 0, height: 0 }}
                                              animate={{ opacity: 1, height: 'auto' }}
                                              exit={{ opacity: 0, height: 0 }}
                                              className="lg:hidden overflow-hidden"
                                          >
                                              <div className="mt-4 space-y-5 bg-white dark:bg-[#23243a] p-7 rounded-[2.5rem] border border-slate-100 dark:border-white/5 shadow-2xl">
                                                  <div className="space-y-3">
                                                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Filtrar por Tipo</p>
                                                      <div className="grid grid-cols-2 gap-2.5">
                                                          {[
                                                              { id: 'all', label: 'Tudo' },
                                                              { id: 'income', label: 'Receitas' },
                                                              { id: 'expense', label: 'Despesas' },
                                                              { id: 'transfer', label: 'Transf.' }
                                                          ].map((item) => (
                                                              <button
                                                                  key={item.id}
                                                                  onClick={() => setFilterType(item.id as any)}
                                                                  className={cn(
                                                                      "py-3.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all",
                                                                      filterType === item.id 
                                                                          ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200 dark:shadow-none' 
                                                                          : 'bg-slate-50 dark:bg-white/5 text-slate-400'
                                                                  )}
                                                              >
                                                                  {item.label}
                                                              </button>
                                                          ))}
                                                      </div>
                                                  </div>
                                                  <div className="space-y-3">
                                                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Filtrar por Conta</p>
                                                      <div className="relative">
                                                          <select 
                                                              value={filterWallet}
                                                              onChange={(e) => setFilterWallet(e.target.value)}
                                                              className="w-full bg-slate-50 dark:bg-white/5 border-2 border-transparent rounded-2xl px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-gray-300 outline-none focus:border-indigo-400 appearance-none cursor-pointer pr-12"
                                                          >
                                                              <option value="all">TODAS AS CONTAS</option>
                                                              {wallets.map(w => <option key={w.id} value={w.id}>{w.name.toUpperCase()}</option>)}
                                                          </select>
                                                          <ChevronDownIcon size={14} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                                                      </div>
                                                  </div>
                                                  <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-white/5">
                                                      <button 
                                                          onClick={() => { setFilterType('all'); setFilterWallet('all'); setSearchQuery(''); }}
                                                          className="text-[10px] font-black text-rose-500 uppercase tracking-[0.2em] hover:opacity-70 transition-opacity"
                                                      >
                                                          Limpar Filtros
                                                      </button>
                                                      <button 
                                                          onClick={() => setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')}
                                                          className="flex items-center gap-2 text-[10px] font-black text-indigo-600 uppercase tracking-[0.2em] hover:opacity-70 transition-opacity"
                                                      >
                                                          <List size={14} className={cn("transition-transform", sortOrder === 'asc' ? 'rotate-180' : '')} />
                                                          {sortOrder === 'asc' ? 'Crescente' : 'Decrescente'}
                                                      </button>
                                                  </div>
                                              </div>
                                          </motion.div>
                                      )}
                                  </AnimatePresence>
                              </div>

                          {/* Period Selector (Pill Style) */}
                          <div className="flex justify-center items-center gap-4 sm:gap-8 px-4">
                              <button onClick={() => { const d = new Date(viewDate); d.setMonth(d.getMonth() - 1); setViewDate(d); }} className="p-2 text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/10 rounded-full transition-all shrink-0"><ChevronLeft size={24}/></button>
                              <div className="flex-1 max-w-[240px] px-4 sm:px-8 py-2.5 border-2 border-indigo-600 dark:border-indigo-400 rounded-full bg-white dark:bg-transparent shadow-sm flex items-center justify-center">
                                  <span className="text-[10px] sm:text-xs font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest whitespace-nowrap">{MONTHS_LABELS_LOCAL[viewDate.getMonth()]} {viewDate.getFullYear()}</span>
                              </div>
                              <button onClick={() => { const d = new Date(viewDate); d.setMonth(d.getMonth() + 1); setViewDate(d); }} className="p-2 text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/10 rounded-full transition-all shrink-0"><ChevronRight size={24}/></button>
                          </div>

                          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 px-2 lg:px-0">
                              {/* Transactions List */}
                              <div className="lg:col-span-12 space-y-6">
                                  {/* Desktop Table View */}
                                  <div className="hidden lg:block bg-white dark:bg-[#23243a] rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-white/5 overflow-hidden transition-colors">
                                      <div className="overflow-x-auto custom-scrollbar">
                                          <table className="w-full text-left border-separate border-spacing-0">
                                              <thead className="bg-slate-50/50 dark:bg-white/5 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                                  <tr>
                                                      <th className="px-8 py-5 border-b border-slate-100 dark:border-white/5">Situação</th>
                                                      <th className="px-8 py-5 border-b border-slate-100 dark:border-white/5 whitespace-nowrap">Data ↓</th>
                                                      <th className="px-8 py-5 border-b border-slate-100 dark:border-white/5">Descrição</th>
                                                      <th className="px-8 py-5 border-b border-slate-100 dark:border-white/5">Categoria</th>
                                                      <th className="px-8 py-5 border-b border-slate-100 dark:border-white/5">Conta</th>
                                                      <th className="px-8 py-5 border-b border-slate-100 dark:border-white/5 text-right">Valor</th>
                                                      <th className="px-8 py-5 border-b border-slate-100 dark:border-white/5 text-center">Ações</th>
                                                  </tr>
                                              </thead>
                                              <tbody className="divide-y divide-slate-50 dark:divide-white/5">
                                                  {groupedTransactions.length === 0 ? (
                                                      <tr>
                                                          <td colSpan={7} className="py-32 text-center">
                                                              <div className="w-20 h-20 bg-slate-50 dark:bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6">
                                                                <History size={32} className="text-slate-200 dark:text-slate-700" />
                                                              </div>
                                                              <p className="text-xs font-black text-slate-400 uppercase tracking-[0.3em]">Nenhuma transação encontrada</p>
                                                          </td>
                                                      </tr>
                                                  ) : (
                                                      groupedTransactions.map(([day, txs]) => (
                                                          <React.Fragment key={day}>
                                                              {txs.map(t => {
                                                                  const isIncome = t.type === 'income';
                                                                  const isTransfer = t.type === 'transfer';
                                                                  const cat = categories.find(c => c.id === t.category_id);
                                                                  const wal = wallets.find(w => w.id === t.wallet_id);
                                                                  const isPaid = t.status === 'paid' || !t.status;
                                                                  const isCancelled = t.status === 'cancelled';
                                                                  return (
                                                                      <tr key={t.id} className={`hover:bg-slate-50/50 dark:hover:bg-white/5 transition-colors group ${isCancelled ? 'opacity-40 grayscale' : ''}`}>
                                                                          <td className="px-8 py-5">
                                                                              <div className="flex items-center gap-3">
                                                                                  {isPaid ? <CheckCircle2 size={18} className="text-emerald-500" /> : <AlertCircle size={18} className="text-rose-500" />}
                                                                                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-white shadow-lg ${isCancelled ? 'bg-slate-400' : isTransfer ? 'bg-indigo-600' : isIncome ? 'bg-emerald-500' : 'bg-rose-500'}`}>
                                                                                      {isTransfer ? <ArrowRightLeft size={14}/> : isIncome ? <ArrowDownLeft size={14}/> : <ArrowUpRightIcon size={14}/>}
                                                                                  </div>
                                                                              </div>
                                                                          </td>
                                                                          <td className="px-8 py-5 text-[11px] font-black text-slate-400 tabular-nums">
                                                                              {new Date(getSafeTimestamp(t.date)).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}
                                                                          </td>
                                                                          <td className={`px-8 py-5 text-sm font-black text-slate-800 dark:text-white uppercase tracking-tight truncate max-w-[500px] ${!isPaid ? 'opacity-50' : ''}`}>
                                                                              {t.description}
                                                                          </td>
                                                                          <td className="px-8 py-5">
                                                                              <div className="flex items-center gap-3">
                                                                                  <div className="w-8 h-8 rounded-full flex items-center justify-center text-white shadow-sm shrink-0" style={{ backgroundColor: cat?.color || '#cbd5e1' }}>
                                                                                      {React.createElement(PRESET_ICONS.find(i => i.id === cat?.icon)?.icon || Tag, { size: 14 })}
                                                                                  </div>
                                                                                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{cat?.name || 'OUTROS'}</span>
                                                                              </div>
                                                                          </td>
                                                                          <td className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                                                              {wal?.name || (t.origin === 'pos' ? 'CAIXA PDV' : 'NÃO INFORMADO')}
                                                                          </td>
                                                                          <td className={`px-8 py-5 text-right text-base font-black tabular-nums tracking-tighter ${isIncome ? 'text-emerald-500' : 'text-rose-500'} ${!isPaid ? 'opacity-50' : ''}`}>
                                                                              {formatCurrency(t.amount)}
                                                                          </td>
                                                                          <td className="px-8 py-5">
                                                                              <div className="flex items-center justify-center gap-3 opacity-0 group-hover:opacity-100 transition-opacity">
                                                                                  <button onClick={() => handleEditTx(t)} className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-white/5 flex items-center justify-center text-slate-400 hover:text-indigo-600 transition-all"><Pencil size={14}/></button>
                                                                                  <button onClick={() => setTxToDelete(t)} className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-white/5 flex items-center justify-center text-slate-400 hover:text-rose-500 transition-all"><Trash2 size={14}/></button>
                                                                              </div>
                                                                          </td>
                                                                      </tr>
                                                                  );
                                                              })}
                                                              <tr className="bg-slate-50/30 dark:bg-white/5">
                                                                  <td colSpan={5} className="px-10 py-4 text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] italic">Saldo do Final do Dia</td>
                                                                  <td className="px-8 py-4 text-right text-xs font-black text-slate-800 dark:text-white tabular-nums tracking-tight">
                                                                      {formatCurrency(txs.reduce((acc, t) => t.type === 'income' ? acc + t.amount : t.type === 'expense' ? acc - t.amount : acc, 0))}
                                                                  </td>
                                                                  <td></td>
                                                              </tr>
                                                          </React.Fragment>
                                                      ))
                                                  )}
                                              </tbody>
                                          </table>
                                      </div>
                                  </div>

                                  {/* Mobile List View */}
                                  <div className="lg:hidden space-y-6">
                                      {groupedTransactions.length === 0 ? (
                                      <motion.div 
                                          initial={{ opacity: 0, scale: 0.9 }}
                                          animate={{ opacity: 1, scale: 1 }}
                                          className="bg-white dark:bg-[#23243a] rounded-[3rem] p-16 text-center border border-slate-100 dark:border-white/5 shadow-xl shadow-slate-200/50 dark:shadow-none"
                                      >
                                          <div className="w-28 h-28 bg-indigo-50 dark:bg-indigo-500/10 rounded-full flex items-center justify-center mx-auto mb-8 relative">
                                              <History size={48} className="text-indigo-600 dark:text-indigo-400" />
                                              <motion.div 
                                                  animate={{ scale: [1, 1.2, 1] }}
                                                  transition={{ repeat: Infinity, duration: 2 }}
                                                  className="absolute -top-1 -right-1 w-8 h-8 bg-rose-500 rounded-full border-4 border-white dark:border-[#23243a] flex items-center justify-center text-white"
                                              >
                                                  <X size={14} strokeWidth={3} />
                                              </motion.div>
                                          </div>
                                          <h3 className="text-xl font-black text-slate-800 dark:text-white uppercase tracking-tight mb-3">Nenhuma Atividade</h3>
                                          <p className="text-[11px] font-bold text-slate-400 uppercase tracking-[0.2em] max-w-[220px] mx-auto leading-relaxed">Parece que você ainda não registrou transações neste período.</p>
                                          <button 
                                              onClick={() => setIsFabOpen(true)}
                                              className="mt-10 w-full py-4 bg-indigo-600 text-white rounded-2xl text-[11px] font-black uppercase tracking-widest shadow-xl shadow-indigo-200 dark:shadow-none active:scale-95 transition-all"
                                          >
                                              Começar Agora
                                          </button>
                                      </motion.div>
                                  ) : (
                                          groupedTransactions.map(([day, txs]) => (
                                              <div key={day} className="space-y-5">
                                                  <div className="flex items-center gap-4 px-2">
                                                      <div className="flex flex-col">
                                                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-0.5">Movimentações de</span>
                                                          <span className="text-sm font-black text-slate-900 dark:text-white uppercase tracking-tight">{day}</span>
                                                      </div>
                                                      <div className="h-px flex-1 bg-gradient-to-r from-slate-200 to-transparent dark:from-white/10 dark:to-transparent"></div>
                                                  </div>
                                                  
                                                  <div className="space-y-4">
                                                      {txs.map((t, tIdx) => {
                                                          const isIncome = t.type === 'income';
                                                          const isTransfer = t.type === 'transfer';
                                                          const cat = categories.find(c => c.id === t.category_id);
                                                          const isPaid = t.status === 'paid' || !t.status;
                                                          const isCancelled = t.status === 'cancelled';
                                                          
                                                          return (
                                                                  <motion.div 
                                                                      key={t.id} 
                                                                      initial={{ opacity: 0, x: -20 }}
                                                                      whileInView={{ opacity: 1, x: 0 }}
                                                                      viewport={{ once: true }}
                                                                      transition={{ delay: tIdx * 0.05 }}
                                                                      onClick={() => setMobileActionTx(t)}
                                                                      className={cn(
                                                                          "group relative bg-white dark:bg-[#23243a] p-2 rounded-2xl border border-slate-100 dark:border-white/5 shadow-md flex items-center gap-2.5 active:scale-[0.98] transition-all mx-1",
                                                                          isCancelled && 'opacity-40 grayscale'
                                                                      )}
                                                                  >
                                                                      <div className={cn(
                                                                          "w-7 h-7 rounded-lg flex items-center justify-center text-white shrink-0 shadow-sm transition-transform group-active:scale-90",
                                                                          isCancelled ? 'bg-slate-400' : isTransfer ? 'bg-indigo-600' : isIncome ? 'bg-emerald-500' : 'bg-rose-500'
                                                                      )}>
                                                                          {isTransfer ? <ArrowRightLeft size={12} strokeWidth={3}/> : isIncome ? <ArrowDownLeft size={12} strokeWidth={3}/> : <ArrowUpRightIcon size={12} strokeWidth={3}/>}
                                                                      </div>
                                                                      <div className="flex-1 min-w-0">
                                                                          <div className="flex justify-between items-center gap-3">
                                                                              <h4 className={cn(
                                                                                  "text-[13px] font-black text-slate-800 dark:text-white uppercase tracking-tight flex-1 leading-tight truncate",
                                                                                  !isPaid && 'opacity-50'
                                                                              )}>{t.description}</h4>
                                                                              <span className={cn(
                                                                                  "text-base font-black tabular-nums tracking-tighter shrink-0",
                                                                                  isIncome ? 'text-emerald-500' : 'text-rose-500',
                                                                                  !isPaid && 'opacity-50'
                                                                              )}>
                                                                                  {formatCurrency(t.amount)}
                                                                              </span>
                                                                          </div>
                                                                          <div className="flex items-center gap-2 mt-1">
                                                                              <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-white/5 px-2 py-0.5 rounded-lg border border-slate-100 dark:border-white/10">
                                                                                  <div className="w-1.5 h-1.5 rounded-full shadow-sm" style={{ backgroundColor: cat?.color || '#cbd5e1' }}></div>
                                                                                  <span className="text-[8px] font-black text-slate-500 dark:text-gray-400 uppercase tracking-widest">{cat?.name || 'OUTROS'}</span>
                                                                              </div>
                                                                              <div className="flex items-center gap-1 text-slate-400">
                                                                                  <History size={10} />
                                                                                  <span className="text-[8px] font-bold uppercase tracking-widest">
                                                                                      {new Date(getSafeTimestamp(t.date)).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                                                                                  </span>
                                                                              </div>
                                                                              {!isPaid && (
                                                                                  <span className="text-[7px] font-black text-rose-500 uppercase tracking-widest bg-rose-50 dark:bg-rose-500/10 px-2 py-0.5 rounded-lg border border-rose-100 dark:border-rose-500/20 animate-pulse">Pendente</span>
                                                                              )}
                                                                          </div>
                                                                      </div>
                                                                      <div className="w-6 h-6 rounded-full bg-slate-50 dark:bg-white/5 flex items-center justify-center text-slate-300 shrink-0">
                                                                          <ChevronRight size={14} />
                                                                      </div>
                                                                  </motion.div>
                                                          );
                                                      })}
                                                  </div>

                                                  {/* Daily Balance Card Refined */}
                                                  <motion.div 
                                                      initial={{ opacity: 0, y: 10 }}
                                                      whileInView={{ opacity: 1, y: 0 }}
                                                      viewport={{ once: true }}
                                                      className="mx-2 bg-slate-900 dark:bg-[#1a1b2e] rounded-[2.5rem] p-7 flex justify-between items-center shadow-2xl relative overflow-hidden group border border-white/10"
                                                  >
                                                      <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/20 via-transparent to-emerald-500/10 opacity-50"></div>
                                                      <div className="absolute -right-4 -bottom-4 w-32 h-32 bg-indigo-500/10 rounded-full blur-3xl"></div>
                                                      
                                                      <div className="relative z-10">
                                                          <div className="flex items-center gap-2.5 mb-1.5">
                                                              <div className="w-2.5 h-2.5 rounded-full bg-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.8)]"></div>
                                                              <span className="text-[11px] font-black text-slate-200 uppercase tracking-[0.25em]">Balanço do Dia</span>
                                                          </div>
                                                          <p className="text-[9px] font-bold text-slate-500 uppercase tracking-[0.2em]">Saldo líquido acumulado</p>
                                                      </div>
                                                      <div className="relative z-10 text-right">
                                                          <span className="text-2xl font-black text-white tabular-nums tracking-tighter block">
                                                              {formatCurrency(txs.reduce((acc, t) => t.type === 'income' ? acc + t.amount : t.type === 'expense' ? acc - t.amount : acc, 0))}
                                                          </span>
                                                          <span className="text-[8px] font-black text-indigo-400 uppercase tracking-widest">Consolidado</span>
                                                      </div>
                                                  </motion.div>
                                              </div>
                                          ))
                                      )}
                                  </div>

                                  {/* Pagination Footer */}
                                  <div className="mx-2 lg:mx-0 px-4 sm:px-6 py-8 border-t border-gray-100 dark:border-white/5 flex flex-col sm:flex-row justify-between items-center gap-8 bg-white dark:bg-[#23243a] rounded-[2.5rem] lg:rounded-t-none lg:rounded-b-[3rem] shadow-xl shadow-slate-200/20 dark:shadow-none">
                                      <div className="flex items-center gap-6 sm:gap-8">
                                          <div className="flex items-center gap-3">
                                              <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Exibir:</span>
                                              <div className="flex items-center gap-2 cursor-pointer group bg-slate-50 dark:bg-white/5 px-4 py-2 rounded-xl border border-slate-100 dark:border-white/10 hover:border-indigo-300 transition-all">
                                                  <span className="text-xs font-black text-slate-700 dark:text-white">50</span>
                                                  <ChevronDownIcon size={14} className="text-slate-400 group-hover:text-indigo-600 transition-colors" />
                                              </div>
                                          </div>
                                          <div className="flex flex-col">
                                              <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest mb-0.5">Resultados</span>
                                              <div className="text-[11px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-tight">
                                                  {filteredTransactions.length > 0 ? (
                                                      <span className="text-indigo-600 dark:text-indigo-400">
                                                          {(currentPage - 1) * ITEMS_PER_PAGE + 1} - {Math.min(currentPage * ITEMS_PER_PAGE, filteredTransactions.length)} <span className="text-slate-300 mx-1">/</span> {filteredTransactions.length}
                                                      </span>
                                                  ) : '0 - 0 / 0'}
                                              </div>
                                          </div>
                                      </div>
                                      
                                      <div className="flex items-center gap-2.5">
                                          <button 
                                              onClick={() => setCurrentPage(1)}
                                              disabled={currentPage === 1}
                                              className="w-12 h-12 rounded-2xl flex items-center justify-center bg-slate-50 dark:bg-white/5 text-slate-400 hover:bg-indigo-50 hover:text-indigo-600 disabled:opacity-30 transition-all border border-slate-100 dark:border-white/10 shadow-sm"
                                          >
                                              <ChevronsLeft size={20} />
                                          </button>
                                          <button 
                                              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                                              disabled={currentPage === 1}
                                              className="w-12 h-12 rounded-2xl flex items-center justify-center bg-slate-50 dark:bg-white/5 text-slate-400 hover:bg-indigo-50 hover:text-indigo-600 disabled:opacity-30 transition-all border border-slate-100 dark:border-white/10 shadow-sm"
                                          >
                                              <ChevronLeft size={20} />
                                          </button>
                                          
                                          <div className="flex items-center gap-1.5 px-4 h-12 rounded-2xl bg-indigo-600 text-white shadow-xl shadow-indigo-200 dark:shadow-none">
                                              <span className="text-[10px] font-black uppercase tracking-widest opacity-60">Pág.</span>
                                              <span className="text-sm font-black tabular-nums">{currentPage}</span>
                                          </div>

                                          <button 
                                              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                                              disabled={currentPage === totalPages}
                                              className="w-12 h-12 rounded-2xl flex items-center justify-center bg-slate-50 dark:bg-white/5 text-slate-400 hover:bg-indigo-50 hover:text-indigo-600 disabled:opacity-30 transition-all border border-slate-100 dark:border-white/10 shadow-sm"
                                          >
                                              <ChevronRight size={20} />
                                          </button>
                                          <button 
                                              onClick={() => setCurrentPage(totalPages)}
                                              disabled={currentPage === totalPages}
                                              className="w-12 h-12 rounded-2xl flex items-center justify-center bg-slate-50 dark:bg-white/5 text-slate-400 hover:bg-indigo-50 hover:text-indigo-600 disabled:opacity-30 transition-all border border-slate-100 dark:border-white/10 shadow-sm"
                                          >
                                              <ChevronsRight size={20} />
                                          </button>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  )}

                  {/* CARTEIRAS - GRID DE CONTAS */}
                  {activeTab === 'wallets' && (
                      <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500 pb-32">
                          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                              <div>
                                  <h2 className="text-xl font-black text-slate-800 dark:text-white uppercase tracking-tighter italic">Minhas Contas</h2>
                                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-1">Saldo consolidado das carteiras líquidas</p>
                              </div>
                              <button onClick={() => { 
                                  setEditingWallet(null); 
                                  setWalletForm({ name: '', type: 'bank', balance: '', color: '#6366f1', initial_balance: '', closing_day: 1, due_day: 5 });
                                  setIsWalletModalOpen(true); 
                              }} className="w-full sm:w-auto bg-indigo-600 text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl flex items-center justify-center gap-2 active:scale-95 transition-all">
                                  <Plus size={16} strokeWidth={3}/> Nova Conta
                              </button>
                          </div>

                          {wallets.filter(w => w.type !== 'credit').length === 0 ? (
                              <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] p-8 sm:p-12 border-2 border-dashed border-slate-200 dark:border-white/10 flex flex-col items-center text-center max-w-4xl mx-auto animate-in fade-in zoom-in duration-500 shadow-sm">
                                  <div className="w-20 h-20 sm:w-24 sm:h-24 bg-indigo-50 dark:bg-indigo-500/10 rounded-full flex items-center justify-center text-indigo-600 dark:text-indigo-400 mb-8 shadow-inner">
                                      <Wallet size={48} strokeWidth={1.5} />
                                  </div>
                                  <h3 className="text-xl sm:text-2xl font-black text-slate-800 dark:text-white uppercase tracking-tighter italic mb-4">Configure suas Carteiras de Recebimento</h3>
                                  <p className="text-slate-500 dark:text-gray-400 text-sm font-medium leading-relaxed mb-10 max-w-2xl">
                                      Para que o sistema controle suas vendas no PDV, você precisa criar as carteiras onde o dinheiro será recebido. Sem elas, o sistema não saberá para onde enviar o saldo de cada venda.
                                  </p>
                                  
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full mb-10">
                                      <div className="bg-slate-50 dark:bg-white/5 p-6 rounded-3xl border border-slate-100 dark:border-white/5 text-left transition-all hover:border-indigo-200 dark:hover:border-indigo-500/30">
                                          <div className="flex items-center gap-3 mb-4">
                                              <div className="w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center text-xs font-black shadow-lg shadow-indigo-200 dark:shadow-none">1</div>
                                              <span className="text-[10px] font-black text-slate-800 dark:text-white uppercase tracking-widest">Criação das Contas</span>
                                          </div>
                                          <p className="text-[11px] text-slate-500 dark:text-gray-400 font-bold leading-relaxed uppercase tracking-tight">
                                              Crie uma conta <span className="text-indigo-600 dark:text-indigo-400">"DINHEIRO"</span> para o caixa físico. Para <span className="text-indigo-600 dark:text-indigo-400">PIX, DÉBITO e CRÉDITO</span>, crie contas vinculadas às suas maquininhas ou bancos (Ex: InfinitePay, PicPay, Cielo, Inter).
                                          </p>
                                      </div>
                                      <div className="bg-slate-50 dark:bg-white/5 p-6 rounded-3xl border border-slate-100 dark:border-white/5 text-left transition-all hover:border-emerald-200 dark:hover:border-emerald-500/30">
                                          <div className="flex items-center gap-3 mb-4">
                                              <div className="w-8 h-8 bg-emerald-500 text-white rounded-full flex items-center justify-center text-xs font-black shadow-lg shadow-emerald-200 dark:shadow-none">2</div>
                                              <span className="text-[10px] font-black text-slate-800 dark:text-white uppercase tracking-widest">Vínculo no PDV</span>
                                          </div>
                                          <p className="text-[11px] text-slate-500 dark:text-gray-400 font-bold leading-relaxed uppercase tracking-tight">
                                              Após criar as contas aqui, vá em <span className="text-emerald-500 cursor-pointer hover:underline decoration-2 underline-offset-4" onClick={() => onNavigate?.('settings')}>CONFIGURAÇÕES &gt; CARTEIRAS</span> para vincular cada método de pagamento à sua respectiva conta de destino.
                                          </p>
                                      </div>
                                  </div>

                                  <button 
                                      onClick={() => { 
                                          setEditingWallet(null); 
                                          setWalletForm({ name: '', type: 'bank', balance: '', color: '#6366f1', initial_balance: '', closing_day: 1, due_day: 5 });
                                          setIsWalletModalOpen(true); 
                                      }}
                                      className="bg-indigo-600 hover:bg-indigo-700 text-white px-10 py-5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-2xl shadow-indigo-200 dark:shadow-none hover:scale-[1.02] active:scale-95 transition-all flex items-center gap-3"
                                  >
                                      <Plus size={20} strokeWidth={3} /> Começar Cadastro
                                  </button>
                              </div>
                          ) : (
                              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
                                  {wallets.filter(w => w.type !== 'credit').map(w => (
                                      <div key={w.id} className="bg-white dark:bg-[#23243a] p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-white/5 transition-all hover:shadow-xl hover:-translate-y-1 group overflow-hidden relative">
                                          <div className="absolute top-0 right-0 p-4 opacity-[0.03] text-indigo-600 group-hover:scale-110 transition-transform duration-700"><Landmark size={80} /></div>
                                          <div className="relative z-10 space-y-4">
                                              <div className="flex justify-between items-start">
                                                  <div className="w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-lg shrink-0" style={{ backgroundColor: w.color || '#6366f1' }}>
                                                      <Landmark size={20} />
                                                  </div>
                                                  <div className="flex items-center gap-2">
                                                      <button onClick={() => { 
                                                          setEditingWallet(w); 
                                                          setWalletForm({ 
                                                              name: w.name || '', 
                                                              type: w.type || 'bank', 
                                                              balance: (w.balance || 0).toString(), 
                                                              color: w.color || '#6366f1', 
                                                              initial_balance: (w.initial_balance || 0).toString(), 
                                                              closing_day: w.closing_day || 1, 
                                                              due_day: w.due_day || 5 
                                                          }); 
                                                          setIsWalletModalOpen(true); 
                                                      }} className="p-2 text-slate-300 hover:text-indigo-600 transition-colors"><Pencil size={16}/></button>
                                                      <button onClick={() => setWalletToDelete(w)} className="p-2 text-slate-300 hover:text-rose-500 transition-colors"><Trash2 size={16}/></button>
                                                  </div>
                                              </div>
                                              <div>
                                                  <h4 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-tighter leading-none mb-1 truncate">{w.name}</h4>
                                                  <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">{w.type === 'bank' ? 'Conta Corrente' : w.type === 'cash' ? 'Dinheiro Físico' : 'Investimento'}</p>
                                              </div>
                                              <div className="pt-3 border-t border-gray-50 dark:border-white/5 transition-colors">
                                                  <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Saldo Disponível</p>
                                                  <p className="text-xl font-black text-slate-900 dark:text-white tabular-nums tracking-tighter">{showValues ? formatCurrency(w.balance) : '****'}</p>
                                              </div>
                                          </div>
                                      </div>
                                  ))}
                              </div>
                          )}
                      </div>
                  )}

                  {/* CARTÕES - GESTÃO DE FATURAS */}
                  {activeTab === 'credit_cards' && (
                      <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500 pb-32">
                          {!selectedCardId ? (
                              <>
                                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                                      <div>
                                          <h2 className="text-xl font-black text-slate-800 dark:text-white uppercase tracking-tighter italic">Cartões de Crédito</h2>
                                          <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-1">Controle de limites e faturas em aberto</p>
                                      </div>
                                      <button onClick={() => { 
                                          setEditingWallet(null); 
                                          setWalletForm({ name: '', type: 'credit', balance: '0', color: '#1e293b', initial_balance: '5000', closing_day: 5, due_day: 10 });
                                          setIsWalletModalOpen(true); 
                                      }} className="w-full sm:w-auto bg-indigo-600 text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl flex items-center justify-center gap-2 active:scale-95 transition-all">
                                          <Plus size={16} strokeWidth={3}/> Novo Cartão
                                      </button>
                                  </div>

                                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                                      {wallets.filter(w => w.type === 'credit').map(card => {
                                          const cardTxs = getStatementTransactions(card.id, viewDate);
                                          const usage = cardTxs.reduce((acc, t) => acc + t.amount, 0);
                                          const limit = card.initial_balance || 5000;
                                          const available = limit - usage;
                                          const usagePct = (usage / limit) * 100;

                                          return (
                                              <div 
                                                key={card.id} 
                                                onClick={() => setSelectedCardId(card.id)}
                                                className="bg-white dark:bg-[#23243a] rounded-3xl p-6 border border-slate-100 dark:border-white/5 shadow-sm hover:shadow-xl transition-all group overflow-hidden relative cursor-pointer"
                                              >
                                                  <div className="relative z-10">
                                                      <div className="flex justify-between items-start mb-6">
                                                          <div className="flex items-center gap-4 min-w-0">
                                                              <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg shrink-0" style={{ backgroundColor: card.color || '#1e293b' }}>
                                                                  <CreditCardIcon size={24} />
                                                              </div>
                                                              <div className="min-w-0">
                                                                  <h4 className="text-base font-black text-slate-800 dark:text-white uppercase tracking-tighter leading-none mb-1 truncate">{card.name}</h4>
                                                                  <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">**** {card.id.substring(0,4).toUpperCase()}</p>
                                                              </div>
                                                          </div>
                                                          <div className="flex items-center gap-2">
                                                              <button onClick={(e) => { 
                                                                  e.stopPropagation();
                                                                  setEditingWallet(card); 
                                                                  setWalletForm({ 
                                                                      name: card.name || '', 
                                                                      type: card.type || 'credit', 
                                                                      balance: (card.balance || 0).toString(), 
                                                                      color: card.color || '#1e293b', 
                                                                      initial_balance: (card.initial_balance || 0).toString(), 
                                                                      closing_day: card.closing_day || 5, 
                                                                      due_day: card.due_day || 10 
                                                                  }); 
                                                                  setIsWalletModalOpen(true); 
                                                              }} className="p-2 text-slate-300 hover:text-indigo-600 transition-colors"><Pencil size={16}/></button>
                                                              <button onClick={(e) => { 
                                                                  e.stopPropagation();
                                                                  setWalletToDelete(card); 
                                                              }} className="p-2 text-slate-300 hover:text-rose-500 transition-colors"><Trash2 size={16}/></button>
                                                          </div>
                                                      </div>

                                                      <div className="grid grid-cols-2 gap-4 mb-6">
                                                          <div>
                                                              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Fatura Atual</p>
                                                              <p className="text-2xl font-black text-slate-900 dark:text-white tabular-nums tracking-tighter leading-none">{showValues ? formatCurrency(usage) : '****'}</p>
                                                          </div>
                                                          <div className="text-right">
                                                              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Limite Disp.</p>
                                                              <p className="text-base font-black text-emerald-500 tabular-nums tracking-tighter leading-none">{showValues ? formatCurrency(available) : '****'}</p>
                                                          </div>
                                                      </div>

                                                      <div className="space-y-2">
                                                          <div className="flex justify-between text-[8px] font-black text-slate-400 uppercase tracking-widest">
                                                              <span>Uso do Limite</span>
                                                              <span>{usagePct.toFixed(1)}%</span>
                                                          </div>
                                                          <div className="h-1.5 w-full bg-slate-50 dark:bg-white/5 rounded-full overflow-hidden">
                                                              <div className={`h-full rounded-full transition-all duration-1000 ease-out ${usagePct > 80 ? 'bg-rose-500' : 'bg-indigo-600'}`} style={{ width: `${Math.min(usagePct, 100)}%` }}></div>
                                                          </div>
                                                      </div>

                                                      <div className="grid grid-cols-2 gap-2 mt-6 pt-4 border-t border-gray-50 dark:border-white/5">
                                                          <div className="bg-slate-50/50 dark:bg-white/5 p-3 rounded-xl text-center">
                                                              <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Vencimento</p>
                                                              <p className="text-xs font-black text-slate-700 dark:text-white leading-none">Dia {card.due_day || 10}</p>
                                                          </div>
                                                          <div className="bg-slate-50/50 dark:bg-white/5 p-3 rounded-xl text-center">
                                                              <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Fechamento</p>
                                                              <p className="text-xs font-black text-slate-700 dark:text-white leading-none">Dia {card.closing_day || 5}</p>
                                                          </div>
                                                      </div>
                                                  </div>
                                                  <div className="absolute -bottom-6 -right-6 opacity-[0.02] text-indigo-600 pointer-events-none group-hover:scale-110 transition-transform duration-1000"><CreditCardIcon size={180} /></div>
                                              </div>
                                          );
                                      })}
                                  </div>
                              </>
                          ) : (
                              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                                  {/* Header de Detalhes do Cartão */}
                                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 bg-slate-50 dark:bg-white/2 p-6 rounded-[2.5rem] border border-slate-100 dark:border-white/5 transition-colors">
                                      <div className="flex items-center gap-5">
                                          <button 
                                            onClick={() => { setSelectedCardId(null); setCardStatementDate(new Date()); }}
                                            className="w-12 h-12 rounded-2xl bg-white dark:bg-[#1a1b2e] border border-slate-200 dark:border-white/10 flex items-center justify-center text-slate-400 hover:text-emerald-600 hover:border-emerald-200 transition-all shadow-sm active:scale-90"
                                          >
                                              <ChevronLeft size={24} strokeWidth={3} />
                                          </button>
                                          <div>
                                              <div className="flex items-center gap-3">
                                                  <div className="w-2 h-6 bg-emerald-500 rounded-full"></div>
                                                  <h2 className="text-2xl font-black text-slate-800 dark:text-white uppercase tracking-tighter italic leading-none">
                                                      {wallets.find(w => w.id === selectedCardId)?.name}
                                                  </h2>
                                              </div>
                                              <div className="flex items-center gap-4 mt-2 ml-5">
                                                  <button onClick={() => { const d = new Date(cardStatementDate); d.setMonth(d.getMonth() - 1); setCardStatementDate(d); }} className="text-slate-400 hover:text-emerald-600 transition-colors"><ChevronLeft size={16}/></button>
                                                  <span className="text-[10px] text-slate-600 dark:text-gray-300 font-black uppercase tracking-widest">
                                                      Fatura de {MONTHS_LABELS_LOCAL[cardStatementDate.getMonth()]} {cardStatementDate.getFullYear()}
                                                  </span>
                                                  <button onClick={() => { const d = new Date(cardStatementDate); d.setMonth(d.getMonth() + 1); setCardStatementDate(d); }} className="text-slate-400 hover:text-emerald-600 transition-colors"><ChevronRight size={16}/></button>
                                              </div>
                                          </div>
                                      </div>
                                      <div className="flex gap-3 w-full sm:w-auto">
                                          <button 
                                            onClick={() => { 
                                                setEditingTx(null); 
                                                setTxForm({ ...initialTxState, walletId: selectedCardId || '', type: 'expense' }); 
                                                setIsTxModalOpen(true); 
                                            }}
                                            className="flex-1 sm:flex-none bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 rounded-2xl font-black text-[11px] uppercase tracking-widest shadow-xl shadow-emerald-200 dark:shadow-none flex items-center justify-center gap-3 active:scale-95 transition-all"
                                          >
                                              <Plus size={18} strokeWidth={3}/> Lançar Compra
                                          </button>
                                      </div>
                                  </div>

                                  {/* Resumo Rápido da Fatura */}
                                  {(() => {
                                      const card = wallets.find(w => w.id === selectedCardId);
                                      if (!card) return null;
                                      const cardTxs = getStatementTransactions(card.id, cardStatementDate);
                                      const usage = cardTxs.reduce((acc, t) => acc + t.amount, 0);
                                      const limit = card.initial_balance || 5000;
                                      return (
                                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                                              <div className="bg-white dark:bg-[#23243a] p-5 rounded-3xl border border-slate-100 dark:border-white/5 flex flex-col justify-center">
                                                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Total da Fatura</p>
                                                  <p className="text-xl font-black text-slate-900 dark:text-white tabular-nums tracking-tighter">{showValues ? formatCurrency(usage) : '****'}</p>
                                              </div>
                                              <div className="bg-white dark:bg-[#23243a] p-5 rounded-3xl border border-slate-100 dark:border-white/5 flex flex-col justify-center">
                                                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Limite Disponível</p>
                                                  <p className="text-xl font-black text-emerald-500 tabular-nums tracking-tighter">{showValues ? formatCurrency(limit - usage) : '****'}</p>
                                              </div>
                                              <div className="bg-white dark:bg-[#23243a] p-5 rounded-3xl border border-slate-100 dark:border-white/5 flex flex-col justify-center">
                                                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Vencimento</p>
                                                  <p className="text-xl font-black text-slate-700 dark:text-white tabular-nums tracking-tighter">Dia {card.due_day || 10}</p>
                                              </div>
                                          </div>
                                      );
                                  })()}

                                  {/* Tabela de Compras do Cartão */}
                                  <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] shadow-xl shadow-slate-200/50 dark:shadow-none border border-slate-100 dark:border-white/5 overflow-hidden">
                                      <div className="overflow-x-auto">
                                          <table className="w-full text-left border-collapse">
                                              <thead>
                                                  <tr className="border-b border-slate-50 dark:border-white/5 bg-slate-50/50 dark:bg-white/2">
                                                      <th className="px-8 py-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.25em]">Data</th>
                                                      <th className="px-8 py-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.25em]">Descrição da Compra</th>
                                                      <th className="px-8 py-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.25em]">Categoria</th>
                                                      <th className="px-8 py-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.25em] text-right">Valor</th>
                                                      <th className="px-8 py-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.25em] text-center">Ações</th>
                                                  </tr>
                                              </thead>
                                              <tbody className="divide-y divide-slate-50 dark:divide-white/5">
                                                  {getStatementTransactions(selectedCardId || '', cardStatementDate)
                                                      .map(t => (
                                                          <tr key={t.id} className="group hover:bg-emerald-50/30 dark:hover:bg-emerald-500/5 transition-all duration-300">
                                                              <td className="px-8 py-5 whitespace-nowrap">
                                                                  <div className="flex flex-col">
                                                                      <span className="text-xs font-black text-slate-700 dark:text-white tabular-nums">
                                                                          {new Date(getSafeTimestamp(t.date)).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}
                                                                      </span>
                                                                      <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                                                                          {new Date(getSafeTimestamp(t.date)).toLocaleDateString('pt-BR', { weekday: 'short' })}
                                                                      </span>
                                                                  </div>
                                                              </td>
                                                              <td className="px-8 py-5">
                                                                  <p className="text-xs font-black text-slate-800 dark:text-white uppercase tracking-tighter truncate max-w-[250px] group-hover:text-emerald-600 transition-colors">
                                                                      {t.description}
                                                                  </p>
                                                              </td>
                                                              <td className="px-8 py-5">
                                                                  {t.category_id ? (
                                                                      <div className="flex items-center gap-3">
                                                                          <div className="w-2.5 h-2.5 rounded-full shadow-sm" style={{ backgroundColor: categories.find(c => c.id === t.category_id)?.color || '#ccc' }}></div>
                                                                          <span className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest">
                                                                              {categories.find(c => c.id === t.category_id)?.name || 'Sem Categoria'}
                                                                          </span>
                                                                      </div>
                                                                  ) : (
                                                                      <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest italic">Sem Categoria</span>
                                                                  )}
                                                              </td>
                                                              <td className="px-8 py-5 text-right">
                                                                  <span className="text-sm font-black text-slate-900 dark:text-white tabular-nums tracking-tighter group-hover:text-emerald-600 transition-colors">
                                                                      {showValues ? formatCurrency(t.amount) : '****'}
                                                                  </span>
                                                              </td>
                                                              <td className="px-8 py-5">
                                                                  <div className="flex items-center justify-center gap-3 opacity-0 group-hover:opacity-100 transition-all translate-x-2 group-hover:translate-x-0">
                                                                      <button 
                                                                        onClick={() => {
                                                                            setEditingTx(t);
                                                                            setTxForm({
                                                                                description: t.description,
                                                                                amount: t.amount.toString(),
                                                                                type: t.type,
                                                                                walletId: t.wallet_id || '',
                                                                                categoryId: t.category_id || '',
                                                                                date: toLocalISO(new Date(getSafeTimestamp(t.date))),
                                                                                status: t.status || 'paid',
                                                                                notes: t.notes || '',
                                                                                tags: t.tags || [],
                                                                                isFixed: t.is_fixed || false,
                                                                                isInstallment: (t.installments_count || 0) > 1,
                                                                                installments_count: t.installments_count || 1,
                                                                                targetWalletId: t.target_wallet_id || '',
                                                                                origin: t.origin || 'manual'
                                                                            });
                                                                            setIsTxModalOpen(true);
                                                                        }}
                                                                        className="w-8 h-8 rounded-xl bg-white dark:bg-[#1a1b2e] border border-slate-100 dark:border-white/10 flex items-center justify-center text-slate-400 hover:text-emerald-600 hover:border-emerald-200 transition-all shadow-sm"
                                                                      >
                                                                          <Pencil size={14} />
                                                                      </button>
                                                                      <button 
                                                                        onClick={() => setTxToDelete(t)}
                                                                        className="w-8 h-8 rounded-xl bg-white dark:bg-[#1a1b2e] border border-slate-100 dark:border-white/10 flex items-center justify-center text-slate-400 hover:text-rose-600 hover:border-rose-200 transition-all shadow-sm"
                                                                      >
                                                                          <Trash2 size={14} />
                                                                      </button>
                                                                  </div>
                                                              </td>
                                                          </tr>
                                                      ))}
                                                  {getStatementTransactions(selectedCardId || '', cardStatementDate).length === 0 && (
                                                      <tr>
                                                          <td colSpan={5} className="px-8 py-20 text-center">
                                                              <div className="flex flex-col items-center gap-4 opacity-20">
                                                                  <div className="w-20 h-20 rounded-[2rem] bg-slate-100 dark:bg-white/5 flex items-center justify-center">
                                                                      <CreditCardIcon size={40} strokeWidth={1.5}/>
                                                                  </div>
                                                                  <p className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em]">Nenhuma compra lançada nesta fatura</p>
                                                              </div>
                                                          </td>
                                                      </tr>
                                                  )}
                                              </tbody>
                                          </table>
                                      </div>
                                  </div>
                              </div>
                          )}
                      </div>
                  )}

                  {/* CATEGORIAS - HIERARQUIA */}
                  {activeTab === 'categories' && (
                    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-8 pb-32 px-4 sm:px-0">
                        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                            <div>
                                <h2 className="text-xl sm:text-2xl font-black text-slate-800 dark:text-white uppercase tracking-tighter italic">Minhas Categorias</h2>
                                <p className="text-[9px] sm:text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Organize suas movimentações em níveis e subníveis</p>
                            </div>
                            <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
                                <div className="flex bg-white dark:bg-[#23243a] p-1.5 rounded-2xl border border-gray-100 dark:border-white/5 shadow-sm transition-all overflow-hidden flex-1 sm:flex-none">
                                    <button 
                                        onClick={() => setCategoryViewType('expense')}
                                        className={`flex-1 sm:flex-none px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${categoryViewType === 'expense' ? 'bg-rose-500 text-white shadow-lg' : 'text-gray-400'}`}
                                    >
                                        Despesas
                                    </button>
                                    <button 
                                        onClick={() => setCategoryViewType('income')}
                                        className={`flex-1 sm:flex-none px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${categoryViewType === 'income' ? 'bg-emerald-500 text-white shadow-lg' : 'text-gray-400'}`}
                                    >
                                        Receitas
                                    </button>
                                </div>
                                <button onClick={() => { 
                                    setEditingCategory(null); 
                                    setCategoryForm({ name: '', type: categoryViewType, color: '#0099ff', icon: 'tag', parentId: null, description: '' });
                                    setIsCategoryModalOpen(true); 
                                }} className="bg-indigo-600 text-white px-8 py-3.5 rounded-2xl font-black text-[11px] uppercase tracking-[0.2em] shadow-xl flex items-center justify-center gap-2 active:scale-95 transition-all">
                                    <Plus size={18} strokeWidth={3} /> Nova Categoria
                                </button>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 sm:gap-8">
                            {organizedCategories.map(parent => (
                                <div key={parent.id} className="bg-white dark:bg-[#23243a] rounded-[2rem] sm:rounded-[3rem] shadow-sm border border-slate-100 dark:border-white/5 overflow-hidden group hover:shadow-2xl transition-all">
                                    <div className="p-6 sm:p-8 border-b border-gray-50 dark:border-white/5 flex justify-between items-center transition-colors">
                                        <div className="flex items-center gap-4 min-w-0">
                                            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl flex items-center justify-center text-white shadow-xl shrink-0" style={{ backgroundColor: parent.color || '#6366f1' }}>
                                                {React.createElement(PRESET_ICONS.find(i => i.id === parent.icon)?.icon || Tag, { size: 24 })}
                                            </div>
                                            <div className="min-w-0">
                                                <h3 className="text-base sm:text-lg font-black text-slate-800 dark:text-white uppercase tracking-tight leading-none mb-1 truncate">{parent.name}</h3>
                                                <span className="text-[8px] sm:text-[9px] font-black text-slate-400 uppercase tracking-widest">{parent.subcategories.length} SUBCATEGORIAS</span>
                                            </div>
                                        </div>
                                        <div className="flex gap-1 shrink-0">
                                            <button onClick={() => { 
                                                setEditingCategory(parent); 
                                                setCategoryForm({ ...parent, color: parent.color || '#0099ff', icon: parent.icon || 'tag', parentId: null, description: parent.description || '' }); 
                                                setIsCategoryModalOpen(true); 
                                            }} className="p-2 text-slate-400 hover:text-indigo-600 transition-colors"><Pencil size={16} /></button>
                                            <button onClick={() => { setCategoryToDelete(parent); }} className="p-2 text-slate-400 hover:text-rose-500 transition-colors"><Trash2 size={16}/></button>
                                        </div>
                                    </div>
                                    <div className="p-6 sm:p-8 space-y-3 sm:space-y-4">
                                        {parent.subcategories.map(sub => (
                                            <div key={sub.id} className="flex items-center justify-between p-3 sm:p-4 bg-gray-50 dark:bg-[#1a1b2e] rounded-2xl group/sub transition-all hover:translate-x-1">
                                                <div className="flex items-center gap-3 min-w-0">
                                                    <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: parent.color || '#6366f1' }}></div>
                                                    <span className="text-xs font-bold text-slate-600 dark:text-gray-300 uppercase tracking-tight truncate">{sub.name}</span>
                                                </div>
                                                <div className="flex gap-2 shrink-0">
                                                    <button onClick={() => { 
                                                        setEditingCategory(sub); 
                                                        setCategoryForm({ ...sub, color: sub.color || '#0099ff', icon: sub.icon || 'tag', parentId: sub.parent_id, description: sub.description || '' }); 
                                                        setIsCategoryModalOpen(true); 
                                                    }} className="text-slate-400 hover:text-indigo-600"><Pencil size={12}/></button>
                                                    <button onClick={() => setCategoryToDelete(sub)} className="text-slate-400 hover:text-rose-500"><Trash2 size={12}/></button>
                                                </div>
                                            </div>
                                        ))}
                                        <button 
                                            onClick={() => { 
                                                setEditingCategory(null); 
                                                setCategoryForm({ name: '', type: parent.type, color: parent.color || '#0099ff', icon: parent.icon || 'tag', parentId: parent.id, description: '' }); 
                                                setIsCategoryModalOpen(true); 
                                            }}
                                            className="w-full py-4 border-2 border-dashed border-gray-100 dark:border-white/5 rounded-2xl text-[10px] font-black text-slate-400 uppercase tracking-widest hover:border-indigo-500 hover:text-indigo-600 transition-all flex items-center justify-center gap-2"
                                        >
                                            <PlusCircle size={14} /> Adicionar Subcategoria
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                  )}
              </div>
          </div>
      </div>

      {/* MODAL CARTEIRA (WALLET) */}
      {isWalletModalOpen && (
          <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4 backdrop-blur-sm transition-all animate-in fade-in">
              <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in-95 border border-transparent dark:border-white/5 transition-colors flex flex-col max-h-[90vh]">
                  <div className="p-8 sm:p-10 border-b border-gray-50 dark:border-white/5 flex justify-between items-center transition-colors shrink-0">
                      <div>
                        <h3 className="text-xl sm:text-2xl font-black text-gray-800 dark:text-white uppercase tracking-tighter italic leading-none">{editingWallet ? 'Editar Conta' : 'Nova Conta'}</h3>
                        <p className="text-[9px] sm:text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mt-2">Gestão de Carteiras e Bancos</p>
                      </div>
                      <button onClick={() => { setIsWalletModalOpen(false); setEditingWallet(null); }} className="p-2 text-gray-400 hover:text-rose-500 transition-colors"><X size={28} /></button>
                  </div>
                  
                  <div className="p-8 sm:p-10 space-y-8 overflow-y-auto custom-scrollbar">
                      <div className="space-y-6">
                          {/* Nome */}
                          <div className="relative group">
                              <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-1 text-[10px] font-black text-indigo-500 uppercase tracking-widest transition-all">Nome da Conta</label>
                              <div className="flex items-center border-2 border-gray-100 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] focus-within:border-indigo-400 transition-all">
                                  <Building className="text-gray-300 mr-3" size={20} />
                                  <input 
                                    type="text" 
                                    className="w-full bg-transparent outline-none text-base font-black text-slate-800 dark:text-white uppercase placeholder:text-gray-500" 
                                    placeholder="Ex: ITAÚ, NUBANK, CAIXA..." 
                                    value={walletForm.name} 
                                    onChange={e => setWalletForm({...walletForm, name: e.target.value})} 
                                  />
                              </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                              {/* Tipo */}
                              <div className="relative group">
                                  <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-1 text-[10px] font-black text-gray-400 uppercase tracking-widest">Tipo de Conta</label>
                                  <div className="flex items-center border-2 border-gray-100 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] focus-within:border-indigo-400 transition-all">
                                      <Landmark className="text-gray-300 mr-3" size={20} />
                                      <select className="w-full bg-transparent outline-none text-sm font-bold text-slate-700 dark:text-white cursor-pointer appearance-none uppercase" value={walletForm.type} onChange={e => setWalletForm({...walletForm, type: e.target.value})}>
                                          <option value="bank" className="bg-white dark:bg-[#1a1b2e] text-slate-700 dark:text-white">CONTA CORRENTE</option>
                                          <option value="money" className="bg-white dark:bg-[#1a1b2e] text-slate-700 dark:text-white">DINHEIRO FÍSICO</option>
                                          <option value="credit" className="bg-white dark:bg-[#1a1b2e] text-slate-700 dark:text-white">CARTÃO DE CRÉDITO</option>
                                      </select>
                                      <ChevronDownIcon size={16} className="text-gray-400" />
                                  </div>
                              </div>
                              {/* Saldo Atual */}
                              <div className="relative group">
                                  <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-1 text-[10px] font-black text-gray-400 uppercase tracking-widest">Saldo Atual R$</label>
                                  <div className="flex items-center border-2 border-gray-100 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] focus-within:border-indigo-400 transition-all">
                                      <DollarSign className="text-gray-300 mr-2" size={20} />
                                      <input 
                                        type="text" 
                                        className="w-full bg-transparent outline-none text-xl font-black text-indigo-600 dark:text-indigo-400 tabular-nums placeholder:text-gray-500" 
                                        placeholder="0,00" 
                                        value={walletForm.balance} 
                                        onChange={e => setWalletForm({...walletForm, balance: e.target.value})} 
                                      />
                                  </div>
                              </div>
                          </div>

                          {walletForm.type === 'credit' && (
                              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 animate-in slide-in-from-top-2">
                                  <div className="relative group">
                                      <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-gray-400 uppercase tracking-widest">Limite R$</label>
                                      <input type="text" className="w-full border-2 border-gray-100 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] outline-none focus:border-indigo-400 text-sm font-bold tabular-nums" value={walletForm.initial_balance} onChange={e => setWalletForm({...walletForm, initial_balance: e.target.value})} />
                                  </div>
                                  <div className="relative group">
                                      <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-gray-400 uppercase tracking-widest">Fechamento</label>
                                      <input type="number" className="w-full border-2 border-gray-100 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] outline-none focus:border-indigo-400 text-sm font-bold" value={isNaN(Number(walletForm.closing_day)) ? '' : walletForm.closing_day} onChange={e => setWalletForm({...walletForm, closing_day: parseInt(e.target.value)})} />
                                  </div>
                                  <div className="relative group">
                                      <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-gray-400 uppercase tracking-widest">Vencimento</label>
                                      <input type="number" className="w-full border-2 border-gray-100 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] outline-none focus:border-indigo-400 text-sm font-bold" value={isNaN(Number(walletForm.due_day)) ? '' : walletForm.due_day} onChange={e => setWalletForm({...walletForm, due_day: parseInt(e.target.value)})} />
                                  </div>
                              </div>
                          )}

                          <div className="space-y-4">
                              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Cor de Identificação</p>
                              <div className="flex flex-wrap gap-3">
                                  {PRESET_COLORS.map(color => (
                                      <button key={color.id} onClick={() => setWalletForm({...walletForm, color: color.hex})} className={`w-10 h-10 rounded-xl transition-all shadow-sm ${walletForm.color === color.hex ? 'ring-4 ring-offset-2 ring-indigo-500 scale-110' : 'hover:scale-110'}`} style={{ backgroundColor: color.hex }}></button>
                                  ))}
                              </div>
                          </div>
                      </div>
                  </div>

                  <div className="p-8 sm:p-10 border-t border-gray-50 dark:border-white/5 bg-gray-50/30 dark:bg-white/5 flex flex-col sm:flex-row gap-4 transition-colors shrink-0">
                      <button onClick={() => { setIsWalletModalOpen(false); setEditingWallet(null); }} className="w-full sm:flex-1 py-4 bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 text-gray-400 font-black text-[11px] uppercase rounded-2xl transition-all">CANCELAR</button>
                      <button onClick={handleSaveWallet} className="w-full sm:flex-[2] py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-black text-[11px] uppercase tracking-widest shadow-xl transition-all active:scale-95 flex items-center justify-center gap-2">
                        <Check size={20} strokeWidth={4} /> {editingWallet ? 'ATUALIZAR CONTA' : 'CRIAR CONTA'}
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* MODAL LANÇAMENTO (TX) - REDESIGN COMPLETO */}
      {isTxModalOpen && (
          <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4 backdrop-blur-sm transition-all animate-in fade-in">
              <div className={`bg-white dark:bg-[#23243a] rounded-[2.5rem] w-full ${isModalExpanded ? 'max-w-4xl' : 'max-w-lg'} shadow-2xl overflow-hidden animate-in zoom-in-95 border border-transparent dark:border-white/5 transition-all duration-500 flex flex-col max-h-[90vh]`}>
                  <div className="p-8 sm:p-10 border-b border-gray-100 dark:border-white/5 flex justify-between items-center transition-colors shrink-0">
                      <h3 className="text-xl sm:text-2xl font-black text-gray-800 dark:text-white uppercase tracking-tighter italic leading-none">
                          {editingTx ? 'EDITAR' : 'NOVA'} {txForm.type === 'income' ? 'RECEITA' : txForm.type === 'expense' ? 'DESPESA' : 'TRANSFERÊNCIA'}
                      </h3>
                      <button onClick={() => { setIsTxModalOpen(false); setEditingTx(null); setIsModalExpanded(false); }} className="p-2 text-gray-400 hover:text-rose-500 transition-colors"><X size={28} /></button>
                  </div>
                  
                  <div className="flex flex-col md:flex-row flex-1 overflow-hidden">
                      {/* Lado Esquerdo - Principal */}
                      <div className={`flex-1 p-8 sm:p-10 space-y-8 overflow-y-auto custom-scrollbar ${isModalExpanded ? 'md:border-r border-gray-100 dark:border-white/5' : ''}`}>
                          {/* Valor */}
                          <div className="relative group">
                              <div className={cn(
                                "flex items-center border-b-2 pb-2 transition-all",
                                txForm.type === 'income' ? "border-blue-500 dark:border-blue-400" : 
                                txForm.type === 'expense' ? "border-rose-500 dark:border-rose-400" : 
                                "border-indigo-500 dark:border-indigo-400"
                              )}>
                                  <Calculator className="text-gray-400 mr-4" size={28} />
                                  <span className={cn(
                                    "text-2xl font-black mr-2",
                                    txForm.type === 'income' ? "text-blue-500 dark:text-blue-400" : 
                                    txForm.type === 'expense' ? "text-rose-500 dark:text-rose-400" : 
                                    "text-indigo-500 dark:text-indigo-400"
                                  )}>R$</span>
                                  <input 
                                    type="text" 
                                    className={cn(
                                      "w-full bg-transparent outline-none text-4xl font-black tabular-nums placeholder:text-gray-400",
                                      txForm.type === 'income' ? "text-blue-600 dark:text-blue-400" : 
                                      txForm.type === 'expense' ? "text-red-500 dark:text-red-400" : 
                                      "text-slate-800 dark:text-white"
                                    )} 
                                    placeholder="0,00" 
                                    value={txForm.amount} 
                                    onChange={e => setTxForm({...txForm, amount: e.target.value})} 
                                  />
                                  <span className="text-[10px] font-black text-gray-400 ml-2">BRL <ChevronDownIcon size={10} className="inline" /></span>
                              </div>
                          </div>

                          {/* Status Pago */}
                          <div className="flex items-center justify-between">
                              <div className="flex items-center gap-4">
                                  <div className="w-10 h-10 rounded-full bg-gray-50 dark:bg-white/5 flex items-center justify-center text-gray-400">
                                      <Check size={20} />
                                  </div>
                                  <span className="text-[11px] font-black text-gray-400 uppercase tracking-[0.2em]">FOI PAGA</span>
                              </div>
                              <button 
                                  onClick={() => setTxForm({...txForm, status: txForm.status === 'paid' ? 'pending' : 'paid'})}
                                  className={`w-12 h-6 rounded-full relative transition-all duration-300 ${txForm.status === 'paid' ? 'bg-rose-500' : 'bg-gray-200 dark:bg-white/10'}`}
                              >
                                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300 ${txForm.status === 'paid' ? 'left-7' : 'left-1'}`}></div>
                              </button>
                          </div>

                          {/* Data Selector */}
                          <div className="flex items-center gap-4">
                              <div className="w-10 h-10 rounded-full bg-gray-50 dark:bg-white/5 flex items-center justify-center text-gray-400 shrink-0">
                                  <Calendar size={20} />
                              </div>
                              <div className="flex gap-2 flex-1">
                                  <button 
                                      onClick={() => setTxForm({...txForm, date: getLocalDateISO()})}
                                      className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${txForm.date === getLocalDateISO() ? 'bg-indigo-600 text-white shadow-lg' : 'bg-gray-100 dark:bg-white/5 text-gray-400'}`}
                                  >
                                      HOJE
                                  </button>
                                  <button 
                                      onClick={() => {
                                          const d = new Date();
                                          d.setDate(d.getDate() - 1);
                                          setTxForm({...txForm, date: d.toISOString().split('T')[0]});
                                      }}
                                      className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${txForm.date === new Date(new Date().setDate(new Date().getDate()-1)).toISOString().split('T')[0] ? 'bg-indigo-600 text-white shadow-lg' : 'bg-gray-100 dark:bg-white/5 text-gray-400'}`}
                                  >
                                      ONTEM
                                  </button>
                                  <div className="relative flex-1">
                                      <input 
                                          type="date" 
                                          className="w-full bg-gray-100 dark:bg-white/5 border-none rounded-xl px-4 py-2.5 text-xs font-bold text-slate-700 dark:text-white outline-none" 
                                          value={txForm.date} 
                                          onChange={e => setTxForm({...txForm, date: e.target.value})} 
                                      />
                                  </div>
                              </div>
                          </div>

                          {/* Descrição */}
                          <div className="flex items-center gap-4">
                              <div className="w-10 h-10 rounded-full bg-gray-50 dark:bg-white/5 flex items-center justify-center text-gray-400 shrink-0">
                                  <FileText size={20} />
                              </div>
                              <div className="flex-1 border-b border-gray-100 dark:border-white/10 pb-1">
                                  <input 
                                    type="text" 
                                    className="w-full bg-transparent outline-none text-xs font-black text-gray-800 dark:text-white uppercase tracking-widest placeholder:text-gray-400" 
                                    placeholder="DESCRIÇÃO" 
                                    value={txForm.description} 
                                    onChange={e => setTxForm({...txForm, description: e.target.value})} 
                                  />
                              </div>
                          </div>

                          {/* Categoria */}
                          <div className="flex items-center gap-4">
                              <div className="w-10 h-10 rounded-full bg-gray-50 dark:bg-white/5 flex items-center justify-center text-gray-400 shrink-0">
                                  <Bookmark size={20} />
                              </div>
                              <button 
                                  onClick={() => { setCategorySearch(''); setIsCategoryPickerOpen(true); }}
                                  className="flex-1 flex items-center justify-between border-2 border-rose-500/30 rounded-full px-6 py-2.5 bg-white dark:bg-transparent hover:border-rose-500 transition-all text-left"
                              >
                                  <span className="text-[10px] font-black text-slate-700 dark:text-gray-300 uppercase tracking-widest truncate">
                                      {selectedCategoryData ? selectedCategoryData.name : 'SELECIONE A CATEGORIA'}
                                  </span>
                                  <ChevronDownIcon size={14} className="text-rose-500" />
                              </button>
                          </div>

                          {/* Conta / Carteira */}
                          <div className="flex items-center gap-4">
                              <div className="w-10 h-10 rounded-full bg-gray-50 dark:bg-white/5 flex items-center justify-center text-gray-400 shrink-0">
                                  <CreditCard size={20} />
                              </div>
                              <div className="relative flex-1">
                                  <select 
                                      className="w-full border-2 border-gray-100 dark:border-white/10 rounded-full px-6 py-2.5 bg-white dark:bg-transparent text-[10px] font-black text-slate-700 dark:text-gray-300 uppercase tracking-widest outline-none focus:border-indigo-400 appearance-none cursor-pointer" 
                                      value={txForm.walletId} 
                                      onChange={e => setTxForm({...txForm, walletId: e.target.value})}
                                  >
                                      <option value="" className="bg-white dark:bg-[#1a1b2e] text-slate-700 dark:text-gray-300">{txForm.type === 'transfer' ? 'CONTA DE ORIGEM' : 'SELECIONE O CARTÃO/CARTEIRA'}</option>
                                      {wallets.map(w => <option key={w.id} value={w.id} className="bg-white dark:bg-[#1a1b2e] text-slate-700 dark:text-gray-300">{w.name.toUpperCase()}</option>)}
                                  </select>
                                  <ChevronDownIcon size={14} className="absolute right-6 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                              </div>
                          </div>

                          {/* Conta de Destino (Apenas para Transferência) */}
                          {txForm.type === 'transfer' && (
                              <div className="flex items-center gap-4 animate-in slide-in-from-top-2">
                                  <div className="w-10 h-10 rounded-full bg-indigo-50 dark:bg-indigo-500/10 flex items-center justify-center text-indigo-500 shrink-0">
                                      <ArrowRightLeft size={20} />
                                  </div>
                                  <div className="relative flex-1">
                                      <select 
                                          className="w-full border-2 border-indigo-100 dark:border-indigo-500/20 rounded-full px-6 py-2.5 bg-white dark:bg-transparent text-[10px] font-black text-slate-700 dark:text-gray-300 uppercase tracking-widest outline-none focus:border-indigo-400 appearance-none cursor-pointer" 
                                          value={txForm.targetWalletId} 
                                          onChange={e => setTxForm({...txForm, targetWalletId: e.target.value})}
                                      >
                                          <option value="" className="bg-white dark:bg-[#1a1b2e] text-slate-700 dark:text-gray-300">CONTA DE DESTINO</option>
                                          {wallets.filter(w => w.id !== txForm.walletId).map(w => <option key={w.id} value={w.id} className="bg-white dark:bg-[#1a1b2e] text-slate-700 dark:text-gray-300">{w.name.toUpperCase()}</option>)}
                                      </select>
                                      <ChevronDownIcon size={14} className="absolute right-6 top-1/2 -translate-y-1/2 text-indigo-400 pointer-events-none" />
                                  </div>
                              </div>
                          )}

                          {/* Mais Detalhes Toggle */}
                          <div className="flex justify-end">
                              <button 
                                  onClick={() => setIsModalExpanded(!isModalExpanded)}
                                  className="flex items-center gap-2 text-[10px] font-black text-slate-800 dark:text-white uppercase tracking-widest hover:underline"
                              >
                                  {isModalExpanded ? 'MENOS DETALHES' : 'MAIS DETALHES'} 
                                  {isModalExpanded ? <ChevronUp size={16} /> : <ChevronRight size={16} />}
                              </button>
                          </div>
                      </div>

                      {/* Lado Direito - Detalhes Adicionais */}
                      {isModalExpanded && (
                          <div className="flex-1 p-8 sm:p-10 space-y-8 bg-gray-50/30 dark:bg-white/5 animate-in slide-in-from-right-4 duration-500 overflow-y-auto custom-scrollbar">
                              {/* Tags */}
                              <div className="flex items-center gap-4">
                                  <div className="w-10 h-10 rounded-full bg-white dark:bg-[#1a1b2e] flex items-center justify-center text-gray-400 shrink-0 shadow-sm">
                                      <Tag size={20} />
                                  </div>
                                  <div className="relative flex-1">
                                      <select className="w-full border-b border-gray-200 dark:border-white/10 bg-transparent py-2 text-xs font-bold text-gray-400 outline-none appearance-none">
                                          <option className="bg-white dark:bg-[#1a1b2e] text-slate-700 dark:text-gray-300">Tags</option>
                                      </select>
                                      <ChevronDownIcon size={14} className="absolute right-0 top-1/2 -translate-y-1/2 text-gray-400" />
                                  </div>
                              </div>

                              {/* Observações */}
                              <div className="flex items-center gap-4">
                                  <div className="w-10 h-10 rounded-full bg-white dark:bg-[#1a1b2e] flex items-center justify-center text-gray-400 shrink-0 shadow-sm">
                                      <PenLine size={20} />
                                  </div>
                                  <div className="flex-1 border-b border-gray-200 dark:border-white/10 pb-1">
                                      <input 
                                          type="text" 
                                          className="w-full bg-transparent outline-none text-xs font-bold text-gray-500 dark:text-gray-400 placeholder:text-gray-500" 
                                          placeholder="Descrição" 
                                          value={txForm.notes}
                                          onChange={e => setTxForm({...txForm, notes: e.target.value})}
                                      />
                                  </div>
                              </div>

                              {/* Despesa Fixa */}
                              <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-4">
                                      <div className="w-10 h-10 rounded-full bg-white dark:bg-[#1a1b2e] flex items-center justify-center text-gray-400 shadow-sm">
                                          <Pin size={20} />
                                      </div>
                                      <span className="text-[11px] font-black text-gray-400 uppercase tracking-[0.2em]">DESPESA FIXA</span>
                                  </div>
                                  <button 
                                      onClick={() => setTxForm({...txForm, isFixed: !txForm.isFixed})}
                                      className={`w-12 h-6 rounded-full relative transition-all duration-300 ${txForm.isFixed ? 'bg-indigo-600' : 'bg-gray-200 dark:bg-white/10'}`}
                                  >
                                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300 ${txForm.isFixed ? 'left-7' : 'left-1'}`}></div>
                                  </button>
                              </div>

                              {/* Repetir */}
                              <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-4">
                                      <div className="w-10 h-10 rounded-full bg-white dark:bg-[#1a1b2e] flex items-center justify-center text-gray-400 shadow-sm">
                                          <Repeat size={20} />
                                      </div>
                                      <span className="text-[11px] font-black text-gray-400 uppercase tracking-[0.2em]">REPETIR</span>
                                  </div>
                                  <button 
                                      onClick={() => setTxForm({...txForm, isInstallment: !txForm.isInstallment})}
                                      className={`w-12 h-6 rounded-full relative transition-all duration-300 ${txForm.isInstallment ? 'bg-indigo-600' : 'bg-gray-200 dark:bg-white/10'}`}
                                  >
                                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300 ${txForm.isInstallment ? 'left-7' : 'left-1'}`}></div>
                                  </button>
                              </div>
                          </div>
                      )}
                  </div>

                  <div className="p-8 sm:p-10 border-t border-gray-100 dark:border-white/5 bg-gray-50/30 dark:bg-white/5 flex flex-col sm:flex-row justify-end gap-4 transition-colors shrink-0">
                      {!editingTx && (
                          <button 
                              onClick={() => { handleSaveTransaction(true); }}
                              disabled={isLoading}
                              className="text-[11px] font-black text-gray-400 uppercase tracking-widest hover:text-indigo-600 transition-colors disabled:opacity-50"
                          >
                              SALVAR E CRIAR NOVA
                          </button>
                      )}
                      <button 
                          onClick={() => handleSaveTransaction(false)} 
                          disabled={isLoading}
                          className="px-12 py-4 bg-indigo-600 text-white rounded-full font-black text-[11px] uppercase tracking-widest shadow-xl transition-all active:scale-95 disabled:opacity-50"
                      >
                          {isLoading ? <Loader2 className="animate-spin inline" size={16} /> : (editingTx ? 'ATUALIZAR LANÇAMENTO' : 'SALVAR')}
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* CATEGORY PICKER POPUP (CUSTOM OVERLAY) */}
      {isCategoryPickerOpen && (
          <div className="fixed inset-0 bg-black/80 z-[200] flex items-center justify-center p-4 lg:p-10 animate-in fade-in transition-all">
              <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in zoom-in-95 duration-200 border border-transparent dark:border-white/5">
                  <div className="p-8 border-b border-gray-100 dark:border-white/5 bg-gray-50/50 dark:bg-white/5 shrink-0 transition-colors">
                      <div className="flex justify-between items-center mb-6">
                        <h3 className="text-xl font-black text-slate-800 dark:text-white uppercase tracking-tighter italic flex items-center gap-3">
                            <Layers className="text-indigo-600" /> Escolha a Categoria
                        </h3>
                        <button onClick={() => setIsCategoryPickerOpen(false)} className="p-2 text-slate-400 hover:text-rose-500 transition-colors bg-white dark:bg-[#1a1b2e] rounded-full shadow-sm"><X size={20} /></button>
                      </div>
                      <div className="relative group">
                          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-indigo-500 transition-colors" size={18} />
                          <input 
                            autoFocus
                            type="text" 
                            className="w-full pl-12 pr-4 py-3 bg-white dark:bg-[#1a1b2e] border-2 border-gray-100 dark:border-white/10 rounded-2xl outline-none focus:border-indigo-400 text-sm font-bold uppercase transition-all"
                            placeholder="Pesquisar categoria..."
                            value={categorySearch}
                            onChange={(e) => setCategorySearch(e.target.value)}
                          />
                      </div>
                  </div>
                  
                  <div className="flex-1 overflow-y-auto p-4 custom-scrollbar space-y-3 bg-white dark:bg-[#23243a]">
                      {filteredPickerCategories.length === 0 ? (
                        <div className="py-20 text-center text-slate-300 dark:text-gray-700 italic uppercase font-black tracking-widest text-[10px]">Nenhuma categoria encontrada</div>
                      ) : (
                        filteredPickerCategories.map(parent => (
                            <div key={parent.id} className="space-y-1.5 animate-in slide-in-from-top-2 duration-300">
                                <button 
                                    onClick={() => { setTxForm({...txForm, categoryId: parent.id}); setIsCategoryPickerOpen(false); }}
                                    className={`w-full flex items-center justify-between p-4 rounded-[1.8rem] transition-all group ${txForm.categoryId === parent.id ? 'bg-indigo-50 dark:bg-indigo-500/10 border-2 border-indigo-500 shadow-lg' : 'bg-gray-50/50 dark:bg-[#1a1b2e] border-2 border-transparent hover:border-gray-200 dark:hover:border-white/10'}`}
                                >
                                    <div className="flex items-center gap-4 min-w-0">
                                        <div className="w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-xl shrink-0 transition-transform group-hover:scale-110" style={{ backgroundColor: parent.color || '#6366f1' }}>
                                            {React.createElement(PRESET_ICONS.find(i => i.id === parent.icon)?.icon || Tag, { size: 20 })}
                                        </div>
                                        <span className={`text-sm font-black uppercase tracking-tight truncate ${txForm.categoryId === parent.id ? 'text-indigo-700 dark:text-indigo-400' : 'text-slate-700 dark:text-gray-300'}`}>{parent.name}</span>
                                    </div>
                                    {txForm.categoryId === parent.id && <CheckCircle2 size={20} className="text-indigo-600 dark:text-indigo-400" />}
                                </button>
                                
                                {parent.subcategories.map(sub => (
                                    <button 
                                        key={sub.id}
                                        onClick={() => { setTxForm({...txForm, categoryId: sub.id}); setIsCategoryPickerOpen(false); }}
                                        className={`w-[calc(100%-2rem)] ml-auto flex items-center justify-between p-3.5 rounded-[1.5rem] transition-all group/sub ${txForm.categoryId === sub.id ? 'bg-indigo-50 dark:bg-indigo-500/10 border-2 border-indigo-500 shadow-md' : 'bg-transparent border-2 border-transparent hover:bg-gray-50 dark:hover:bg-white/5'}`}
                                    >
                                        <div className="flex items-center gap-3 min-w-0">
                                            <CornerDownRight size={14} className="text-slate-300 shrink-0" />
                                            <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: parent.color }}></div>
                                            <span className={`text-xs font-bold uppercase tracking-tight truncate ${txForm.categoryId === sub.id ? 'text-indigo-700 dark:text-indigo-400' : 'text-slate-500 dark:text-gray-400'}`}>{sub.name}</span>
                                        </div>
                                        {txForm.categoryId === sub.id && <Check size={16} className="text-indigo-600 dark:text-indigo-400" strokeWidth={3} />}
                                    </button>
                                ))}
                            </div>
                        ))
                      )}
                  </div>

                  <div className="p-6 bg-slate-50 dark:bg-white/5 border-t dark:border-white/5 shrink-0 text-center transition-colors">
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Selecione uma opção para continuar</p>
                  </div>
              </div>
          </div>
      )}

      {/* CONFIRMAÇÃO DE EXCLUSÃO DE TRANSAÇÃO */}
      {txToDelete && (
          <div className="fixed inset-0 bg-black/60 z-[110] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in">
              <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] w-full max-w-sm shadow-2xl p-8 sm:p-10 text-center animate-in zoom-in-95 border border-transparent dark:border-white/5 transition-colors">
                  <div className="w-16 h-16 sm:w-20 h-20 bg-rose-50 dark:bg-rose-500/10 text-rose-500 rounded-full flex items-center justify-center mx-auto mb-6"><AlertTriangle size={40} /></div>
                  <h3 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tight mb-2">Cancelar Lançamento?</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-8 leading-relaxed font-medium">Deseja cancelar o lançamento <b>{txToDelete.description}</b>? O valor será estornado da carteira e o registro ficará marcado como cancelado.</p>
                  <div className="flex flex-col gap-3">
                      <button 
                        onClick={handleDeleteTransaction} 
                        disabled={isLoading}
                        className="w-full py-4 bg-rose-500 text-white font-black rounded-2xl shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {isLoading ? <Loader2 className="animate-spin" size={20} /> : 'SIM, CANCELAR AGORA'}
                      </button>
                      <button 
                        onClick={() => setTxToDelete(null)} 
                        disabled={isLoading}
                        className="w-full py-4 bg-slate-100 text-slate-500 font-bold rounded-2xl transition-all disabled:opacity-50"
                      >
                        VOLTAR
                      </button>
                  </div>
              </div>
          </div>
      )}

      {walletToDelete && (
          <div className="fixed inset-0 bg-black/60 z-[110] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in">
              <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] w-full max-w-sm shadow-2xl p-8 sm:p-10 text-center animate-in zoom-in-95 border border-transparent dark:border-white/5 transition-colors">
                  <div className="w-16 h-16 sm:w-20 h-20 bg-rose-50 dark:bg-rose-500/10 text-rose-500 rounded-full flex items-center justify-center mx-auto mb-6"><AlertTriangle size={40} /></div>
                  <h3 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tight mb-2">Excluir Carteira?</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-8 leading-relaxed font-medium">Deseja realmente excluir a carteira <b>{walletToDelete.name}</b>? Esta ação não poderá ser desfeita.</p>
                  <div className="flex flex-col gap-3">
                      <button 
                        onClick={handleDeleteWallet} 
                        disabled={isLoading}
                        className="w-full py-4 bg-rose-500 text-white font-black rounded-2xl shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {isLoading ? <Loader2 className="animate-spin" size={20} /> : 'SIM, EXCLUIR AGORA'}
                      </button>
                      <button 
                        onClick={() => setWalletToDelete(null)} 
                        disabled={isLoading}
                        className="w-full py-4 bg-slate-100 text-slate-500 font-bold rounded-2xl transition-all disabled:opacity-50"
                      >
                        VOLTAR
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* MODAL CATEGORIA */}
      {isCategoryModalOpen && (
          <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4 backdrop-blur-sm transition-all animate-in fade-in">
              <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in-95 border border-transparent dark:border-white/5 transition-colors">
                  <div className="p-8 sm:p-10 border-b border-gray-100 dark:border-white/5 flex justify-between items-center transition-colors">
                      <div>
                        <h3 className="text-2xl font-black text-gray-800 dark:text-white uppercase tracking-tighter italic">{editingCategory ? 'Editar Categoria' : 'Nova Categoria'}</h3>
                        <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mt-2">Classificação de Fluxo Financeiro</p>
                      </div>
                      <button onClick={() => { setIsCategoryModalOpen(false); setEditingCategory(null); }} className="p-2 text-gray-400 hover:text-rose-500 transition-colors"><X size={28} /></button>
                  </div>
                  <div className="p-8 sm:p-10 space-y-8 overflow-y-auto max-h-[70vh] custom-scrollbar">
                      <div className="space-y-6">
                          <div className="relative border-2 border-slate-100 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] focus-within:border-indigo-400 transition-all">
                              <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-indigo-500 uppercase tracking-widest transition-all">Nome da Categoria</label>
                              <input type="text" className="w-full bg-transparent outline-none text-base font-black text-slate-700 dark:text-white uppercase placeholder:text-gray-400" placeholder="Ex: ALIMENTAÇÃO, INTERNET..." value={categoryForm.name} onChange={e => setCategoryForm({...categoryForm, name: e.target.value})} autoFocus />
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                              <div className="relative border-2 border-slate-100 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] focus-within:border-indigo-400 transition-all">
                                  <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-gray-400 uppercase tracking-widest">Tipo</label>
                                  <select className="w-full bg-transparent outline-none text-sm font-bold text-slate-700 dark:text-white cursor-pointer appearance-none" value={categoryForm.type} onChange={e => setCategoryForm({...categoryForm, type: e.target.value as any})}>
                                      <option value="expense" className="bg-white dark:bg-[#1a1b2e] text-slate-700 dark:text-white">DESPESA</option>
                                      <option value="income" className="bg-white dark:bg-[#1a1b2e] text-slate-700 dark:text-white">RECEITA</option>
                                  </select>
                              </div>
                              <div className="relative border-2 border-slate-100 dark:border-white/10 rounded-2xl p-4 bg-white dark:bg-[#1a1b2e] focus-within:border-indigo-400 transition-all">
                                  <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-1 text-[9px] font-black text-gray-400 uppercase tracking-widest">Categoria Pai</label>
                                  <select className="w-full bg-transparent outline-none text-sm font-bold text-slate-700 dark:text-white cursor-pointer appearance-none" value={categoryForm.parentId || ''} onChange={e => setCategoryForm({...categoryForm, parentId: e.target.value || null})}>
                                      <option value="" className="bg-white dark:bg-[#1a1b2e] text-slate-700 dark:text-white">ESTA É UMA PRINCIPAL</option>
                                      {categories.filter(c => !c.parent_id && c.id !== editingCategory?.id && c.type === categoryForm.type).map(c => <option key={c.id} value={c.id} className="bg-white dark:bg-[#1a1b2e] text-slate-700 dark:text-white">{c.name}</option>)}
                                  </select>
                              </div>
                          </div>

                          {!categoryForm.parentId && (
                              <div className="space-y-6 animate-in slide-in-from-top-2">
                                  <div className="space-y-4">
                                      <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Ícone Representativo</p>
                                      <div className="grid grid-cols-4 sm:grid-cols-6 gap-3">
                                          {PRESET_ICONS.map(item => (
                                              <button key={item.id} onClick={() => setCategoryForm({...categoryForm, icon: item.id})} className={`p-3 rounded-xl transition-all border-2 flex items-center justify-center ${categoryForm.icon === item.id ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600' : 'border-gray-50 dark:border-white/5 text-slate-400 hover:border-gray-200'}`} title={item.label}><item.icon size={20} /></button>
                                          ))}
                                      </div>
                                  </div>
                                  <div className="space-y-4">
                                      <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Cor de Identificação</p>
                                      <div className="flex flex-wrap gap-4">
                                          {PRESET_COLORS.map(color => (
                                              <button key={color.id} onClick={() => setCategoryForm({...categoryForm, color: color.hex})} className={`w-10 h-10 rounded-xl transition-all shadow-sm ${categoryForm.color === color.hex ? 'ring-4 ring-offset-2 ring-indigo-500 scale-110' : 'hover:scale-110'}`} style={{ backgroundColor: color.hex }}></button>
                                          ))}
                                      </div>
                                  </div>
                              </div>
                          )}
                      </div>
                  </div>
                  <div className="p-8 sm:p-10 border-t border-gray-100 dark:border-white/5 bg-gray-50/30 dark:bg-white/5 flex flex-col sm:flex-row gap-4 transition-colors">
                      <button onClick={() => { setIsCategoryModalOpen(false); setEditingCategory(null); }} className="flex-1 py-4 bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 text-gray-400 font-black text-[11px] uppercase rounded-2xl transition-all">CANCELAR</button>
                      <button onClick={handleSaveCategory} className="flex-[2] py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-black text-[11px] uppercase tracking-widest shadow-xl flex items-center justify-center gap-3">
                        <CheckCircle2 size={18} strokeWidth={3} /> {editingCategory ? 'ATUALIZAR' : 'CRIAR'}
                      </button>
                  </div>
              </div>
          </div>
      )}

      {categoryToDelete && (
        <div className="fixed inset-0 bg-black/60 z-[110] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] w-full max-w-sm shadow-2xl p-10 text-center animate-in zoom-in-95 border dark:border-white/5 transition-colors">
                <div className="w-20 h-20 bg-rose-50 dark:bg-rose-500/10 text-rose-500 rounded-full flex items-center justify-center mx-auto mb-6"><AlertTriangle size={40} /></div>
                <h3 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Excluir Categoria?</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-8 leading-relaxed font-medium">Você está excluindo a categoria <b>{categoryToDelete.name}</b>. Isso pode afetar lançamentos vinculados.</p>
                <div className="flex flex-col gap-3">
                    <button onClick={handleDeleteCategory} className="w-full py-4 bg-rose-500 text-white font-black rounded-2xl shadow-xl active:scale-95 transition-all">SIM, EXCLUIR AGORA</button>
                    <button onClick={() => setCategoryToDelete(null)} className="w-full py-4 bg-slate-100 text-slate-500 font-bold rounded-2xl transition-all">VOLTAR</button>
                </div>
            </div>
        </div>
      )}

      {/* MOBILE ACTION POPUP */}
      {mobileActionTx && (
          <div className="fixed inset-0 bg-black/60 z-[150] flex items-end sm:items-center justify-center p-0 sm:p-4 backdrop-blur-sm animate-in fade-in">
              <div className="bg-white dark:bg-[#23243a] w-full max-w-sm rounded-t-[2.5rem] sm:rounded-[2.5rem] shadow-2xl p-8 sm:p-10 animate-in slide-in-from-bottom-10 duration-300 border border-transparent dark:border-white/5 transition-colors">
                  <div className="flex justify-between items-center mb-8">
                      <div>
                          <h3 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tight leading-none mb-1">{mobileActionTx.description}</h3>
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                              {new Date(getSafeTimestamp(mobileActionTx.date)).toLocaleDateString('pt-BR')} • {formatCurrency(mobileActionTx.amount)}
                          </p>
                      </div>
                      <button onClick={() => setMobileActionTx(null)} className="p-2 text-slate-400 hover:text-rose-500 transition-colors bg-slate-50 dark:bg-white/5 rounded-full"><X size={20} /></button>
                  </div>

                  <div className="grid grid-cols-1 gap-3">
                      <button 
                        onClick={() => { handleEditTx(mobileActionTx); setMobileActionTx(null); }}
                        className="w-full py-4 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-black rounded-2xl flex items-center justify-center gap-3 active:scale-95 transition-all"
                      >
                        <Pencil size={18} /> EDITAR LANÇAMENTO
                      </button>
                      <button 
                        onClick={() => { setTxToDelete(mobileActionTx); setMobileActionTx(null); }}
                        className="w-full py-4 bg-rose-50 dark:bg-rose-500/10 text-rose-500 font-black rounded-2xl flex items-center justify-center gap-3 active:scale-95 transition-all"
                      >
                        <Trash2 size={18} /> EXCLUIR LANÇAMENTO
                      </button>
                      <button 
                        onClick={() => setMobileActionTx(null)}
                        className="w-full py-4 bg-slate-100 dark:bg-white/5 text-slate-500 dark:text-gray-400 font-bold rounded-2xl active:scale-95 transition-all"
                      >
                        VOLTAR
                      </button>
                  </div>
              </div>
          </div>
      )}

      <Toast message={toastMessage} isVisible={showToast} onClose={() => setShowToast(false)} />
    </div>
  );
};

export default FinanceScreen;
