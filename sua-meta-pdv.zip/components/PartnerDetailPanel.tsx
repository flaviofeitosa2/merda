
import React from 'react';
import { 
  ArrowLeft, Star, DollarSign, Clock, CheckCircle2, Calendar, 
  MessageCircle, Mail, User, ArrowUpRight, Check, X, ShieldCheck,
  TrendingUp, Building2, ShoppingBag, Landmark
} from 'lucide-react';
import { Customer, Subscription } from '../types';

interface PartnerDetailPanelProps {
  partner: Customer;
  subscriptions: Subscription[];
  customers: Customer[];
  onBack: () => void;
  onRefresh: () => void;
  portalUserIds: Set<string>;
}

const formatCurrency = (val: number) => val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const PartnerDetailPanel: React.FC<PartnerDetailPanelProps> = ({ partner, subscriptions, customers, onBack, onRefresh, portalUserIds }) => {
  
  const stats = {
      totalReferrals: subscriptions.length,
      paidCommissions: subscriptions.filter(s => !!s.commission_payment_date).reduce((acc, curr) => acc + (curr.commission_value || 0), 0),
      pendingCommissions: subscriptions.filter(s => !s.commission_payment_date).reduce((acc, curr) => acc + (curr.commission_value || 0), 0),
      activeContracts: subscriptions.filter(s => s.status === 'active').length
  };

  const getCustomerName = (id: string) => {
      const customer = customers.find(c => c.id === id);
      return customer ? customer.name : id;
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#f8fafc] dark:bg-[#1a1b2e] overflow-hidden transition-colors font-sans">
      
      <header className="bg-white dark:bg-[#23243a] px-8 py-6 flex justify-between items-center border-b border-gray-100 dark:border-white/5 shrink-0 z-20">
          <div className="flex items-center gap-5">
              <button onClick={onBack} className="p-2.5 hover:bg-gray-100 dark:hover:bg-white/5 rounded-2xl text-gray-500 dark:text-gray-400 transition-colors"><ArrowLeft size={24} /></button>
              <div>
                  <h2 className="text-xl font-black text-slate-800 dark:text-white uppercase tracking-tighter italic leading-none">{partner.name}</h2>
                  <p className="text-[10px] text-amber-500 font-black uppercase tracking-widest mt-2 flex items-center gap-1.5"><Star size={12} fill="currentColor" /> Parceiro Verificado</p>
              </div>
          </div>
          <div className="flex gap-3">
              <button className="hidden sm:flex items-center gap-2 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 px-6 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all hover:bg-emerald-100"><MessageCircle size={16}/> Chamar no WhatsApp</button>
          </div>
      </header>

      <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
          <div className="max-w-6xl mx-auto space-y-10 pb-20">
              
              {/* DASHBOARD RÁPIDO DO PARCEIRO */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="bg-white dark:bg-[#23243a] p-8 rounded-[2.5rem] border border-slate-100 dark:border-white/5 shadow-sm transition-all hover:shadow-xl">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Saldo Pendente</p>
                      <h3 className="text-3xl font-black text-rose-500 tabular-nums tracking-tighter">{formatCurrency(stats.pendingCommissions)}</h3>
                      <div className="mt-4 flex items-center gap-2 text-[9px] font-bold text-rose-400 uppercase tracking-widest"><Clock size={12} /> Aguardando Liquidação</div>
                  </div>
                  <div className="bg-white dark:bg-[#23243a] p-8 rounded-[2.5rem] border border-slate-100 dark:border-white/5 shadow-sm transition-all hover:shadow-xl">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Total Já Pago</p>
                      <h3 className="text-3xl font-black text-emerald-500 tabular-nums tracking-tighter">{formatCurrency(stats.paidCommissions)}</h3>
                      <div className="mt-4 flex items-center gap-2 text-[9px] font-bold text-emerald-500 uppercase tracking-widest"><CheckCircle2 size={12} /> Tudo OK</div>
                  </div>
                  <div className="bg-white dark:bg-[#23243a] p-8 rounded-[2.5rem] border border-slate-100 dark:border-white/5 shadow-sm transition-all hover:shadow-xl">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Indicações Totais</p>
                      <h3 className="text-3xl font-black text-slate-800 dark:text-white tabular-nums tracking-tighter">{stats.totalReferrals}</h3>
                      <div className="mt-4 flex items-center gap-2 text-[9px] font-bold text-indigo-400 uppercase tracking-widest"><TrendingUp size={12} /> Conversão de 84%</div>
                  </div>
                  <div className="bg-[#1e293b] p-8 rounded-[2.5rem] shadow-2xl text-white relative overflow-hidden group">
                      <div className="relative z-10">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 opacity-60">Status do Contrato</p>
                        <h3 className="text-3xl font-black uppercase italic tracking-tighter">Diamante</h3>
                        <div className="mt-4 flex items-center gap-2 text-[9px] font-bold text-indigo-300 uppercase tracking-widest"><ShieldCheck size={12} /> 15% de Comissionamento</div>
                      </div>
                      <Star size={120} className="absolute -bottom-4 -right-4 opacity-5 group-hover:scale-110 transition-transform duration-1000" fill="currentColor" />
                  </div>
              </div>

              {/* HISTÓRICO DE COMISSÕES */}
              <div className="bg-white dark:bg-[#23243a] rounded-[3rem] shadow-sm border border-slate-100 dark:border-white/5 overflow-hidden transition-all">
                  <div className="px-10 py-8 border-b dark:border-white/5 bg-gray-50/50 dark:bg-white/5 flex flex-col sm:flex-row justify-between items-center gap-4">
                      <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 rounded-2xl flex items-center justify-center shadow-sm"><Landmark size={24}/></div>
                          <div>
                            <h3 className="text-xl font-black text-slate-800 dark:text-white uppercase tracking-tighter italic">Extrato de Comissões</h3>
                            <p className="text-[10px] text-slate-400 font-bold uppercase mt-1 tracking-widest">Listagem cronológica de indicações</p>
                          </div>
                      </div>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-separate border-spacing-0">
                        <thead>
                            <tr className="bg-slate-50/50 dark:bg-white/5 text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-[0.2em] border-b dark:border-white/5">
                                <th className="px-10 py-6">Data</th>
                                <th className="px-10 py-6">Cliente Indicado</th>
                                <th className="px-10 py-6">Produto</th>
                                <th className="px-10 py-6">Valor Contrato</th>
                                <th className="px-10 py-6">Valor Comissão</th>
                                <th className="px-10 py-6 text-center">Status Pagto</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50 dark:divide-white/5">
                            {subscriptions.length === 0 ? (
                                <tr><td colSpan={5} className="py-24 text-center text-slate-300 font-black uppercase text-sm tracking-widest">Nenhuma indicação encontrada.</td></tr>
                            ) : (
                                subscriptions.map(sub => (
                                    <tr key={sub.id} className="hover:bg-gray-50/50 dark:hover:bg-white/5 transition-colors group">
                                        <td className="px-10 py-6">
                                            <div className="flex flex-col">
                                                <span className="text-sm font-bold text-slate-800 dark:text-white leading-none mb-1">{new Date(sub.start_date).toLocaleDateString('pt-BR')}</span>
                                                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Início do Ciclo</span>
                                            </div>
                                        </td>
                                        <td className="px-10 py-6">
                                            <div className="flex items-center gap-4">
                                                <div className="w-9 h-9 bg-gray-100 dark:bg-white/5 rounded-xl flex items-center justify-center text-slate-400"><User size={18}/></div>
                                                <div className="flex items-center gap-2 min-w-0">
                                                  <span className="text-sm font-black text-slate-700 dark:text-white uppercase tracking-tight truncate max-w-[200px]">{getCustomerName(sub.customer_id)}</span>
                                                  {portalUserIds.has(sub.customer_id) && (
                                                    <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.6)] shrink-0" title="Cadastro Habilitado no Portal" />
                                                  )}
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-10 py-6"><span className="text-sm font-bold text-slate-600 dark:text-slate-300">{sub.provider || 'Assinatura'}</span></td>
                                        <td className="px-10 py-6"><span className="text-sm font-bold text-slate-400 tabular-nums">{formatCurrency(sub.value)}</span></td>
                                        <td className="px-10 py-6"><span className="text-base font-black text-indigo-600 dark:text-indigo-400 tabular-nums tracking-tighter">{formatCurrency(sub.commission_value || 0)}</span></td>
                                        <td className="px-10 py-6 text-center">
                                            {sub.commission_payment_date ? (
                                                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-500/20 text-[9px] font-black uppercase tracking-widest">
                                                    <Check size={14} strokeWidth={4} /> Pago em {new Date(sub.commission_payment_date).toLocaleDateString('pt-BR')}
                                                </div>
                                            ) : (
                                                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-400 border border-amber-100 dark:border-amber-500/20 text-[9px] font-black uppercase tracking-widest">
                                                    <Clock size={14} strokeWidth={4} /> Aguardando
                                                </div>
                                            )}
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                  </div>
                  <div className="p-8 bg-gray-50/50 dark:bg-white/5 border-t border-gray-100 dark:border-white/5 text-center">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Relatório oficial gerado pelo sistema White-Label SuaMeta</p>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
};

export default PartnerDetailPanel;
