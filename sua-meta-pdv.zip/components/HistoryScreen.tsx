
import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  Plus, 
  Eye, 
  Edit2, 
  Trash2, 
  Clock, 
  ChevronLeft, 
  ChevronRight, 
  List,
  Banknote,
  QrCode,
  CreditCard,
  History as HistoryIcon,
  User,
  Link as LinkIcon,
  Calendar,
  TrendingUp,
  AlertTriangle,
  XCircle,
  FileText,
  Building2,
  Store,
  CalendarX
} from 'lucide-react';
import { Sale, UserProfile, Customer, PaymentMethod, FinanceTransaction } from '../types';
import SaleDetailPanel from './SaleDetailPanel';
import UserMenu from './UserMenu';
import HistoryFilterPanel, { FilterState } from './HistoryFilterPanel';
import SaleEditModal from './SaleEditModal';
import AuthConfirmationModal from './AuthConfirmationModal';

interface HistoryScreenProps {
  sales: Sale[];
  financeTransactions?: FinanceTransaction[];
  customers: Customer[];
  users: UserProfile[]; 
  userProfile: UserProfile;
  toggleSidebar: () => void;
  onNavigateToPOS: () => void;
  onCancelSale: (id: string, reason: string) => Promise<void>;
  onUpdateSale: (id: string, data: any) => Promise<void>;
  onDeleteSale: (id: string) => Promise<void>;
  portalUserIds: Set<string>;
  permissions?: any;
}

const formatCurrency = (val: number) => val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

// Helper para data local YYYY-MM-DD
const getTodayLocalISO = () => {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

// Helper para data local Ontem YYYY-MM-DD
const getYesterdayLocalISO = () => {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

// Helper para converter qualquer formato de data (ISO ou YYYY-MM-DD) para data local YYYY-MM-DD
const getSaleLocalDateStr = (dateStr: string) => {
    if (!dateStr) return '';
    
    // Se for exatamente YYYY-MM-DD (sem horário), retorna direto
    if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
        return dateStr;
    }

    const d = new Date(dateStr);
    if (isNaN(d.getTime())) {
        const match = dateStr.match(/^(\d{4}-\d{2}-\d{2})/);
        return match ? match[1] : '';
    }
    
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

const HistoryScreen: React.FC<HistoryScreenProps> = ({ 
  sales = [], 
  financeTransactions = [],
  customers = [],
  users = [],
  userProfile,
  toggleSidebar,
  onNavigateToPOS,
  onUpdateSale,
  onCancelSale,
  onDeleteSale,
  portalUserIds,
  permissions
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null);
  const [editingSale, setEditingSale] = useState<Sale | null>(null);
  const [mobileActionSale, setMobileActionSale] = useState<Sale | null>(null);
  
  // Controle de Autenticação
  const [isAuthConfirmOpen, setIsAuthConfirmOpen] = useState(false);
  const [pendingSale, setPendingSale] = useState<Sale | null>(null);
  const [pendingActionType, setPendingActionType] = useState<'edit' | 'cancel' | 'delete' | null>(null);
  
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 50;
  
  const [filters, setFilters] = useState<FilterState>({
      startDate: getTodayLocalISO(), 
      endDate: getTodayLocalISO(), 
      quickPeriod: 'hoje', 
      paymentMethods: [], 
      onlyCancelled: false, 
      selectedSellers: []
  });

  const isOperator = userProfile.role === 'operator' || userProfile.role === 'operador';
  const isAdminOrMaster = userProfile.role === 'admin' || userProfile.role === 'master' || userProfile.role === 'owner';

  // Mapa de Clientes para busca rápida O(1)
  const customerMap = useMemo(() => {
      const map = new Map<string, Customer>();
      customers.forEach(c => map.set(c.id, c));
      return map;
  }, [customers]);

  // COMBINA VENDAS PDV + TRANSAÇÕES FINANCEIRAS MANUAIS (Tipo 'Income' e Origem != 'pos')
  const unifiedOperations = useMemo(() => {
      const currentUserName = (userProfile.full_name || '').trim().toLowerCase();

      // Regra de Privacidade: Operador só vê as próprias vendas
      const salesSource = isOperator 
        ? sales.filter(s => {
            const seller = (s.sellerName || '').trim().toLowerCase();
            // Se o operador não tem nome, ou o vendedor é o padrão, permitir ver se for dele
            if (!currentUserName) return true; 
            return seller === currentUserName || seller === 'vendedor';
          })
        : sales;

      // Regra de Privacidade: Operador não vê receitas financeiras globais da empresa
      const manualIncome = isOperator ? [] : financeTransactions
          .filter(t => t.type === 'income' && t.origin !== 'pos')
          .map(t => ({
              id: `FIN-${t.id}`,
              code: 'EXT', // Externo
              date: t.date,
              clientName: t.description || 'RECEITA FINANCEIRA',
              sellerName: 'FINANCEIRO',
              total: Number(t.amount),
              status: (t.status === 'paid' || !t.status) ? 'completed' : 'pending',
              paymentMethod: 'others' as PaymentMethod,
              items: [],
              payments: [{ method: 'others' as PaymentMethod, amount: Number(t.amount) }],
              isFinance: true
          } as unknown as Sale)); // Cast para Sale para compatibilidade

      return [...salesSource, ...manualIncome].sort((a, b) => {
          const timeA = new Date(a.date).getTime();
          const timeB = new Date(b.date).getTime();
          return (isNaN(timeB) ? 0 : timeB) - (isNaN(timeA) ? 0 : timeA);
      });
  }, [sales, financeTransactions, isOperator, userProfile.full_name]);

  // Lógica de cálculo dos cards de resumo
  const summaryMetrics = useMemo(() => {
    const today = getTodayLocalISO();
    const yesterday = getYesterdayLocalISO();

    const now = new Date();
    const weekStart = new Date(now);
    weekStart.setDate(now.getDate() - now.getDay());
    weekStart.setHours(0,0,0,0);

    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    monthStart.setHours(0,0,0,0);

    const calc = (filterFn: (s: Sale) => boolean) => {
        // Filtra apenas completas para os cards de resumo geral
        const filtered = unifiedOperations.filter(s => s.status === 'completed' && filterFn(s));
        // Usando soma de centavos para precisão matemática absoluta
        const totalCents = filtered.reduce((acc, s) => acc + Math.round((Number(s.total) || 0) * 100), 0);
        return {
            count: filtered.length,
            total: totalCents / 100
        };
    };

    return {
        hoje: calc(s => getSaleLocalDateStr(s.date) === today),
        ontem: calc(s => getSaleLocalDateStr(s.date) === yesterday),
        semana: calc(s => {
            const saleDate = getSaleLocalDateStr(s.date);
            return saleDate >= getSaleLocalDateStr(weekStart.toISOString());
        }),
        mes: calc(s => {
            const saleDate = getSaleLocalDateStr(s.date);
            return saleDate >= getSaleLocalDateStr(monthStart.toISOString());
        })
    };
  }, [unifiedOperations]);

  const filteredSales = useMemo(() => {
      const query = searchQuery.toLowerCase().trim();
      const today = getTodayLocalISO();
      const yesterday = getYesterdayLocalISO();
      
      return unifiedOperations.filter(sale => {
          if (sale.status === 'pending') return false;

          // Converte a data UTC da venda para a data local YYYY-MM-DD para comparação com os filtros
          const saleDateStr = getSaleLocalDateStr(sale.date);

          // REGRA DE PRIVACIDADE TEMPORAL (OPERADOR): Só vê Hoje e Ontem se não tiver permissão de dashboard
          // Mas se ele selecionou um filtro de data específico (e tem permissão para isso), permitimos ver
          if (isOperator && permissions?.dashboard === false) {
              const isTodayOrYesterday = saleDateStr === today || saleDateStr === yesterday;
              const hasDateFilter = filters.startDate || filters.endDate;
              
              // Se não for hoje/ontem E não tiver um filtro de data explícito que inclua essa data, ocultar
              if (!isTodayOrYesterday && !hasDateFilter) return false;
              
              // Se tiver filtro de data, o filtro de data abaixo cuidará de mostrar apenas o que foi pedido
          }

          const clientName = (sale.clientName || 'Cliente Balcão').toLowerCase();
          const code = (sale.code || '').toLowerCase();
          
          // Dados adicionais do cliente para busca
          const customerDetails = sale.customerId ? customerMap.get(sale.customerId) : null;
          const socialReason = (customerDetails?.socialReason || '').toLowerCase();
          const fantasyName = (customerDetails?.fantasyName || '').toLowerCase();

          const totalStr = (sale.total || 0).toString();
          const totalFormatted = (sale.total || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 });

          const matchesSearch = !query || 
                                clientName.includes(query) || 
                                code.includes(query) ||
                                socialReason.includes(query) ||
                                fantasyName.includes(query) ||
                                totalStr.includes(query) ||
                                totalFormatted.includes(query);

          if (!matchesSearch) return false;
          
          // Filtro de Data Início
          if (filters.startDate) {
              if (saleDateStr < filters.startDate) return false;
          }
          
          // Filtro de Data Fim
          if (filters.endDate) {
              if (saleDateStr > filters.endDate) return false;
          }

          if (filters.paymentMethods.length > 0) {
              const saleMethods = (sale.payments && sale.payments.length > 0) 
                  ? sale.payments.map(p => p.method) 
                  : [sale.paymentMethod];
              
              const hasMatch = saleMethods.some(m => filters.paymentMethods.includes(m));
              if (!hasMatch) return false;
          }

          if (filters.selectedSellers.length > 0) {
              const sellerNormalized = (sale.sellerName || '').toUpperCase().trim();
              if (!filters.selectedSellers.includes(sellerNormalized)) return false;
          }

          if (filters.onlyCancelled) {
             if (sale.status !== 'cancelled') return false;
          }

          return true;
      });
  }, [unifiedOperations, searchQuery, filters, customerMap, isOperator, permissions]);

  // Métricas para o card dinâmico (Filtro Ativo) - LÓGICA DE AUDITORIA FINANCEIRA MISTA
  const filteredMetrics = useMemo(() => {
    let totalCents = 0;
    let cancelledCents = 0;
    let count = 0;
    let cancelledCount = 0;

    filteredSales.forEach(s => {
        // Determinar o valor relevante para a soma com base nos filtros de pagamento
        let relevantAmount = 0;

        if (filters.paymentMethods.length === 0) {
            // Se não há filtro de método de pagamento, pega o total da venda cheio
            relevantAmount = Number(s.total) || 0;
        } else {
            // Se há filtro de método, soma APENAS as partes que correspondem ao filtro (Pagamento Misto)
            if (s.payments && s.payments.length > 0) {
                s.payments.forEach(p => {
                    if (filters.paymentMethods.includes(p.method)) {
                        relevantAmount += Number(p.amount) || 0;
                    }
                });
            } else {
                // Fallback para vendas legadas sem array de pagamentos
                if (filters.paymentMethods.includes(s.paymentMethod)) {
                    relevantAmount += Number(s.total) || 0;
                }
            }
        }

        const valCents = Math.round(relevantAmount * 100);

        if (s.status === 'completed') {
            totalCents += valCents;
            count++;
        } else if (s.status === 'cancelled') {
            cancelledCents += valCents;
            cancelledCount++;
        }
    });

    return {
        count,
        total: totalCents / 100,
        cancelledCount,
        cancelledTotal: cancelledCents / 100
    };
  }, [filteredSales, filters.paymentMethods]);

  const totalPages = Math.ceil(filteredSales.length / itemsPerPage);
  const paginatedSales = filteredSales.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const getPaymentBadge = (method: string, isCancelled: boolean) => {
    const m = method?.toLowerCase();
    let config = { label: 'OUTROS', color: 'text-slate-500 bg-slate-50 border-slate-100', icon: CreditCard };
    
    switch (m) {
      case 'money': config = { label: 'DINHEIRO', color: 'text-emerald-500 bg-emerald-50 border-emerald-100', icon: Banknote }; break;
      case 'pix': config = { label: 'PIX', color: 'text-teal-500 bg-teal-100 border-teal-100', icon: QrCode }; break;
      case 'debit': config = { label: 'DÉBITO', color: 'text-sky-500 bg-sky-50 border-sky-100', icon: CreditCard }; break;
      case 'credit': config = { label: 'CRÉDITO', color: 'text-indigo-500 bg-indigo-100 border-indigo-100', icon: CreditCard }; break;
      case 'credit_tab': config = { label: 'FIADO', color: 'text-amber-600 bg-amber-50 border-amber-100', icon: User }; break;
      case 'link': config = { label: 'LINK', color: 'text-purple-500 bg-purple-50 border-purple-100', icon: LinkIcon }; break;
    }

    if (isCancelled) {
        config.color = 'text-slate-400 bg-slate-100/50 border-slate-200';
    }

    return config;
  };

  const getMonthAbbr = (dateStr: string) => {
      const date = new Date(dateStr);
      const months = ['JAN.', 'FEV.', 'MAR.', 'ABR.', 'MAI.', 'JUN.', 'JUL.', 'AGO.', 'SET.', 'OUT.', 'NOV.', 'DEZ.'];
      return months[date.getMonth()];
  };

  const handleEditClick = (sale: Sale) => {
    // Não permitir editar entradas financeiras manuais por aqui (elas não tem items)
    if ((sale as any).isFinance) return alert("Edite este lançamento no módulo Financeiro.");
    
    setPendingActionType('edit');
    setPendingSale(sale);
    setIsAuthConfirmOpen(true);
  };

  const handleCancelClick = (sale: Sale) => {
    // Não permitir cancelar entradas financeiras manuais por aqui
    if ((sale as any).isFinance) return alert("Remova este lançamento no módulo Financeiro.");

    setPendingActionType('cancel');
    setPendingSale(sale);
    setIsAuthConfirmOpen(true);
  };

  const handleDeleteClick = (sale: Sale) => {
    if ((sale as any).isFinance) return alert("Remova este lançamento no módulo Financeiro.");
    setPendingActionType('delete');
    setPendingSale(sale);
    setIsAuthConfirmOpen(true);
  };

  const handleAuthSuccess = async () => {
    setIsAuthConfirmOpen(false);
    
    if (pendingActionType === 'edit') {
      setEditingSale(pendingSale);
    } else if (pendingActionType === 'cancel' && pendingSale) {
      try {
        await onCancelSale(pendingSale.id, 'Cancelamento solicitado pelo usuário via Histórico');
      } catch (err) {
        alert('Erro ao cancelar venda');
      }
    } else if (pendingActionType === 'delete' && pendingSale) {
      try {
        await onDeleteSale(pendingSale.id);
      } catch (err) {
        alert('Erro ao excluir venda');
      }
    }
    
    setPendingSale(null);
    setPendingActionType(null);
  };

  const SummaryCard = ({ title, count, total, highlight = false, subTotal }: { title: string, count: number, total: number, highlight?: boolean, subTotal?: { label: string, value: number } }) => (
    <div className={`p-1.5 lg:p-6 rounded-xl lg:rounded-3xl border transition-all hover:shadow-md relative overflow-hidden ${highlight ? 'bg-indigo-600 border-indigo-500 text-white shadow-indigo-100' : 'bg-white dark:bg-[#23243a] border-slate-100 dark:border-white/5'}`}>
        <p className={`text-[6px] lg:text-[10px] font-black uppercase tracking-widest mb-0.5 lg:mb-1 ${highlight ? 'text-indigo-100/80' : 'text-slate-400'}`}>
            {title}: <span className={highlight ? 'text-white' : 'text-slate-600 dark:text-slate-300'}>{count}</span>
        </p>
        <p className={`text-[9px] lg:text-xl font-black tabular-nums tracking-tighter leading-none ${highlight ? 'text-white' : 'text-slate-800 dark:text-white'}`}>
            {formatCurrency(total)}
        </p>
        {subTotal && subTotal.value > 0 && (
            <div className={`mt-1 lg:mt-2 pt-1 lg:pt-2 border-t flex items-center gap-1 ${highlight ? 'border-white/20' : 'border-slate-100 dark:border-white/5'}`}>
                <XCircle size={6} className={highlight ? 'text-indigo-200' : 'text-rose-400'} />
                <span className={`text-[5px] lg:text-[9px] font-bold uppercase tracking-wide ${highlight ? 'text-indigo-100' : 'text-rose-500'}`}>
                    {subTotal.label}: {formatCurrency(subTotal.value)}
                </span>
            </div>
        )}
    </div>
  );

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#F3F6F9] dark:bg-[#1a1b2e] transition-colors relative font-sans">
      
      <header className="bg-white dark:bg-[#23243a] h-[90px] px-4 lg:px-10 flex justify-between items-center shrink-0 border-b border-gray-100 dark:border-white/5 sticky top-0 z-50 transition-colors">
          <div className="flex items-center gap-4">
              <button onClick={toggleSidebar} className="lg:hidden p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-xl transition-colors">
                  <List size={26} />
              </button>
              <div>
                  <h1 className="text-[23px] font-mono font-black text-gray-900 dark:text-white tracking-tighter uppercase leading-none italic">Histórico</h1>
                  <p className="text-[10px] text-gray-400 font-black uppercase tracking-[0.3em] mt-1 hidden sm:block">Faturamento Bruto (PDV + Receitas)</p>
              </div>
          </div>
          <UserMenu />
      </header>

      <div className="px-2 lg:px-10 mb-8 grid grid-cols-5 gap-1 lg:gap-4 shrink-0 py-2">
          <SummaryCard title="Hoje" count={summaryMetrics.hoje.count} total={summaryMetrics.hoje.total} />
          <SummaryCard title="Ontem" count={summaryMetrics.ontem.count} total={summaryMetrics.ontem.total} />
          
          {!isOperator ? (
            <>
                <SummaryCard title="Semana" count={summaryMetrics.semana.count} total={summaryMetrics.semana.total} />
                <SummaryCard title="Mês" count={summaryMetrics.mes.count} total={summaryMetrics.mes.total} />
            </>
          ) : (
            <>
              <div className="hidden sm:block"></div>
              <div className="hidden sm:block"></div>
            </>
          )}

          {(filters.startDate || filters.paymentMethods.length > 0 || filters.selectedSellers.length > 0 || searchQuery) ? (
             <SummaryCard 
                title={filters.quickPeriod === 'hoje' ? "Hoje" : filters.paymentMethods.length > 0 ? "Método" : "Líquido"} 
                count={filteredMetrics.count} 
                total={filteredMetrics.total} 
                highlight={true}
                subTotal={filteredMetrics.cancelledTotal > 0 ? { label: 'Canc.', value: filteredMetrics.cancelledTotal } : undefined}
             />
          ) : (
            <div className="hidden md:block"></div>
          )}
      </div>

      <div className="px-4 lg:px-10 mb-8 flex items-center gap-4 shrink-0">
          <div className="flex-1 bg-white dark:bg-[#23243a] rounded-2xl shadow-sm border border-slate-100 dark:border-white/5 flex items-center px-4 lg:px-6 py-1 group transition-all focus-within:shadow-md">
              <Search className="text-slate-300 dark:text-slate-600 mr-2 lg:mr-4" size={20} />
              <input 
                  type="text" 
                  placeholder="BUSCAR..." 
                  className="flex-1 py-4 bg-transparent outline-none text-[10px] lg:text-xs font-bold text-slate-700 dark:text-white placeholder:text-slate-300 uppercase tracking-widest"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
              />
          </div>
          <button 
            onClick={() => setIsFilterPanelOpen(true)}
            className={`flex items-center gap-2 lg:gap-3 px-4 lg:px-8 py-5 bg-white dark:bg-[#23243a] rounded-2xl font-black text-[10px] uppercase tracking-widest border transition-all shadow-sm ${
              (filters.startDate !== getTodayLocalISO() || filters.endDate !== getTodayLocalISO() || filters.paymentMethods.length > 0 || filters.selectedSellers.length > 0 || filters.onlyCancelled) 
              ? 'text-indigo-600 border-indigo-200' 
              : 'text-slate-400 border-slate-100 dark:border-white/5 hover:text-indigo-600'
            }`}
          >
              <Filter size={18} /> <span className="hidden sm:inline">Filtros</span> {(filters.paymentMethods.length + filters.selectedSellers.length > 0) ? `(${filters.paymentMethods.length + filters.selectedSellers.length})` : ''}
          </button>

      </div>

      <div className="flex-1 overflow-y-auto px-2 lg:px-10 pb-40 custom-scrollbar">
          <div className="bg-white dark:bg-[#23243a] rounded-[1rem] lg:rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-white/5 overflow-hidden transition-colors">
              <table className="w-full text-left border-separate border-spacing-0">
                  <thead className="bg-[#f8fafc] dark:bg-white/5 text-[9px] lg:text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] transition-colors">
                      <tr>
                          <th className="px-1 lg:px-8 py-4 lg:py-6 text-left">Data</th>
                          <th className="px-8 py-6 hidden lg:table-cell">Código</th>
                          <th className="px-1 lg:px-8 py-4 lg:py-6 text-left">Cliente</th>
                          <th className="px-8 py-6 hidden lg:table-cell">Vendedor</th>
                          <th className="px-1 lg:px-8 py-4 lg:py-6 text-center">Tipo</th>
                          <th className="px-1 lg:px-8 py-4 lg:py-6 text-right">Valor</th>
                          <th className="px-8 py-6 text-center hidden lg:table-cell">Ações</th>
                      </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 dark:divide-white/5">
                      {paginatedSales.length === 0 ? (
                          <tr>
                            <td colSpan={7} className="py-32 text-center">
                              <div className="flex flex-col items-center justify-center animate-in fade-in duration-500">
                                <CalendarX size={64} className="text-slate-200 dark:text-slate-800 mb-6" strokeWidth={1.5} />
                                <p className="text-sm font-black text-slate-400 uppercase tracking-[0.2em]">
                                  {filters.quickPeriod === 'hoje' 
                                    ? 'Ainda não existem vendas registradas para hoje.' 
                                    : 'Nenhum registro encontrado para este período.'}
                                </p>
                                <p className="text-[10px] text-slate-300 dark:text-slate-600 uppercase font-bold tracking-widest mt-2 max-w-xs leading-relaxed">
                                  {isOperator 
                                    ? 'Operadores podem visualizar apenas registros de Hoje e Ontem.'
                                    : 'Utilize o botão de filtros acima para selecionar outro período de visualização.'}
                                </p>
                                {!isOperator && (
                                    <button 
                                      onClick={() => setIsFilterPanelOpen(true)}
                                      className="mt-8 text-indigo-500 font-black text-[10px] uppercase tracking-widest border-2 border-indigo-50 dark:border-indigo-500/10 px-6 py-2.5 rounded-full hover:bg-indigo-50 transition-all"
                                    >
                                      Selecionar Outro Período
                                    </button>
                                )}
                              </div>
                            </td>
                          </tr>
                      ) : (
                          paginatedSales.map(s => {
                              const isFinance = (s as any).isFinance;
                              const itemsCount = isFinance ? 0 : (s.items?.reduce((acc, i) => acc + i.quantity, 0) || 0);
                              const isCancelled = s.status === 'cancelled';
                              
                              const uniqueMethods = Array.from(new Set<PaymentMethod>(
                                  (s.payments && s.payments.length > 0) 
                                  ? s.payments.map(p => p.method) 
                                  : [s.paymentMethod]
                              ));

                              const customer = s.customerId ? customerMap.get(s.customerId) : null;

                              return (
                                <tr 
                                  key={s.id} 
                                  onClick={() => {
                                    if (window.innerWidth < 1024) {
                                      setMobileActionSale(s);
                                    }
                                  }}
                                  className={`hover:bg-slate-50/50 dark:hover:bg-white/5 transition-colors group ${isCancelled ? 'bg-slate-100/50 dark:bg-white/5' : ''} cursor-pointer lg:cursor-default`}
                                >
                                    <td className="px-1 lg:px-8 py-4 lg:py-5">
                                        <div className="flex items-center gap-1 lg:gap-4">
                                            <div className={`flex flex-col items-center justify-center w-8 h-8 lg:w-12 lg:h-12 rounded-lg lg:rounded-xl border ${isCancelled ? 'border-gray-200 bg-gray-100' : 'border-indigo-100 dark:border-white/10 bg-indigo-50/30 dark:bg-white/5'}`}>
                                                <span className={`text-sm lg:text-lg font-black leading-none ${isCancelled ? 'text-gray-400' : 'text-indigo-600 dark:text-indigo-400'}`}>{new Date(s.date).getDate()}</span>
                                                <span className={`text-[6px] lg:text-[8px] font-black uppercase ${isCancelled ? 'text-gray-300' : 'text-indigo-400'}`}>{getMonthAbbr(s.date)}</span>
                                            </div>
                                            <div className={`hidden lg:flex items-center gap-1.5 text-[10px] lg:text-xs font-bold ${isCancelled ? 'text-gray-400 line-through' : 'text-slate-400'}`}>
                                                <Clock size={14} className="text-slate-300" />
                                                {new Date(s.date).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-8 py-5 hidden lg:table-cell">
                                        <span className={`px-3 py-1.5 rounded-lg text-[11px] font-black border transition-colors ${isCancelled ? 'bg-gray-50 text-gray-400 border-gray-200 line-through' : 'bg-gray-100 dark:bg-white/5 text-slate-400 dark:text-gray-500 border-transparent'} tracking-tighter`}>{isFinance ? <FileText size={12} className="inline mr-1"/> : '#'} {s.code}</span>
                                    </td>
                                    <td className="px-1 lg:px-8 py-4 lg:py-5">
                                        <div className="flex flex-col gap-0.5">
                                            <span className={`text-[10px] lg:text-sm font-black uppercase truncate tracking-tight max-w-[60px] lg:max-w-[200px] transition-colors ${isCancelled ? 'text-gray-400 line-through' : 'text-slate-800 dark:text-white'}`}>
                                                <div className="flex items-center gap-1">
                                                 {s.clientName}
                                                 {s.customerId && portalUserIds.has(s.customerId) && (
                                                   <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.6)]" title="Cadastro Habilitado no Portal" />
                                                 )}
                                               </div>
                                            </span>
                                            {customer?.socialReason && (
                                                <span className={`text-[7px] lg:text-[9px] font-bold uppercase flex items-center gap-1 truncate max-w-[80px] lg:max-w-[200px] ${isCancelled ? 'text-gray-300 line-through' : 'text-indigo-500 dark:text-indigo-400'}`}>
                                                    <Building2 size={8} className="shrink-0" /> {customer.socialReason}
                                                </span>
                                            )}
                                        </div>
                                    </td>
                                    <td className="px-8 py-5 hidden lg:table-cell">
                                        <div className="flex items-center gap-2">
                                            <div className="w-6 h-6 rounded-full bg-slate-100 dark:bg-white/10 flex items-center justify-center text-slate-400 text-[9px] font-black border border-slate-200 dark:border-white/5">
                                                <User size={10} />
                                            </div>
                                            <span className={`text-[10px] font-bold uppercase ${isCancelled ? 'text-gray-300 line-through' : 'text-slate-500 dark:text-slate-400'}`}>
                                                {s.sellerName}
                                            </span>
                                        </div>
                                    </td>
                                    <td className="px-1 lg:px-8 py-4 lg:py-5 text-center">
                                        {isFinance ? (
                                            <div className="inline-flex items-center gap-2 px-2 lg:px-3 py-1 rounded-full text-[8px] lg:text-[9px] font-black uppercase tracking-widest border transition-all text-emerald-600 bg-emerald-50 border-emerald-100">
                                                <TrendingUp size={10} strokeWidth={3} /> <span className="hidden lg:inline">RECEITA</span>
                                            </div>
                                        ) : (
                                            <div className="flex flex-wrap justify-center gap-0.5 lg:gap-2">
                                                {uniqueMethods.map((method, idx) => {
                                                    const badge = getPaymentBadge(method as string, isCancelled);
                                                    return (
                                                        <div key={idx} className={`inline-flex items-center gap-1 lg:gap-2 px-1.5 lg:px-3 py-0.5 lg:py-1 rounded-full text-[8px] lg:text-[9px] font-black uppercase tracking-widest border transition-all ${badge.color}`} title={badge.label}>
                                                            <badge.icon size={10} strokeWidth={3} />
                                                            <span className="hidden lg:inline">{badge.label}</span>
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        )}
                                    </td>
                                    <td className="px-1 lg:px-8 py-4 lg:py-5 text-right">
                                        <div className="flex flex-col items-end">
                                            <span className={`text-sm lg:text-lg font-black tracking-tighter tabular-nums transition-colors ${isCancelled ? 'text-gray-400 line-through' : 'text-slate-900 dark:text-white'}`}>{formatCurrency(s.total)}</span>
                                            {!isFinance && (
                                                <span className={`text-[7px] lg:text-[9px] font-black uppercase tracking-widest ${isCancelled ? 'text-gray-300' : 'text-slate-400'}`}>{itemsCount} {itemsCount === 1 ? 'IT' : 'ITS'}</span>
                                            )}
                                        </div>
                                    </td>
                                    <td className="px-8 py-5 hidden lg:table-cell">
                                        <div className="flex justify-center gap-2">
                                            {!isFinance && (
                                                <button onClick={(e) => { e.stopPropagation(); setSelectedSale(s); }} className="p-2.5 text-slate-300 hover:text-indigo-600 hover:bg-white rounded-full transition-all shadow-sm"><Eye size={18}/></button>
                                            )}
                                            
                                            {!isCancelled && isAdminOrMaster && !isFinance && (
                                              <>
                                                <button 
                                                  onClick={(e) => { e.stopPropagation(); handleEditClick(s); }}
                                                  className="p-2.5 text-slate-300 hover:text-emerald-500 hover:bg-white rounded-full transition-all shadow-sm"
                                                >
                                                  <Edit2 size={18}/>
                                                </button>
                                                <button 
                                                  onClick={(e) => { e.stopPropagation(); handleCancelClick(s); }}
                                                  className="p-2.5 text-slate-300 hover:text-rose-500 hover:bg-white rounded-full transition-all shadow-sm"
                                                  title="Cancelar Venda"
                                                >
                                                  <Trash2 size={18}/>
                                                </button>
                                              </>
                                            )}
                                        </div>
                                    </td>
                                </tr>
                              );
                          })
                      )}
                  </tbody>
              </table>
          </div>
      </div>

      <div className="fixed bottom-6 lg:bottom-10 left-1/2 -translate-x-1/2 z-40 animate-in slide-in-from-bottom-6 duration-700 w-[90%] sm:w-auto">
          <div className="bg-white/80 dark:bg-[#23243a]/90 backdrop-blur-xl border border-slate-200/50 dark:border-white/10 rounded-full px-4 lg:px-8 py-3 lg:py-4 shadow-[0_20px_50px_rgba(0,0,0,0.15)] flex items-center justify-between lg:justify-start gap-4 lg:gap-10">
              <div className="hidden sm:flex items-center gap-2 shrink-0">
                  <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></div>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{filteredSales.length} Operações</span>
              </div>

              <div className="flex items-center gap-2 lg:gap-4">
                  <button 
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                    className="p-1 lg:p-2 text-slate-400 hover:text-indigo-600 disabled:opacity-30 transition-all"
                  >
                      <ChevronLeft size={20} lg:size={24} strokeWidth={3}/>
                  </button>
                  <div className="bg-slate-50 dark:bg-black/20 px-4 lg:px-6 py-1.5 lg:py-2 rounded-full border dark:border-white/5">
                      <span className="text-[10px] lg:text-xs font-black text-slate-800 dark:text-white uppercase tracking-tighter">PÁG. {currentPage} / {totalPages || 1}</span>
                  </div>
                  <button 
                    disabled={currentPage === totalPages || totalPages === 0}
                    onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                    className="p-1 lg:p-2 text-slate-400 hover:text-indigo-600 disabled:opacity-30 transition-all"
                  >
                      <ChevronRight size={20} lg:size={24} strokeWidth={3}/>
                  </button>
              </div>

              <button className="bg-indigo-600 text-white px-4 lg:px-6 py-2 lg:py-2.5 rounded-full font-black text-[8px] lg:text-[9px] uppercase tracking-widest shadow-lg shadow-indigo-200 active:scale-95 transition-all">
                  {itemsPerPage} P/ PÁG.
              </button>
          </div>
      </div>

      <HistoryFilterPanel 
        isOpen={isFilterPanelOpen} 
        onClose={() => setIsFilterPanelOpen(false)} 
        onApplyFilters={(newFilters) => {
            setFilters(newFilters);
            setCurrentPage(1);
        }} 
        allUsers={users} 
        currentFilters={filters} 
        userRole={userProfile.role}
        permissions={permissions}
      />

      <AuthConfirmationModal 
        isOpen={isAuthConfirmOpen}
        onClose={() => { setIsAuthConfirmOpen(false); setPendingSale(null); setPendingActionType(null); }}
        onSuccess={handleAuthSuccess}
        userEmail={userProfile.email || ''}
      />

      <SaleEditModal 
        isOpen={!!editingSale} 
        onClose={() => setEditingSale(null)} 
        sale={editingSale} 
        users={users} 
        onSave={onUpdateSale}
      />

      <SaleDetailPanel isOpen={!!selectedSale} onClose={() => setSelectedSale(null)} sale={selectedSale} portalUserIds={portalUserIds} />

      {/* Popup de Ações Mobile */}
      {mobileActionSale && (
        <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-300">
          <div 
            className="w-full max-w-sm bg-white dark:bg-[#23243a] rounded-[2rem] shadow-2xl overflow-hidden animate-in slide-in-from-bottom-10 duration-500"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b border-slate-100 dark:border-white/5 flex justify-between items-center">
              <div>
                <h3 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-widest">Ações da Venda</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">#{mobileActionSale.code} - {mobileActionSale.clientName}</p>
              </div>
              <button 
                onClick={() => setMobileActionSale(null)}
                className="p-2 text-slate-400 hover:bg-slate-50 dark:hover:bg-white/5 rounded-full transition-colors"
              >
                <XCircle size={20} />
              </button>
            </div>
            <div className="p-4 flex flex-col gap-2">
              <button 
                onClick={() => {
                  setSelectedSale(mobileActionSale);
                  setMobileActionSale(null);
                }}
                className="flex items-center gap-4 w-full p-4 hover:bg-slate-50 dark:hover:bg-white/5 rounded-2xl transition-all group"
              >
                <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-500/10 flex items-center justify-center text-indigo-600 dark:text-indigo-400 group-hover:scale-110 transition-transform">
                  <Eye size={20} />
                </div>
                <span className="text-xs font-black text-slate-700 dark:text-slate-200 uppercase tracking-widest">Visualizar Detalhes</span>
              </button>

              {!(mobileActionSale as any).isFinance && mobileActionSale.status !== 'cancelled' && isAdminOrMaster && (
                <>
                  <button 
                    onClick={() => {
                      handleEditClick(mobileActionSale);
                      setMobileActionSale(null);
                    }}
                    className="flex items-center gap-4 w-full p-4 hover:bg-slate-50 dark:hover:bg-white/5 rounded-2xl transition-all group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 flex items-center justify-center text-emerald-600 dark:text-emerald-400 group-hover:scale-110 transition-transform">
                      <Edit2 size={20} />
                    </div>
                    <span className="text-xs font-black text-slate-700 dark:text-slate-200 uppercase tracking-widest">Editar Registro</span>
                  </button>

                  <button 
                    onClick={() => {
                      handleCancelClick(mobileActionSale);
                      setMobileActionSale(null);
                    }}
                    className="flex items-center gap-4 w-full p-4 hover:bg-slate-50 dark:hover:bg-white/5 rounded-2xl transition-all group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-rose-50 dark:bg-rose-500/10 flex items-center justify-center text-rose-600 dark:text-rose-400 group-hover:scale-110 transition-transform">
                      <Trash2 size={20} />
                    </div>
                    <span className="text-xs font-black text-slate-700 dark:text-slate-200 uppercase tracking-widest">Cancelar Venda</span>
                  </button>
                </>
              )}
            </div>
            <div className="p-4 bg-slate-50 dark:bg-white/5">
              <button 
                onClick={() => setMobileActionSale(null)}
                className="w-full py-4 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
              >
                Fechar Menu
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HistoryScreen;
