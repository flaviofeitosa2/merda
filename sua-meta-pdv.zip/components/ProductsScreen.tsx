
import React, { useState, useMemo, useEffect } from 'react';
import { 
  Search, 
  Plus, 
  Star, 
  Trash2, 
  Loader2,
  Menu,
  Upload,
  Package,
  AlertTriangle,
  SlidersHorizontal,
  Filter,
  Layers,
  Edit3,
  ChevronRight,
  ChevronLeft,
  X,
  List,
  PackagePlus,
  ArrowRight,
  PlusCircle
} from 'lucide-react';
import { Product, Category, UserRole, OperatorPermissions } from '../types';
import UserMenu from './UserMenu';
import ProductForm from './ProductForm';
import CategoryPanel from './CategoryPanel';
import ProductFilterPanel, { ProductFilters } from './ProductFilterPanel';
import ProductImportModal from './ProductImportModal';
import Toast from './Toast';

interface ProductsScreenProps {
  products: Product[];
  categories: Category[];
  toggleSidebar: () => void;
  onAddCategory: (name: string) => void;
  onEditCategory: (id: string, name: string) => void;
  onDeleteCategory: (id: string) => Promise<void>;
  onAddProduct: (product: Product) => Promise<boolean>;
  onUpdateProduct: (product: Product) => Promise<boolean>;
  onDeleteProduct: (id: string) => Promise<void>;
  userRole?: UserRole;
  permissions?: OperatorPermissions;
}

const ITEMS_PER_PAGE = 50; // Ajustado para 50 conforme solicitação de padrão

const ProductsScreen: React.FC<ProductsScreenProps> = ({ 
    products, 
    categories, 
    toggleSidebar,
    onAddCategory,
    onEditCategory,
    onDeleteCategory,
    onAddProduct,
    onUpdateProduct,
    onDeleteProduct,
    userRole,
    permissions
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'itens' | 'estoque' | 'categorias'>('itens');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | undefined>(undefined);
  const [isCategoryPanelOpen, setIsCategoryPanelOpen] = useState(false);
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  const [activeFilters, setActiveFilters] = useState<ProductFilters>({
    stockStatus: [],
    categories: [],
    sortBy: 'name_asc'
  });
  
  const [productToDelete, setProductToDelete] = useState<{ id: string; name: string } | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, activeFilters]);

  const canManageStock = userRole !== 'operator' || permissions?.stock;

  const processedProducts = useMemo(() => {
      let filtered = products.filter(p => 
          (p.name || '').toLowerCase().includes(searchQuery.toLowerCase()) || 
          (p.code && p.code.includes(searchQuery))
      );

      if (activeFilters.stockStatus.length > 0) {
          filtered = filtered.filter(p => {
              if (activeFilters.stockStatus.includes('no_control') && !p.manage_stock) return true;
              if (!p.manage_stock) return false;
              if (activeFilters.stockStatus.includes('out') && (p.stock || 0) <= 0) return true;
              if (activeFilters.stockStatus.includes('min') && (p.stock || 0) > 0 && (p.stock || 0) <= (p.min_stock || 0)) return true;
              if (activeFilters.stockStatus.includes('available') && (p.stock || 0) > (p.min_stock || 0)) return true;
              return false;
          });
      }

      if (activeFilters.categories.length > 0) {
          filtered = filtered.filter(p => {
              const isService = p.category?.toLowerCase().includes('serviço');
              const isProduct = !isService;
              
              if (activeFilters.categories.includes('Serviço') && isService) return true;
              if (activeFilters.categories.includes('Produto') && isProduct) return true;
              return false;
          });
      }

      filtered.sort((a, b) => {
          if (activeFilters.sortBy.includes('name')) {
              if (a.is_favorite && !b.is_favorite) return -1;
              if (!a.is_favorite && b.is_favorite) return 1;
          }

          if (activeFilters.sortBy === 'name_asc') return (a.name || '').localeCompare(b.name || '');
          if (activeFilters.sortBy === 'name_desc') return (b.name || '').localeCompare(a.name || '');
          if (activeFilters.sortBy === 'stock_asc') return (a.stock || 0) - (b.stock || 0);
          if (activeFilters.sortBy === 'stock_desc') return (b.stock || 0) - (a.stock || 0);
          
          return 0;
      });
      
      return filtered;
  }, [products, searchQuery, activeFilters]);

  const totalPages = Math.ceil(processedProducts.length / ITEMS_PER_PAGE);
  const paginatedProducts = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return processedProducts.slice(start, start + ITEMS_PER_PAGE);
  }, [processedProducts, currentPage]);

  const stockStats = useMemo(() => {
    let totalValue = 0;
    let totalQuantity = 0;
    let lowStockCount = 0;

    products.forEach(p => {
      const stock = p.stock || 0;
      totalValue += (p.price * stock);
      totalQuantity += stock;
      if (p.manage_stock && stock <= (p.min_stock || 0)) lowStockCount++;
    });

    return { totalValue, totalQuantity, lowStockCount, activeCount: products.length };
  }, [products]);

  const handleRowClick = (product: Product) => {
      setEditingProduct(product); 
      setIsFormOpen(true);
  };

  const handleConfirmDelete = async () => {
      if (!productToDelete) return;
      setIsDeleting(true);
      try {
          await onDeleteProduct(productToDelete.id);
          setProductToDelete(null);
      } finally {
          setIsDeleting(false);
      }
  };

  const handleImportExecute = async (items: any[], mode: 'create' | 'update') => {
      for (const item of items) {
          try {
              if (mode === 'create') {
                  const newProduct: any = {
                      name: item.name,
                      code: item.code,
                      category: item.category,
                      price: item.price,
                      cost: item.cost,
                      stock: item.stock,
                      min_stock: item.minStock,
                      description: item.description,
                      manage_stock: item.stock !== undefined && item.stock !== null,
                      image: 'https://cdn-icons-png.flaticon.com/512/1256/1256650.png' 
                  };
                  await onAddProduct(newProduct);
              } else {
                  const existing = products.find(p => p.id === item.id || (item.code && p.code === item.code));
                  if (existing) {
                      await onUpdateProduct({
                          ...existing,
                          name: item.name || existing.name,
                          price: item.price || existing.price,
                          stock: item.stock !== undefined ? item.stock : existing.stock,
                          code: item.code || existing.code,
                          category: item.category || existing.category
                      });
                  }
              }
          } catch (err) {
              console.error("Erro ao importar item:", item.name, err);
          }
      }
  };

  if (isFormOpen) {
      return (
        <ProductForm 
            onBack={() => setIsFormOpen(false)} 
            onSave={async (p) => {
                  let success = false;
                  if (editingProduct) success = await onUpdateProduct(p as Product);
                  else success = await onAddProduct(p as Product);
                  
                  if (success) {
                    setIsFormOpen(false);
                    setToastMessage("Produto salvo com sucesso!");
                    setShowToast(true);
                  }
            }} 
            onAddCategoryClick={() => setIsCategoryPanelOpen(true)} 
            categories={categories} 
            initialData={editingProduct} 
            canManageStock={canManageStock} 
        />
      );
  }

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#EEF2F6] dark:bg-[#1a1b2e] relative font-sans transition-colors">
      
      <ProductImportModal 
        /* Fixed typo in isOpen property: changed from isImportOpenModalOpen to isImportModalOpen */
        isOpen={isImportModalOpen} 
        onClose={() => setIsImportModalOpen(false)} 
        onImport={handleImportExecute} 
        existingProducts={products} 
      />

      {productToDelete && (
          <div className="fixed inset-0 bg-black/60 z-[150] flex items-center justify-center p-4 backdrop-blur-sm">
              <div className="bg-white dark:bg-[#23243a] rounded-2xl w-full max-sm:max-w-sm shadow-2xl p-6 border border-transparent dark:border-white/5">
                  <div className="flex flex-col items-center text-center">
                      <div className="w-16 h-16 bg-red-100 dark:bg-rose-500/10 rounded-full flex items-center justify-center mb-4 text-red-500 dark:text-rose-500">
                          <AlertTriangle size={32} />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Excluir Produto?</h3>
                      <p className="text-gray-500 dark:text-gray-400 text-sm mb-6">Deseja excluir <span className="font-bold text-gray-800 dark:text-gray-200">"{productToDelete.name}"</span>?</p>
                      <div className="flex gap-3 w-full">
                          <button onClick={() => setProductToDelete(null)} className="flex-1 py-3 bg-gray-100 dark:bg-white/5 text-gray-700 dark:text-gray-300 font-bold rounded-xl transition-colors">Cancelar</button>
                          <button onClick={handleConfirmDelete} className="flex-1 py-3 bg-red-500 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-all">
                              {isDeleting ? <Loader2 size={18} className="animate-spin" /> : <Trash2 size={18} />} Excluir
                          </button>
                      </div>
                  </div>
              </div>
          </div>
      )}

      <header className="bg-white dark:bg-[#23243a] h-[90px] px-4 lg:px-10 flex justify-between items-center shrink-0 border-b border-gray-100 dark:border-white/5 sticky top-0 z-50 transition-colors">
          <div className="flex items-center gap-4">
              <button onClick={toggleSidebar} className="lg:hidden p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-xl transition-colors">
                  <List size={26} />
              </button>
              <div>
                  <h1 className="text-[23px] font-mono font-black text-gray-900 dark:text-white tracking-tighter uppercase leading-none italic flex items-center gap-2">
                      Produtos <span className="lg:hidden text-gray-400 dark:text-gray-500 font-medium text-lg">({products.length})</span>
                  </h1>
                  <p className="text-[10px] text-gray-400 font-black uppercase tracking-[0.3em] mt-1 hidden sm:block">Gestão de catálogo e estoque</p>
              </div>
          </div>
          <UserMenu />
      </header>

      {products.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 animate-in fade-in zoom-in duration-500">
              <div className="w-24 h-24 bg-white dark:bg-[#23243a] rounded-[2rem] shadow-xl shadow-indigo-500/10 border border-indigo-100 dark:border-indigo-500/20 flex items-center justify-center text-indigo-500 mb-8">
                  <PackagePlus size={48} strokeWidth={1.5} />
              </div>
              
              <h3 className="text-2xl font-bold text-gray-800 dark:text-white uppercase tracking-tight mb-3 text-center">Seu inventário está vazio</h3>
              <p className="text-gray-500 dark:text-gray-400 max-w-md mx-auto mb-10 leading-relaxed font-medium text-center">
                  Para começar, organize seus itens por categorias (opcional) e cadastre seus produtos para realizar suas vendas no PDV.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 w-full max-w-md justify-center">
                  <button 
                    onClick={() => setIsCategoryPanelOpen(true)}
                    className="flex-1 flex items-center justify-center gap-3 bg-white dark:bg-white/5 hover:bg-gray-50 dark:hover:bg-white/10 text-indigo-600 dark:text-indigo-400 font-black py-4 px-6 rounded-2xl border border-indigo-200 dark:border-indigo-500/20 shadow-sm transition-all uppercase text-[10px] tracking-widest"
                  >
                      <PlusCircle size={18} strokeWidth={2.5} />
                      Categorias
                  </button>
                  
                  <button 
                    onClick={() => { setEditingProduct(undefined); setIsFormOpen(true); }}
                    className="flex-[1.5] flex items-center justify-center gap-3 bg-[#2dd4bf] hover:bg-[#14b8a6] text-white font-black py-4 px-8 rounded-2xl shadow-xl shadow-teal-500/30 transition-all transform hover:scale-105 active:scale-95 uppercase text-[10px] tracking-widest"
                  >
                      <Plus size={20} strokeWidth={3} />
                      Cadastrar Produto
                      <ArrowRight size={18} />
                  </button>
              </div>
          </div>
      ) : (
          <>
            <div className="hidden lg:flex flex-col h-full overflow-hidden">
                <div className="bg-white dark:bg-[#23243a] border-b border-gray-100 dark:border-white/5 px-10 py-5 flex items-center justify-between shadow-sm sticky top-0 z-[50] transition-colors">
                    <div className="flex items-center gap-4 flex-1 max-w-2xl">
                        <div className="relative flex-1 group">
                            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300 dark:text-gray-500 group-focus-within:text-[#2ebc7d] transition-colors" size={20} />
                            <input 
                              type="text" 
                              placeholder="Buscar produtos..." 
                              className="w-full pl-12 pr-4 py-3 bg-gray-50 dark:bg-[#1a1b2e] dark:text-white border-2 border-transparent rounded-2xl outline-none focus:bg-white dark:focus:bg-[#1a1b2e] focus:border-[#2ebc7d]/30 transition-all font-medium text-sm"
                              value={searchQuery}
                              onChange={(e) => setSearchQuery(e.target.value)}
                            />
                        </div>
                        <button onClick={() => setIsFilterPanelOpen(true)} className={`p-3 border-2 rounded-2xl transition-all ${activeFilters.stockStatus.length > 0 || activeFilters.categories.length > 0 ? 'bg-[#2ebc7d]/10 border-[#2ebc7d] text-[#2ebc7d]' : 'bg-white dark:bg-white/5 border-gray-100 dark:border-white/10 text-gray-400 hover:bg-gray-50 dark:hover:bg-white/10'}`}>
                            <Filter size={20} />
                        </button>
                    </div>

                    <div className="flex items-center gap-4">
                        <button onClick={() => setIsImportModalOpen(true)} className="flex items-center gap-2 px-5 py-3 text-xs font-bold uppercase tracking-widest text-gray-500 dark:text-gray-400 border-2 border-gray-100 dark:border-white/10 rounded-2xl hover:bg-gray-50 dark:hover:bg-white/10 transition-all">
                            <Upload size={16} /> Importar
                        </button>
                        <button onClick={() => setIsCategoryPanelOpen(true)} className="flex items-center gap-2 px-5 py-3 text-xs font-bold uppercase tracking-widest text-gray-500 dark:text-gray-400 border-2 border-gray-100 dark:border-white/10 rounded-2xl hover:bg-gray-50 dark:hover:bg-white/10 transition-all">
                            <Layers size={16} /> Categorias
                        </button>
                        <button 
                          onClick={() => { setEditingProduct(undefined); setIsFormOpen(true); }}
                          className="flex items-center gap-2 px-8 py-3.5 text-xs font-bold uppercase tracking-widest text-white bg-[#8ec332] rounded-2xl shadow-lg shadow-[#8ec332]/20 hover:brightness-105 active:scale-95 transition-all"
                        >
                            <Plus size={20} strokeWidth={3} /> Adicionar Novo
                        </button>
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto px-10 py-6 custom-scrollbar pb-40 relative">
                    <div className="bg-white dark:bg-[#23243a] rounded-[2rem] shadow-sm border border-gray-100 dark:border-white/5 transition-colors overflow-hidden">
                        <table className="w-full text-left border-separate border-spacing-0">
                            <thead className="bg-gray-50 dark:bg-[#2a2b42] transition-colors">
                                <tr className="text-[10px] font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-[0.2em]">
                                    <th className="sticky top-0 z-20 bg-inherit px-8 py-6 border-b border-gray-100 dark:border-white/5">Produto</th>
                                    <th className="sticky top-0 z-20 bg-inherit px-8 py-6 border-b border-gray-100 dark:border-white/5">Categoria</th>
                                    <th className="sticky top-0 z-20 bg-inherit px-8 py-6 text-right border-b border-gray-100 dark:border-white/5">Preço</th>
                                    <th className="sticky top-0 z-20 bg-inherit px-8 py-6 text-center border-b border-gray-100 dark:border-white/5">Estoque</th>
                                    <th className="sticky top-0 z-20 bg-inherit px-8 py-6 text-right border-b border-gray-100 dark:border-white/5">Ações</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-50 dark:divide-white/5">
                                {paginatedProducts.length === 0 ? (
                                    <tr><td colSpan={5} className="py-20 text-center text-gray-400 dark:text-gray-600 font-bold uppercase text-xs">Nenhum produto encontrado</td></tr>
                                ) : (
                                    paginatedProducts.map(p => (
                                        <tr key={p.id} className="hover:bg-gray-50/50 dark:hover:bg-white/5 transition-colors group">
                                            <td className="px-8 py-4">
                                                <div className="flex items-center gap-4">
                                                    <div className="w-12 h-12 rounded-xl bg-gray-50 dark:bg-white/5 border border-gray-100 dark:border-white/10 flex items-center justify-center p-1.5 shrink-0 overflow-hidden">
                                                        <img src={p.image || 'https://cdn-icons-png.flaticon.com/512/1256/1256650.png'} className="w-full h-full object-contain" />
                                                    </div>
                                                    <div className="flex flex-col">
                                                        <div className="flex items-center gap-1.5">
                                                            {p.is_favorite && <Star size={14} className="text-amber-400 fill-current" />}
                                                            <span className="text-sm font-semibold text-gray-800 dark:text-white uppercase tracking-tight">{p.name}</span>
                                                        </div>
                                                        <span className="text-[10px] font-medium text-gray-400 dark:text-gray-500 uppercase">Cód. {p.code || '---'}</span>
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="px-8 py-4">
                                                <span className="px-3 py-1 bg-gray-100 dark:bg-white/5 text-gray-500 dark:text-gray-400 rounded-lg text-[10px] font-semibold uppercase tracking-wider">{p.category}</span>
                                            </td>
                                            <td className="px-8 py-4 text-right">
                                                <span className="text-sm font-bold text-gray-800 dark:text-white">{p.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                                            </td>
                                            <td className="px-8 py-4 text-center">
                                                <span className={`inline-flex items-center justify-center w-10 h-6 rounded-lg text-xs font-bold ${!p.manage_stock ? 'bg-gray-100 dark:bg-white/5 text-gray-400 dark:text-gray-600' : (p.stock || 0) <= (p.min_stock || 0) ? 'bg-rose-50 dark:bg-rose-500/10 text-rose-500' : 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-500'}`}>
                                                    {p.manage_stock ? (p.stock || 0) : '∞'}
                                                </span>
                                            </td>
                                            <td className="px-8 py-4 text-right">
                                                <div className="flex justify-end gap-1">
                                                    <button onClick={() => handleRowClick(p)} className="p-2 text-gray-300 dark:text-gray-600 hover:text-[#2ebc7d] dark:hover:text-[#c1ff72] hover:bg-emerald-50 dark:hover:bg-white/5 rounded-xl transition-all"><Edit3 size={18} /></button>
                                                    <button onClick={() => setProductToDelete({ id: p.id, name: p.name })} className="p-2 text-gray-300 dark:text-gray-600 hover:text-rose-500 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-xl transition-all"><Trash2 size={18} /></button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div className="block lg:hidden flex flex-col h-full overflow-hidden">
                <header className="bg-white dark:bg-[#23243a] border-b border-gray-100 dark:border-white/5 flex flex-col shrink-0 z-30 transition-colors">
                    <div className="flex">
                        <button 
                            onClick={() => setActiveTab('itens')}
                            className={`flex-1 py-3 text-sm font-bold uppercase tracking-widest transition-colors ${activeTab === 'itens' ? 'text-[#2ebc7d] border-b-2 border-[#2ebc7d]' : 'text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300'}`}
                        >
                            Itens
                        </button>
                        <button 
                            onClick={() => setActiveTab('estoque')}
                            className={`flex-1 py-3 text-sm font-bold uppercase tracking-widest transition-colors ${activeTab === 'estoque' ? 'text-[#2ebc7d] border-b-2 border-[#2ebc7d]' : 'text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300'}`}
                        >
                            Estoque
                        </button>
                    </div>
                </header>

                <div className="bg-white dark:bg-[#23243a] px-4 py-4 flex items-center gap-3 shrink-0 transition-colors">
                    <div className="relative flex-1 group">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-600 group-focus-within:text-[#2ebc7d]" size={20} />
                        <input type="text" placeholder="Item, valor ou código" className="w-full pl-11 pr-4 py-3 bg-gray-50 dark:bg-[#1a1b2e] dark:text-white rounded-xl text-sm font-medium outline-none focus:ring-2 focus:ring-[#2ebc7d]/10 transition-all border border-transparent focus:border-[#2ebc7d]/30" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
                    </div>
                    {activeTab === 'itens' ? (
                        <button onClick={() => { setEditingProduct(undefined); setIsFormOpen(true); }} className="p-3 bg-[#2ebc7d] text-white rounded-xl shadow-lg shadow-[#2ebc7d]/20 active:scale-95 transition-all"><Plus size={24} strokeWidth={3} /></button>
                    ) : (
                        <button onClick={() => setIsFilterPanelOpen(true)} className={`p-3 border-2 rounded-xl transition-all ${activeFilters.stockStatus.length > 0 || activeFilters.categories.length > 0 ? 'bg-[#2ebc7d]/10 border-[#2ebc7d] text-[#2ebc7d]' : 'bg-white dark:bg-white/5 border-gray-100 dark:border-white/10 text-gray-400 hover:bg-gray-50 dark:hover:bg-white/10'}`}>
                            <Filter size={24} />
                        </button>
                    )}
                </div>

                <div className="flex-1 overflow-y-auto px-4 pb-40 custom-scrollbar">
                    <div className="divide-y divide-gray-100 dark:divide-white/5">
                        {paginatedProducts.length === 0 ? (
                            <div className="flex flex-col items-center justify-center py-20 text-center text-gray-400 dark:text-gray-600"><Package size={48} className="mb-2 opacity-20" /><p className="text-sm font-medium">Nenhum produto encontrado</p></div>
                        ) : (
                            paginatedProducts.map((product) => (
                                <div key={product.id} onClick={() => handleRowClick(product)} className="flex items-center gap-4 py-4 group active:bg-gray-50 dark:active:bg-white/5 transition-colors">
                                    <div className="relative shrink-0">
                                        <div className="w-16 h-16 rounded-xl bg-white dark:bg-white/5 border border-gray-100 dark:border-white/10 overflow-hidden flex items-center justify-center p-1"><img src={product.image || 'https://via.placeholder.com/80'} alt="" className="w-full h-full object-contain" /></div>
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center gap-1.5 mb-0.5">{product.is_favorite && <Star size={14} className="text-amber-400 fill-current" />}<h3 className="text-sm font-semibold text-gray-800 dark:text-white truncate uppercase tracking-tight">{product.name}</h3></div>
                                        <p className="text-xs text-gray-400 dark:text-gray-500 font-medium">{product.category}</p>
                                    </div>
                                    <div className="text-right shrink-0">
                                        {activeTab === 'itens' ? (
                                            <span className="text-sm font-semibold text-gray-600 dark:text-gray-300">{product.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                                        ) : (
                                            <span className={`text-sm font-semibold ${!product.manage_stock ? 'text-gray-400' : (product.stock || 0) <= 0 ? 'text-red-500' : (product.stock || 0) <= (product.min_stock || 0) ? 'text-amber-500' : 'text-emerald-500'}`}>
                                                {!product.manage_stock ? 'N/A' : product.stock}
                                            </span>
                                        )}
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            </div>

            {/* BARRA DE PAGINAÇÃO FLUTUANTE (FLOATING UI) */}
            {totalPages > 1 && (
                <div className="fixed bottom-8 left-1/2 -translate-x-1/2 w-[90%] max-w-lg z-[60] animate-in slide-in-from-bottom-6 fade-in duration-500">
                    <div className="bg-white/80 dark:bg-[#23243a]/90 backdrop-blur-md border border-slate-200/50 dark:border-white/10 rounded-full px-6 py-3 shadow-[0_20px_50px_rgba(0,0,0,0.15)] dark:shadow-[0_20px_50px_rgba(0,0,0,0.3)] flex items-center justify-between gap-4 transition-all">
                        
                        <div className="flex items-center gap-1.5 shrink-0">
                            <span className="flex h-2 w-2 rounded-full bg-[#2ebc7d] animate-pulse"></span>
                            <p className="text-[10px] font-black text-slate-500 dark:text-gray-400 uppercase tracking-widest hidden sm:block">
                                {processedProducts.length} itens
                            </p>
                        </div>
                        
                        <div className="flex items-center gap-2">
                            <button 
                                onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                                disabled={currentPage === 1}
                                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${currentPage === 1 ? 'text-slate-300 dark:text-slate-700 cursor-not-allowed' : 'text-[#2ebc7d] dark:text-[#c1ff72] hover:bg-slate-100 dark:hover:bg-white/10 active:scale-90 shadow-sm'}`}
                            >
                                <ChevronLeft size={22} strokeWidth={3} />
                            </button>
                            
                            <div className="px-5 py-1.5 bg-slate-50 dark:bg-black/20 rounded-full border border-slate-200 dark:border-white/5">
                                <span className="text-xs font-black text-slate-800 dark:text-white uppercase tracking-tighter whitespace-nowrap">
                                    Pág. {currentPage} <span className="text-slate-300 dark:text-slate-600 mx-1">/</span> {totalPages}
                                </span>
                            </div>

                            <button 
                                onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                                disabled={currentPage === totalPages}
                                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${currentPage === totalPages ? 'text-slate-300 dark:text-slate-700 cursor-not-allowed' : 'text-[#2ebc7d] dark:text-[#c1ff72] hover:bg-slate-100 dark:hover:bg-white/10 active:scale-90 shadow-sm'}`}
                            >
                                <ChevronRight size={22} strokeWidth={3} />
                            </button>
                        </div>

                        <div className="hidden sm:block shrink-0">
                             <div className="text-[9px] font-black text-white bg-indigo-600 px-3 py-1 rounded-full uppercase tracking-tighter">
                                {ITEMS_PER_PAGE} p/ pág.
                             </div>
                        </div>
                    </div>
                </div>
            )}
          </>
      )}

      <CategoryPanel 
        isOpen={isCategoryPanelOpen}
        onClose={() => setIsCategoryPanelOpen(false)}
        categories={categories}
        onAddCategory={onAddCategory as any}
        onEditCategory={onEditCategory as any}
        onDeleteCategory={onDeleteCategory}
      />

      <ProductFilterPanel 
        isOpen={isFilterPanelOpen}
        onClose={() => setIsFilterPanelOpen(false)}
        currentFilters={activeFilters}
        onApplyFilters={setActiveFilters}
      />

      <Toast message={toastMessage} isVisible={showToast} onClose={() => setShowToast(false)} />
    </div>
  );
};

export default ProductsScreen;
