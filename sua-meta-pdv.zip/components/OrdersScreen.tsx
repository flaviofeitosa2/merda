
import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  User, 
  Clock, 
  Plus, 
  Trash2,
  Calendar,
  ShoppingBag,
  ArrowRight,
  AlertCircle,
  List,
  Menu,
  Upload,
  ChevronRight,
  ChevronDown,
  Building2,
  DollarSign,
  Tag,
  AlertOctagon,
  X,
  Loader2,
  AlertTriangle
} from 'lucide-react';
import { Sale, UserProfile } from '../types';
import UserMenu from './UserMenu';
import OrdersFilterPanel, { OrderFilterState } from './OrdersFilterPanel';

interface OrdersScreenProps {
  sales: Sale[];
  userProfile: UserProfile;
  toggleSidebar: () => void;
  onLoadOrder: (sale: Sale) => void;
  onCreateNew: () => void;
  onCancelOrder: (saleId: string, reason: string) => void;
  portalUserIds: Set<string>;
}

// FIX: Helper para converter UTC string para data local correta YYYY-MM-DD
const getOrderDate = (dateStr: string) => {
    const d = new Date(dateStr);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

const OrdersScreen: React.FC<OrdersScreenProps> = ({ 
    sales, 
    userProfile,
    toggleSidebar,
    onLoadOrder,
    onCreateNew,
    onCancelOrder,
    portalUserIds
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [orderToDelete, setOrderToDelete] = useState<Sale | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  
  const [filters, setFilters] = useState<OrderFilterState>({
    startDate: '',
    endDate: '',
    quickPeriod: null,
    paymentMethods: [],
    onlyCancelled: false,
    status: ['pending'],
    selectedSellers: []
  });

  const getFriendlyDate = (dateStr: string) => {
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    const saleDate = getOrderDate(dateStr);
    if (saleDate === today) return 'Hoje';
    if (saleDate === yesterday) return 'Ontem';
    return new Date(dateStr).toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'short', year: 'numeric' }).replace(/^\w/, (c) => c.toUpperCase());
  };

  const filteredSales = useMemo(() => {
    const isOperator = userProfile.role === 'operator' || userProfile.role === 'operador';
    const currentUserName = (userProfile.full_name || '').trim().toLowerCase();

    return sales.filter(s => {
      // Filtro de Status (se não houver filtro, mostra apenas pending por padrão na tela de "Pedidos em Aberto")
      // Mas se o usuário explicitamente filtrar, respeitamos o filtro.
      if (filters.status.length > 0) {
        if (!filters.status.includes(s.status as any)) return false;
      } else {
        if (s.status !== 'pending') return false;
      }

      // Regra de Privacidade: Operador só vê os próprios pedidos
      if (isOperator) {
        const sellerName = (s.sellerName || '').trim().toLowerCase();
        if (sellerName !== currentUserName) return false;
      }

      const searchLower = searchQuery.toLowerCase();
      const matchesSearch = 
        s.clientName.toLowerCase().includes(searchLower) ||
        s.code.toLowerCase().includes(searchLower) ||
        (s.items?.some(i => i.name.toLowerCase().includes(searchLower)));
      
      if (!matchesSearch) return false;

      // Filtro de Vendedores
      if (filters.selectedSellers.length > 0) {
        if (!filters.selectedSellers.includes(s.sellerName)) return false;
      }

      // Filtro de Datas
      if (filters.startDate) {
        const sDate = new Date(s.date);
        const filterStart = new Date(filters.startDate);
        filterStart.setHours(0,0,0,0);
        if (sDate < filterStart) return false;
      }
      if (filters.endDate) {
        const sDate = new Date(s.date);
        const filterEnd = new Date(filters.endDate);
        filterEnd.setHours(23,59,59,999);
        if (sDate > filterEnd) return false;
      }

      // Filtro de Meios de Pagamento
      if (filters.paymentMethods.length > 0) {
        if (!filters.paymentMethods.includes(s.payment_method as any)) return false;
      }

      // Filtro de Cancelados
      if (filters.onlyCancelled) {
        if (s.status !== 'cancelled') return false;
      }

      return true;
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [sales, searchQuery, filters, userProfile]);

  const groupedSales = useMemo(() => {
    const groups: Record<string, { sales: Sale[], total: number }> = {};
    filteredSales.forEach(sale => {
      const day = getOrderDate(sale.date);
      if (!groups[day]) groups[day] = { sales: [], total: 0 };
      groups[day].sales.push(sale);
      groups[day].total += sale.total;
    });
    return Object.entries(groups).sort((a, b) => b[0].localeCompare(a[0]));
  }, [filteredSales]);

  const stats = useMemo(() => {
      const count = filteredSales.length;
      const totalPotential = filteredSales.reduce((acc, s) => acc + s.total, 0);
      
      let oldestDate = null;
      if (filteredSales.length > 0) {
          const dates = filteredSales.map(s => new Date(s.date).getTime());
          oldestDate = new Date(Math.min(...dates)).toLocaleString('pt-BR', {
              day: '2-digit',
              month: '2-digit',
              year: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
          });
      }

      return { count, totalPotential, oldestDate };
  }, [filteredSales]);

  const handleOpenDeleteModal = (e: React.MouseEvent, sale: Sale) => {
      e.stopPropagation();
      setOrderToDelete(sale);
  };

  const handleConfirmDelete = async () => {
      if (!orderToDelete) return;
      setIsDeleting(true);
      try {
          await onCancelOrder(orderToDelete.id, 'Cancelado na tela de Pedidos Abertos');
          setOrderToDelete(null);
      } catch (err) {
          console.error(err);
      } finally {
          setIsDeleting(false);
      }
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#F5F7F9] dark:bg-[#1a1b2e] relative font-sans transition-colors">
      
      {/* MODAL DE CONFIRMAÇÃO DE EXCLUSÃO */}
      {orderToDelete && (
          <div className="fixed inset-0 bg-black/60 z-[150] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
              <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] w-full max-sm:max-w-sm shadow-2xl p-8 text-center animate-in zoom-in-95 duration-300 border border-transparent dark:border-white/5 transition-all">
                  <div className="w-20 h-20 bg-rose-50 dark:bg-rose-500/10 text-rose-500 dark:text-rose-400 rounded-full flex items-center justify-center mx-auto mb-6">
                      <AlertTriangle size={40} />
                  </div>
                  <h3 className="text-xl font-black text-gray-900 dark:text-white uppercase tracking-tight mb-2">Excluir Pedido?</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-8 leading-relaxed font-medium">
                      Tem certeza que deseja excluir o pedido <strong className="text-gray-800 dark:text-gray-200">#{orderToDelete.code}</strong> do cliente <strong className="text-gray-800 dark:text-gray-200 uppercase">{orderToDelete.clientName}</strong>? Esta ação não pode ser desfeita.
                  </p>
                  <div className="flex flex-col gap-3">
                      <button 
                        onClick={handleConfirmDelete}
                        disabled={isDeleting}
                        className="w-full py-4 bg-rose-500 hover:bg-rose-600 text-white font-black rounded-2xl shadow-xl shadow-rose-100 dark:shadow-none flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
                      >
                          {isDeleting ? <Loader2 className="animate-spin" size={20} /> : <Trash2 size={20} />}
                          SIM, EXCLUIR AGORA
                      </button>
                      <button 
                        onClick={() => setOrderToDelete(null)}
                        disabled={isDeleting}
                        className="w-full py-4 bg-gray-100 dark:bg-white/5 text-gray-500 dark:text-gray-400 font-bold rounded-2xl hover:bg-gray-200 dark:hover:bg-white/10 transition-all"
                      >
                          CANCELAR
                      </button>
                  </div>
              </div>
          </div>
      )}

      <header className="bg-white dark:bg-[#23243a] h-[90px] px-4 lg:px-10 flex justify-between items-center shrink-0 border-b border-gray-100 dark:border-white/5 sticky top-0 z-50 transition-colors">
          <div className="flex items-center gap-4">
              <button onClick={toggleSidebar} className="lg:hidden p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-xl transition-colors">
                  <List size={26} />
              </button>
              <div>
                  <h1 className="text-[23px] font-mono font-black text-gray-900 dark:text-white tracking-tighter uppercase leading-none italic flex items-center gap-3">
                      Pedidos
                      <span className="bg-orange-500 text-white text-[10px] px-2 py-0.5 rounded-full shadow-lg shadow-orange-500/20 font-bold transition-all">
                          {stats.count}
                      </span>
                  </h1>
                  <p className="text-[10px] text-gray-400 font-black uppercase tracking-[0.3em] mt-1 hidden sm:block">Vendas salvas aguardando finalização</p>
              </div>
          </div>
          <div className="flex items-center gap-2 lg:gap-6">
              <button 
                onClick={onCreateNew}
                className="hidden sm:flex bg-[#2dd4bf] hover:bg-[#14b8a6] text-white px-4 lg:px-6 py-2 rounded-lg font-bold text-xs lg:text-sm shadow-lg shadow-teal-500/20 items-center gap-2 transition-all active:scale-95"
              >
                <Plus size={18} strokeWidth={3} /> Novo Pedido
              </button>
              <div className="flex lg:hidden items-center gap-1">
                  <button className="p-2 text-gray-500 dark:text-gray-400"><Upload size={22} /></button>
                  <button onClick={() => setIsFilterOpen(true)} className="p-2 text-gray-500 dark:text-gray-400"><Filter size={22} /></button>
              </div>
              <UserMenu />
          </div>
      </header>



      {/* --- ÁREA DE CONTEÚDO --- */}
      <div className="flex-1 overflow-y-auto custom-scrollbar">
          
          <div className="hidden lg:block p-8 max-w-[1600px] mx-auto w-full">
              
              <div className="grid grid-cols-3 gap-6 mb-8">
                  <div className="bg-white dark:bg-[#23243a] p-6 rounded-xl shadow-sm border border-gray-100 dark:border-white/5 flex justify-between items-center relative overflow-hidden transition-colors">
                      <div>
                          <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-2">Total em aberto</p>
                          <h3 className="text-3xl font-black text-gray-800 dark:text-white transition-colors">{stats.totalPotential.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</h3>
                          <p className="text-[10px] text-gray-400 dark:text-gray-500 font-medium mt-1">Receita potencial</p>
                      </div>
                      <div className="p-4 bg-amber-50 dark:bg-amber-500/10 rounded-xl text-amber-500 dark:text-amber-400 transition-colors">
                          <ShoppingBag size={28} />
                      </div>
                      <div className="absolute bottom-0 left-0 right-0 h-1 bg-amber-400"></div>
                  </div>

                  <div className="bg-white dark:bg-[#23243a] p-6 rounded-xl shadow-sm border border-gray-100 dark:border-white/5 flex justify-between items-center transition-colors">
                      <div>
                          <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-2">Pedidos Salvos</p>
                          <h3 className="text-3xl font-black text-gray-800 dark:text-white transition-colors">{stats.count}</h3>
                          <p className="text-[10px] text-gray-400 dark:text-gray-500 font-medium mt-1">Aguardando pagamento</p>
                      </div>
                      <div className="p-4 bg-blue-50 dark:bg-blue-500/10 rounded-xl text-blue-500 dark:text-blue-400 transition-colors">
                          <Clock size={28} />
                      </div>
                  </div>

                  <div className="bg-white dark:bg-[#23243a] p-6 rounded-xl shadow-sm border border-gray-100 dark:border-white/5 flex justify-between items-center transition-colors">
                      <div>
                          <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mb-2">Pedido mais antigo</p>
                          <h3 className="text-xl font-black text-gray-800 dark:text-white transition-colors">{stats.oldestDate?.split(' ')[0] || '--/--/----'}</h3>
                          <p className="text-[10px] text-gray-400 dark:text-gray-500 font-medium mt-1">{stats.oldestDate?.split(' ')[1] || '00:00'}</p>
                      </div>
                      <div className="p-4 bg-rose-50 dark:bg-rose-500/10 rounded-xl text-rose-500 dark:text-rose-400 transition-colors">
                          <AlertOctagon size={28} />
                      </div>
                  </div>
              </div>

              <div className="flex items-center gap-4 mb-6">
                  <div className="relative flex-1 max-w-md group">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-600 group-focus-within:text-[#2dd4bf] transition-colors" size={18} />
                      <input 
                        type="text" 
                        placeholder="Buscar pedido por cliente ou código..." 
                        className="w-full bg-white dark:bg-[#23243a] dark:text-white border border-gray-200 dark:border-white/10 rounded-lg pl-10 pr-4 py-2.5 text-sm outline-none focus:border-[#2dd4bf] transition-all shadow-sm"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                  </div>
                  <button 
                    onClick={() => setIsFilterOpen(true)}
                    className="p-2.5 bg-white dark:bg-[#23243a] border border-gray-200 dark:border-white/10 text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-white rounded-lg shadow-sm transition-all"
                  >
                      <Filter size={20} />
                  </button>
              </div>

              <div className="bg-white dark:bg-[#23243a] rounded-xl shadow-sm border border-gray-100 dark:border-white/5 overflow-hidden transition-colors">
                  <table className="w-full text-left">
                      <thead className="bg-white dark:bg-white/5 text-gray-400 dark:text-gray-500 font-bold text-[10px] uppercase tracking-widest border-b border-gray-100 dark:border-white/5 transition-colors">
                          <tr>
                              <th className="px-8 py-5">Código / Data</th>
                              <th className="px-8 py-5">Cliente</th>
                              <th className="px-8 py-5">Vendedor</th>
                              <th className="px-8 py-5 text-center">Itens</th>
                              <th className="px-8 py-5 text-right">Total</th>
                              <th className="px-8 py-5 text-right">Ação</th>
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-50 dark:divide-white/5">
                          {filteredSales.length === 0 ? (
                              <tr>
                                  <td colSpan={6} className="py-20 text-center text-gray-300 dark:text-gray-600 font-bold uppercase text-xs tracking-widest">Nenhum pedido pendente</td>
                              </tr>
                          ) : (
                              filteredSales.map((sale) => (
                                  <tr key={sale.id} className="hover:bg-gray-50 dark:hover:bg-white/5 transition-colors group">
                                      <td className="px-8 py-5">
                                          <div className="flex flex-col">
                                              <span className="font-black text-gray-900 dark:text-white text-xs bg-gray-100 dark:bg-white/5 px-2 py-0.5 rounded border border-gray-200 dark:border-white/10 w-fit transition-colors">#{sale.code}</span>
                                              <span className="text-[10px] text-gray-400 dark:text-gray-500 mt-1.5 font-bold flex items-center gap-1 transition-colors"><Calendar size={10} /> {new Date(sale.date).toLocaleDateString('pt-BR')} • {new Date(sale.date).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</span>
                                          </div>
                                      </td>
                                      <td className="px-8 py-5">
                                          <div className="flex items-center gap-3">
                                              <div className="w-8 h-8 rounded-full bg-amber-100 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center text-[10px] font-black uppercase transition-colors">
                                                  {sale.clientName.substring(0,2)}
                                              </div>
                                              <div className="flex flex-col">
                                                  <span className="text-xs font-bold text-gray-800 dark:text-white uppercase transition-colors">{sale.clientName}</span>
                                                  {portalUserIds.has(sale.customerId) && (
                                                    <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.6)]" title="Cadastro Habilitado no Portal" />
                                                  )}
                                                  <span className="text-[10px] text-gray-400 text-gray-500 font-medium transition-colors">Cliente Balcão</span>
                                              </div>
                                          </div>
                                      </td>
                                      <td className="px-8 py-5">
                                          <div className="flex items-center gap-2 text-xs font-medium text-gray-500 dark:text-gray-400 transition-colors">
                                              <User size={14} className="text-gray-300 dark:text-gray-600 transition-colors" />
                                              {sale.sellerName}
                                          </div>
                                      </td>
                                      <td className="px-8 py-5 text-center">
                                          <span className="bg-gray-100 dark:bg-white/5 text-gray-600 dark:text-gray-400 px-2.5 py-1 rounded-md text-[10px] font-black transition-colors">{sale.items.length}</span>
                                      </td>
                                      <td className="px-8 py-5 text-right font-black text-gray-900 dark:text-white text-sm transition-colors">
                                          {sale.total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                                      </td>
                                      <td className="px-8 py-5 text-right">
                                          <div className="flex justify-end items-center gap-3">
                                              <button 
                                                onClick={(e) => handleOpenDeleteModal(e, sale)}
                                                className="p-2 text-gray-300 dark:text-gray-600 hover:text-rose-500 dark:hover:text-rose-400 transition-colors"
                                              >
                                                  <Trash2 size={18} />
                                              </button>
                                              <button 
                                                onClick={() => onLoadOrder(sale)}
                                                className="bg-[#2dd4bf] hover:bg-[#14b8a6] text-white px-5 py-2 rounded-lg text-xs font-black uppercase tracking-widest flex items-center gap-2 transition-all active:scale-95"
                                              >
                                                  Continuar <ArrowRight size={16} />
                                              </button>
                                          </div>
                                      </td>
                                  </tr>
                              ))
                          )}
                      </tbody>
                  </table>
                  <div className="bg-gray-50/50 dark:bg-white/5 py-4 text-center border-t border-gray-100 dark:border-white/5 transition-colors">
                      <p className="text-[10px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-widest">{stats.count} Pedidos aguardando finalização</p>
                  </div>
              </div>
          </div>

          {/* VISUALIZAÇÃO MOBILE */}
          <div className="lg:hidden px-6 pb-32">
              <div className="px-0 py-2 space-y-4 shrink-0 bg-transparent border-b border-gray-50 dark:border-white/5 transition-colors mb-4">
                  <div className="relative group">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-600" size={20} />
                      <input 
                        type="text" 
                        placeholder="Item, cliente, valor ou código" 
                        className="w-full pl-11 pr-4 py-3 bg-white dark:bg-[#23243a] dark:text-white border-none rounded-xl text-sm font-medium outline-none shadow-sm transition-colors"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                  </div>
                  <div className="flex items-center gap-6 pb-2">
                      <button className="flex items-center gap-1.5 text-gray-600 dark:text-gray-300 text-sm font-bold transition-colors">
                          <Clock size={18} className="text-gray-400 dark:text-gray-600" />
                          <span>Todos os status</span>
                          <ChevronDown size={16} className="text-gray-400 dark:text-gray-600" />
                      </button>
                      <button className="flex items-center gap-1.5 text-gray-600 dark:text-gray-300 text-sm font-bold transition-colors">
                          <User size={18} className="text-gray-400 dark:text-gray-600" />
                          <span>Vendedores</span>
                          <ChevronDown size={16} className="text-gray-400 dark:text-gray-600" />
                      </button>
                  </div>
              </div>

              {groupedSales.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-20 text-gray-300 dark:text-gray-700">
                      <ShoppingBag size={64} strokeWidth={1} />
                      <p className="mt-4 font-bold uppercase text-xs tracking-widest">Nenhum pedido</p>
                  </div>
              ) : (
                  <div className="mt-2 space-y-10">
                      {groupedSales.map(([date, group]) => (
                          <section key={date} className="animate-in fade-in slide-in-from-bottom-2 duration-500">
                              <header className="mb-4">
                                  <h3 className="text-lg font-bold text-gray-700 dark:text-white tracking-tight transition-colors">{getFriendlyDate(group.sales[0].date)}</h3>
                                  <p className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest transition-colors">{group.sales.length} {group.sales.length === 1 ? 'pedido' : 'pedidos'}, {group.total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
                              </header>
                              <div className="space-y-8">
                                  {group.sales.map((sale) => (
                                      <div key={sale.id} onClick={() => onLoadOrder(sale)} className="flex items-start gap-4 active:bg-gray-50 dark:active:bg-white/5 transition-colors cursor-pointer group relative">
                                          <div className="mt-1 text-gray-500 dark:text-gray-400 group-active:text-teal-500 transition-colors">
                                              <Clock size={20} />
                                          </div>
                                          <div className="flex-1 min-w-0">
                                              <div className="flex justify-between items-baseline">
                                                  <div className="flex items-baseline gap-1.5 overflow-hidden">
                                                      <span className="text-base font-bold text-gray-900 dark:text-white whitespace-nowrap transition-colors">{sale.total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                                                      <span className="text-xs text-gray-400 dark:text-gray-500 font-bold truncate transition-colors">por {sale.sellerName?.split(' ')[0] || 'Sistema'}</span>
                                                  </div>
                                                  <span className="text-xs font-bold text-gray-400 dark:text-gray-500 transition-colors">{new Date(sale.date).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</span>
                                              </div>
                                              <div className="flex justify-between items-center mt-1">
                                                  <p className="text-xs text-gray-500 dark:text-gray-400 font-bold truncate pr-4 transition-colors">
                                                      {sale.items.length} itens: {sale.items.map(i => `${i.quantity}x ${i.name.substring(0,8)}`).join(' ')}
                                                  </p>
                                                  <span className="text-[10px] font-bold text-gray-300 dark:text-gray-600 tracking-tighter transition-colors">#{sale.code}</span>
                                              </div>
                                              <div className="flex items-center gap-2 mt-1.5">
                                                  <Building2 size={14} className="text-gray-400 dark:text-gray-600 transition-colors" />
                                                  <span className="text-[11px] font-bold text-gray-700 dark:text-gray-300 uppercase truncate transition-colors">{sale.clientName || 'CLIENTE BALCÃO'}</span>
                                                  {sale.customerId && portalUserIds.has(sale.customerId) && (
                                                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_6px_rgba(16,185,129,0.6)]" title="Cadastro Habilitado no Portal" />
                                                  )}
                                                  
                                                  <div className="ml-auto flex items-center gap-4">
                                                      <button 
                                                        onClick={(e) => handleOpenDeleteModal(e, sale)}
                                                        className="p-2 text-rose-400 active:scale-90 transition-transform"
                                                      >
                                                          <Trash2 size={20} />
                                                      </button>
                                                      <Tag size={12} className="text-gray-400 dark:text-gray-600 transition-colors" />
                                                  </div>
                                              </div>
                                          </div>
                                      </div>
                                  ))}
                              </div>
                          </section>
                      ))}
                  </div>
              )}
          </div>
      </div>

      <footer className="lg:hidden fixed bottom-0 left-0 right-0 bg-[#374151] dark:bg-[#23243a] text-white px-6 py-4 shadow-[0_-10px_30px_rgba(0,0,0,0.1)] z-40 transition-colors">
          <p className="text-[11px] font-bold uppercase tracking-[0.2em] opacity-60 mb-1">Total em pedidos</p>
          <div className="flex justify-between items-center">
              <p className="text-lg font-bold tracking-tight">
                  {stats.totalPotential.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  <span className="text-xs font-medium opacity-60 ml-2">em {stats.count} pedidos</span>
              </p>
              <ChevronRight size={20} className="opacity-40" />
          </div>
      </footer>

      <OrdersFilterPanel 
        isOpen={isFilterOpen}
        onClose={() => setIsFilterOpen(false)}
        onApplyFilters={setFilters}
        salesData={sales}
        currentFilters={filters}
      />
    </div>
  );
};

export default OrdersScreen;
