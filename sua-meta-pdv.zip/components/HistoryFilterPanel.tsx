
import React, { useState, useEffect, useMemo } from 'react';
import { X, ChevronDown, ChevronRight, Calendar, Check, Search, Users } from 'lucide-react';
import { PaymentMethod, UserRole } from '../types';

export interface FilterState {
  startDate: string;
  endDate: string;
  quickPeriod: string | null;
  paymentMethods: PaymentMethod[];
  onlyCancelled: boolean;
  selectedSellers: string[];
}

interface HistoryFilterPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyFilters: (filters: FilterState) => void;
  allUsers: {id: string, full_name: string}[];
  currentFilters: FilterState;
  userRole?: UserRole;
  permissions?: any;
}

const toLocalISO = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

/**
 * Movido para fora do componente HistoryFilterPanel para evitar erros de tipo 
 * com a propriedade reservada 'key' do React ao ser utilizado em mapeamentos.
 */
const CustomCheckbox = ({ checked, label, onChange }: { checked: boolean; label: string; onChange: () => void; key?: React.Key }) => (
  <label className="flex items-center gap-3 cursor-pointer group py-1">
      <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${
        checked 
          ? 'bg-indigo-600 border-indigo-600' 
          : 'bg-white border-slate-200 group-hover:border-slate-300'
      }`}>
          {checked && <Check size={14} className="text-white" strokeWidth={4} />}
      </div>
      <span className={`text-[11px] font-black uppercase tracking-widest ${checked ? 'text-slate-900' : 'text-slate-400'}`}>{label}</span>
      <input type="checkbox" className="hidden" checked={checked} onChange={onChange} />
  </label>
);

const HistoryFilterPanel: React.FC<HistoryFilterPanelProps> = ({ 
  isOpen, 
  onClose, 
  onApplyFilters,
  allUsers = [],
  currentFilters,
  userRole,
  permissions
}) => {
  const [filters, setFilters] = useState<FilterState>(currentFilters);
  const [isSellersOpen, setIsSellersOpen] = useState(true);
  const [sellerSearch, setSellerSearch] = useState('');

  const isOperator = userRole === 'operator' || userRole === 'operador';

  useEffect(() => {
    if (isOpen) {
      setFilters(currentFilters);
      setSellerSearch('');
    }
  }, [isOpen, currentFilters]);

  const paymentOptions: { id: PaymentMethod; label: string }[] = [
    { id: 'pix', label: 'PIX' },
    { id: 'money', label: 'DINHEIRO' },
    { id: 'debit', label: 'CARTÃO DE DÉBITO' },
    { id: 'credit', label: 'CARTÃO DE CRÉDITO' },
    { id: 'others', label: 'OUTROS' },
    { id: 'credit_tab', label: 'VENDA FIADO' },
    { id: 'link', label: 'LINK DE PAGAMENTO' },
  ];

  const handleClear = () => {
    const today = toLocalISO(new Date());
    setFilters({
      startDate: today,
      endDate: today,
      quickPeriod: 'hoje',
      paymentMethods: [],
      onlyCancelled: false,
      selectedSellers: []
    });
  };

  const handleQuickPeriod = (period: string) => {
    const today = new Date();
    let start = new Date();
    let end = new Date();

    switch (period) {
      case 'hoje': 
        start = new Date();
        end = new Date();
        break;
      case 'ontem':
        start.setDate(today.getDate() - 1);
        end.setDate(today.getDate() - 1);
        break;
      case 'esta_semana':
        start.setDate(today.getDate() - today.getDay());
        end = new Date();
        break;
      case 'semana_passada':
        start.setDate(today.getDate() - today.getDay() - 7);
        end.setDate(today.getDate() - today.getDay() - 1);
        break;
      case 'este_mes':
        start.setDate(1);
        end = new Date();
        break;
      case 'mes_passado':
        start.setMonth(today.getMonth() - 1, 1);
        end.setMonth(today.getMonth(), 0);
        break;
      case 'este_ano':
        start.setMonth(0, 1);
        end = new Date();
        break;
      case 'ano_passado':
        start.setFullYear(today.getFullYear() - 1, 0, 1);
        end.setFullYear(today.getFullYear() - 1, 11, 31);
        break;
      default: break;
    }

    setFilters(prev => ({
      ...prev,
      startDate: toLocalISO(start),
      endDate: toLocalISO(end),
      quickPeriod: prev.quickPeriod === period ? null : period
    }));
  };

  const togglePaymentMethod = (method: PaymentMethod) => {
    setFilters(prev => {
      const exists = prev.paymentMethods.includes(method);
      return {
        ...prev,
        paymentMethods: exists 
          ? prev.paymentMethods.filter(p => p !== method)
          : [...prev.paymentMethods, method]
      };
    });
  };

  const toggleSeller = (sellerName: string) => {
    setFilters(prev => {
      const normalized = (sellerName || '').toUpperCase().trim();
      if (!normalized) return prev;
      const exists = prev.selectedSellers.includes(normalized);
      return {
        ...prev,
        selectedSellers: exists
          ? prev.selectedSellers.filter(s => s !== normalized)
          : [...prev.selectedSellers, normalized]
      };
    });
  };

  const filteredStaff = useMemo(() => {
    if (!sellerSearch.trim()) return allUsers;
    const q = sellerSearch.toLowerCase();
    return allUsers.filter(u => (u.full_name || '').toLowerCase().includes(q));
  }, [allUsers, sellerSearch]);

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 bg-black/40 z-[100] transition-opacity backdrop-blur-[2px]" onClick={onClose} />
      )}

      <div className={`fixed inset-y-0 right-0 w-full max-w-[380px] bg-white shadow-2xl z-[110] transform transition-transform duration-300 ease-in-out flex flex-col font-sans border-l border-slate-100 ${
        isOpen ? 'translate-x-0' : 'translate-x-full'
      }`}>
        <div className="flex items-center justify-between px-8 py-8">
          <div className="flex items-center gap-6">
            <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tighter italic leading-none">Filtros</h2>
            <button 
              onClick={handleClear} 
              className="text-indigo-500 font-bold text-[10px] uppercase hover:underline tracking-widest"
            >
              Limpar Tudo
            </button>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors p-1">
            <X size={28} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-8 space-y-12 pb-32 custom-scrollbar">
          
          <section>
            <h3 className="font-black text-slate-800 mb-6 text-[11px] uppercase tracking-[0.2em]">Período da Venda</h3>
            
            {/* Oculta inputs de data livre para Operadores para evitar navegação manual proibida, a menos que tenha permissão de dashboard */}
            {(!isOperator || permissions?.dashboard !== false) && (
                <div className="flex gap-4 mb-8">
                    <div className="flex-1 relative">
                        <input 
                            type="date" 
                            className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-4 text-[11px] font-bold text-slate-400 outline-none focus:bg-white focus:border-indigo-200 transition-all uppercase"
                            value={filters.startDate}
                            onChange={(e) => setFilters(prev => ({ ...prev, startDate: e.target.value, quickPeriod: null }))}
                        />
                        <Calendar size={14} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                    </div>
                    <div className="flex-1 relative">
                        <input 
                            type="date" 
                            className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-4 text-[11px] font-bold text-slate-400 outline-none focus:bg-white focus:border-indigo-200 transition-all uppercase"
                            value={filters.endDate}
                            onChange={(e) => setFilters(prev => ({ ...prev, endDate: e.target.value, quickPeriod: null }))}
                        />
                        <Calendar size={14} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                    </div>
                </div>
            )}

            <div className="grid grid-cols-2 gap-x-6 gap-y-4">
              {[
                { id: 'hoje', label: 'Hoje' },
                { id: 'ontem', label: 'Ontem' },
                { id: 'esta_semana', label: 'Esta semana' },
                { id: 'semana_passada', label: 'Semana passada' },
                { id: 'este_mes', label: 'Este mês' },
                { id: 'mes_passado', label: 'Mês passado' },
                { id: 'este_ano', label: 'Este ano' },
                { id: 'ano_passado', label: 'Ano passado' },
              ].filter(item => {
                  // Filtra opções permitidas para operador
                  if (isOperator && permissions?.dashboard === false) return item.id === 'hoje' || item.id === 'ontem';
                  return true;
              }).map((item) => (
                <CustomCheckbox 
                  key={item.id}
                  label={item.label}
                  checked={filters.quickPeriod === item.id}
                  onChange={() => handleQuickPeriod(item.id)}
                />
              ))}
            </div>
          </section>

          <div className="h-px bg-slate-100 w-full"></div>

          <section>
            <button 
              onClick={() => setIsSellersOpen(!isSellersOpen)}
              className="flex items-center justify-between w-full group mb-6"
            >
                <div className="flex items-center gap-3">
                  <Users size={16} className="text-slate-400" />
                  <h3 className="font-black text-slate-800 text-[11px] uppercase tracking-[0.2em]">Equipe de Vendas</h3>
                </div>
                {isSellersOpen ? <ChevronDown size={18} className="text-slate-400" /> : <ChevronRight size={18} className="text-slate-400" />}
            </button>
            
            {isSellersOpen && (
              <div className="space-y-4 animate-in slide-in-from-top-2">
                {(!isOperator || permissions?.dashboard !== false) && (
                    <div className="relative group mb-4">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500" size={16} />
                        <input 
                          type="text" 
                          placeholder="Pesquisar colaborador..."
                          className="w-full bg-slate-50 border border-slate-100 rounded-xl pl-12 pr-4 py-3 text-[10px] font-bold uppercase outline-none focus:bg-white focus:border-indigo-100 transition-all"
                          value={sellerSearch}
                          onChange={e => setSellerSearch(e.target.value)}
                        />
                    </div>
                )}

                <div className="space-y-3 max-h-48 overflow-y-auto custom-scrollbar pr-1">
                    {filteredStaff.length === 0 ? (
                        <p className="text-[10px] text-slate-300 italic font-bold uppercase tracking-widest text-center py-2">Nenhum colaborador</p>
                    ) : (
                        filteredStaff.map((user) => {
                            const normalizedName = (user.full_name || '').toUpperCase().trim();
                            const isSelected = filters.selectedSellers.includes(normalizedName);
                            return (
                              <CustomCheckbox 
                                key={user.id}
                                label={user.full_name || 'SEM NOME'}
                                checked={isSelected}
                                onChange={() => toggleSeller(user.full_name)}
                              />
                            );
                        })
                    )}
                    {isOperator && permissions?.dashboard === false && (
                        <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest text-center py-2 bg-slate-50 rounded-xl">
                            Acesso restrito ao próprio usuário
                        </p>
                    )}
                </div>
              </div>
            )}
          </section>

          <div className="h-px bg-slate-100 w-full"></div>

          <section>
            <h3 className="font-black text-slate-800 mb-6 text-[11px] uppercase tracking-[0.2em]">Meios de Pagamento</h3>
            <div className="grid grid-cols-2 gap-x-6 gap-y-4">
              {paymentOptions.map((item) => (
                <CustomCheckbox 
                  key={item.id}
                  label={item.label}
                  checked={filters.paymentMethods.includes(item.id)}
                  onChange={() => togglePaymentMethod(item.id)}
                />
              ))}
            </div>
          </section>

          <div className="h-px bg-slate-100 w-full"></div>

          <section>
            <h3 className="font-black text-slate-800 mb-6 text-[11px] uppercase tracking-[0.2em]">Auditoria de Estornos</h3>
            <div className="bg-slate-50 border border-slate-100 rounded-[1.5rem] p-5 flex items-center justify-between transition-all">
                <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Exibir somente cancelados</span>
                <label className="flex items-center cursor-pointer">
                    <div className="relative">
                        <input 
                            type="checkbox" 
                            className="sr-only" 
                            checked={filters.onlyCancelled}
                            onChange={() => setFilters(prev => ({ ...prev, onlyCancelled: !prev.onlyCancelled }))}
                        />
                        <div className={`w-12 h-6 rounded-full transition-colors ${filters.onlyCancelled ? 'bg-indigo-600' : 'bg-slate-200'}`}></div>
                        <div className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full shadow-sm transform transition-transform ${filters.onlyCancelled ? 'translate-x-6' : 'translate-x-0'}`}></div>
                    </div>
                </label>
            </div>
          </section>

        </div>

        <div className="p-8 bg-white border-t border-slate-50 sticky bottom-0 left-0 right-0 z-20">
           <button 
             onClick={() => {
               onApplyFilters(filters);
               onClose();
             }}
             className="w-full bg-[#5d5fe3] hover:bg-[#4a4cc7] text-white font-black py-5 rounded-[1.5rem] transition-all text-xs uppercase tracking-[0.25em] shadow-xl shadow-indigo-100 active:scale-95"
           >
             Aplicar Filtros
           </button>
        </div>
      </div>
    </>
  );
};

export default HistoryFilterPanel;
