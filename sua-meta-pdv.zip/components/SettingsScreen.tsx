import React, { useState, useEffect } from 'react';
import { 
  HelpCircle, 
  ChevronDown, 
  Store, 
  Lock, 
  MapPin, 
  List,
  Receipt,
  User,
  Loader2,
  Wallet,
  CreditCard,
  Banknote,
  QrCode,
  Link as LinkIcon,
  ArrowRightLeft,
  AlertCircle,
  Shield,
  Phone,
  Instagram,
  Mail,
  Image as ImageIcon,
  CheckCircle2,
  LayoutGrid,
  ShoppingBag,
  Users,
  CalendarCheck,
  History,
  DollarSign,
  BarChart2,
  Settings,
  PieChart,
  Info,
  Save,
  MessageSquare,
  AlertTriangle,
  Target,
  Plus,
  X,
  Star
} from 'lucide-react';
import UserMenu from './UserMenu';
import { UserProfile, Company, Wallet as WalletType, OperatorPermissions } from '../types';
import { supabase } from '../supabaseClient';
import Toast from './Toast';

interface FloatingInputProps {
    label: string;
    value: any;
    onChange: (e: any) => void;
    readOnly?: boolean;
    icon?: React.ReactNode;
    rightIcon?: React.ReactNode;
    type?: string;
    prefix?: React.ReactNode;
    multiline?: boolean;
}

const FloatingInput = ({ 
    label, 
    value, 
    readOnly = false, 
    icon = null, 
    rightIcon = <HelpCircle size={18} className="text-gray-400 dark:text-gray-600" />,
    type = "text",
    prefix = null,
    onChange,
    multiline = false
}: FloatingInputProps) => (
    <div className="relative mb-4">
      <label className="absolute -top-2.5 left-3 bg-white dark:bg-[#23243a] px-1 text-[10px] text-gray-500 dark:text-gray-400 z-10 font-bold uppercase tracking-widest transition-colors">
        {label}
      </label>
      <div className={`flex w-full border border-gray-200 dark:border-white/10 rounded-xl p-3.5 bg-white dark:bg-[#1a1b2e] focus-within:border-[#2dd4bf] focus-within:ring-4 focus-within:ring-[#2dd4bf]/5 transition-all ${multiline ? 'items-start' : 'items-center'}`}>
        {prefix && <span className="mr-2 text-gray-500 dark:text-gray-400 font-bold">{prefix}</span>}
        {icon && <div className="mr-3 text-gray-400 dark:text-gray-600">{icon}</div>}
        
        {multiline ? (
            <textarea
                value={value ?? ''}
                readOnly={readOnly}
                onChange={onChange}
                rows={3}
                className={`flex-1 outline-none text-gray-700 dark:text-gray-200 text-sm font-medium bg-transparent resize-none ${readOnly ? 'cursor-not-allowed text-gray-500' : ''}`}
            />
        ) : (
            <input 
                type={type}
                value={value ?? ''}
                readOnly={readOnly}
                disabled={readOnly}
                onChange={onChange}
                className={`flex-1 outline-none text-gray-700 dark:text-gray-200 text-sm font-bold bg-transparent ${readOnly ? 'cursor-not-allowed text-gray-500' : ''}`}
            />
        )}
        
        {readOnly && <Lock size={16} className="text-gray-400 dark:text-gray-600 ml-2" />}
        {!readOnly && rightIcon && <div className="ml-2">{rightIcon}</div>}
      </div>
    </div>
);

interface PermissionToggleProps {
    label: string;
    description?: string;
    icon?: React.ElementType;
    isChecked: boolean;
    onToggle: () => void;
}

const PermissionToggle: React.FC<PermissionToggleProps> = ({ label, description, icon: Icon, isChecked, onToggle }) => (
    <div 
        onClick={onToggle}
        className={`flex items-center justify-between p-5 border rounded-2xl cursor-pointer transition-all duration-300 group ${isChecked ? 'border-[#2dd4bf] bg-teal-50/30 dark:bg-teal-500/5 dark:border-[#2dd4bf]/40' : 'border-gray-100 dark:border-white/5 hover:border-gray-200 dark:hover:border-white/10 bg-white dark:bg-[#1a1b2e]'}`}
    >
        <div className="flex items-center gap-4">
            {Icon && (
                <div className={`p-2.5 rounded-xl transition-colors ${isChecked ? 'bg-[#2dd4bf] text-white' : 'bg-gray-100 dark:bg-white/5 text-gray-400 dark:text-gray-600 group-hover:text-gray-600 dark:group-hover:text-gray-400'}`}>
                    <Icon size={20} />
                </div>
            )}
            <div>
                <span className={`text-sm font-bold block tracking-tight ${isChecked ? 'text-gray-800 dark:text-white' : 'text-gray-500 dark:text-gray-400'}`}>{label}</span>
                {description && <span className="text-[10px] text-gray-400 dark:text-gray-500 font-medium uppercase tracking-widest leading-none">{description}</span>}
            </div>
        </div>
        
        <div className={`w-11 h-6 rounded-full p-1 transition-colors duration-200 ease-in-out flex-shrink-0 ${isChecked ? 'bg-[#2dd4bf]' : 'bg-gray-200 dark:bg-[#23243a]'}`}>
            <div className={`w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform duration-200 ${isChecked ? 'translate-x-5' : 'translate-x-0'}`}></div>
        </div>
    </div>
);

const MENU_PERMISSIONS_MAPPING = [
    { key: 'dashboard', label: 'Dashboard', icon: PieChart, desc: 'Visão geral' },
    { key: 'goals', label: 'Metas', icon: Target, desc: 'Objetivos' },
    { key: 'pos', label: 'Vender (PDV)', icon: CheckCircle2, desc: 'Caixa aberto' },
    { key: 'orders', label: 'Pedidos', icon: ShoppingBag, desc: 'Gestão de vendas' },
    { key: 'products', label: 'Produtos', icon: LayoutGrid, desc: 'Catálogo' },
    { key: 'customers', label: 'Clientes', icon: Users, desc: 'Base de dados' },
    { key: 'subscriptions', label: 'Assinaturas', icon: CalendarCheck, desc: 'Recorrência' },
    { key: 'history', label: 'Histórico', icon: History, desc: 'Registros' },
    { key: 'finance', label: 'Finanças', icon: DollarSign, desc: 'Fluxo de caixa' },
    { key: 'stats', label: 'Estatísticas', icon: BarChart2, desc: 'Inteligência' },
    { key: 'users', label: 'Usuários', icon: User, desc: 'Equipe' },
    { key: 'settings', label: 'Configurações', icon: Settings, desc: 'Ajustes' },
];

interface SettingsScreenProps {
  toggleSidebar?: () => void;
  userProfile: UserProfile;
  onCompanyUpdate?: (name: string) => void;
  onPermissionsUpdate?: () => void; 
}

const SettingsScreen: React.FC<SettingsScreenProps> = ({ toggleSidebar, userProfile, onCompanyUpdate, onPermissionsUpdate }) => {
  const [activeTab, setActiveTab] = useState('GERAL');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const [generalForm, setGeneralForm] = useState<Partial<Company>>({
      name: '',
      social_reason: '',
      cnpj: '',
      description: '',
      phone: '',
      whatsapp: '',
      instagram: '',
      email: '',
      address: '',
      complement: '',
      currency: 'BRL',
      show_decimals: true,
      logo_url: '',
      cancelled_sales_visibility: 'strike'
  });
  
  const [wallets, setWallets] = useState<WalletType[]>([]);
  const [walletAssociations, setWalletAssociations] = useState<Record<string, string | string[]>>({});

  const [opPermissions, setOpPermissions] = useState<OperatorPermissions>({
      dashboard: true, goals: true, pos: true, orders: true, products: true, stock: true,
      customers: true, finance: false, history: true, users: false, settings: false, subscriptions: false, stats: false
  });

  const tabs = [
    'GERAL', 
    'CARTEIRAS',
    'PERMISSÕES'
  ];

  const paymentMethodsList = [
      { id: 'money', label: 'Dinheiro', icon: Banknote, color: 'text-emerald-600', bg: 'bg-emerald-50 dark:bg-emerald-500/10', allowMultiple: false },
      { id: 'pix', label: 'PIX', icon: QrCode, color: 'text-teal-600', bg: 'bg-teal-50 dark:bg-teal-500/10', allowMultiple: true },
      { id: 'debit', label: 'Cartão de Débito', icon: CreditCard, color: 'text-blue-600', bg: 'bg-blue-50 dark:bg-blue-500/10', allowMultiple: true },
      { id: 'credit', label: 'Cartão de Crédito', icon: CreditCard, color: 'text-indigo-600', bg: 'bg-indigo-50 dark:bg-indigo-500/10', allowMultiple: true },
      { id: 'credit_tab', label: 'Venda Fiado', icon: User, color: 'text-amber-600', bg: 'bg-amber-50 dark:bg-amber-500/10', allowMultiple: false },
      { id: 'link', label: 'Link de Pagamento', icon: LinkIcon, color: 'text-purple-600', bg: 'bg-purple-50 dark:bg-purple-500/10', allowMultiple: false },
      { id: 'others', label: 'Outros', icon: ArrowRightLeft, color: 'text-gray-600', bg: 'bg-gray-50 dark:bg-white/5', allowMultiple: false },
  ];

  useEffect(() => {
      const fetchData = async () => {
          if(!userProfile.company_id) return;
          setLoading(true);
          
          try {
              const [compRes, walletRes] = await Promise.all([
                  supabase.from('companies').select('*').eq('id', userProfile.company_id).single(),
                  supabase.from('wallets').select('*').eq('company_id', userProfile.company_id)
              ]);
              
              if (compRes.data) {
                  const compData = compRes.data;
                  setGeneralForm({
                      name: compData.name || '',
                      social_reason: compData.social_reason || '',
                      cnpj: compData.cnpj || '',
                      description: compData.description || '',
                      phone: compData.phone || '',
                      whatsapp: compData.whatsapp || '',
                      instagram: compData.instagram || '',
                      email: compData.email || '',
                      address: compData.address || '',
                      complement: compData.complement || '',
                      currency: compData.currency || 'BRL',
                      show_decimals: compData.show_decimals ?? true,
                      logo_url: compData.logo_url || '',
                      cancelled_sales_visibility: compData.cancelled_sales_visibility || 'strike'
                  });

                  if (compData.wallet_settings) {
                      setWalletAssociations(compData.wallet_settings);
                  }
                  
                  if (compData.permissions && compData.permissions.operator) {
                      setOpPermissions(prev => ({ ...prev, ...compData.permissions!.operator }));
                  }
              }

              if (walletRes.data) {
                  setWallets(walletRes.data);
              }
          } catch(e) {
              console.warn("Failed to load company settings fully", e);
          }

          setLoading(false);
      };
      fetchData();
  }, [userProfile]);

  const maskCpfCnpj = (value: string) => {
    const v = value.replace(/\D/g, '');
    if (v.length <= 11) {
      return v.replace(/(\d{3})(\d)/, '$1.$2')
              .replace(/(\d{3})(\d)/, '$1.$2')
              .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    } else {
      return v.substring(0, 14).replace(/^(\d{2})(\d)/, '$1.$2')
              .replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3')
              .replace(/\.(\d{3})(\d)/, '.$1/$2')
              .replace(/(\d{4})(\d)/, '$1-$2');
    }
  };

  const maskPhone = (value: string) => {
    let v = value.replace(/\D/g, '');
    v = v.substring(0, 11);
    if (v.length > 10) {
       return v.replace(/^(\d\d)(\d{5})(\d{4}).*/, "($1) $2-$3");
    } else if (v.length > 5) {
       return v.replace(/^(\d\d)(\d{4})(\d{0,4}).*/, "($1) $2-$3");
    } else if (v.length > 2) {
       return v.replace(/^(\d\d)(\d{0,5}).*/, "($1) $2");
    } else {
       return v.replace(/^(\d*)/, "($1");
    }
  };

  const handleGeneralChange = (field: keyof Company, value: any) => {
      let finalValue = value;
      if (field === 'cnpj') finalValue = maskCpfCnpj(value);
      if (field === 'phone' || field === 'whatsapp') finalValue = maskPhone(value);
      
      setGeneralForm(prev => ({ ...prev, [field]: finalValue }));

      if (field === 'name' && onCompanyUpdate) {
          onCompanyUpdate(finalValue);
      }
  };

  const handleSaveGeneral = async () => {
      if (!userProfile?.company_id) return;
      setSaving(true);
      setErrorMessage('');

      try {
          const { error } = await supabase
              .from('companies')
              .update(generalForm)
              .eq('id', userProfile.company_id);

          if (error) throw error;
          
          if (onCompanyUpdate && generalForm.name) {
              onCompanyUpdate(generalForm.name);
          }

          setShowToast(true);
      } catch (error: any) {
          console.error(error);
          setErrorMessage("Erro ao salvar dados da empresa.");
      } finally {
          setSaving(false);
      }
  };

  const handleSaveAssociations = async () => {
      if (!userProfile?.company_id) return;
      setSaving(true);
      setErrorMessage('');
      
      try {
          const { error } = await supabase
              .from('companies')
              .update({ wallet_settings: walletAssociations })
              .eq('id', userProfile.company_id);

          if (error) throw error;
          setShowToast(true);
      } catch (error: any) {
          setErrorMessage(error.message || "Erro ao salvar.");
      } finally {
          setSaving(false);
      }
  };

  const handleSavePermissions = async () => {
      if (!userProfile?.company_id) return;
      setSaving(true);
      setErrorMessage('');

      try {
          const permissionsPayload = {
              operator: opPermissions
          };

          const { error } = await supabase
              .from('companies')
              .update({ permissions: permissionsPayload })
              .eq('id', userProfile.company_id);

          if (error) throw error;
          setShowToast(true);
          
          if (onPermissionsUpdate) {
              onPermissionsUpdate();
          }
      } catch (error: any) {
          console.error(error);
          setErrorMessage("Erro ao salvar permissões.");
      } finally {
          setSaving(false);
      }
  };

  const handleAddWalletToMethod = (methodId: string, walletId: string) => {
      if (!walletId) return;
      setWalletAssociations(prev => {
          const current = prev[methodId];
          let newList: string[] = [];
          if (Array.isArray(current)) {
              if (current.includes(walletId)) return prev;
              newList = [...current, walletId];
          } else if (current) {
              if (current === walletId) return prev;
              newList = [current, walletId];
          } else {
              newList = [walletId];
          }
          return { ...prev, [methodId]: newList };
      });
  };

  const handleRemoveWalletFromMethod = (methodId: string, walletId: string) => {
      setWalletAssociations(prev => {
          const current = prev[methodId];
          if (!Array.isArray(current)) {
              return { ...prev, [methodId]: [] };
          }
          return { ...prev, [methodId]: current.filter(id => id !== walletId) };
      });
  };

  const togglePermission = (key: keyof OperatorPermissions) => {
      setOpPermissions(prev => ({
          ...prev,
          [key]: !prev[key]
      }));
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#EEF2F6] dark:bg-[#1a1b2e] relative font-sans transition-colors">
      
      <header className="bg-white dark:bg-[#23243a] h-[90px] px-4 lg:px-10 flex justify-between items-center shrink-0 border-b border-gray-100 dark:border-white/5 sticky top-0 z-50 transition-colors">
          <div className="flex items-center gap-4">
              <button 
                  onClick={() => toggleSidebar?.()} 
                  className="lg:hidden p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-xl transition-colors"
              >
                  <List size={26} />
              </button>
              <div>
                  <h1 className="text-[23px] font-mono font-black text-gray-900 dark:text-white tracking-tighter uppercase leading-none italic">Configurações</h1>
                  <p className="text-[10px] text-gray-400 font-black uppercase tracking-[0.3em] mt-1 hidden sm:block">Ajustes da Empresa e Permissões de Acesso</p>
              </div>
          </div>
          <div className="flex items-center gap-4">
              <button className="hidden sm:flex items-center gap-1.5 text-xs font-bold text-gray-500 dark:text-gray-400 bg-white dark:bg-white/5 hover:bg-gray-50 dark:hover:bg-white/10 border border-gray-200 dark:border-white/10 px-4 py-2 rounded-full transition-all">
                  <HelpCircle size={14} /> Ajuda
              </button>
              <UserMenu />
          </div>
      </header>

      <div className="px-6 py-4 overflow-x-auto bg-white/50 dark:bg-[#23243a]/50 border-b border-gray-100 dark:border-white/5 transition-colors">
        <div className="flex gap-2 min-w-max">
            {tabs.map(tab => (
                <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-8 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                        activeTab === tab 
                        ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20 dark:shadow-none' 
                        : 'bg-gray-200 dark:bg-white/5 text-gray-500 dark:text-gray-400 hover:bg-gray-300 dark:hover:bg-white/10'
                    }`}
                >
                    {tab}
                </button>
            ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-8 custom-scrollbar">
        
        {loading ? (
             <div className="flex flex-col items-center justify-center h-64 text-gray-400 dark:text-gray-600 gap-4">
                 <Loader2 className="animate-spin" size={32} /> 
                 <p className="text-[10px] font-black uppercase tracking-widest">Carregando dados da empresa...</p>
             </div>
        ) : (
            <div className="max-w-7xl mx-auto pb-20">
                {activeTab === 'GERAL' && (
                    <div className="animate-in fade-in slide-in-from-bottom-2 duration-500 space-y-10">
                        <div className="flex flex-col items-center mb-4">
                            <div className="w-16 h-16 bg-white dark:bg-[#23243a] rounded-2xl shadow-sm border border-gray-200 dark:border-white/10 flex items-center justify-center mb-3 transition-colors">
                                <Store size={32} className="text-indigo-600 dark:text-indigo-400" />
                            </div>
                            <h3 className="text-gray-800 dark:text-white font-bold text-lg uppercase tracking-tight">Informações gerais</h3>
                            <p className="text-gray-500 dark:text-gray-500 text-xs font-medium uppercase tracking-widest">Configure os dados do seu negócio</p>
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                            <div className="lg:col-span-8 space-y-8">
                                <div className="bg-white dark:bg-[#23243a] p-8 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-white/5 transition-colors">
                                    <h4 className="text-gray-800 dark:text-white font-black text-[10px] uppercase tracking-[0.2em] mb-8 border-b border-gray-50 dark:border-white/5 pb-4 transition-colors">Identificação Corporativa</h4>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div className="md:col-span-2">
                                            <FloatingInput 
                                                label="Nome da Loja" 
                                                value={generalForm.name} 
                                                onChange={(e: any) => handleGeneralChange('name', e.target.value)}
                                            />
                                        </div>
                                        <FloatingInput 
                                            label="Razão Social" 
                                            value={generalForm.social_reason} 
                                            onChange={(e: any) => handleGeneralChange('social_reason', e.target.value)}
                                        />
                                        <FloatingInput 
                                            label="CPF ou CNPJ" 
                                            value={generalForm.cnpj} 
                                            onChange={(e: any) => handleGeneralChange('cnpj', e.target.value)}
                                        />
                                    </div>
                                </div>

                                <div className="bg-white dark:bg-[#23243a] p-8 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-white/5 transition-colors">
                                    <h4 className="text-gray-800 dark:text-white font-black text-[10px] uppercase tracking-[0.2em] mb-8 border-b border-gray-50 dark:border-white/5 pb-4 transition-colors">Canais de Atendimento</h4>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <FloatingInput 
                                            label="Telefone Comercial" 
                                            value={generalForm.phone} 
                                            prefix={<div className="flex items-center gap-1 border-r border-gray-200 dark:border-white/10 pr-2 mr-0"><img src="https://flagcdn.com/w20/br.png" width="16" alt="BR"/></div>}
                                            onChange={(e: any) => handleGeneralChange('phone', e.target.value)}
                                            icon={<Phone size={16}/>}
                                        />
                                        <FloatingInput 
                                            label="WhatsApp" 
                                            value={generalForm.whatsapp} 
                                            prefix={<div className="flex items-center gap-1 border-r border-gray-200 dark:border-white/10 pr-2 mr-0"><img src="https://flagcdn.com/w20/br.png" width="16" alt="BR"/></div>}
                                            onChange={(e: any) => handleGeneralChange('whatsapp', e.target.value)}
                                            icon={<MessageSquare size={16}/>}
                                        />
                                        <FloatingInput 
                                            label="Perfil Instagram" 
                                            value={generalForm.instagram} 
                                            prefix="@"
                                            onChange={(e: any) => handleGeneralChange('instagram', e.target.value)}
                                            icon={<Instagram size={16}/>}
                                        />
                                        <FloatingInput 
                                            label="E-mail" 
                                            value={generalForm.email} 
                                            type="email"
                                            onChange={(e: any) => handleGeneralChange('email', e.target.value)}
                                            icon={<Mail size={16}/>}
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="lg:col-span-4 space-y-8">
                                <div className="bg-white dark:bg-[#23243a] p-8 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-white/5 flex flex-col items-center justify-center transition-colors">
                                    <h4 className="text-gray-800 dark:text-white font-black text-[10px] uppercase tracking-[0.2em] mb-8 self-start border-b border-gray-50 dark:border-white/5 pb-4 w-full text-left transition-colors">Logomarca</h4>
                                    {generalForm.logo_url ? (
                                        <div className="bg-white p-4 rounded-3xl mb-6 shadow-inner border border-gray-100">
                                            {generalForm.logo_url && (
                                                <img src={generalForm.logo_url} alt="Logo" className="max-h-24 object-contain" />
                                            )}
                                        </div>
                                    ) : (
                                        <div className="w-full h-32 bg-gray-50 dark:bg-[#1a1b2e] rounded-[2rem] flex items-center justify-center mb-6 text-gray-300 dark:text-gray-700 border-2 border-dashed border-gray-200 dark:border-white/10 transition-colors">
                                            <ImageIcon size={48} />
                                        </div>
                                    )}
                                    <input 
                                        type="text"
                                        className="w-full border border-gray-200 dark:border-white/10 rounded-xl p-4 text-[10px] font-bold outline-none focus:border-indigo-500 bg-gray-50 dark:bg-[#1a1b2e] dark:text-white transition-all uppercase"
                                        placeholder="URL da Logomarca"
                                        value={generalForm.logo_url}
                                        onChange={(e) => handleGeneralChange('logo_url', e.target.value)}
                                    />
                                </div>

                                <div className="sticky bottom-4 z-10 pt-4">
                                    <button 
                                        onClick={handleSaveGeneral}
                                        disabled={saving}
                                        className="w-full bg-[#2dd4bf] hover:bg-[#14b8a6] text-white dark:text-[#1a1b2e] font-black py-5 px-10 rounded-[1.8rem] shadow-xl shadow-teal-500/20 dark:shadow-none flex items-center justify-center gap-3 transition-all transform hover:scale-[1.02] active:scale-95 text-xs uppercase tracking-widest"
                                    >
                                        {saving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                                        Salvar Configurações
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {activeTab === 'CARTEIRAS' && (
                    <div className="max-w-5xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-10">
                        <div className="flex flex-col items-center mb-4 text-center">
                            <div className="w-16 h-16 bg-white dark:bg-[#23243a] rounded-2xl shadow-sm border border-gray-200 dark:border-white/10 flex items-center justify-center mb-3 transition-colors">
                                <Wallet size={32} className="text-indigo-600 dark:text-indigo-400" />
                            </div>
                            <h3 className="text-gray-800 dark:text-white font-bold text-lg uppercase tracking-tight">Contas por Forma de Pagamento</h3>
                            <p className="text-gray-500 dark:text-gray-500 text-xs font-medium uppercase tracking-widest max-w-lg mt-2">
                                Escolha uma ou mais carteiras para cada meio de recebimento. <br/>
                                <span className="text-indigo-500 font-black italic">A primeira selecionada será a conta principal no PDV.</span>
                            </p>
                        </div>

                        {wallets.length === 0 ? (
                            <div className="bg-white dark:bg-[#23243a] p-12 rounded-[3rem] shadow-sm border border-gray-200 dark:border-white/5 text-center transition-colors">
                                <AlertCircle size={48} className="mx-auto text-amber-400 mb-6" />
                                <h3 className="text-gray-800 dark:text-white font-black text-xl mb-3">Nenhuma carteira configurada</h3>
                                <p className="text-gray-500 dark:text-gray-400 text-sm">Crie suas carteiras em Finanças &gt; Carteiras primeiro.</p>
                            </div>
                        ) : (
                            <div className="bg-white dark:bg-[#23243a] rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-white/5 overflow-hidden transition-colors">
                                <div className="divide-y divide-gray-50 dark:divide-white/5">
                                    {paymentMethodsList.map((method) => {
                                        const currentAssoc = walletAssociations[method.id];
                                        const assocList = Array.isArray(currentAssoc) ? currentAssoc : (currentAssoc ? [currentAssoc] : []);

                                        return (
                                            <div key={method.id} className="p-8 space-y-6">
                                                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                                                    <div className="flex items-center gap-5">
                                                        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${method.bg} ${method.color} shadow-sm`}>
                                                            <method.icon size={26} />
                                                        </div>
                                                        <div>
                                                            <p className="text-sm font-black text-gray-800 dark:text-white uppercase tracking-tighter">{method.label}</p>
                                                            <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Contas associadas: {assocList.length}</p>
                                                        </div>
                                                    </div>

                                                    <div className="w-full sm:w-72 relative">
                                                        <select
                                                            onChange={(e) => handleAddWalletToMethod(method.id, e.target.value)}
                                                            className="w-full appearance-none bg-gray-50 dark:bg-[#1a1b2e] border-2 border-gray-100 dark:border-white/10 rounded-2xl py-3 pl-5 pr-12 text-[10px] font-black text-gray-400 outline-none focus:border-indigo-500 transition-all cursor-pointer uppercase"
                                                        >
                                                            <option value="">{method.allowMultiple ? '+ Adicionar Conta' : 'Selecionar Conta'}</option>
                                                            {wallets.map(wallet => (
                                                                <option key={wallet.id} value={wallet.id} disabled={assocList.includes(wallet.id)}>
                                                                    {wallet.name.toUpperCase()}
                                                                </option>
                                                            ))}
                                                        </select>
                                                        <ChevronDown size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300 pointer-events-none" />
                                                    </div>
                                                </div>

                                                <div className="flex flex-wrap gap-3">
                                                    {assocList.length === 0 ? (
                                                        <p className="text-[10px] font-bold text-gray-300 dark:text-gray-700 italic uppercase">Nenhuma conta vinculada.</p>
                                                    ) : (
                                                        assocList.map((wId, index) => {
                                                            const wallet = wallets.find(w => w.id === wId);
                                                            if (!wallet) return null;
                                                            const isPrimary = index === 0;
                                                            return (
                                                                <div key={wId} className={`flex items-center gap-3 px-4 py-2 rounded-xl border-2 transition-all group ${isPrimary ? 'bg-indigo-50 border-indigo-200 text-indigo-700 dark:bg-indigo-500/10 dark:border-indigo-500/30 dark:text-indigo-400' : 'bg-white dark:bg-white/5 border-gray-100 dark:border-white/5 text-gray-500'}`}>
                                                                    {isPrimary && <Star size={12} fill="currentColor" />}
                                                                    <span className="text-[10px] font-black uppercase tracking-tight">{wallet.name}</span>
                                                                    {isPrimary && <span className="text-[8px] font-black bg-indigo-600 text-white px-1.5 py-0.5 rounded leading-none">PRINCIPAL</span>}
                                                                    <button 
                                                                        onClick={() => handleRemoveWalletFromMethod(method.id, wId)}
                                                                        className="ml-1 p-1 hover:bg-rose-50 dark:hover:bg-rose-500/10 text-gray-300 hover:text-rose-500 rounded-md transition-colors"
                                                                    >
                                                                        <X size={14} />
                                                                    </button>
                                                                </div>
                                                            );
                                                        })
                                                    )}
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>

                                <div className="p-8 bg-gray-50/50 dark:bg-white/5 border-t border-gray-100 dark:border-white/5 flex justify-end transition-colors">
                                    <button 
                                        onClick={handleSaveAssociations}
                                        disabled={saving}
                                        className="bg-indigo-600 hover:bg-indigo-700 text-white font-black py-4 px-12 rounded-2xl shadow-xl transition-all text-xs uppercase tracking-widest active:scale-95 flex items-center gap-3"
                                    >
                                        {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                                        Salvar Associações
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                )}

                {activeTab === 'PERMISSÕES' && (
                    <div className="max-w-6xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-10">
                        <div className="flex flex-col items-center mb-4 text-center">
                            <div className="w-16 h-16 bg-white dark:bg-[#23243a] rounded-2xl shadow-sm border border-gray-200 dark:border-white/10 flex items-center justify-center mb-3 transition-colors">
                                <Shield size={32} className="text-indigo-600 dark:text-indigo-400" />
                            </div>
                            <h3 className="text-gray-800 dark:text-white font-bold text-lg uppercase tracking-tight">Privilégios do Operador</h3>
                            <p className="text-gray-500 dark:text-gray-500 text-xs font-medium uppercase tracking-widest max-w-lg mt-2">Defina os acessos para colaboradores de nível operacional.</p>
                        </div>

                        <div className="bg-white dark:bg-[#23243a] rounded-[3rem] shadow-sm border border-gray-100 dark:border-white/5 overflow-hidden transition-colors">
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 p-8">
                                {MENU_PERMISSIONS_MAPPING.map(item => (
                                    <PermissionToggle 
                                        key={item.key}
                                        label={item.label}
                                        description={item.desc}
                                        icon={item.icon}
                                        isChecked={opPermissions[item.key as keyof OperatorPermissions]}
                                        onToggle={() => togglePermission(item.key as keyof OperatorPermissions)} 
                                    />
                                ))}
                            </div>
                            <div className="p-8 bg-gray-50/50 dark:bg-white/5 border-t border-gray-100 dark:border-white/5 flex justify-end transition-colors">
                                <button onClick={handleSavePermissions} disabled={saving} className="bg-indigo-600 hover:bg-indigo-700 text-white font-black py-4 px-12 rounded-2xl shadow-xl transition-all text-xs uppercase tracking-widest active:scale-95">
                                    {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />} Salvar Permissões
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        )}

      </div>
      <Toast message="Alterações aplicadas com sucesso!" isVisible={showToast} onClose={() => setShowToast(false)} />
    </div>
  );
};

export default SettingsScreen;