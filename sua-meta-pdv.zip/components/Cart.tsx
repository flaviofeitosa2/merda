
import React, { useState, useMemo, useEffect } from 'react';
import { 
  X, 
  Trash2, 
  Minus, 
  Plus, 
  ShoppingCart, 
  User, 
  ChevronRight, 
  Edit2, 
  Search,
  UserPlus,
  Loader2,
  Check,
  ArrowLeft,
  CalendarCheck,
  AlertCircle,
  Hash,
  MoreHorizontal,
  PlusCircle,
  CalendarDays,
  ChevronDown,
  AlertOctagon,
  CheckCircle2,
  Tag,
  Building2
} from 'lucide-react';
import { CartItem, Customer, Product, Subscription } from '../types';
import DiscountModal from './DiscountModal';
import { supabase } from '../supabaseClient';

interface CartProps {
  items: CartItem[];
  updateQuantity: (id: string, delta: number) => void;
  setQuantity: (id: string, quantity: number) => void;
  removeFromCart: (id: string) => void;
  clearCart: () => void;
  isOpen: boolean;
  onClose: () => void;
  onCheckout: () => void;
  customers: Customer[];
  selectedCustomer: Customer | null;
  onSelectCustomer: (customer: Customer | null) => void;
  discount: number;
  onApplyDiscount: (discount: number) => void;
  addToCart: (product: Product, meta?: any) => void;
  allProducts: Product[];
  onRegisterCustomer: (customer: Customer) => Promise<Customer | null>;
  portalUserIds: Set<string>;
}

const Cart: React.FC<CartProps> = ({
  items,
  updateQuantity,
  setQuantity,
  removeFromCart,
  clearCart,
  isOpen,
  onClose,
  onCheckout,
  customers,
  selectedCustomer,
  onSelectCustomer,
  discount,
  onApplyDiscount,
  addToCart,
  onRegisterCustomer,
  portalUserIds
}) => {
  const [isDiscountModalOpen, setIsDiscountModalOpen] = useState(false);
  const [isCustomerDrawerOpen, setIsCustomerDrawerOpen] = useState(false);
  const [drawerSearch, setDrawerSearch] = useState('');
  const [activeSubscription, setActiveSubscription] = useState<Subscription | null>(null);
  const [loadingSub, setLoadingSub] = useState(false);

  // Busca robusta de assinatura pendente
  useEffect(() => {
    const fetchSubscription = async () => {
      if (!selectedCustomer?.id) {
        setActiveSubscription(null);
        return;
      }
      
      setLoadingSub(true);
      try {
        const { data, error } = await supabase
          .from('subscriptions')
          .select('*')
          .eq('customer_id', selectedCustomer.id)
          .is('payment_date', null)
          .order('end_date', { ascending: true })
          .limit(1);
        
        if (!error && data && data.length > 0) {
            setActiveSubscription(data[0]);
        } else {
            setActiveSubscription(null);
        }
      } catch (err) {
        console.error("Erro PDV ao buscar plano:", err);
      } finally {
        setLoadingSub(false);
      }
    };
    
    fetchSubscription();
  }, [selectedCustomer?.id]);

  const subtotal = items.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const total = Math.max(0, subtotal - discount);
  const totalItemsCount = items.reduce((acc, i) => acc + i.quantity, 0);

  const isSubAlreadyInCart = activeSubscription && items.some(i => i.subscriptionReconciliationId === activeSubscription.id);

  const handleAddSubscriptionToCart = () => {
      if (!activeSubscription || isSubAlreadyInCart) return;

      const subProduct: Product = {
          id: `SUB_REC_${activeSubscription.id}`,
          code: 'RENOVAÇÃO',
          name: `MENSALIDADE: ${activeSubscription.provider.toUpperCase()}`,
          price: activeSubscription.value || 0,
          category: 'Assinaturas',
          image: 'https://cdn-icons-png.flaticon.com/512/9644/9644171.png',
          manage_stock: false
      };

      addToCart(subProduct, { 
          subscriptionReconciliationId: activeSubscription.id,
          quantity: 1 
      });
  };

  const filteredCustomers = useMemo(() => {
    const query = drawerSearch.toLowerCase().trim();
    const queryNumbers = query.replace(/\D/g, '');

    const filtered = customers.filter(c => {
      // Busca por Nome
      const matchName = (c.name || '').toLowerCase().includes(query);
      // Busca por Razão Social
      const matchSocial = (c.socialReason || '').toLowerCase().includes(query);
      // Busca por Nome Fantasia
      const matchFantasy = (c.fantasyName || '').toLowerCase().includes(query);
      
      // Busca por CPF/CNPJ (compara apenas os números se a query tiver números)
      const cCpfNumbers = (c.cpf || '').replace(/\D/g, '');
      const cCnpjNumbers = (c.cnpj || '').replace(/\D/g, '');
      const matchDoc = queryNumbers !== '' && (cCpfNumbers.includes(queryNumbers) || cCnpjNumbers.includes(queryNumbers));

      // Busca por Telefone
      const matchPhone = queryNumbers !== '' && (c.phone || '').replace(/\D/g, '').includes(queryNumbers);

      return matchName || matchSocial || matchFantasy || matchDoc || matchPhone;
    });

    const uniqueMap = new Map<string, Customer>();
    filtered.forEach(c => {
        const doc = (c.cpf || c.cnpj || '').replace(/\D/g, '');
        const key = `${c.name.trim().toLowerCase()}-${doc}`;
        const existing = uniqueMap.get(key);
        if (!existing || (c.isSubscriber && !existing.isSubscriber)) {
            uniqueMap.set(key, c);
        }
    });

    return Array.from(uniqueMap.values());
  }, [customers, drawerSearch]);

  const handleManualQuantityChange = (id: string, val: string) => {
    const num = parseInt(val);
    if (!isNaN(num)) {
        setQuantity(id, num);
    } else if (val === '') {
        setQuantity(id, 0);
    }
  };

  return (
    <>
      <div className={`fixed inset-0 bg-black/50 z-[40] transition-opacity backdrop-blur-[1px] lg:hidden ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={onClose} />
      
      <div className={`fixed inset-y-0 right-0 w-full max-w-md bg-white dark:bg-[#23243a] shadow-2xl z-[50] transform transition-transform duration-300 flex flex-col lg:static lg:translate-x-0 lg:w-[400px] lg:border-l lg:border-gray-200 lg:dark:border-white/5 lg:shadow-none transition-colors ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        
        {/* HEADER */}
        <div className="px-6 py-5 border-b border-gray-100 dark:border-white/10 flex justify-between items-center bg-white dark:bg-[#23243a] z-10 transition-colors">
          <div className="flex items-center gap-3">
            <button onClick={onClose} className="p-1 text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-white/5 rounded-lg lg:hidden">
              <ArrowLeft size={24} />
            </button>
            <h2 className="text-xl font-black text-gray-700 dark:text-white uppercase tracking-tighter italic">CARRINHO</h2>
          </div>
          
          <button onClick={() => setIsCustomerDrawerOpen(true)} className="p-2 text-[#2dd4bf] hover:bg-teal-50 dark:hover:bg-teal-500/10 rounded-full transition-colors relative">
            <UserPlus size={26} />
            {selectedCustomer && <div className="absolute top-0 right-0 w-3 h-3 bg-[#2dd4bf] border-2 border-white dark:border-[#23243a] rounded-full"></div>}
          </button>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar">
            {/* AREA DO CLIENTE SELECIONADO */}
            {selectedCustomer && (
                <div className="px-6 py-5 bg-white dark:bg-[#1a1b2e]/30 border-b border-gray-100 dark:border-white/5 transition-colors">
                    <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-xl bg-[#2ebc7d] flex items-center justify-center text-white font-bold text-sm shadow-sm uppercase">
                                {selectedCustomer.avatarText || selectedCustomer.name.substring(0, 2)}
                            </div>
                            <div className="min-w-0">
                                <p className="text-sm font-black text-gray-800 dark:text-white truncate uppercase tracking-tighter leading-none mb-1 flex items-center gap-2">
                                  {selectedCustomer.name}
                                  {portalUserIds.has(selectedCustomer.id) && (
                                    <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.6)]" title="Cadastro Habilitado no Portal" />
                                  )}
                                </p>
                                <p className="text-[10px] text-gray-400 dark:text-gray-500 font-bold uppercase tracking-widest">{selectedCustomer.cpf || selectedCustomer.cnpj || 'Consumidor'}</p>
                            </div>
                        </div>
                        <button onClick={() => onSelectCustomer(null)} className="text-[10px] text-rose-500 font-black uppercase tracking-widest hover:underline transition-all">Alterar</button>
                    </div>

                    {loadingSub ? (
                        <div className="flex items-center gap-2 py-2">
                            <Loader2 size={14} className="animate-spin text-teal-400" />
                            <span className="text-[10px] font-black text-teal-400 uppercase tracking-widest">Sincronizando faturas...</span>
                        </div>
                    ) : activeSubscription ? (
                        <div className={`mt-2 p-4 rounded-2xl border-2 flex items-center justify-between transition-all animate-in zoom-in-95 duration-300 ${isSubAlreadyInCart ? 'bg-emerald-50 dark:bg-emerald-500/10 border-emerald-500/20 dark:border-emerald-500/30' : 'bg-white dark:bg-[#1a1b2e] border-indigo-500/20 dark:border-indigo-500/40 shadow-xl shadow-indigo-500/5'}`}>
                            <div className="flex items-center gap-3">
                                <div className={`p-2.5 rounded-xl ${isSubAlreadyInCart ? 'bg-emerald-500 text-white' : 'bg-indigo-600 text-white shadow-md shadow-indigo-200 dark:shadow-none'}`}>
                                    <CalendarDays size={20} strokeWidth={2.5} />
                                </div>
                                <div className="min-w-0">
                                    <p className={`text-[9px] font-black uppercase tracking-widest ${isSubAlreadyInCart ? 'text-emerald-600 dark:text-emerald-400' : 'text-indigo-500 dark:text-indigo-400'}`}>
                                        {isSubAlreadyInCart ? 'MENSALIDADE NO CARRINHO' : 'MENSALIDADE PENDENTE'}
                                    </p>
                                    <p className="text-xs font-bold text-gray-700 dark:text-gray-300 uppercase truncate max-w-[150px]">
                                        {activeSubscription.provider} ({activeSubscription.value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })})
                                    </p>
                                </div>
                            </div>

                            {!isSubAlreadyInCart && (
                                <button 
                                    onClick={handleAddSubscriptionToCart}
                                    className="bg-indigo-600 text-white px-4 py-2.5 rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 dark:shadow-none flex items-center gap-1.5 animate-pulse"
                                >
                                    <span className="text-[10px] font-black uppercase tracking-tighter">Lançar</span>
                                    <PlusCircle size={14} strokeWidth={3} />
                                </button>
                            )}

                            {isSubAlreadyInCart && (
                                <div className="p-2 bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-lg border border-emerald-200 dark:border-emerald-500/30">
                                    <Check size={18} strokeWidth={4} />
                                </div>
                            )}
                        </div>
                    ) : selectedCustomer.isSubscriber ? (
                        <div className="mt-2 p-3 bg-slate-50 dark:bg-white/5 rounded-xl border border-slate-200 dark:border-white/5 flex items-center gap-3 transition-colors">
                             <CheckCircle2 size={18} className="text-emerald-500" />
                             <p className="text-[9px] font-black text-slate-500 dark:text-gray-400 uppercase tracking-widest leading-tight">Assinatura em dia para este período.</p>
                        </div>
                    ) : null}
                </div>
            )}

            {/* LISTA DE PRODUTOS */}
            <div className="px-6 py-4">
                {items.length === 0 ? (
                    <div className="text-center py-20 flex flex-col items-center animate-in fade-in duration-700">
                        <ShoppingCart size={84} strokeWidth={1} className="mb-4 text-gray-200 dark:text-white/20" />
                        <p className="text-sm font-black uppercase tracking-[0.2em] text-gray-300 dark:text-white/40">CARRINHO VAZIO</p>
                    </div>
                ) : (
                    <div className="divide-y divide-gray-100 dark:divide-white/5">
                        {items.map((item) => (
                            <div key={item.id} className="py-4 flex items-start gap-4 group">
                                <div className="flex flex-col items-center gap-1 shrink-0">
                                    <input 
                                        type="number"
                                        min="1"
                                        className={`w-12 text-center bg-gray-50 dark:bg-[#1a1b2e] border border-gray-100 dark:border-white/10 rounded-lg py-1.5 text-sm font-black outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 dark:focus:ring-indigo-500/10 transition-all ${item.subscriptionReconciliationId ? 'text-indigo-600 dark:text-indigo-400' : 'text-gray-700 dark:text-white'}`}
                                        value={item.quantity}
                                        onChange={(e) => handleManualQuantityChange(item.id, e.target.value)}
                                        disabled={!!item.subscriptionReconciliationId}
                                    />
                                    <span className="text-[8px] font-black text-gray-400 dark:text-gray-500 uppercase tracking-tighter">UNID</span>
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex justify-between items-start">
                                        <div className="min-w-0 pr-2">
                                            <h4 className={`font-bold text-sm uppercase tracking-tight leading-tight truncate ${item.subscriptionReconciliationId ? 'text-indigo-600 dark:text-indigo-400' : 'text-gray-800 dark:text-gray-100'}`}>
                                                {item.name}
                                                {item.subscriptionReconciliationId && (
                                                    <span className="block text-[8px] font-black text-indigo-400 dark:text-indigo-500 mt-1 uppercase tracking-widest">BAIXA NO CONTRATO</span>
                                                )}
                                            </h4>
                                            <p className="text-[11px] text-gray-400 dark:text-gray-500 font-bold mt-0.5">{item.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
                                        </div>
                                        <p className="font-black text-gray-700 dark:text-white text-sm shrink-0">{(item.price * item.quantity).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
                                    </div>
                                    <div className="flex items-center gap-3 mt-3">
                                        {!item.subscriptionReconciliationId && (
                                            <>
                                                <button onClick={() => updateQuantity(item.id, -1)} className="p-1.5 text-gray-400 dark:text-gray-500 hover:text-rose-500 dark:hover:text-rose-400 bg-gray-50 dark:bg-white/5 rounded-md transition-colors"><Minus size={14} /></button>
                                                <button onClick={() => updateQuantity(item.id, 1)} className="p-1.5 text-gray-400 dark:text-gray-500 hover:text-teal-500 dark:hover:text-[#2dd4bf] bg-gray-50 dark:bg-white/5 rounded-md transition-colors"><Plus size={14} /></button>
                                                <div className="w-px h-3 bg-gray-200 dark:bg-white/10"></div>
                                            </>
                                        )}
                                        <button onClick={() => removeFromCart(item.id)} className="text-[10px] font-black text-gray-400 dark:text-gray-500 hover:text-rose-500 dark:hover:text-rose-400 uppercase tracking-widest transition-colors">REMOVER</button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>

        <div className="px-6 py-6 bg-white dark:bg-[#23243a] border-t border-gray-100 dark:border-white/10 transition-colors">
            
            <div className="flex flex-col gap-2 mb-4">
                <div className="flex justify-between items-center text-[10px] font-black text-gray-400 uppercase tracking-widest px-1">
                    <span>Subtotal</span>
                    <span>{subtotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                </div>
                
                {discount > 0 && (
                    <div className="flex justify-between items-center text-[10px] font-black text-rose-500 uppercase tracking-widest px-1">
                        <span>Desconto Aplicado</span>
                        <span>- {discount.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                    </div>
                )}

                <div className="flex justify-between items-center pt-2">
                    <button 
                        onClick={() => setIsDiscountModalOpen(true)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all border ${discount > 0 ? 'bg-rose-50 border-rose-200 text-rose-600 dark:bg-rose-500/10 dark:border-rose-500/20 dark:text-rose-400' : 'bg-gray-50 border-gray-200 text-gray-500 dark:bg-white/5 dark:border-white/10 dark:text-gray-400 hover:bg-gray-100'}`}
                    >
                        <Tag size={12} strokeWidth={3} />
                        {discount > 0 ? 'Alterar Desconto' : 'Aplicar Desconto'}
                    </button>
                    <p className="text-xl font-black text-gray-800 dark:text-white uppercase tracking-tighter transition-colors">TOTAL: {total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
                </div>
            </div>

            <div className="flex gap-3">
                <button onClick={clearCart} className="w-16 h-16 bg-gray-50 dark:bg-white/5 flex items-center justify-center rounded-2xl text-gray-300 dark:text-gray-600 hover:text-rose-500 dark:hover:text-rose-400 transition-all border border-gray-100 dark:border-white/5" title="Limpar Tudo"><Trash2 size={24} /></button>
                <button 
                  onClick={onCheckout} 
                  disabled={items.length === 0} 
                  className={`flex-1 h-16 rounded-2xl font-bold text-base flex items-center justify-between px-8 transition-all shadow-lg active:scale-[0.98] ${items.length === 0 ? 'bg-gray-100 dark:bg-white/5 text-gray-300 dark:text-gray-700' : 'bg-[#2dd4bf] text-white shadow-teal-500/20 hover:brightness-105'}`}
                >
                    <span className="uppercase">{totalItemsCount} ITENS</span>
                    <ChevronRight size={24} strokeWidth={4} />
                </button>
            </div>
        </div>
      </div>

      {/* GAVETA DE CLIENTES */}
      {isCustomerDrawerOpen && (
        <>
          <div className="fixed inset-0 bg-black/40 z-[100] backdrop-blur-[2px] transition-opacity" onClick={() => setIsCustomerDrawerOpen(false)} />
          <div className="fixed inset-y-0 right-0 w-full max-w-md bg-white dark:bg-[#23243a] shadow-2xl z-[110] flex flex-col animate-in slide-in-from-right duration-300 border-l dark:border-white/5">
            <div className="px-6 py-5 border-b border-gray-100 dark:border-white/10 flex items-center gap-4 bg-white dark:bg-[#23243a] sticky top-0 z-10 transition-colors">
                <button onClick={() => setIsCustomerDrawerOpen(false)} className="text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-white"><X size={24} /></button>
                <div className="flex-1 relative group">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-600 group-focus-within:text-[#2dd4bf] transition-colors" size={18} />
                    <input autoFocus type="text" placeholder="Nome, fantasia, razão, CPF ou CNPJ..." className="w-full bg-gray-50 dark:bg-[#1a1b2e] dark:text-white border border-gray-200 dark:border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-sm outline-none focus:border-[#2dd4bf] focus:bg-white dark:focus:bg-[#1a1b2e] transition-all font-bold uppercase text-[10px]" value={drawerSearch} onChange={(e) => setDrawerSearch(e.target.value)} />
                </div>
                <button 
                  onClick={() => {
                    // Aqui precisaríamos abrir o modal de cliente. 
                    // Como o modal está no App.tsx ou CustomersScreen, 
                    // poderíamos emitir um evento ou usar um estado global.
                    // Por enquanto, vamos apenas logar.
                    console.log("Solicitando abertura de cadastro de cliente");
                    // Se onRegisterCustomer for passado, podemos tentar usá-lo se ele abrir um modal
                  }}
                  className="p-2.5 bg-[#2dd4bf] text-white rounded-xl shadow-lg shadow-teal-500/20 hover:brightness-105 transition-all"
                  title="Novo Cliente"
                >
                  <UserPlus size={20} />
                </button>
            </div>
            <div className="flex-1 overflow-y-auto custom-scrollbar">
                {filteredCustomers.length === 0 ? (
                    <div className="p-10 text-center text-gray-400 dark:text-gray-600 italic uppercase text-xs font-bold tracking-widest">Nenhum cliente encontrado.</div>
                ) : (
                    filteredCustomers.map(c => (
                        <button key={c.id} onClick={() => { onSelectCustomer(c); setIsCustomerDrawerOpen(false); }} className="w-full text-left px-6 py-4 hover:bg-teal-50/30 dark:hover:bg-white/5 flex items-center gap-4 border-b border-gray-50 dark:border-white/5 transition-colors group">
                            <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-xs shadow-sm transition-colors shrink-0 ${c.isSubscriber ? 'bg-indigo-100 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-500/30' : 'bg-gray-100 dark:bg-white/5 text-gray-400 dark:text-gray-600'}`}>
                                {c.avatarText || c.name.substring(0,2)}
                            </div>
                            <div className="min-w-0 flex-1">
                                <div className="flex items-center gap-2">
                                    <p className="text-sm font-bold text-gray-800 dark:text-white uppercase truncate group-hover:text-teal-600 dark:group-hover:text-[#2dd4bf] transition-colors flex items-center gap-2">
                                      {c.name}
                                      {portalUserIds.has(c.id) && (
                                        <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_6px_rgba(16,185,129,0.6)]" title="Cadastro Habilitado no Portal" />
                                      )}
                                    </p>
                                    {c.isSubscriber && <CalendarCheck size={14} className="text-indigo-500" />}
                                </div>
                                <div className="flex flex-col gap-0.5 mt-0.5">
                                    {(c.fantasyName || c.socialReason) && (
                                        <p className="text-[9px] text-indigo-500 dark:text-indigo-400 font-bold uppercase truncate flex items-center gap-1">
                                            <Building2 size={10} /> {c.fantasyName || c.socialReason}
                                        </p>
                                    )}
                                    <p className="text-[10px] text-gray-400 dark:text-gray-500 uppercase tracking-widest font-mono">{c.cpf || c.cnpj || 'Consumidor'}</p>
                                </div>
                            </div>
                            <ChevronRight size={16} className="text-gray-300 dark:text-gray-700 group-hover:text-teal-400 dark:group-hover:text-[#2dd4bf] transition-transform group-hover:translate-x-1" />
                        </button>
                    ))
                )}
            </div>
          </div>
        </>
      )}

      <DiscountModal 
        isOpen={isDiscountModalOpen} 
        onClose={() => setIsDiscountModalOpen(false)} 
        onApply={onApplyDiscount} 
        subtotal={subtotal} 
        initialDiscount={discount} 
      />
    </>
  );
};

export default Cart;
