
import React, { useState, useEffect } from 'react';
import { Brain, Sparkles, TrendingUp, AlertCircle, RefreshCcw, CheckCircle } from 'lucide-react';
import { analyzeSalesPerformance } from '../aiService';
import { Sale, Product, FinanceTransaction, Company } from '../types';
import { motion, AnimatePresence } from 'framer-motion';

interface AISalesIntelligenceProps {
  sales: Sale[];
  products: Product[];
  transactions: FinanceTransaction[];
  companyData: Company | null;
}

const AISalesIntelligence: React.FC<AISalesIntelligenceProps> = ({ sales, products, transactions, companyData }) => {
  const [insights, setInsights] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchInsights = async () => {
    if (!companyData) return;
    setLoading(true);
    setError(null);
    try {
      const result = await analyzeSalesPerformance(sales, products, transactions, companyData.name);
      setInsights(result || "");
    } catch (err) {
      setError("Não foi possível gerar os insights agora.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (sales.length > 0 && !insights && !loading) {
      fetchInsights();
    }
  }, [sales.length]);

  return (
    <div className="p-4 sm:p-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
            <Brain className="text-indigo-600" size={32} />
            IA de Inteligência de Vendas
          </h1>
          <p className="text-slate-500 font-medium mt-1">Insights estratégicos baseados em dados reais do seu negócio.</p>
        </div>
        <button 
          onClick={fetchInsights}
          disabled={loading}
          className="flex items-center justify-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-2xl font-bold transition-all hover:bg-indigo-700 active:scale-95 disabled:opacity-50"
        >
          {loading ? <RefreshCcw className="animate-spin" size={18} /> : <Sparkles size={18} />}
          {loading ? 'Analisando...' : 'Atualizar Insights'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <AnimatePresence mode="wait">
            {loading ? (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-white rounded-[2.5rem] p-12 border border-slate-100 flex flex-col items-center justify-center min-h-[400px] text-center"
              >
                <div className="relative mb-6">
                  <div className="absolute inset-0 bg-indigo-100 rounded-full blur-2xl animate-pulse"></div>
                  <Brain className="text-indigo-600 relative animate-bounce" size={64} />
                </div>
                <h3 className="text-xl font-bold text-slate-800">Processando seus dados...</h3>
                <p className="text-slate-500 max-w-xs mt-2">Nossa IA está analisando padrões nas suas vendas para encontrar as melhores oportunidades para você.</p>
              </motion.div>
            ) : insights ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white rounded-[2.5rem] p-8 sm:p-10 border border-slate-100 shadow-xl shadow-indigo-500/5 relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 p-8 opacity-5">
                   <Sparkles size={120} className="text-indigo-600" />
                </div>
                
                <h3 className="text-xl font-black text-slate-900 mb-6 flex items-center gap-2">
                  <TrendingUp className="text-emerald-500" size={24} />
                  Diagnóstico IA
                </h3>
                
                <div className="prose prose-slate max-w-none">
                  <div className="whitespace-pre-wrap text-slate-700 leading-relaxed font-medium text-lg">
                    {insights}
                  </div>
                </div>

                <div className="mt-10 p-6 bg-slate-50 rounded-2xl border border-slate-100">
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest leading-none mb-2">Monitoramento de Custo</p>
                  <div className="flex items-center gap-2 text-emerald-600 font-bold text-sm">
                    <CheckCircle className="shrink-0" size={16} />
                    <span>Processado via Gemini Flash-8B (Otimizado para economia)</span>
                  </div>
                </div>
              </motion.div>
            ) : error ? (
              <div className="bg-rose-50 rounded-[2.5rem] p-10 border border-rose-100 text-center">
                <AlertCircle className="text-rose-500 mx-auto mb-4" size={48} />
                <h3 className="text-xl font-bold text-slate-800">Ocorreu um erro</h3>
                <p className="text-slate-500 mt-2">{error}</p>
                <button 
                  onClick={fetchInsights}
                  className="mt-6 px-6 py-2 bg-rose-500 text-white rounded-xl font-bold"
                >
                  Tentar Novamente
                </button>
              </div>
            ) : (
              <div className="bg-slate-50 rounded-[2.5rem] p-20 border border-slate-100 border-dashed text-center">
                <Brain className="text-slate-300 mx-auto mb-4" size={64} />
                <p className="text-slate-500 font-medium tracking-tight">Sem dados suficientes para análise no momento.</p>
              </div>
            )}
          </AnimatePresence>
        </div>

        <div className="space-y-6">
          <div className="bg-indigo-600 rounded-[2.5rem] p-8 text-white">
            <h4 className="font-black text-xl mb-4 tracking-tight">Como funciona?</h4>
            <ul className="space-y-4">
              <li className="flex gap-3">
                <span className="shrink-0 w-6 h-6 bg-white/20 rounded-full flex items-center justify-center text-xs font-black">1</span>
                <p className="text-sm font-medium opacity-90">Analisamos seu faturamento e volume de pedidos.</p>
              </li>
              <li className="flex gap-3">
                <span className="shrink-0 w-6 h-6 bg-white/20 rounded-full flex items-center justify-center text-xs font-black">2</span>
                <p className="text-sm font-medium opacity-90">Identificamos quais produtos sustentam seu negócio (80/20).</p>
              </li>
              <li className="flex gap-3">
                <span className="shrink-0 w-6 h-6 bg-white/20 rounded-full flex items-center justify-center text-xs font-black">3</span>
                <p className="text-sm font-medium opacity-90">Geramos sugestões práticas baseadas em modelos de consultoria.</p>
              </li>
            </ul>
          </div>

          <div className="bg-white rounded-[2.5rem] p-8 border border-slate-100 border-dashed">
            <h4 className="font-black text-slate-800 mb-2">Meta de Redução</h4>
            <p className="text-sm text-slate-500 font-medium">Esta migração para o modelo Lite visa uma redução de até 60% no custo de processamento de tokens por requisição.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AISalesIntelligence;
