
import React, { useState, useMemo, useEffect } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  ShoppingBag, 
  Target, 
  Percent,
  Clock,
  Award,
  Users,
  CreditCard,
  PieChart,
  ArrowUpRight,
  List,
  MoreHorizontal
} from 'lucide-react';
import { Sale, Product, Customer, UserProfile, FinanceTransaction } from '../types';
import UserMenu from './UserMenu';
import { supabase } from '../supabaseClient';

const formatCurrency = (val: number) => val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

interface StatsScreenProps {
  sales: Sale[];
  products: Product[];
  customers: Customer[];
  financeTransactions: FinanceTransaction[];
  toggleSidebar: () => void;
  userProfile: UserProfile;
}

const getSafeTimestamp = (dateStr: any, origin: string = 'pos') => {
    if (!dateStr || typeof dateStr !== 'string') return 0;
    try {
        if (origin === 'pos' || dateStr.includes('T') || dateStr.includes('Z')) {
            const t = new Date(dateStr).getTime();
            return isNaN(t) ? 0 : t;
        }
        const datePart = dateStr.split(/[T ]/)[0];
        if (!datePart) return 0;
        const parts = datePart.split('-');
        if (parts.length < 3) return 0;
        const [y, m, d] = parts.map(Number);
        const t = new Date(y, m - 1, d, 12, 0, 0).getTime();
        return isNaN(t) ? 0 : t;
    } catch (e) {
        return 0;
    }
};

const StatsScreen: React.FC<StatsScreenProps> = ({ sales, products, customers, financeTransactions, toggleSidebar, userProfile }) => {
  const [period, setPeriod] = useState<'dia' | 'semana' | 'mes' | 'ano'>('mes');
  const [viewDate, setViewDate] = useState(new Date());

  // Navegação de Datas
  const handlePrevDate = () => {
    const next = new Date(viewDate);
    if (period === 'mes') next.setMonth(next.getMonth() - 1);
    else if (period === 'dia') next.setDate(next.getDate() - 1);
    else if (period === 'ano') next.setFullYear(next.getFullYear() - 1);
    setViewDate(next);
  };

  const handleNextDate = () => {
    const next = new Date(viewDate);
    if (period === 'mes') next.setMonth(next.getMonth() + 1);
    else if (period === 'dia') next.setDate(next.getDate() + 1);
    else if (period === 'ano') next.setFullYear(next.getFullYear() + 1);
    setViewDate(next);
  };

  const periodLabel = useMemo(() => {
    if (period === 'mes') return `ESTE MÊS: ${viewDate.toLocaleString('pt-BR', { month: 'long', year: 'numeric' }).toUpperCase()}`;
    if (period === 'dia') return `DIA: ${viewDate.toLocaleDateString('pt-BR')}`;
    return `ANO: ${viewDate.getFullYear()}`;
  }, [viewDate, period]);

  // Processamento de Dados
  const data = useMemo(() => {
    const start = new Date(viewDate.getFullYear(), viewDate.getMonth(), 1, 0, 0, 0).getTime();
    const end = new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 0, 23, 59, 59).getTime();

    const filteredSales = sales.filter(s => {
      const t = getSafeTimestamp(s.date);
      return s.status === 'completed' && t >= start && t <= end;
    });

    const manualRevenue = financeTransactions
      .filter(t => t.type === 'income' && t.origin !== 'pos' && getSafeTimestamp(t.date, 'finance') >= start && getSafeTimestamp(t.date, 'finance') <= end)
      .reduce((acc, t) => acc + Number(t.amount), 0);

    const revenue = filteredSales.reduce((acc, s) => acc + s.total, 0) + manualRevenue;
    const salesCount = filteredSales.length;
    const avgTicket = salesCount > 0 ? (revenue - manualRevenue) / salesCount : 0;
    
    // Lucro estimado (Receita - Custos)
    let totalCost = 0;
    filteredSales.forEach(s => {
      s.items.forEach(item => {
        const p = products.find(prod => prod.id === item.id);
        totalCost += (p?.cost || 0) * item.quantity;
      });
    });
    const profit = revenue - totalCost;

    // Performance por Hora
    const hourly = Array(24).fill(0);
    filteredSales.forEach(s => {
      const h = new Date(s.date).getHours();
      hourly[h] += s.total;
    });
    
    const maxHourVal = Math.max(...hourly, 1);
    const bestHour = hourly.indexOf(maxHourVal);
    
    // Encontrar a pior hora (menor valor maior que zero)
    let minVal = Infinity;
    let worst = -1;
    hourly.forEach((val, h) => {
        if (val > 0 && val < minVal) {
            minVal = val;
            worst = h;
        }
    });
    const worstHour = worst;

    // Ranking Produtos
    const prodMap = new Map();
    filteredSales.forEach(s => {
      s.items.forEach(i => {
        const curr = prodMap.get(i.id) || { name: i.name, image: i.image, price: i.price, qty: 0, total: 0 };
        curr.qty += i.quantity;
        curr.total += i.price * i.quantity;
        prodMap.set(i.id, curr);
      });
    });
    const topProducts = Array.from(prodMap.values()).sort((a, b) => b.total - a.total);

    // Meios Pagamento
    const payments: Record<string, number> = { pix: 0, credit: 0, debit: 0, money: 0, others: 0 };
    filteredSales.forEach(s => {
        if (s.payments && s.payments.length > 0) {
            s.payments.forEach(p => { if(payments[p.method] !== undefined) payments[p.method] += p.amount; else payments.others += p.amount; });
        } else {
            if(payments[s.paymentMethod] !== undefined) payments[s.paymentMethod] += s.total; else payments.others += s.total;
        }
    });

    // Top Clientes
    const custMap = new Map();
    filteredSales.forEach(s => {
        const curr = custMap.get(s.clientName) || { name: s.clientName, count: 0, total: 0 };
        curr.count++;
        curr.total += s.total;
        custMap.set(s.clientName, curr);
    });
    const topCustomers = Array.from(custMap.values()).sort((a, b) => b.total - a.total).slice(0, 5);

    // Ranking Vendedores
    const sellerMap = new Map();
    filteredSales.forEach(s => {
        const curr = sellerMap.get(s.sellerName) || { name: s.sellerName, count: 0, total: 0 };
        curr.count++;
        curr.total += s.total;
        sellerMap.set(s.sellerName, curr);
    });
    const topSellers = Array.from(sellerMap.values()).sort((a, b) => b.total - a.total);

    return { 
        revenue, salesCount, avgTicket, profit, 
        hourly, bestHour, worstHour, maxHourVal, topProducts, payments,
        topCustomers, topSellers 
    };
  }, [sales, financeTransactions, viewDate, products]);

  return (
    <div className="flex-1 flex flex-col h-full bg-[#f1f5f9] dark:bg-[#131422] transition-colors overflow-hidden font-sans">
      
      {/* HEADER PRINCIPAL */}
      <header className="bg-white dark:bg-[#23243a] h-[90px] px-4 lg:px-10 flex justify-between items-center shrink-0 border-b border-gray-100 dark:border-white/5 sticky top-0 z-50 transition-colors">
          <div className="flex items-center gap-4">
              <button 
                onClick={toggleSidebar} 
                className="lg:hidden p-2 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-xl transition-colors"
              >
                <List size={26} />
              </button>
              <div>
                  <h1 className="text-[23px] font-mono font-black text-gray-900 dark:text-white tracking-tighter uppercase leading-none italic">Estatísticas</h1>
                  <p className="text-[10px] text-gray-400 font-black uppercase tracking-[0.3em] mt-1 hidden sm:block">Inteligência de Dados e Performance</p>
              </div>
          </div>
          <div className="flex items-center gap-4">
              <div className="hidden sm:flex items-center gap-2 px-4 py-2 bg-white dark:bg-white/5 rounded-full border border-slate-100 dark:border-white/5 shadow-sm">
                  <Clock className="text-emerald-500" size={14} />
                  <span className="text-[9px] font-black text-slate-500 dark:text-gray-400 uppercase tracking-widest">Atualizado Agora</span>
              </div>
              <UserMenu />
          </div>
      </header>

      {/* BARRA DE NAVEGAÇÃO TEMPORAL */}
      <div className="px-6 lg:px-10 mb-8 flex flex-col sm:flex-row justify-between items-center shrink-0 gap-4">
          <div className="flex items-center gap-4 w-full sm:w-auto">
              <div className="flex flex-1 sm:flex-none bg-white dark:bg-white/5 rounded-xl border border-slate-100 dark:border-white/5 shadow-sm overflow-hidden">
                  <button onClick={handlePrevDate} className="p-3 hover:bg-slate-50 dark:hover:bg-white/5 text-slate-400 transition-colors"><ChevronLeft size={18} /></button>
                  <div className="px-4 lg:px-6 flex items-center border-x border-slate-100 dark:border-white/10 flex-1 justify-center">
                      <span className="text-[10px] lg:text-[11px] font-black text-slate-700 dark:text-gray-200 tracking-widest whitespace-nowrap">{periodLabel}</span>
                  </div>
                  <button onClick={handleNextDate} className="p-3 hover:bg-slate-50 dark:hover:bg-white/5 text-slate-400 transition-colors"><ChevronRight size={18} /></button>
              </div>
          </div>

          <div className="flex bg-[#e2e8f0] dark:bg-white/5 p-1 rounded-xl w-full sm:w-auto">
              {[
                { id: 'dia', label: 'DIA' },
                { id: 'semana', label: 'SEMANA' },
                { id: 'mes', label: 'MÊS' },
                { id: 'ano', label: 'ANO' }
              ].map(t => (
                  <button 
                    key={t.id} 
                    onClick={() => setPeriod(t.id as any)}
                    className={`flex-1 sm:flex-none px-4 lg:px-6 py-2 rounded-lg text-[9px] lg:text-[10px] font-black tracking-widest transition-all ${period === t.id ? 'bg-white dark:bg-indigo-600 text-slate-800 dark:text-white shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                  >
                      {t.label}
                  </button>
              ))}
          </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 lg:px-10 pb-20 custom-scrollbar">
          <div className="max-w-[1800px] mx-auto space-y-10">
              
              {/* LINHA SUPERIOR: KPIS LATERAIS + GRÁFICO TEMPORAL */}
              <div className="flex flex-col lg:flex-row gap-8">
                  
                  {/* KPI SIDEBAR */}
                  <div className="grid grid-cols-2 lg:grid-cols-1 lg:w-72 gap-4 shrink-0">
                      <div className="bg-white dark:bg-[#1a1b2e] p-6 rounded-[2rem] border-2 border-emerald-400/30 dark:border-emerald-500/20 shadow-xl shadow-emerald-500/5 relative overflow-hidden group">
                          <div className="flex justify-between items-start">
                              <div className="w-10 h-10 bg-emerald-400 text-white rounded-xl flex items-center justify-center shadow-lg"><DollarSign size={20} /></div>
                              <div className="flex items-center gap-1 text-[10px] font-black text-emerald-500"><TrendingUp size={12} /> 12%</div>
                          </div>
                          <div className="mt-6">
                              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Faturamento</p>
                              <p className="text-xl lg:text-2xl font-black text-slate-800 dark:text-white tracking-tighter mt-1">{formatCurrency(data.revenue)}</p>
                          </div>
                          <div className="absolute bottom-0 left-0 h-1 bg-emerald-400 w-full opacity-60"></div>
                      </div>

                      <div className="bg-white dark:bg-[#1a1b2e] p-6 rounded-[2rem] border border-slate-100 dark:border-white/5 shadow-sm">
                          <div className="flex justify-between items-start">
                              <div className="w-10 h-10 bg-slate-100 dark:bg-white/5 text-slate-400 rounded-xl flex items-center justify-center"><ShoppingBag size={20} /></div>
                              <div className="flex items-center gap-1 text-[10px] font-black text-emerald-500"><TrendingUp size={12} /> 8%</div>
                          </div>
                          <div className="mt-6">
                              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Vendas</p>
                              <p className="text-xl lg:text-2xl font-black text-slate-800 dark:text-white tracking-tighter mt-1">{data.salesCount}</p>
                          </div>
                          <div className="h-0.5 bg-slate-100 dark:bg-white/5 w-2/3 mt-4 rounded-full"></div>
                      </div>

                      <div className="bg-white dark:bg-[#1a1b2e] p-6 rounded-[2rem] border border-slate-100 dark:border-white/5 shadow-sm">
                          <div className="flex justify-between items-start">
                              <div className="w-10 h-10 bg-slate-100 dark:bg-white/5 text-slate-400 rounded-xl flex items-center justify-center"><Target size={20} /></div>
                              <div className="flex items-center gap-1 text-[10px] font-black text-rose-500"><TrendingDown size={12} /> 3%</div>
                          </div>
                          <div className="mt-6">
                              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Ticket Médio</p>
                              <p className="text-xl lg:text-2xl font-black text-slate-800 dark:text-white tracking-tighter mt-1">{formatCurrency(data.avgTicket)}</p>
                          </div>
                          <div className="h-0.5 bg-slate-100 dark:bg-white/5 w-2/3 mt-4 rounded-full"></div>
                      </div>

                      <div className="bg-white dark:bg-[#1a1b2e] p-6 rounded-[2rem] border border-slate-100 dark:border-white/5 shadow-sm">
                          <div className="flex justify-between items-start">
                              <div className="w-10 h-10 bg-slate-100 dark:bg-white/5 text-slate-400 rounded-xl flex items-center justify-center"><Percent size={20} /></div>
                              <div className="flex items-center gap-1 text-[10px] font-black text-emerald-500"><TrendingUp size={12} /> 15%</div>
                          </div>
                          <div className="mt-6">
                              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Lucro Líquido</p>
                              <p className="text-xl lg:text-2xl font-black text-slate-800 dark:text-white tracking-tighter mt-1">{formatCurrency(data.profit)}</p>
                          </div>
                          <div className="h-0.5 bg-slate-100 dark:bg-white/5 w-2/3 mt-4 rounded-full"></div>
                      </div>
                  </div>

                  {/* GRÁFICO TEMPORAL */}
                  <div className="flex-1 bg-white dark:bg-[#1a1b2e] rounded-[3rem] p-6 lg:p-10 border border-slate-100 dark:border-white/5 shadow-sm transition-all relative overflow-hidden">
                      <div className="flex justify-between items-start mb-8 lg:mb-12">
                          <div>
                              <h3 className="text-xl font-black text-slate-800 dark:text-white uppercase tracking-tighter italic">Performance Temporal</h3>
                              <p className="text-[9px] text-slate-400 font-bold uppercase mt-2 tracking-widest">Análise detalhada por hora do dia</p>
                          </div>
                      </div>

                      <div className="h-64 lg:h-80 w-full flex items-end justify-between gap-1 px-2 lg:px-4 relative">
                          {/* Linhas de Grade de Fundo */}
                          <div className="absolute inset-0 flex flex-col justify-between pointer-events-none px-4 py-0">
                              <div className="w-full border-t border-slate-100 dark:border-white/5 border-dashed"></div>
                              <div className="w-full border-t border-slate-100 dark:border-white/5 border-dashed"></div>
                              <div className="w-full border-t border-slate-100 dark:border-white/5 border-dashed"></div>
                          </div>

                          {data.hourly.map((val, h) => {
                              const isBest = h === data.bestHour && val > 0;
                              const isWorst = h === data.worstHour && val > 0;
                              const heightPct = (val / (data.maxHourVal || 1)) * 100;

                              return (
                                <div key={h} className="flex-1 flex flex-col items-center group relative h-full justify-end">
                                    {/* Tooltip no Hover */}
                                    <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] font-black px-3 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-all pointer-events-none whitespace-nowrap z-20 shadow-xl border border-white/10 scale-90 group-hover:scale-100 mb-2">
                                        {h}h: {formatCurrency(val)}
                                    </div>

                                    {/* Slot da Barra (Background Fino) */}
                                    <div className="w-[2px] lg:w-[3px] h-full bg-slate-50 dark:bg-white/5 rounded-full absolute bottom-0"></div>

                                    {/* Barra Ativa */}
                                    <div 
                                        className={`w-[3px] lg:w-[4px] rounded-t-full transition-all duration-1000 ease-out relative z-10 
                                            ${isBest ? 'bg-emerald-400 shadow-[0_-8px_20px_rgba(52,211,153,0.4)]' : 
                                              isWorst ? 'bg-rose-500 shadow-[0_-8px_20px_rgba(244,63,94,0.3)]' : 
                                              'bg-slate-200 dark:bg-white/20'}`}
                                        style={{ height: `${Math.max(heightPct, 2)}%` }}
                                    >
                                    </div>

                                    {/* Label da Hora */}
                                    <span className={`text-[7px] lg:text-[8px] font-black mt-4 uppercase transition-colors ${val > 0 ? 'text-slate-600 dark:text-slate-300' : 'text-slate-300 dark:text-slate-700'}`}>
                                        {h}h
                                    </span>
                                </div>
                              );
                          })}
                      </div>

                      <div className="mt-12 flex flex-wrap gap-4 lg:gap-8">
                          <div className="flex items-center gap-3">
                              <div className="w-3 h-3 rounded-full bg-emerald-400"></div>
                              <span className="text-[10px] font-black text-slate-500 dark:text-gray-400 uppercase tracking-widest">Melhor Hora</span>
                          </div>
                          <div className="flex items-center gap-3">
                              <div className="w-3 h-3 rounded-full bg-rose-500"></div>
                              <span className="text-[10px] font-black text-slate-500 dark:text-gray-400 uppercase tracking-widest">Pior Hora</span>
                          </div>
                      </div>
                  </div>
              </div>

              {/* RANKING DE PRODUTOS */}
              <div className="bg-white dark:bg-[#1a1b2e] rounded-[3rem] shadow-sm border border-slate-100 dark:border-white/5 overflow-hidden transition-all">
                  <div className="px-6 lg:px-10 py-8 border-b dark:border-white/5 flex flex-col sm:flex-row justify-between items-center bg-gray-50/30 dark:bg-white/5 gap-4">
                      <div className="flex items-center gap-5">
                          <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 rounded-2xl flex items-center justify-center shadow-sm"><Award size={24} /></div>
                          <div>
                            <h3 className="text-xl font-black text-slate-800 dark:text-white uppercase tracking-tighter italic">Ranking de Produtos</h3>
                            <p className="text-[9px] text-slate-400 font-bold uppercase mt-1 tracking-widest">Os itens mais vendidos no período</p>
                          </div>
                      </div>
                      <div className="bg-indigo-600 text-white px-6 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest shadow-xl shadow-indigo-200 dark:shadow-none">
                          {data.topProducts.reduce((a,b)=>a+b.qty,0)} Itens Vendidos
                      </div>
                  </div>
                  <div className="overflow-x-auto">
                      <table className="w-full text-left border-separate border-spacing-0">
                          <thead>
                              <tr className="bg-slate-50/50 dark:bg-white/5 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                  <th className="px-6 lg:px-10 py-6">POS.</th>
                                  <th className="px-6 lg:px-10 py-6">Produto</th>
                                  <th className="px-6 lg:px-10 py-6 text-right">Valor Unit.</th>
                                  <th className="px-6 lg:px-10 py-6 text-center">Qtd. Vendida</th>
                                  <th className="px-6 lg:px-10 py-6 text-right">Total Faturado</th>
                              </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-50 dark:divide-white/5">
                              {data.topProducts.slice(0, 10).map((p, idx) => (
                                  <tr key={idx} className="hover:bg-gray-50/50 dark:hover:bg-white/5 transition-colors group">
                                      <td className="px-6 lg:px-10 py-5">
                                          <div className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-[10px] shadow-sm ${idx === 0 ? 'bg-amber-100 text-amber-600 border border-amber-200' : idx === 1 ? 'bg-slate-100 text-slate-500 border border-slate-200' : idx === 2 ? 'bg-orange-50 text-orange-600 border border-orange-200' : 'text-slate-300'}`}>
                                              {idx + 1}º
                                          </div>
                                      </td>
                                      <td className="px-6 lg:px-10 py-5">
                                          <div className="flex items-center gap-4">
                                              <div className="w-12 h-12 bg-gray-50 dark:bg-white/5 rounded-xl flex items-center justify-center p-2 border dark:border-white/10 group-hover:scale-105 transition-transform">
                                                  <img src={p.image || 'https://cdn-icons-png.flaticon.com/512/1256/1256650.png'} className="max-w-full max-h-full object-contain" />
                                              </div>
                                              <span className="text-sm font-black text-slate-700 dark:text-white uppercase truncate max-w-[150px] lg:max-w-[250px] tracking-tight">{p.name}</span>
                                          </div>
                                      </td>
                                      <td className="px-6 lg:px-10 py-5 text-right font-bold text-slate-400 whitespace-nowrap">{formatCurrency(p.price)}</td>
                                      <td className="px-6 lg:px-10 py-5 text-center">
                                          <span className="bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 px-3 py-1.5 rounded-lg text-xs font-black tabular-nums border border-emerald-100 dark:border-emerald-500/20">{p.qty}</span>
                                      </td>
                                      <td className="px-6 lg:px-10 py-5 text-right font-black text-slate-800 dark:text-white tabular-nums tracking-tighter whitespace-nowrap">{formatCurrency(p.total)}</td>
                                  </tr>
                              ))}
                          </tbody>
                      </table>
                  </div>
              </div>

              {/* GRID DE TRÊS COLUNAS: PAGAMENTOS, DESTAQUES, TOP CLIENTES */}
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
                  
                  {/* MEIOS DE PAGAMENTO */}
                  <div className="bg-white dark:bg-[#1a1b2e] rounded-[3rem] p-6 lg:p-10 border border-slate-100 dark:border-white/5 shadow-sm transition-all">
                      <div className="flex justify-between items-center mb-10">
                          <h3 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-widest italic">Meios de Pagamento</h3>
                          <PieChart size={18} className="text-slate-300" />
                      </div>
                      <div className="space-y-6">
                          {[
                              { label: 'PIX', key: 'pix' },
                              { label: 'CRÉDITO', key: 'credit' },
                              { label: 'DÉBITO', key: 'debit' },
                              { label: 'DINHEIRO', key: 'money' },
                              { label: 'OUTROS', key: 'others' }
                          ].map(m => {
                              const total = data.revenue || 1;
                              const val = data.payments[m.key] || 0;
                              const pct = (val / total) * 100;
                              return (
                                  <div key={m.key} className="space-y-2">
                                      <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
                                          <span className="text-slate-400">{m.label}</span>
                                          <span className="text-slate-800 dark:text-white">{pct.toFixed(1)}%</span>
                                      </div>
                                      <div className="h-1.5 w-full bg-slate-50 dark:bg-white/5 rounded-full overflow-hidden">
                                          <div className={`h-full ${pct > 50 ? 'bg-indigo-600' : pct > 20 ? 'bg-indigo-400' : 'bg-slate-400'} transition-all duration-1000`} style={{ width: `${pct}%` }}></div>
                                      </div>
                                  </div>
                              );
                          })}
                      </div>
                  </div>

                  {/* DESTAQUES POR VENDAS */}
                  <div className="bg-white dark:bg-[#1a1b2e] rounded-[3rem] p-6 lg:p-10 border border-slate-100 dark:border-white/5 shadow-sm transition-all">
                      <div className="flex justify-between items-center mb-10">
                          <h3 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-widest italic">Destaques por Vendas</h3>
                          <Award size={18} className="text-amber-400" />
                      </div>
                      <div className="space-y-6">
                          {data.topProducts.slice(0, 5).map((p, idx) => (
                              <div key={idx} className="flex items-center gap-4">
                                  <div className="w-7 h-7 bg-slate-900 text-white rounded-full flex items-center justify-center text-[9px] font-black shrink-0">{idx + 1}</div>
                                  <div className="flex items-center gap-3 min-w-0 flex-1">
                                      <img src={p.image || 'https://cdn-icons-png.flaticon.com/512/1256/1256650.png'} className="w-10 h-10 rounded-lg p-1 bg-gray-50 dark:bg-white/5 shrink-0" />
                                      <div className="min-w-0 flex-1">
                                          <p className="text-[11px] font-black text-slate-800 dark:text-white uppercase truncate tracking-tighter">{p.name}</p>
                                          <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{p.qty} UNIDADES</p>
                                      </div>
                                  </div>
                                  <span className="text-[11px] font-black text-slate-700 dark:text-gray-200 tabular-nums whitespace-nowrap">{formatCurrency(p.total)}</span>
                              </div>
                          ))}
                      </div>
                  </div>

                  {/* TOP CLIENTES */}
                  <div className="bg-white dark:bg-[#1a1b2e] rounded-[3rem] p-6 lg:p-10 border border-slate-100 dark:border-white/5 shadow-sm transition-all md:col-span-2 xl:col-span-1">
                      <div className="flex justify-between items-center mb-10">
                          <h3 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-widest italic">Top Clientes</h3>
                          <Users size={18} className="text-indigo-400" />
                      </div>
                      <div className="space-y-6">
                          {data.topCustomers.map((c, idx) => (
                              <div key={idx} className="flex items-center justify-between">
                                  <div className="flex items-center gap-4">
                                      <div className="w-10 h-10 rounded-full bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-black text-[10px] uppercase shadow-inner border border-indigo-100/50">{c.name.substring(0, 2)}</div>
                                      <div className="min-w-0">
                                          <p className="text-[11px] font-black text-slate-800 dark:text-white uppercase truncate max-w-[120px] tracking-tighter">{c.name}</p>
                                          <div className="flex items-center gap-3">
                                              <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{c.count} PEDIDOS</p>
                                              <span className="text-[7px] font-black text-emerald-500 bg-emerald-50 dark:bg-emerald-500/10 px-1.5 py-0.5 rounded tracking-tighter uppercase">LTV ALTO</span>
                                          </div>
                                      </div>
                                  </div>
                                  <span className="text-[11px] font-black text-slate-800 dark:text-gray-200 tabular-nums whitespace-nowrap">{formatCurrency(c.total)}</span>
                              </div>
                          ))}
                      </div>
                  </div>
              </div>

              {/* VENDAS POR USUÁRIO (RANKING FINAL) */}
              <div className="bg-white dark:bg-[#1a1b2e] rounded-[3rem] shadow-sm border border-slate-100 dark:border-white/5 overflow-hidden transition-all">
                  <div className="px-6 lg:px-10 py-10 border-b dark:border-white/5 flex flex-col sm:flex-row justify-between items-center gap-4">
                      <div>
                        <h3 className="text-xl font-black text-slate-800 dark:text-white uppercase tracking-tighter italic">Vendas por Usuário</h3>
                        <p className="text-[9px] text-slate-400 font-bold uppercase mt-1 tracking-widest">Ranking de produtividade da equipe</p>
                      </div>
                      <button className="text-indigo-600 font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:underline">Relatório Completo <ArrowUpRight size={14} /></button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-separate border-spacing-0">
                        <thead>
                            <tr className="bg-slate-50/50 dark:bg-white/5 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                <th className="px-2 sm:px-4 lg:px-10 py-4 sm:py-6">Vendedor</th>
                                <th className="px-2 sm:px-4 lg:px-10 py-4 sm:py-6 text-center">Nº de Vendas</th>
                                <th className="px-2 sm:px-4 lg:px-10 py-4 sm:py-6 text-center">Faturamento</th>
                                <th className="px-6 lg:px-10 py-6 text-center hidden sm:table-cell">Ticket Médio</th>
                                <th className="px-6 lg:px-10 py-6 text-right hidden sm:table-cell">Ação</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50 dark:divide-white/5">
                            {data.topSellers.map((s, idx) => (
                                <tr key={idx} className="hover:bg-gray-50/50 dark:hover:bg-white/5 transition-colors group">
                                    <td className="px-2 sm:px-4 lg:px-10 py-4 sm:py-6">
                                        <div className="flex items-center gap-2 sm:gap-3 lg:gap-4">
                                            <div className="w-7 h-7 sm:w-8 sm:h-8 lg:w-10 lg:h-10 bg-gray-100 dark:bg-white/5 rounded-xl flex items-center justify-center text-slate-400 font-black text-[8px] sm:text-[9px] lg:text-[10px] uppercase shrink-0">{s.name.substring(0, 2)}</div>
                                            <span className="text-[10px] sm:text-xs lg:text-sm font-black text-slate-800 dark:text-white uppercase tracking-tight truncate max-w-[60px] sm:max-w-none">{s.name}</span>
                                        </div>
                                    </td>
                                    <td className="px-2 sm:px-4 lg:px-10 py-4 sm:py-6 text-center font-bold text-slate-500 text-[10px] sm:text-xs lg:text-sm">{s.count}</td>
                                    <td className="px-2 sm:px-4 lg:px-10 py-4 sm:py-6 text-center font-black text-slate-800 dark:text-white tabular-nums tracking-tighter whitespace-nowrap text-[10px] sm:text-xs lg:text-sm">{formatCurrency(s.total)}</td>
                                    <td className="px-6 lg:px-10 py-6 text-center font-bold text-slate-400 tabular-nums whitespace-nowrap hidden sm:table-cell">{formatCurrency(s.total / (s.count || 1))}</td>
                                    <td className="px-6 lg:px-10 py-6 text-right hidden sm:table-cell">
                                        <button className="text-slate-300 hover:text-indigo-600 transition-colors"><ChevronRight size={20} /></button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                  </div>
              </div>

          </div>
      </div>
    </div>
  );
};

export default StatsScreen;
