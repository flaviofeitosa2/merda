// This file was created by mistake and should be ignored.
export default function Placeholder() { return null; }