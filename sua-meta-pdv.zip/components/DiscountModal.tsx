
import React, { useState, useEffect } from 'react';
// Added 'Check' to the lucide-react imports
import { X, Tag, Percent, DollarSign, Check } from 'lucide-react';

interface DiscountModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApply: (discountValue: number) => void;
  subtotal: number;
  initialDiscount?: number;
}

const DiscountModal: React.FC<DiscountModalProps> = ({ 
  isOpen, 
  onClose, 
  onApply, 
  subtotal,
  initialDiscount = 0
}) => {
  const [discountValue, setDiscountValue] = useState<string>('');
  const [discountPercent, setDiscountPercent] = useState<string>('');

  // Initialize values when modal opens
  useEffect(() => {
    if (isOpen) {
      if (initialDiscount > 0) {
        setDiscountValue(initialDiscount.toFixed(2));
        const percent = (initialDiscount / subtotal) * 100;
        setDiscountPercent(percent.toFixed(2));
      } else {
        setDiscountValue('');
        setDiscountPercent('');
      }
    }
  }, [isOpen, initialDiscount, subtotal]);

  const parseAmount = (val: string | number | null | undefined) => {
      if (!val) return 0;
      let raw = val.toString().replace(/[^\d.,]/g, '');
      const lastComma = raw.lastIndexOf(',');
      const lastDot = raw.lastIndexOf('.');
      if (lastComma > lastDot) {
          raw = raw.replace(/\./g, '').replace(',', '.');
      } else if (lastDot > lastComma) {
          if (lastComma === -1 && raw.length - lastDot === 4) {
              raw = raw.replace(/\./g, '');
          } else {
              raw = raw.replace(/,/g, '');
          }
      }
      return parseFloat(raw) || 0;
  };

  const handleValueChange = (val: string) => {
    setDiscountValue(val);
    const numVal = parseAmount(val);
    if (subtotal > 0) {
      const percent = (numVal / subtotal) * 100;
      setDiscountPercent(numVal === 0 ? '' : percent.toFixed(2));
    }
  };

  const handlePercentChange = (val: string) => {
    setDiscountPercent(val);
    const numPercent = parseAmount(val);
    const value = subtotal * (numPercent / 100);
    setDiscountValue(numPercent === 0 ? '' : value.toFixed(2));
  };

  const handleApply = () => {
    const finalDiscount = parseAmount(discountValue);
    if (finalDiscount > subtotal) {
        alert("O desconto não pode ser maior que o subtotal.");
        return;
    }
    onApply(finalDiscount);
    onClose();
  };

  if (!isOpen) return null;

  const currentDiscount = parseAmount(discountValue);
  const finalTotal = Math.max(0, subtotal - currentDiscount);

  return (
    <>
      <div 
        className="fixed inset-0 bg-black/60 z-[150] transition-opacity backdrop-blur-sm"
        onClick={onClose}
      />
      <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white dark:bg-[#23243a] rounded-[2.5rem] shadow-2xl z-[160] w-full max-w-sm p-8 animate-in fade-in zoom-in-95 duration-200 border border-transparent dark:border-white/5 transition-colors">
        
        <div className="flex justify-between items-start mb-8">
            <div>
                <h3 className="text-xl font-black text-gray-800 dark:text-white uppercase tracking-tighter flex items-center gap-2">
                    <Tag className="text-rose-500" /> Desconto
                </h3>
                <p className="text-[10px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-widest mt-1">Subtotal: {subtotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
            </div>
            <button onClick={onClose} className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-white/5 rounded-full transition-all">
                <X size={20} />
            </button>
        </div>

        <div className="space-y-6 mb-10">
            <div className="relative group">
                <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-2 text-[10px] font-black text-gray-400 uppercase tracking-widest transition-all">Desconto em Reais (R$)</label>
                <div className="flex items-center gap-3 border-2 border-gray-100 dark:border-white/10 rounded-2xl p-4 focus-within:border-rose-400 transition-all bg-white dark:bg-[#1a1b2e]">
                    <span className="text-gray-300 dark:text-gray-600 font-bold">R$</span>
                    <input 
                        type="number"
                        step="0.01"
                        className="w-full bg-transparent outline-none text-lg font-black text-gray-800 dark:text-white placeholder-gray-300 dark:placeholder-gray-700"
                        placeholder="0,00"
                        value={discountValue}
                        onChange={(e) => handleValueChange(e.target.value)}
                    />
                </div>
            </div>

            <div className="flex items-center gap-4">
                <div className="h-px bg-gray-100 dark:bg-white/5 flex-1"></div>
                <span className="text-[10px] font-black text-gray-300 uppercase tracking-widest">OU</span>
                <div className="h-px bg-gray-100 dark:bg-white/5 flex-1"></div>
            </div>

            <div className="relative group">
                <label className="absolute -top-2.5 left-4 bg-white dark:bg-[#23243a] px-2 text-[10px] font-black text-gray-400 uppercase tracking-widest transition-all">Desconto em Porcentagem (%)</label>
                <div className="flex items-center gap-3 border-2 border-gray-100 dark:border-white/10 rounded-2xl p-4 focus-within:border-rose-400 transition-all bg-white dark:bg-[#1a1b2e]">
                    <span className="text-gray-300 dark:text-gray-600 font-bold">%</span>
                    <input 
                        type="number"
                        step="0.01"
                        className="w-full bg-transparent outline-none text-lg font-black text-gray-800 dark:text-white placeholder-gray-300 dark:placeholder-gray-700"
                        placeholder="0"
                        value={discountPercent}
                        onChange={(e) => handlePercentChange(e.target.value)}
                    />
                </div>
            </div>
        </div>

        <div className="bg-gray-50 dark:bg-white/5 p-6 rounded-3xl mb-8 border border-gray-100 dark:border-white/5">
            <div className="flex justify-between items-end">
                <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Total com Desconto</span>
                <span className="text-2xl font-black text-emerald-500 dark:text-emerald-400 tracking-tighter">
                    {finalTotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                </span>
            </div>
        </div>

        <div className="flex gap-3">
            <button 
                onClick={onClose}
                className="flex-1 py-4 bg-white dark:bg-white/5 border border-gray-200 dark:border-white/10 text-gray-400 font-black text-[11px] uppercase rounded-2xl hover:bg-gray-50 transition-all"
            >
                Cancelar
            </button>
            <button 
                onClick={handleApply}
                className="flex-[2] py-4 bg-rose-500 hover:bg-rose-600 text-white font-black text-[11px] uppercase rounded-2xl shadow-xl shadow-rose-100 dark:shadow-none transition-all active:scale-95 flex items-center justify-center gap-2"
            >
                {/* Now using the imported Check icon */}
                <Check size={18} strokeWidth={4} /> Aplicar agora
            </button>
        </div>

      </div>
    </>
  );
};

export default DiscountModal;
